import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ISN"
sp=importlib.util.spec_from_file_location("skl_isn",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_isn"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def link(self):return q.InterstellarOpticalLink(4.24,1e-6,1e9,100,30,0,.8,.8,.8,1e-18,10)
 def test_percentile(self):self.assertEqual(q.percentile([1,2,3,4,5],.5),3)
 def test_sensitivity_power(self):
  base=self.link()
  fn=lambda p:q.InterstellarOpticalLink(base.distance_ly,base.wavelength_m,p,base.transmitter_diameter_m,base.receiver_diameter_m).ideal_bit_rate_bps
  self.assertAlmostEqual(q.normalized_local_sensitivity(fn,1e9),1,places=5)
 def test_mc_seed(self):
  a=q.monte_carlo_optical_rate(self.link(),200,42,.05,1e-10);b=q.monte_carlo_optical_rate(self.link(),200,42,.05,1e-10);self.assertEqual(a,b)
 def test_mc_order(self):
  a=q.monte_carlo_optical_rate(self.link(),200,2);self.assertLessEqual(a.p05_rate_bps,a.p50_rate_bps);self.assertLessEqual(a.p50_rate_bps,a.p95_rate_bps)
 def test_gate_causality(self):self.assertTrue(next(x for x in q.interstellar_failure_gates() if x.gate_id=="ISN-GATE-CAUSALITY").passed)
 def test_gate_rate(self):self.assertTrue(any(x.gate_id=="ISN-GATE-RATE" for x in q.interstellar_failure_gates(self.link(),min_rate_bps=0)))
 def test_sgl_gate_fail(self):
  g=q.interstellar_failure_gates(require_sgl=True,sgl_terminal=q.SolarGravitationalLensTerminal(500,1e-6,1000))
  self.assertFalse(next(x for x in g if x.gate_id=="ISN-GATE-SGL-FOCAL").passed)
 def test_sgl_gate_pass(self):
  g=q.interstellar_failure_gates(require_sgl=True,sgl_terminal=q.SolarGravitationalLensTerminal(650,1e-6,1000))
  self.assertTrue(next(x for x in g if x.gate_id=="ISN-GATE-SGL-FOCAL").passed)
 def test_critical(self):self.assertTrue(q.all_critical_gates_pass(q.interstellar_failure_gates()))
 def test_cross_engine(self):
  c=q.run_cross_engine_validation(R);self.assertEqual(len(c),11);self.assertTrue(all(c.values()))
 def test_integrated_sim_preserved(self):
  n=q.GalacticNetwork(["A","B"]);n.add_edge(q.GalacticEdge("A","B",4,10,.9));self.assertTrue(q.simulate_route(n,"A","B").route_found)
 def test_galactic_preserved(self):self.assertEqual(q.average_node_degree(10,20),4)
 def test_pulsar_preserved(self):self.assertEqual(q.minimum_pulsars_for_3d_position_and_clock(),4)
 def test_sgl_preserved(self):self.assertTrue(540<q.minimum_solar_focal_distance_au()<560)
 def test_relay_preserved(self):self.assertEqual(q.hop_delivery_capacity_bps([100,20]),20)
 def test_causality_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ISN-VAL-MC","ISN-VAL-SENS","ISN-VAL-GATES"}<={x.model_id for x in q.InterstellarNetworkRegistry().all()})
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-ISN-08");self.assertEqual(x["status"],"COMPLETE — ISN 8/8")
 def test_complete_marker(self):
  x=json.loads((R/"ISN_COMPLETE.json").read_text());self.assertEqual(x["status"],"COMPLETE");self.assertEqual(x["sequence"]["complete"],8)
 def test_prior_completion_markers(self):
  for f in ("PHO_COMPLETE.json","STO_COMPLETE.json","QMEM_COMPLETE.json","HQIC_COMPLETE.json","RF_COMPLETE.json","OPT_COMPLETE.json","QCOM_COMPLETE.json"):self.assertTrue((R/f).exists(),f)
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
