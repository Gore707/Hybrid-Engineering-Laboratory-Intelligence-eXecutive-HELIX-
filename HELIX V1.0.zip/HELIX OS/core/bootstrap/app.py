from __future__ import annotations
import sys
from pathlib import Path

from .config import ConfigError, load_config
from .crash import install_crash_handler
from .identity import IDENTITY
from .logging_setup import configure_logging
from .preflight import run_preflight

def _root() -> Path:
    return Path(__file__).resolve().parents[2]

def _bootstrap():
    root = _root()
    cfg = load_config(root / "skl.config")
    log_cfg = cfg["logging"]
    logger = configure_logging(
        root / "data" / "logs",
        log_cfg["level"],
        int(log_cfg["max_bytes"]),
        int(log_cfg["backup_count"]),
    )
    install_crash_handler(root / "data" / "crash", logger)
    checks = run_preflight(root, cfg)
    failed = [c for c in checks if not c.passed]
    return root, cfg, logger, checks, failed

def main() -> int:
    try:
        root, cfg, logger, checks, failed = _bootstrap()
    except ConfigError as exc:
        print(f"HELIX BOOT FAILURE: {exc}", file=sys.stderr)
        return 2

    logger.info("%s starting | %s | Core %s",
                IDENTITY.product, IDENTITY.patch_id, IDENTITY.core_version)

    if failed:
        for c in failed:
            logger.error("Preflight FAIL: %s — %s", c.name, c.detail)
        print("HELIX BOOT BLOCKED: startup preflight failed.", file=sys.stderr)
        return 3

    try:
        from PySide6.QtWidgets import QApplication
        from core.ui.main_window import HelixMainWindow
        from core.ui.theme import HELIX_DARK
    except (ImportError, RuntimeError) as exc:
        logger.error("GUI dependency unavailable: %s", exc)
        print("HELIX C02 bootstrap is valid, but PySide6 is not installed.")
        print("Install it with: py -3 -m pip install PySide6")
        return 4

    app = QApplication(sys.argv)
    app.setApplicationName("HELIX")
    app.setOrganizationName("Sierra Kilo Labs")
    app.setApplicationDisplayName("HELIX — THE ARCHIMEDES PROJECT")
    app.setStyleSheet(HELIX_DARK)

    window = HelixMainWindow(cfg, root)
    window.show()
    logger.info("C02 UI shell displayed successfully.")
    return app.exec()
