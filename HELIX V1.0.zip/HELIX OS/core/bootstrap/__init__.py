"""HELIX bootstrap subsystem — SKL-CORE-C01."""
