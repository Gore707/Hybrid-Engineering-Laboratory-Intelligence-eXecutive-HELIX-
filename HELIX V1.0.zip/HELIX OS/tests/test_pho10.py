import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-PHO"
sp=importlib.util.spec_from_file_location("skl_pho",M/"__init__.py",submodule_search_locations=[str(M)]);p=importlib.util.module_from_spec(sp);sys.modules["skl_pho"]=p;sp.loader.exec_module(p)
class T(unittest.TestCase):
 def test_self_validation(self):
  r=p.run_photonics_self_validation();self.assertTrue(r.passed);self.assertEqual(r.passed_count,7);self.assertEqual(r.total_count,7)
 def test_fresnel(self):
  x=p.dielectric_interface(1,1.5,0,"s");self.assertAlmostEqual(x.reflectance+x.transmittance,1)
 def test_abcd(self):
  A=p.free_space(2);self.assertAlmostEqual(A.determinant,1)
 def test_gaussian(self):
  b=p.GaussianBeam(1e-6,1e-3);self.assertAlmostEqual(b.radius_m(b.rayleigh_range_m),b.waist_m*math.sqrt(2))
 def test_wave_interference(self):self.assertAlmostEqual(p.two_beam_intensity(1,1,math.pi),0)
 def test_polarization(self):self.assertAlmostEqual(p.malus_law(1,math.pi/2),0,places=12)
 def test_material_optics(self):self.assertAlmostEqual(p.beer_lambert_transmission(0,100),1)
 def test_laser_detector_chain(self):
  L=p.LaserSource(1e-6,1);d=p.Photodiode(.5);self.assertEqual(d.signal_current(L.output_power_w),.5)
 def test_registry_core_models(self):
  r=p.PhotonicsRegistry()
  for k in ("PHO-SNELL","PHO-ABCD-LENS","PHO-INTERFERENCE-2","PHO-GAUSS-Q","PHO-MALUS","PHO-SELLMEIER","PHO-LASER-FSR","PHO-DETECT-SHOT"):self.assertEqual(r.get(k).evidence_class,"ESTABLISHED_PHYSICS")
 def test_manifest_complete(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-PHO-10");self.assertIn("COMPLETE",x["status"])
 def test_core_manifest_root(self):
  self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
