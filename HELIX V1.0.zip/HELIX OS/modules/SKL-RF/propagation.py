from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .foundation import C,wavelength_m,free_space_path_loss_db

class PropagationEnvironment(str,Enum):
    VACUUM="VACUUM"
    TERRESTRIAL_ATMOSPHERE="TERRESTRIAL_ATMOSPHERE"
    PLANETARY_ATMOSPHERE="PLANETARY_ATMOSPHERE"
    DEEP_SPACE="DEEP_SPACE"

def propagation_delay_s(distance_m):
    if distance_m<0: raise ValueError("distance must be nonnegative")
    return distance_m/C

def one_way_doppler_shift_hz(carrier_frequency_hz,radial_velocity_m_s):
    if carrier_frequency_hz<=0 or abs(radial_velocity_m_s)>=C: raise ValueError("invalid carrier/velocity")
    # First-order nonrelativistic convention: positive velocity = closing.
    return carrier_frequency_hz*radial_velocity_m_s/C

def relativistic_received_frequency_hz(carrier_frequency_hz,radial_velocity_m_s):
    if carrier_frequency_hz<=0 or abs(radial_velocity_m_s)>=C: raise ValueError("invalid carrier/velocity")
    beta=radial_velocity_m_s/C
    # positive beta = closing
    return carrier_frequency_hz*math.sqrt((1+beta)/(1-beta))

def fresnel_zone_radius_m(order,d1_m,d2_m,frequency_hz):
    if order<1 or int(order)!=order or d1_m<=0 or d2_m<=0 or frequency_hz<=0: raise ValueError("invalid Fresnel inputs")
    lam=wavelength_m(frequency_hz)
    return math.sqrt(order*lam*d1_m*d2_m/(d1_m+d2_m))

def fresnel_clearance_fraction(clearance_m,order,d1_m,d2_m,frequency_hz):
    if clearance_m<0: raise ValueError("clearance must be nonnegative")
    return clearance_m/fresnel_zone_radius_m(order,d1_m,d2_m,frequency_hz)

def attenuation_linear_from_db(loss_db):
    if loss_db<0: raise ValueError("loss dB must be nonnegative")
    return 10**(-loss_db/10)

def specific_attenuation_loss_db(specific_db_per_km,path_length_km):
    if specific_db_per_km<0 or path_length_km<0: raise ValueError("attenuation/path must be nonnegative")
    return specific_db_per_km*path_length_km

def two_ray_delay_spread_s(path_length_a_m,path_length_b_m):
    if path_length_a_m<0 or path_length_b_m<0: raise ValueError("path lengths must be nonnegative")
    return abs(path_length_a_m-path_length_b_m)/C

def coherence_bandwidth_hz(rms_delay_spread_s,factor=5.0):
    if rms_delay_spread_s<=0 or factor<=0: raise ValueError("positive delay spread/factor required")
    return 1/(factor*rms_delay_spread_s)

def rayleigh_outage_probability(power_threshold_over_mean):
    if power_threshold_over_mean<0: raise ValueError("ratio must be nonnegative")
    return 1-math.exp(-power_threshold_over_mean)

@dataclass(frozen=True)
class PropagationLossBudget:
    distance_m:float
    frequency_hz:float
    atmospheric_loss_db:float=0.0
    rain_loss_db:float=0.0
    polarization_loss_db:float=0.0
    pointing_loss_db:float=0.0
    implementation_loss_db:float=0.0
    environment:PropagationEnvironment=PropagationEnvironment.VACUUM
    def __post_init__(self):
        if self.distance_m<=0 or self.frequency_hz<=0: raise ValueError("positive distance/frequency required")
        if min(self.atmospheric_loss_db,self.rain_loss_db,self.polarization_loss_db,self.pointing_loss_db,self.implementation_loss_db)<0:
            raise ValueError("loss terms must be nonnegative")
    @property
    def fspl_db(self): return free_space_path_loss_db(self.distance_m,self.frequency_hz)
    @property
    def excess_loss_db(self): return self.atmospheric_loss_db+self.rain_loss_db+self.polarization_loss_db+self.pointing_loss_db+self.implementation_loss_db
    @property
    def total_loss_db(self): return self.fspl_db+self.excess_loss_db
    @property
    def one_way_delay_s(self): return propagation_delay_s(self.distance_m)
    def report(self):
        return {"environment":self.environment.value,"distance_m":self.distance_m,"frequency_hz":self.frequency_hz,
                "fspl_db":self.fspl_db,"excess_loss_db":self.excess_loss_db,"total_loss_db":self.total_loss_db,
                "one_way_delay_s":self.one_way_delay_s}
