from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np

def entanglement_fidelity_from_kraus(rho,kraus_operators):
    r=np.asarray(rho,dtype=complex)
    if r.ndim!=2 or r.shape[0]!=r.shape[1]: raise ValueError("rho must be square")
    if not np.allclose(r,r.conj().T,atol=1e-10) or not np.isclose(np.trace(r),1,atol=1e-10):
        raise ValueError("rho must be a normalized Hermitian density matrix")
    vals=np.linalg.eigvalsh(r)
    if np.min(vals)<-1e-10: raise ValueError("rho must be positive semidefinite")
    total=0.0
    for k in kraus_operators:
        K=np.asarray(k,dtype=complex)
        if K.shape!=r.shape: raise ValueError("Kraus dimension mismatch")
        total+=abs(np.trace(r@K))**2
    return float(np.real(total))

def average_gate_fidelity_from_entanglement_fidelity(entanglement_fidelity,dimension):
    if not 0<=entanglement_fidelity<=1 or dimension<2: raise ValueError("invalid fidelity/dimension")
    return (dimension*entanglement_fidelity+1)/(dimension+1)

def majority_vote_logical_error_probability(bit_error_probability,code_distance):
    if not 0<=bit_error_probability<=1 or code_distance<1 or code_distance%2==0:
        raise ValueError("p must be 0..1 and repetition-code distance must be odd")
    threshold=(code_distance+1)//2
    return sum(math.comb(code_distance,k)*(bit_error_probability**k)*((1-bit_error_probability)**(code_distance-k))
               for k in range(threshold,code_distance+1))

def repetition_syndrome(bits):
    b=tuple(int(x) for x in bits)
    if len(b)<3 or len(b)%2==0 or any(x not in (0,1) for x in b): raise ValueError("odd binary repetition block required")
    return tuple(b[i]^b[i+1] for i in range(len(b)-1))

def repetition_decode(bits):
    b=tuple(int(x) for x in bits)
    if len(b)<3 or len(b)%2==0 or any(x not in (0,1) for x in b): raise ValueError("odd binary repetition block required")
    return 1 if sum(b)>len(b)//2 else 0

def qec_overhead_ratio(physical_qubits,logical_qubits):
    if physical_qubits<1 or logical_qubits<1 or physical_qubits<logical_qubits:
        raise ValueError("invalid qubit counts")
    return physical_qubits/logical_qubits

def break_even_improvement(physical_error_probability,logical_error_probability):
    if not 0<=physical_error_probability<=1 or not 0<=logical_error_probability<=1:
        raise ValueError("probabilities must be 0..1")
    if logical_error_probability==0:return math.inf if physical_error_probability>0 else 1.0
    return physical_error_probability/logical_error_probability

@dataclass(frozen=True)
class QECMemoryAssessment:
    physical_error_probability:float
    code_distance:int
    physical_qubits:int
    logical_qubits:int=1
    def __post_init__(self):
        if not 0<=self.physical_error_probability<=1 or self.code_distance<1 or self.code_distance%2==0:
            raise ValueError("invalid error probability/code distance")
        if self.physical_qubits<1 or self.logical_qubits<1 or self.physical_qubits<self.logical_qubits:
            raise ValueError("invalid qubit counts")
    @property
    def logical_error_probability(self):
        return majority_vote_logical_error_probability(self.physical_error_probability,self.code_distance)
    @property
    def overhead(self): return qec_overhead_ratio(self.physical_qubits,self.logical_qubits)
    @property
    def improvement_factor(self): return break_even_improvement(self.physical_error_probability,self.logical_error_probability)
    @property
    def improves_error_rate(self): return self.logical_error_probability < self.physical_error_probability
