from __future__ import annotations
import json
import platform
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Type

def install_crash_handler(crash_dir: Path, logger) -> None:
    crash_dir.mkdir(parents=True, exist_ok=True)

    def handle(exc_type: Type[BaseException], exc: BaseException, tb) -> None:
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc, tb)
            return

        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        report_path = crash_dir / f"helix-crash-{stamp}.json"
        report = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "exception_type": exc_type.__name__,
            "message": str(exc),
            "traceback": "".join(traceback.format_exception(exc_type, exc, tb)),
            "python": sys.version,
            "platform": platform.platform(),
        }
        try:
            report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
            logger.critical("Unhandled exception. Crash report: %s", report_path)
        finally:
            sys.__excepthook__(exc_type, exc, tb)

    sys.excepthook = handle
