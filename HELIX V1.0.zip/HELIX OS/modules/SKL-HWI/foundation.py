from __future__ import annotations
from dataclasses import dataclass,field
from enum import Enum
from typing import Any
import time,uuid

class SourceState(str,Enum):
    HARDWARE="HARDWARE"
    IMPORTED="IMPORTED"
    SIMULATION="SIMULATION"
    SOFTWARE="SOFTWARE"

class ConnectionState(str,Enum):
    DISCONNECTED="DISCONNECTED"
    CONNECTING="CONNECTING"
    CONNECTED="CONNECTED"
    DEGRADED="DEGRADED"
    ERROR="ERROR"

class CalibrationState(str,Enum):
    UNKNOWN="UNKNOWN"
    VALID="VALID"
    EXPIRED="EXPIRED"
    INVALID="INVALID"
    NOT_REQUIRED="NOT_REQUIRED"

class HealthState(str,Enum):
    OK="OK"
    NOTICE="NOTICE"
    WARNING="WARNING"
    ERROR="ERROR"
    CRITICAL="CRITICAL"

@dataclass(frozen=True)
class HardwareIdentity:
    device_id:str
    vendor:str
    model:str
    serial_number:str=""
    firmware_version:str=""
    driver_version:str=""
    def __post_init__(self):
        if not self.device_id or not self.vendor or not self.model:raise ValueError("device_id, vendor and model required")

@dataclass(frozen=True)
class CapabilityDescriptor:
    capability_id:str
    quantity:str
    unit:str
    minimum:float|None=None
    maximum:float|None=None
    resolution:float|None=None
    sample_rate_hz:float|None=None
    writable:bool=False
    def __post_init__(self):
        if not self.capability_id or not self.quantity or not self.unit:raise ValueError("capability identity required")
        if self.minimum is not None and self.maximum is not None and self.minimum>self.maximum:raise ValueError("minimum <= maximum")
        if self.resolution is not None and self.resolution<=0:raise ValueError("resolution positive")
        if self.sample_rate_hz is not None and self.sample_rate_hz<=0:raise ValueError("sample rate positive")

@dataclass(frozen=True)
class CalibrationRecord:
    state:CalibrationState
    calibrated_at_unix_s:float|None=None
    expires_at_unix_s:float|None=None
    certificate_id:str=""
    def is_valid_at(self,unix_s):
        if self.state==CalibrationState.NOT_REQUIRED:return True
        if self.state!=CalibrationState.VALID:return False
        return self.expires_at_unix_s is None or unix_s<=self.expires_at_unix_s

@dataclass(frozen=True)
class MeasurementProvenance:
    source_state:SourceState
    device_id:str|None
    capability_id:str
    timestamp_unix_s:float
    calibration_state:CalibrationState
    experiment_id:str|None=None
    imported_source:str|None=None
    def __post_init__(self):
        if self.source_state==SourceState.HARDWARE and not self.device_id:raise ValueError("hardware measurement requires device_id")
        if not self.capability_id:raise ValueError("capability_id required")

@dataclass(frozen=True)
class Measurement:
    value:float
    unit:str
    provenance:MeasurementProvenance

class InstrumentTransport:
    """Transport contract. Concrete USB/serial/TCP/VISA/vendor adapters arrive in later HWI patches."""
    transport_name="ABSTRACT"
    def open(self):raise NotImplementedError
    def close(self):raise NotImplementedError
    def read(self,capability_id):raise NotImplementedError
    def write(self,capability_id,value):raise NotImplementedError

class Instrument:
    def __init__(self,identity,capabilities,transport=None,calibration=None):
        self.identity=identity
        self.capabilities={c.capability_id:c for c in capabilities}
        if len(self.capabilities)!=len(tuple(capabilities)):raise ValueError("duplicate capability id")
        self.transport=transport
        self.calibration=calibration or CalibrationRecord(CalibrationState.UNKNOWN)
        self.connection_state=ConnectionState.DISCONNECTED
        self.health_state=HealthState.OK
        self.last_error=None
    def capability(self,capability_id):return self.capabilities[capability_id]
    def connect(self):
        if self.transport is None:raise RuntimeError("no transport configured")
        self.connection_state=ConnectionState.CONNECTING
        try:
            self.transport.open();self.connection_state=ConnectionState.CONNECTED;self.last_error=None
        except Exception as e:
            self.connection_state=ConnectionState.ERROR;self.health_state=HealthState.ERROR;self.last_error=str(e);raise
    def disconnect(self):
        if self.transport is not None:self.transport.close()
        self.connection_state=ConnectionState.DISCONNECTED
    def mark_degraded(self,message):
        self.connection_state=ConnectionState.DEGRADED;self.health_state=HealthState.WARNING;self.last_error=message

class InstrumentRegistry:
    def __init__(self):self._devices={}
    def register(self,instrument):
        did=instrument.identity.device_id
        if did in self._devices:raise ValueError("duplicate device_id")
        self._devices[did]=instrument;return instrument
    def unregister(self,device_id):return self._devices.pop(device_id)
    def get(self,device_id):return self._devices[device_id]
    def all(self):return tuple(self._devices.values())
    def by_capability(self,capability_id):return tuple(d for d in self._devices.values() if capability_id in d.capabilities)

def make_provenance(source_state,capability_id,device_id=None,calibration_state=CalibrationState.UNKNOWN,experiment_id=None,imported_source=None,timestamp_unix_s=None):
    return MeasurementProvenance(source_state,device_id,capability_id,time.time() if timestamp_unix_s is None else timestamp_unix_s,calibration_state,experiment_id,imported_source)

class HALInstrumentAdapter:
    """Maps an Instrument to HELIX-style source-separated measurement records without pretending a device exists."""
    def __init__(self,instrument):self.instrument=instrument
    def measurement(self,capability_id,value,unit,experiment_id=None,timestamp_unix_s=None):
        self.instrument.capability(capability_id)
        p=make_provenance(SourceState.HARDWARE,capability_id,self.instrument.identity.device_id,
                          self.instrument.calibration.state,experiment_id,timestamp_unix_s=timestamp_unix_s)
        return Measurement(value,unit,p)
