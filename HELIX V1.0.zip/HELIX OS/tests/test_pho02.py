import unittest,importlib.util,sys,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-PHO"
spec=importlib.util.spec_from_file_location("skl_pho",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
p=importlib.util.module_from_spec(spec);sys.modules["skl_pho"]=p;spec.loader.exec_module(p)
class PHO02(unittest.TestCase):
 def test_free_space(self):
  r=p.free_space(2).apply(p.Ray(1,.1));self.assertAlmostEqual(r.height_m,1.2);self.assertAlmostEqual(r.angle_rad,.1)
 def test_thin_lens(self):
  r=p.thin_lens(.5).apply(p.Ray(.1,0));self.assertAlmostEqual(r.angle_rad,-.2)
 def test_system_order(self):
  M=p.system_matrix([p.free_space(1),p.thin_lens(.5)]);r=M.apply(p.Ray(0,.1));self.assertAlmostEqual(r.height_m,.1);self.assertAlmostEqual(r.angle_rad,-.1)
 def test_trace(self):self.assertEqual(len(p.trace(p.Ray(0,.1),[p.free_space(1),p.free_space(1)])),3)
 def test_imaging(self):
  r=p.thin_lens_imaging(2,.5);self.assertAlmostEqual(r.image_distance_m,2/3);self.assertTrue(r.real_image)
 def test_lensmaker(self):
  f=p.lensmaker_thin(1.5,1,0.1,-0.1);self.assertAlmostEqual(f,.1)
 def test_mirror(self):
  r=p.spherical_mirror(2).apply(p.Ray(.1,0));self.assertAlmostEqual(r.angle_rad,-.1)
 def test_refraction(self):
  r=p.planar_refraction(1,1.5).apply(p.Ray(0,.3));self.assertAlmostEqual(r.angle_rad,.2)
 def test_na_airy(self):
  na=p.numerical_aperture(1,math.pi/6);self.assertAlmostEqual(na,.5);self.assertAlmostEqual(p.diffraction_limited_airy_radius(500e-9,na),610e-9)
 def test_registry_and_manifest(self):
  self.assertEqual(p.PhotonicsRegistry().get("PHO-ABCD-LENS").evidence_class,"ESTABLISHED_PHYSICS")
  m=json.loads((MOD/"module.json").read_text());self.assertEqual(m["patch_id"],"SKL-PHO-02")
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
