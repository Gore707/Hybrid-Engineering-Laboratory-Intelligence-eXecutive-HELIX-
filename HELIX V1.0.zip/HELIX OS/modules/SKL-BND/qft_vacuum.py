from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import BoundaryEvidence,C_M_S

HBAR_J_S=1.054571817e-34

def minkowski_interval_m2(dt_s,dx_m,dy_m=0.0,dz_m=0.0):
    return (C_M_S*dt_s)**2-dx_m**2-dy_m**2-dz_m**2

def is_spacelike(dt_s,dx_m,dy_m=0.0,dz_m=0.0):
    return minkowski_interval_m2(dt_s,dx_m,dy_m,dz_m)<0

def microcausal_commutator_vanishes_for_spacelike_separation(dt_s,dx_m,dy_m=0.0,dz_m=0.0):
    """Local relativistic QFT guard: local observables commute at spacelike separation."""
    return is_spacelike(dt_s,dx_m,dy_m,dz_m)

def spacelike_vacuum_correlation_implies_controllable_signal():
    return False

def squeezed_quadrature_variance(vacuum_variance,squeeze_r,quadrature="squeezed"):
    if vacuum_variance<0 or squeeze_r<0:raise ValueError("nonnegative variance/r")
    if quadrature=="squeezed":return vacuum_variance*math.exp(-2*squeeze_r)
    if quadrature=="antisqueezed":return vacuum_variance*math.exp(2*squeeze_r)
    raise ValueError("quadrature must be squeezed or antisqueezed")

def squeezing_db(squeeze_r):
    if squeeze_r<0:raise ValueError("r nonnegative")
    return 20*squeeze_r/math.log(10)

def thermal_occupation(frequency_hz,temperature_k):
    """Planck mean occupation nbar=1/(exp(hbar omega/kT)-1)."""
    if frequency_hz<=0 or temperature_k<0:raise ValueError("invalid thermal inputs")
    if temperature_k==0:return 0.0
    k=1.380649e-23; x=HBAR_J_S*2*math.pi*frequency_hz/(k*temperature_k)
    return 0.0 if x>700 else 1/math.expm1(x)

def bosonic_loss_channel_mean_photons(input_mean_photons,transmissivity,environment_mean_photons=0.0):
    if input_mean_photons<0 or environment_mean_photons<0 or not 0<=transmissivity<=1:raise ValueError("invalid channel")
    return transmissivity*input_mean_photons+(1-transmissivity)*environment_mean_photons

def shot_noise_snr(mean_signal_counts,mean_background_counts=0.0):
    if mean_signal_counts<0 or mean_background_counts<0:raise ValueError("nonnegative counts")
    total=mean_signal_counts+mean_background_counts
    return 0.0 if total==0 else mean_signal_counts/math.sqrt(total)

def causal_message_latency_s(distance_m):
    if distance_m<0:raise ValueError("distance nonnegative")
    return distance_m/C_M_S

@dataclass(frozen=True)
class VacuumChannelAssessment:
    distance_m:float
    transmissivity:float
    input_mean_photons:float
    environment_mean_photons:float=0.0
    squeeze_r:float=0.0
    evidence:BoundaryEvidence=BoundaryEvidence.ESTABLISHED_PHYSICS
    def __post_init__(self):
        if self.distance_m<0 or not 0<=self.transmissivity<=1 or self.input_mean_photons<0 or self.environment_mean_photons<0 or self.squeeze_r<0:
            raise ValueError("invalid assessment")
    @property
    def output_mean_photons(self):
        return bosonic_loss_channel_mean_photons(self.input_mean_photons,self.transmissivity,self.environment_mean_photons)
    @property
    def minimum_causal_latency_s(self):return causal_message_latency_s(self.distance_m)
    @property
    def ftl_information_available(self):return False
