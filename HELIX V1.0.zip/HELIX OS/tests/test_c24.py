import unittest,tempfile,json,subprocess,sys
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.integration import CoreHealthCheck
from core.design import DesignStudio,Component,Parameter
from core.engineering.assessment import assess_design
from core.physics.registry import PhysicsRegistry
from core.simulation import SimulationEngine,SimulationSpec,SimulationMode
from core.hal import HardwareAbstractionLayer,DeviceDescriptor,HALSource,SimulatedDevice
from core.safety import AppendOnlyAudit,SafetyController,PreflightEngine
from core.modules import ModuleRegistry,ModuleManifest
ROOT=Path(__file__).resolve().parents[1]
class C24Tests(unittest.TestCase):
 def test_identity(self):
  self.assertEqual(IDENTITY.core_version,"1.0.0");self.assertEqual(IDENTITY.api_version,"1.0")
 def test_health(self):
  r=CoreHealthCheck(ROOT).run()
  self.assertTrue(r.passed,[x for x in r.checks if not x["passed"]])
 def test_design_to_assessment(self):
  s=DesignStudio();d=s.new("Link","COMMUNICATIONS")
  s.add_component(d,Component("C","Tx","source",{"p":Parameter("p",1,"W")},["MODEL-ARCH-SHANNON-001"],["EQ-ARCH-SHANNON-001"],"ESTABLISHED_PHYSICS",["SRC"]))
  self.assertTrue(assess_design(s,d).integrity_passed)
 def test_physics_to_simulation(self):
  p=PhysicsRegistry(ROOT/"core/resources/constants/physical_constants.json",ROOT/"core/resources/equations",ROOT/"core/resources/models")
  e=SimulationEngine(p);r=e.run(SimulationSpec("MODEL-ARCH-SHANNON-001",SimulationMode.POINT,{"B":1e6,"S":10,"N":1}))
  self.assertGreater(r.records[0]["outputs"]["C"],0)
 def test_hal_safety_separation(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);h=HardwareAbstractionLayer(td/"hal.jsonl")
   h.register(SimulatedDevice(DeviceDescriptor("S","sim","meter",HALSource.SIMULATION,("read",)),{"v":(1,"V")}));h.connect("S")
   self.assertEqual(h.read("S","v").source,HALSource.SIMULATION)
   c=SafetyController(AppendOnlyAudit(td/"safety.jsonl"));pre=PreflightEngine().run({},[],())
   self.assertTrue(c.authorize_experiment_start(pre))
 def test_module_api(self):
  with tempfile.TemporaryDirectory() as td:
   r=ModuleRegistry(Path(td)/"registry.json","1.0");r.register(ModuleManifest("SKL-MAT-TEST","test","1.0.0","1.0"))
   self.assertIn("SKL-MAT-TEST",r.modules)
 def test_selftest_process(self):
  p=subprocess.run([sys.executable,str(ROOT/"HELIX_SELFTEST.py")],cwd=ROOT,capture_output=True,text=True)
  self.assertEqual(p.returncode,0,p.stdout+p.stderr)
 def test_manifest_24_patches(self):
  d=json.loads((ROOT/"CORE_1_0_MANIFEST.json").read_text());self.assertEqual(len(d["patches"]),24)
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
