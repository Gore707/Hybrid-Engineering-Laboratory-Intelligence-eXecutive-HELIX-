import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-PHO";sp=importlib.util.spec_from_file_location("skl_pho",M/"__init__.py",submodule_search_locations=[str(M)]);p=importlib.util.module_from_spec(sp);sys.modules["skl_pho"]=p;sp.loader.exec_module(p)
class T(unittest.TestCase):
 def test_free_space_ray(self):
  s=p.BenchState(1e-6,1,p.Ray(0,.1));r=p.OpticalBench([p.BenchComponent("fs","free_space",{"length_m":2})]).run(s);self.assertAlmostEqual(r.final_state.ray.height_m,.2);self.assertEqual(len(r.final_state.events),1)
 def test_opl(self):
  s=p.BenchState(1e-6,1,p.Ray(0,0));r=p.OpticalBench([p.BenchComponent("g","free_space",{"length_m":1,"n":1.5})]).run(s);self.assertEqual(r.final_state.optical_path_m,1.5)
 def test_lens(self):
  s=p.BenchState(1e-6,1,p.Ray(.1,0));r=p.OpticalBench([p.BenchComponent("l","thin_lens",{"focal_length_m":1})]).run(s);self.assertAlmostEqual(r.final_state.ray.angle_rad,-.1)
 def test_gaussian_q_chain(self):
  b=p.GaussianBeam(1e-6,1e-3);s=p.gaussian_bench_state(b);r=p.OpticalBench([p.BenchComponent("fs","free_space",{"length_m":1})]).run(s);self.assertAlmostEqual(r.final_state.q.real,1)
 def test_attenuator(self):
  s=p.BenchState(1e-6,2,p.Ray(0,0));r=p.OpticalBench([p.BenchComponent("a","attenuator",{"power_transmission":.25})]).run(s);self.assertEqual(r.final_state.power_w,.5)
 def test_polarizer_power(self):
  s=p.BenchState(1e-6,2,p.Ray(0,0),polarization=p.JonesVector(1/math.sqrt(2),1/math.sqrt(2)));r=p.OpticalBench([p.BenchComponent("p","linear_polarizer",{"angle_rad":0})]).run(s);self.assertAlmostEqual(r.final_state.power_w,1)
 def test_retarder_power_conserved(self):
  s=p.BenchState(1e-6,2,p.Ray(0,0),polarization=p.JonesVector(1,0));r=p.OpticalBench([p.BenchComponent("q","retarder",{"retardance_rad":math.pi/2})]).run(s);self.assertAlmostEqual(r.final_state.power_w,2)
 def test_detector(self):
  s=p.BenchState(1e-6,1,p.Ray(0,0));r=p.OpticalBench([p.BenchComponent("d","detector",{"responsivity_a_w":.5,"bandwidth_hz":1e6})]).run(s);self.assertEqual(r.detector_readings[0]["signal_current_a"],.5);self.assertGreater(r.detector_readings[0]["snr_shot"],0)
 def test_chain(self):
  b=p.GaussianBeam(1e-6,1e-3,power_w=2);s=p.gaussian_bench_state(b,polarization=p.JonesVector(1,1).normalized());bench=p.OpticalBench().add(p.BenchComponent("fs","free_space",{"length_m":.5})).add(p.BenchComponent("a","attenuator",{"power_transmission":.5})).add(p.BenchComponent("d","detector",{"responsivity_a_w":.8}));r=bench.run(s);self.assertEqual(len(r.final_state.events),3);self.assertAlmostEqual(r.detector_readings[0]["signal_current_a"],.8)
 def test_unsupported(self):
  with self.assertRaises(ValueError):p.OpticalBench([p.BenchComponent("x","magic",{})]).run(p.BenchState(1e-6,1,p.Ray(0,0)))
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-PHO-09")
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
