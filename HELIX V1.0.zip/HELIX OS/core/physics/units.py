from __future__ import annotations
from dataclasses import dataclass
import json
from pathlib import Path

class UnitError(ValueError): pass

@dataclass(frozen=True)
class Quantity:
    value:float
    unit:str

class UnitRegistry:
    def __init__(self,path:Path):
        self.data=json.loads(path.read_text(encoding="utf-8"))["units"]
    def definition(self,symbol):
        if symbol not in self.data: raise UnitError(f"Unknown unit: {symbol}")
        return self.data[symbol]
    def compatible(self,a,b):
        return self.definition(a)["dimension"]==self.definition(b)["dimension"]
    def convert(self,q:Quantity,target:str):
        if not self.compatible(q.unit,target): raise UnitError(f"Incompatible units: {q.unit} -> {target}")
        a=self.definition(q.unit);b=self.definition(target)
        return Quantity(q.value*a["scale"]/b["scale"],target)
