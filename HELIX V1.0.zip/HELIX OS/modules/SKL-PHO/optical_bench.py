from __future__ import annotations
from dataclasses import dataclass,field
from typing import Any
import math
from .foundation import OpticalWave
from .geometric import Ray,free_space,thin_lens
from .gaussian import GaussianBeam,q_propagate,beam_from_q
from .polarization import JonesVector,linear_polarizer,retarder
from .detectors import Photodiode
@dataclass(frozen=True)
class BenchComponent:
 component_id:str;kind:str;parameters:dict[str,Any]
 def __post_init__(self):
  if not self.component_id or not self.kind:raise ValueError("component id/kind required")
@dataclass
class BenchState:
 wavelength_m:float;power_w:float;ray:Ray;q:complex|None=None;polarization:JonesVector|None=None
 optical_path_m:float=0.0;events:list[dict[str,Any]]=field(default_factory=list)
@dataclass(frozen=True)
class BenchResult:
 final_state:BenchState;detector_readings:tuple[dict[str,Any],...]
class OpticalBench:
 def __init__(self,components=()):self.components=list(components)
 def add(self,component):self.components.append(component);return self
 def run(self,state):
  readings=[]
  for c in self.components:
   k=c.kind.lower();p=c.parameters
   if k=="free_space":
    L=float(p["length_m"]);n=float(p.get("n",1));state.ray=free_space(L).apply(state.ray)
    if state.q is not None:state.q=q_propagate(state.q,free_space(L))
    state.optical_path_m+=n*L
   elif k=="thin_lens":
    mat=thin_lens(float(p["focal_length_m"]));state.ray=mat.apply(state.ray)
    if state.q is not None:state.q=q_propagate(state.q,mat)
   elif k=="attenuator":
    t=float(p["power_transmission"])
    if not 0<=t<=1:raise ValueError("transmission 0..1")
    state.power_w*=t
   elif k=="linear_polarizer":
    if state.polarization is None:raise ValueError("polarization state required")
    before=state.polarization.intensity;state.polarization=linear_polarizer(float(p["angle_rad"]))@state.polarization
    if before>0:state.power_w*=state.polarization.intensity/before
   elif k=="retarder":
    if state.polarization is None:raise ValueError("polarization state required")
    state.polarization=retarder(float(p.get("angle_rad",0)),float(p["retardance_rad"]))@state.polarization
   elif k=="detector":
    d=Photodiode(float(p["responsivity_a_w"]),float(p.get("dark_current_a",0)),float(p.get("bandwidth_hz",1)),p.get("saturation_current_a"))
    sig=d.signal_current(state.power_w);noise=d.shot_noise(state.power_w)
    readings.append({"component_id":c.component_id,"optical_power_w":state.power_w,"signal_current_a":sig,"shot_noise_a_rms":noise,"snr_shot":(sig/noise if noise>0 else math.inf)})
   else:raise ValueError(f"unsupported bench component kind: {c.kind}")
   state.events.append({"component_id":c.component_id,"kind":c.kind,"power_w":state.power_w,"ray_height_m":state.ray.height_m,"ray_angle_rad":state.ray.angle_rad})
  return BenchResult(state,tuple(readings))
def gaussian_bench_state(beam:GaussianBeam,ray=None,polarization=None):
 return BenchState(beam.wavelength_m,beam.power_w,ray or Ray(0,0),beam.q(),polarization)
