import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-RF"
sp=importlib.util.spec_from_file_location("skl_rf",M/"__init__.py",submodule_search_locations=[str(M)])
r=importlib.util.module_from_spec(sp);sys.modules["skl_rf"]=r;sp.loader.exec_module(r)
class T(unittest.TestCase):
 def test_delay(self):self.assertAlmostEqual(r.propagation_delay_s(r.C),1)
 def test_zero_delay(self):self.assertEqual(r.propagation_delay_s(0),0)
 def test_doppler_first(self):self.assertAlmostEqual(r.one_way_doppler_shift_hz(r.C,1),1)
 def test_rel_doppler_zero(self):self.assertEqual(r.relativistic_received_frequency_hz(1e9,0),1e9)
 def test_rel_doppler_closing(self):self.assertGreater(r.relativistic_received_frequency_hz(1e9,1000),1e9)
 def test_fresnel(self):self.assertAlmostEqual(r.fresnel_zone_radius_m(1,1,1,r.C),math.sqrt(.5))
 def test_clearance(self):
  rr=r.fresnel_zone_radius_m(1,1,1,r.C);self.assertAlmostEqual(r.fresnel_clearance_fraction(rr,1,1,1,r.C),1)
 def test_attenuation_linear(self):self.assertAlmostEqual(r.attenuation_linear_from_db(10),.1)
 def test_specific_loss(self):self.assertEqual(r.specific_attenuation_loss_db(.5,10),5)
 def test_delay_spread(self):self.assertAlmostEqual(r.two_ray_delay_spread_s(r.C+1,1),1)
 def test_coherence_bw(self):self.assertAlmostEqual(r.coherence_bandwidth_hz(1e-6,5),200000)
 def test_rayleigh_zero(self):self.assertEqual(r.rayleigh_outage_probability(0),0)
 def test_rayleigh_one(self):self.assertAlmostEqual(r.rayleigh_outage_probability(1),1-math.exp(-1))
 def test_budget(self):
  b=r.PropagationLossBudget(1000,1e9,1,2,3,4,5,r.PropagationEnvironment.TERRESTRIAL_ATMOSPHERE)
  self.assertAlmostEqual(b.excess_loss_db,15);self.assertAlmostEqual(b.total_loss_db,b.fspl_db+15)
 def test_budget_delay(self):self.assertAlmostEqual(r.PropagationLossBudget(r.C,1e9).one_way_delay_s,1)
 def test_budget_report(self):self.assertEqual(r.PropagationLossBudget(1,1e9,environment=r.PropagationEnvironment.DEEP_SPACE).report()["environment"],"DEEP_SPACE")
 def test_negative_loss_rejected(self):
  with self.assertRaises(ValueError):r.PropagationLossBudget(1,1e9,atmospheric_loss_db=-1)
 def test_invalid_velocity(self):
  with self.assertRaises(ValueError):r.relativistic_received_frequency_hz(1e9,r.C)
 def test_foundation_preserved(self):self.assertAlmostEqual(r.wavelength_m(r.C),1)
 def test_array_preserved(self):self.assertAlmostEqual(r.uniform_linear_array_factor(4,.5,r.C,.2,.2),1)
 def test_registry(self):self.assertTrue({"RF-PROP-DELAY","RF-DOPPLER-REL","RF-FRESNEL","RF-COHERENCE-BW","RF-RAYLEIGH-OUTAGE"}<={x.model_id for x in r.RFRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-RF-03")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-HQIC"])
 def test_hqic_complete(self):self.assertEqual(json.loads((R/"HQIC_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
