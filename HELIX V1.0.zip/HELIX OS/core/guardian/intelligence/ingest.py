from __future__ import annotations
import json
from pathlib import Path
from .knowledge import KnowledgeItem
def ingest_physics(index,constants_path:Path,equations_dir:Path,models_dir:Path):
 count=0
 document=json.loads(constants_path.read_text(encoding="utf-8"))
 constants=document.get("constants",{})
 for symbol,c in constants.items():
  index.upsert(KnowledgeItem("CONST-"+symbol,"constant",symbol,
   f'{c["name"]}: {c["value"]} {c["unit"]}. {c.get("source","")}',
   evidence_class="ESTABLISHED_PHYSICS",provenance="HELIX canonical constants"));count+=1
 for p in equations_dir.glob("*.json"):
  e=json.loads(p.read_text(encoding="utf-8"))
  index.upsert(KnowledgeItem(e["resource_id"],"equation",e["name"],
   f'{e["name"]}. {e["latex"]}. {e.get("description","")}',evidence_class=e.get("evidence_class"),provenance=str(p)));count+=1
 for p in models_dir.glob("*.json"):
  m=json.loads(p.read_text(encoding="utf-8"))
  index.upsert(KnowledgeItem(m["resource_id"],"model",m["name"],
   f'{m["name"]}. {m.get("description","")} Equations: {", ".join(m.get("equation_ids",[]))}.',
   evidence_class=m.get("evidence_class"),provenance=str(p)));count+=1
 return count
def ingest_truth(index,truth_store):
 for r in truth_store.records.values():
  index.upsert(KnowledgeItem(r.record_id,"truth",r.subject_id,r.claim,
   source_id=r.source_ids[0] if r.source_ids else None,evidence_class=r.evidence_class.value,
   provenance="HELIX Truth Store"))
 return len(truth_store.records)
