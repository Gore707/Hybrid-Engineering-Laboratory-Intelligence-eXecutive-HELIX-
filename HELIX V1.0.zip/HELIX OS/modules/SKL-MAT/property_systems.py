from __future__ import annotations
from dataclasses import dataclass
import math
@dataclass(frozen=True)
class Sample:
 x:float;y:float
 def __post_init__(self):
  if not math.isfinite(self.x) or not math.isfinite(self.y):raise ValueError("samples must be finite")
class PropertyCurve:
 def __init__(self,samples,domain_name,unit):
  self.samples=tuple(sorted(samples,key=lambda s:s.x));self.domain_name=domain_name;self.unit=unit
  if not self.samples:raise ValueError("curve requires samples")
  if len({s.x for s in self.samples})!=len(self.samples):raise ValueError("duplicate domain values")
 def evaluate(self,x,allow_extrapolation=False):
  if not math.isfinite(x):raise ValueError("domain value must be finite")
  s=self.samples
  if len(s)==1:
   if x!=s[0].x and not allow_extrapolation:raise ValueError("outside measured domain")
   return s[0].y
  if x<s[0].x:
   if not allow_extrapolation:raise ValueError("below measured domain")
   a,b=s[0],s[1]
  elif x>s[-1].x:
   if not allow_extrapolation:raise ValueError("above measured domain")
   a,b=s[-2],s[-1]
  else:
   for a,b in zip(s,s[1:]):
    if a.x<=x<=b.x:break
  return a.y+(b.y-a.y)*(x-a.x)/(b.x-a.x)
 @property
 def domain(self):return self.samples[0].x,self.samples[-1].x
@dataclass(frozen=True)
class ThermalProperties:
 conductivity_w_mk:float;specific_heat_j_kgk:float;density_kg_m3:float;cte_per_k:float=0.0
 def diffusivity_m2_s(self):
  if min(self.conductivity_w_mk,self.specific_heat_j_kgk,self.density_kg_m3)<=0:raise ValueError("thermal values must be positive")
  return self.conductivity_w_mk/(self.density_kg_m3*self.specific_heat_j_kgk)
 def volumetric_heat_capacity(self):return self.density_kg_m3*self.specific_heat_j_kgk
@dataclass(frozen=True)
class OpticalProperties:
 refractive_index:float;extinction_coefficient:float=0.0
 def __post_init__(self):
  if self.refractive_index<=0 or self.extinction_coefficient<0:raise ValueError("invalid optical properties")
 def reflectance_normal(self,n_incident=1.0):
  n,k=self.refractive_index,self.extinction_coefficient
  return ((n-n_incident)**2+k*k)/((n+n_incident)**2+k*k)
 def absorption_coefficient_per_m(self,wavelength_m):
  if wavelength_m<=0:raise ValueError("wavelength must be positive")
  return 4*math.pi*self.extinction_coefficient/wavelength_m
@dataclass(frozen=True)
class ElectricalProperties:
 resistivity_ohm_m:float;relative_permittivity:float=1.0
 def __post_init__(self):
  if self.resistivity_ohm_m<0 or self.relative_permittivity<=0:raise ValueError("invalid electrical properties")
 def conductivity_s_m(self):return math.inf if self.resistivity_ohm_m==0 else 1/self.resistivity_ohm_m
@dataclass(frozen=True)
class MechanicalProperties:
 youngs_modulus_pa:float;poisson_ratio:float;yield_strength_pa:float
 def __post_init__(self):
  if self.youngs_modulus_pa<=0 or self.yield_strength_pa<=0 or not -1<self.poisson_ratio<.5:raise ValueError("invalid isotropic mechanical properties")
 def shear_modulus_pa(self):return self.youngs_modulus_pa/(2*(1+self.poisson_ratio))
 def bulk_modulus_pa(self):return self.youngs_modulus_pa/(3*(1-2*self.poisson_ratio))
