import math,unittest
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.physics import PhysicsRegistry,UnitRegistry,Quantity
from core.physics.units import UnitError
ROOT=Path(__file__).resolve().parents[1]
def reg():
 return PhysicsRegistry(ROOT/"core/resources/constants/physical_constants.json",
  ROOT/"core/resources/equations",ROOT/"core/resources/models")
class C10Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C10")
 def test_units(self):
  u=UnitRegistry(ROOT/"core/resources/constants/units.json")
  self.assertAlmostEqual(u.convert(Quantity(1,"km"),"m").value,1000)
  self.assertAlmostEqual(u.convert(Quantity(500,"nm"),"m").value,5e-7)
  with self.assertRaises(UnitError):u.convert(Quantity(1,"s"),"m")
 def test_constants(self):
  r=reg();self.assertEqual(r.constant("c")["value"],299792458.0);self.assertTrue(r.constant("h")["exact"])
 def test_equation_model_links(self):self.assertTrue(reg().verify_links())
 def test_shannon(self):
  out=reg().evaluate("MODEL-ARCH-SHANNON-001",B=1e6,S=10.0,N=1.0)
  self.assertAlmostEqual(out["C"],1e6*math.log2(11))
 def test_fspl(self):
  out=reg().evaluate("MODEL-ARCH-FSPL-001",d=1000.0,**{"lambda":0.1})
  self.assertGreater(out["L_FS"],1e9)
 def test_photon(self):
  out=reg().evaluate("MODEL-ARCH-PHOTON-001",**{"lambda":500e-9})
  self.assertAlmostEqual(out["E_gamma"],3.972891714e-19,places=27)
 def test_coherence(self):
  out=reg().evaluate("MODEL-ARCH-COHERENCE-001",C0=1.0,t=2.0,T2=2.0)
  self.assertAlmostEqual(out["C"],math.e**-1)
 def test_strict_inputs(self):
  with self.assertRaises(ValueError):reg().evaluate("MODEL-ARCH-SHANNON-001",B=1,S=1)
 def test_latex_not_ascii_style(self):
  r=reg()
  self.assertIn(r"\log_{2}",r.equation("EQ-ARCH-SHANNON-001")["latex"])
  self.assertIn(r"\lambda",r.equation("EQ-ARCH-PHOTON-001")["latex"])
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
