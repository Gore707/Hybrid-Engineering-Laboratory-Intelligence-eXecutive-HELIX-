from __future__ import annotations
from dataclasses import dataclass,field
from enum import Enum
from typing import Any
import math,uuid
class StorageClass(str,Enum):
 CLASSICAL="CLASSICAL";QUANTUM="QUANTUM";HYBRID="HYBRID"
class MediumFamily(str,Enum):
 GLASS_5D="GLASS_5D";HOLOGRAPHIC="HOLOGRAPHIC";SPECTRAL="SPECTRAL";MOLECULAR="MOLECULAR";MAGNETIC="MAGNETIC";OTHER="OTHER"
class EvidenceClass(str,Enum):
 DEMONSTRATED_TECH="DEMONSTRATED_TECH";ESTABLISHED_PHYSICS="ESTABLISHED_PHYSICS";EXTRAPOLATED_ENGINEERING="EXTRAPOLATED_ENGINEERING";SPECULATIVE_UNRESOLVED="SPECULATIVE_UNRESOLVED";NEW_PHYSICS="NEW_PHYSICS"
@dataclass(frozen=True)
class StorageGeometry:
 x_m:float;y_m:float;z_m:float
 def __post_init__(self):
  if min(self.x_m,self.y_m,self.z_m)<=0 or not all(math.isfinite(v) for v in (self.x_m,self.y_m,self.z_m)):raise ValueError("positive finite dimensions required")
 @property
 def volume_m3(self):return self.x_m*self.y_m*self.z_m
@dataclass(frozen=True)
class StorageMedium:
 medium_id:str;name:str;family:MediumFamily;storage_class:StorageClass;geometry:StorageGeometry
 evidence_class:EvidenceClass;source_ids:tuple[str,...]=();metadata:dict[str,Any]=field(default_factory=dict)
 def __post_init__(self):
  if not self.medium_id or not self.name:raise ValueError("medium id/name required")
@dataclass(frozen=True)
class CapacityEstimate:
 usable_bits:float;raw_bits:float;overhead_fraction:float;basis:str;evidence_class:EvidenceClass
 def __post_init__(self):
  if self.raw_bits<0 or self.usable_bits<0 or self.usable_bits>self.raw_bits:raise ValueError("invalid capacity")
  if not 0<=self.overhead_fraction<1:raise ValueError("invalid overhead")
 @property
 def usable_bytes(self):return self.usable_bits/8
@dataclass(frozen=True)
class StorageDevice:
 device_id:str;name:str;medium:StorageMedium;interface:str="VIRTUAL";controller_id:str|None=None
 def __post_init__(self):
  if not self.device_id or not self.name or not self.interface:raise ValueError("device id/name/interface required")
def capacity_from_bit_density(volume_m3,bits_per_m3,overhead_fraction=0.0,evidence_class=EvidenceClass.EXTRAPOLATED_ENGINEERING,basis="volumetric bit density"):
 if volume_m3<=0 or bits_per_m3<0 or not 0<=overhead_fraction<1:raise ValueError("invalid capacity inputs")
 raw=volume_m3*bits_per_m3
 return CapacityEstimate(raw*(1-overhead_fraction),raw,overhead_fraction,basis,evidence_class)
def capacity_from_sites(site_count,bits_per_site,overhead_fraction=0.0,evidence_class=EvidenceClass.EXTRAPOLATED_ENGINEERING,basis="discrete sites"):
 if site_count<0 or int(site_count)!=site_count or bits_per_site<0:raise ValueError("invalid site capacity inputs")
 raw=int(site_count)*bits_per_site
 if not 0<=overhead_fraction<1:raise ValueError("invalid overhead")
 return CapacityEstimate(raw*(1-overhead_fraction),raw,overhead_fraction,basis,evidence_class)
def new_medium_id(prefix="MED"):return f"{prefix}-{uuid.uuid4().hex[:12].upper()}"
