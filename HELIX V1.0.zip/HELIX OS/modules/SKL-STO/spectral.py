from __future__ import annotations
from dataclasses import dataclass
import math
from .framework import CapacityEstimate,EvidenceClass
def coherence_time_from_homogeneous_linewidth_s(linewidth_hz):
 if linewidth_hz<=0:raise ValueError("linewidth positive")
 return 1/(math.pi*linewidth_hz)
def max_uniform_channels(total_bandwidth_hz,channel_spacing_hz,guard_fraction=0.0):
 if total_bandwidth_hz<0 or channel_spacing_hz<=0 or guard_fraction<0:raise ValueError("invalid channel parameters")
 effective=channel_spacing_hz*(1+guard_fraction)
 return int(math.floor(total_bandwidth_hz/effective+1e-12))
@dataclass(frozen=True)
class SpectralHole:
 center_hz:float;fwhm_hz:float;depth_fraction:float
 def __post_init__(self):
  if self.center_hz<=0 or self.fwhm_hz<=0 or not 0<=self.depth_fraction<=1:raise ValueError("invalid spectral hole")
 def lorentzian_depth(self,frequency_hz):
  x=2*(frequency_hz-self.center_hz)/self.fwhm_hz
  return self.depth_fraction/(1+x*x)
@dataclass(frozen=True)
class AtomicFrequencyComb:
 tooth_spacing_hz:float;tooth_fwhm_hz:float;tooth_count:int
 def __post_init__(self):
  if self.tooth_spacing_hz<=0 or self.tooth_fwhm_hz<=0 or self.tooth_count<1 or self.tooth_fwhm_hz>self.tooth_spacing_hz:raise ValueError("invalid AFC")
 @property
 def finesse(self):return self.tooth_spacing_hz/self.tooth_fwhm_hz
 @property
 def nominal_echo_time_s(self):return 1/self.tooth_spacing_hz
 @property
 def occupied_span_hz(self):return (self.tooth_count-1)*self.tooth_spacing_hz+self.tooth_fwhm_hz
 def tooth_frequencies(self,center_hz):
  if center_hz<=0:raise ValueError("center positive")
  start=center_hz-(self.tooth_count-1)*self.tooth_spacing_hz/2
  return tuple(start+i*self.tooth_spacing_hz for i in range(self.tooth_count))
@dataclass(frozen=True)
class SpectralStoragePlan:
 spectral_channels:int;spatial_sites:int;bits_per_channel:int=1;reserved_fraction:float=0.0
 def __post_init__(self):
  if min(self.spectral_channels,self.spatial_sites,self.bits_per_channel)<1 or not 0<=self.reserved_fraction<1:raise ValueError("invalid spectral plan")
 @property
 def raw_bits(self):return self.spectral_channels*self.spatial_sites*self.bits_per_channel
 def capacity(self,evidence_class=EvidenceClass.EXTRAPOLATED_ENGINEERING):
  raw=self.raw_bits;usable=raw*(1-self.reserved_fraction)
  return CapacityEstimate(usable,raw,self.reserved_fraction,"spectral channels × spatial sites × payload",evidence_class)
def lifetime_limited_linewidth_hz(lifetime_s):
 if lifetime_s<=0:raise ValueError("lifetime positive")
 return 1/(2*math.pi*lifetime_s)
