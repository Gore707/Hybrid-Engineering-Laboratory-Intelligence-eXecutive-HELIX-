import unittest,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]; MAIN=(R/"core/ui/main_window.py").read_text(); THEME=(R/"core/ui/theme.py").read_text()
class T(unittest.TestCase):
 def test_command_center(self):self.assertIn("HELIX COMMAND CENTER",MAIN)
 def test_cards(self):
  for x in ('_home_card("PROJECT"','_home_card("COMPUTE"','_home_card("HARDWARE"','_home_card("GUARDIAN"'):self.assertIn(x,MAIN)
 def test_quick_start_real_handlers(self):
  for x in ("bnew.clicked.connect(self._new_project)","bopen.clicked.connect(self._open_project)","bexp.clicked.connect(self._new_experiment)","bguard.clicked.connect(self._show_guardian_console)"):self.assertIn(x,MAIN)
 def test_tree(self):self.assertIn("QTreeWidget()",MAIN);self.assertIn('self.project_tree.setHeaderHidden(True)',MAIN)
 def test_scientific_categories(self):
  for x in ("Experiments","Models","Equations","Simulations","Datasets","Materials","Devices","Hardware","Figures","Research","Reports"):self.assertIn(x,MAIN)
 def test_no_fake_telemetry(self):self.assertNotIn("CPU 7%",MAIN);self.assertNotIn("RAM 18",MAIN)
 def test_theme(self):self.assertIn("QFrame#HomeCard",THEME);self.assertIn("QTreeWidget#ProjectTree",THEME)
 def test_ui01_preserved(self):self.assertTrue((R/"UI_01_COMPLETE.json").exists())
 def test_ui02_marker(self):self.assertEqual(json.loads((R/"UI_02_COMPLETE.json").read_text())["sequence"],"2/6")
 def test_backend_preserved(self):self.assertEqual(json.loads((R/"HELIX_136_COMPLETE.json").read_text())["patches_completed"],136)
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
