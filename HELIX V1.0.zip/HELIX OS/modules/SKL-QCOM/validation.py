from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math,random,statistics

class FailureSeverity(str,Enum):
    INFO="INFO"; NOTICE="NOTICE"; WARNING="WARNING"; ERROR="ERROR"; CRITICAL="CRITICAL"

@dataclass(frozen=True)
class FailureFinding:
    gate_id:str
    severity:FailureSeverity
    passed:bool
    message:str

@dataclass(frozen=True)
class SensitivityPoint:
    parameter:str
    fractional_change:float
    output_value:float
    normalized_sensitivity:float

@dataclass(frozen=True)
class MonteCarloSummary:
    samples:int
    mean:float
    stdev:float
    p05:float
    median:float
    p95:float
    minimum:float
    maximum:float

def percentile(values,p):
    if not values or not 0<=p<=1:raise ValueError("invalid percentile")
    x=sorted(values);k=(len(x)-1)*p;lo=math.floor(k);hi=math.ceil(k)
    return x[lo] if lo==hi else x[lo]*(hi-k)+x[hi]*(k-lo)

def monte_carlo_link_rate(source_rate_per_s,efficiency_mean,efficiency_sigma,background_rate_per_s=0.0,samples=1000,seed=1):
    if source_rate_per_s<0 or background_rate_per_s<0 or not 0<=efficiency_mean<=1 or efficiency_sigma<0 or samples<2:
        raise ValueError("invalid Monte Carlo inputs")
    rng=random.Random(seed);vals=[]
    for _ in range(samples):
        eta=max(0.0,min(1.0,rng.gauss(efficiency_mean,efficiency_sigma)))
        vals.append(source_rate_per_s*eta+background_rate_per_s)
    return MonteCarloSummary(samples,statistics.mean(vals),statistics.stdev(vals),
        percentile(vals,.05),percentile(vals,.5),percentile(vals,.95),min(vals),max(vals))

def normalized_local_sensitivity(model,parameter_name,base_parameters,fractional_step=.01):
    if parameter_name not in base_parameters or fractional_step<=0:raise ValueError("invalid sensitivity request")
    x0=float(base_parameters[parameter_name])
    if x0==0:raise ValueError("base parameter must be nonzero")
    y0=float(model(**base_parameters))
    if y0==0:raise ValueError("base output must be nonzero")
    pts=[]
    for frac in (-fractional_step,fractional_step):
        p=dict(base_parameters);p[parameter_name]=x0*(1+frac)
        y=float(model(**p))
        s=((y-y0)/y0)/frac
        pts.append(SensitivityPoint(parameter_name,frac,y,s))
    return tuple(pts)

def quantum_link_failure_gates(channel_efficiency,qber,fidelity,secret_key_rate_bps,entanglement_rate_per_s,
                               max_qber=.11,min_fidelity=2/3,min_channel_efficiency=1e-12):
    if not 0<=channel_efficiency<=1 or not 0<=qber<=.5 or not 0<=fidelity<=1 or secret_key_rate_bps<0 or entanglement_rate_per_s<0:
        raise ValueError("invalid metrics")
    return (
      FailureFinding("QCOM-GATE-CHANNEL",FailureSeverity.CRITICAL,channel_efficiency>=min_channel_efficiency,
                     "Channel transmission above configured feasibility floor."),
      FailureFinding("QCOM-GATE-QBER",FailureSeverity.CRITICAL,qber<=max_qber,
                     "QBER below configured protocol-analysis threshold."),
      FailureFinding("QCOM-GATE-FIDELITY",FailureSeverity.ERROR,fidelity>=min_fidelity,
                     "Entanglement/teleportation fidelity above configured classical benchmark."),
      FailureFinding("QCOM-GATE-KEY",FailureSeverity.WARNING,secret_key_rate_bps>0,
                     "Positive modeled secret-key throughput."),
      FailureFinding("QCOM-GATE-ENT",FailureSeverity.WARNING,entanglement_rate_per_s>0,
                     "Positive modeled entanglement throughput."),
    )

def all_critical_gates_pass(findings):
    return all(x.passed for x in findings if x.severity==FailureSeverity.CRITICAL)

def run_cross_engine_validation():
    checks={}
    # Internal analytical identities / cross-patch invariants.
    from .foundation import no_signalling_remote_probability
    from .free_space import link_loss_db
    from .interplanetary import one_way_light_time_s,C_M_S
    from .squeezed import loss_degraded_variance,causality_or_capacity_bypass_available
    from .memory_nodes import multimode_throughput_limit_per_s
    from .repeaters import nested_swap_success_probability
    from .teleportation import pre_classical_message_receiver_state_information_bits
    checks["no_signalling"]=no_signalling_remote_probability("validation")==(.5,.5)
    checks["one_light_second"]=abs(one_way_light_time_s(C_M_S)-1)<1e-12
    checks["10db_at_0p1"]=abs(link_loss_db(.1)-10)<1e-12
    checks["total_loss_restores_vacuum"]=abs(loss_degraded_variance(.2,0)-1)<1e-12
    checks["squeezing_no_causality_bypass"]=causality_or_capacity_bypass_available() is False
    checks["teleport_requires_classical"]=pre_classical_message_receiver_state_information_bits()==0
    checks["memory_modes"]=abs(multimode_throughput_limit_per_s(10,.01)-1000)<1e-12
    checks["nested_repeater"]=abs(nested_swap_success_probability(.5,.5,1)-.125)<1e-12
    # Cross-engine completion markers: validate that required upstream modules are installed complete.
    from pathlib import Path
    r=Path(__file__).resolve().parents[2]
    for marker,key in [("PHO_COMPLETE.json","photonics_complete"),("QMEM_COMPLETE.json","qmem_complete"),("OPT_COMPLETE.json","opt_complete")]:
        import json
        p=r/marker
        checks[key]=p.exists() and json.loads(p.read_text()).get("status")=="COMPLETE"
    return checks
