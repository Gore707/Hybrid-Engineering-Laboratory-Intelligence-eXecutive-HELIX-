import unittest,json
from pathlib import Path
from core.guardian.analytics import GuardianAnalytics
from core.guardian.analytics_service import GuardianAnalyticsService,AnalyticsRequest
R=Path(__file__).resolve().parents[1]
class T(unittest.TestCase):
 def setUp(self):self.a=GuardianAnalytics()
 def test_outlier(self):
  f=self.a.robust_outliers("x",[10,10,11,9,10,100]);self.assertEqual(len(f),1);self.assertEqual(f[0].kind,"OUTLIER")
 def test_no_small_sample_claim(self):self.assertEqual(self.a.robust_outliers("x",[1,2,100]),[])
 def test_trend(self):
  f=self.a.trend("x",[1,2,3,4,5]);self.assertIsNotNone(f);self.assertGreater(f.evidence["slope_per_sample"],0)
 def test_divergence(self):
  f=self.a.divergence("x",[1,2,4],[1,2,3]);self.assertGreater(f.evidence["normalized_rmse"],0)
 def test_consistency(self):self.assertEqual(len(self.a.consistency("t",[1,2,9],upper=5)),1)
 def test_provenance(self):self.assertEqual(self.a.trend("x",[1,2,3,4],provenance="SIMULATION").provenance,"SIMULATION")
 def test_service(self):self.assertTrue(GuardianAnalyticsService().analyze(AnalyticsRequest("trend","x",(1,2,3,4))))
 def test_marker(self):self.assertEqual(json.loads((R/"GAI_03_COMPLETE.json").read_text())["sequence"],"3/8")
 def test_prior(self):self.assertTrue((R/"GAI_01_COMPLETE.json").exists());self.assertTrue((R/"GAI_02_COMPLETE.json").exists())
 def test_no_heavy_ml_dependency(self):
  s=(R/"core/guardian/analytics.py").read_text();self.assertNotIn("sklearn",s);self.assertNotIn("torch",s)
 def test_llm_still_separate(self):self.assertTrue((R/"core/guardian/local_llm.py").exists())
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
