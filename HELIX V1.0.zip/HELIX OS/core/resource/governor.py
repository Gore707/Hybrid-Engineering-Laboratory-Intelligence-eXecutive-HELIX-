from __future__ import annotations
import json,os
from dataclasses import dataclass
from enum import IntEnum
from pathlib import Path
from .telemetry import ResourceTelemetry

class JobPriority(IntEnum):
    GUARDIAN=10
    VISUALIZATION=20
    SCIENTIFIC_COMPUTE=30
    EXPERIMENT=40
    HARDWARE=50
    SAFETY=60

@dataclass(frozen=True)
class ResourceDecision:
    allowed:bool
    worker_limit:int
    batch_scale:float
    reason:str
    emergency:bool=False

class AdaptiveResourceGovernor:
    def __init__(self,modes_path:Path,mode="Balanced",custom=None,thermal_soft_c=82.0,thermal_hard_c=92.0):
        self.modes=json.loads(modes_path.read_text(encoding="utf-8"))
        self.mode=mode;self.custom=custom
        self.thermal_soft=thermal_soft_c;self.thermal_hard=thermal_hard_c
        self.logical_cores=os.cpu_count() or 1
        self.last=None
    def limits(self):
        if self.mode=="Custom":
            if not self.custom:raise ValueError("Custom mode requires explicit limits.")
            return self.custom
        if self.mode not in self.modes:raise ValueError(f"Unknown resource mode: {self.mode}")
        return self.modes[self.mode]
    def set_mode(self,mode,custom=None):
        if mode!="Custom" and mode not in self.modes:raise ValueError(f"Unknown resource mode: {mode}")
        self.mode=mode;self.custom=custom
    def decide(self,t:ResourceTelemetry,priority:JobPriority=JobPriority.SCIENTIFIC_COMPUTE):
        lim=self.limits()
        workers=max(1,int(self.logical_cores*lim["max_workers_fraction"]))
        scale=1.0
        if t.gpu_temperature_c is not None and t.gpu_temperature_c>=self.thermal_hard:
            d=ResourceDecision(False,1,0.0,"Hard thermal limit reached; compute paused.",True);self.last=d;return d
        if t.gpu_temperature_c is not None and t.gpu_temperature_c>=self.thermal_soft:
            scale=min(scale,0.35);workers=max(1,workers//2)
        if t.cpu_fraction is not None and t.cpu_fraction>=lim["cpu_limit"]:
            scale=min(scale,0.5);workers=max(1,workers//2)
        if t.ram_fraction is not None and t.ram_fraction>=lim["memory_limit"]:
            scale=min(scale,0.35);workers=max(1,workers//2)
        if t.gpu_util_fraction is not None and t.gpu_util_fraction>=lim["gpu_limit"]:
            scale=min(scale,0.5)
        # Guardian yields first under pressure; safety/hardware remain eligible unless emergency.
        if priority==JobPriority.GUARDIAN and scale<1.0:
            d=ResourceDecision(False,1,0.0,"Guardian yielded resources to higher-priority HELIX work.");self.last=d;return d
        reason="Within configured resource envelope." if scale==1 else "Resource pressure detected; workload throttled."
        d=ResourceDecision(True,workers,scale,reason);self.last=d;return d
