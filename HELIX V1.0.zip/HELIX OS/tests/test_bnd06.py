import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-BND"
sp=importlib.util.spec_from_file_location("skl_bnd",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_bnd"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_metric(self):self.assertAlmostEqual(q.morris_thorne_radial_metric_factor(10,5),2)
 def test_redshift(self):self.assertEqual(q.redshift_time_factor(0),1)
 def test_throat(self):self.assertTrue(q.throat_condition(10,10))
 def test_flare(self):self.assertTrue(q.flare_out_condition_at_throat(.5));self.assertFalse(q.flare_out_condition_at_throat(1))
 def test_nec_indicator(self):self.assertLess(q.nec_radial_indicator_at_throat(1,.5),0)
 def test_nec_violation(self):self.assertTrue(q.radial_nec_violated_at_throat(.5))
 def test_proper_distance_flat(self):self.assertAlmostEqual(q.proper_radial_distance_numeric(1,2,lambda r:0,100),1)
 def test_path_saving(self):self.assertEqual(q.effective_path_saving_m(100,10),90)
 def test_local_transit(self):self.assertEqual(q.wormhole_transit_time_s(q.C_M_S),1)
 def test_reject_local_ftl(self):
  with self.assertRaises(ValueError):q.wormhole_transit_time_s(1,q.C_M_S*1.01)
 def test_apparent_speed(self):self.assertGreater(q.apparent_effective_speed_m_s(10*q.C_M_S,1),q.C_M_S)
 def test_clock_offset(self):self.assertEqual(q.mouth_clock_arrival_offset_s(1,-2),-1)
 def test_chronology_risk(self):self.assertTrue(q.chronology_risk_from_clock_offset(1,-2))
 def test_no_hardware(self):self.assertFalse(q.physically_demonstrated_traversable_wormhole_available())
 def test_link(self):
  l=q.MorrisThorneCommunicationLink(10,.5,q.C_M_S,10*q.C_M_S,-2);self.assertTrue(l.flare_out_satisfied);self.assertTrue(l.radial_nec_violated);self.assertGreater(l.apparent_effective_speed_m_s,q.C_M_S);self.assertTrue(l.chronology_risk);self.assertFalse(l.demonstrated_hardware)
 def test_gr_preserved(self):self.assertGreater(q.schwarzschild_radius_m(1e30),0)
 def test_qft_preserved(self):self.assertFalse(q.spacelike_vacuum_correlation_implies_controllable_signal())
 def test_registry(self):self.assertTrue({"BND-WH-GRR","BND-WH-FLARE","BND-WH-NEC","BND-WH-LINK"}<={x.model_id for x in q.default_registry().all()})
 def test_foundation_guard(self):self.assertFalse(q.established_physics_causality_bypass_available())
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-BND-06")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
