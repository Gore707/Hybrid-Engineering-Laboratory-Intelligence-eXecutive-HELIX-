from __future__ import annotations
from dataclasses import dataclass
import math
from .free_space import gaussian_beam_radius_m,circular_aperture_capture_fraction,gaussian_pointing_efficiency,link_loss_db,C_M_S
from .qkd import qber_from_signal_and_background,asymptotic_bb84_secret_fraction

AU_M=149597870700.0
EARTH_MOON_MEAN_M=384400000.0

def one_way_light_time_s(distance_m):
    if distance_m<0:raise ValueError("distance nonnegative")
    return distance_m/C_M_S

def round_trip_light_time_s(distance_m):return 2*one_way_light_time_s(distance_m)

def diffraction_limited_divergence_rad(wavelength_m,transmitter_diameter_m):
    if wavelength_m<=0 or transmitter_diameter_m<=0:raise ValueError("positive wavelength/aperture")
    return 1.22*wavelength_m/transmitter_diameter_m

def far_field_spot_radius_m(distance_m,divergence_rad):
    if distance_m<0 or divergence_rad<0:raise ValueError("nonnegative geometry")
    return distance_m*divergence_rad

def pointing_requirement_rad(spot_radius_m,distance_m,max_offset_fraction=0.1):
    if spot_radius_m<0 or distance_m<=0 or not 0<max_offset_fraction<=1:raise ValueError("invalid pointing requirement")
    return max_offset_fraction*spot_radius_m/distance_m

def memory_survival_over_herald_time(distance_m,coherence_time_s,processing_delay_s=0.0):
    if coherence_time_s<=0 or processing_delay_s<0:raise ValueError("invalid memory timing")
    t=round_trip_light_time_s(distance_m)+processing_delay_s
    return math.exp(-t/coherence_time_s)

def required_memory_coherence_for_survival(distance_m,min_survival,processing_delay_s=0.0):
    if not 0<min_survival<1 or processing_delay_s<0:raise ValueError("survival in (0,1)")
    t=round_trip_light_time_s(distance_m)+processing_delay_s
    return 0.0 if t==0 else -t/math.log(min_survival)

def direct_entanglement_pair_rate_per_s(pair_source_rate_per_s,channel_efficiency_a,channel_efficiency_b,detector_efficiency_a=1.0,detector_efficiency_b=1.0,coincidence_efficiency=1.0):
    xs=(channel_efficiency_a,channel_efficiency_b,detector_efficiency_a,detector_efficiency_b,coincidence_efficiency)
    if pair_source_rate_per_s<0 or not all(0<=x<=1 for x in xs):raise ValueError("invalid rates/efficiencies")
    out=pair_source_rate_per_s
    for x in xs:out*=x
    return out

@dataclass(frozen=True)
class InterplanetaryQuantumLink:
    wavelength_m:float
    tx_beam_waist_m:float
    distance_m:float
    rx_aperture_diameter_m:float
    pointing_offset_rad:float=0.0
    tx_efficiency:float=1.0
    rx_efficiency:float=1.0
    detector_efficiency:float=1.0
    source_rate_per_s:float=1.0
    background_rate_per_s:float=0.0
    intrinsic_error:float=0.0
    def __post_init__(self):
        if self.wavelength_m<=0 or self.tx_beam_waist_m<=0 or self.distance_m<0 or self.rx_aperture_diameter_m<=0 or self.pointing_offset_rad<0 or self.source_rate_per_s<0 or self.background_rate_per_s<0:
            raise ValueError("invalid geometry/rates")
        if not all(0<=x<=1 for x in (self.tx_efficiency,self.rx_efficiency,self.detector_efficiency)):raise ValueError("efficiencies in [0,1]")
        if not 0<=self.intrinsic_error<=.5:raise ValueError("intrinsic error in [0,.5]")
    @property
    def beam_radius_m(self):return gaussian_beam_radius_m(self.tx_beam_waist_m,self.wavelength_m,self.distance_m)
    @property
    def aperture_capture(self):return circular_aperture_capture_fraction(self.rx_aperture_diameter_m,self.beam_radius_m)
    @property
    def pointing_efficiency(self):return gaussian_pointing_efficiency(self.pointing_offset_rad,self.distance_m,self.beam_radius_m)
    @property
    def channel_efficiency(self):return self.tx_efficiency*self.aperture_capture*self.pointing_efficiency*self.rx_efficiency
    @property
    def detected_signal_rate_per_s(self):return self.source_rate_per_s*self.channel_efficiency*self.detector_efficiency
    @property
    def qber(self):return qber_from_signal_and_background(self.detected_signal_rate_per_s,self.background_rate_per_s,self.intrinsic_error)
    @property
    def idealized_bb84_secret_rate_bps(self):
        raw=self.detected_signal_rate_per_s+self.background_rate_per_s
        return .5*raw*asymptotic_bb84_secret_fraction(self.qber)
    @property
    def one_way_light_time_s(self):return one_way_light_time_s(self.distance_m)
    @property
    def total_loss_db(self):return link_loss_db(self.channel_efficiency*self.detector_efficiency)
