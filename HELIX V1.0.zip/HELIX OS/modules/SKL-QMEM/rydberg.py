from __future__ import annotations
from dataclasses import dataclass
import math

HBAR=1.054571817e-34
H=6.62607015e-34
C=299792458.0
EPS0=8.8541878128e-12

def angular_rabi_frequency_rad_s(dipole_moment_c_m,electric_field_v_m):
    if dipole_moment_c_m<0 or electric_field_v_m<0: raise ValueError("nonnegative coupling inputs required")
    return dipole_moment_c_m*electric_field_v_m/HBAR

def rabi_frequency_hz(dipole_moment_c_m,electric_field_v_m):
    return angular_rabi_frequency_rad_s(dipole_moment_c_m,electric_field_v_m)/(2*math.pi)

def photon_energy_j(wavelength_m):
    if wavelength_m<=0: raise ValueError("positive wavelength required")
    return H*C/wavelength_m

def two_photon_detuning_rad_s(delta_probe_rad_s,delta_control_rad_s):
    return delta_probe_rad_s+delta_control_rad_s

def eit_dark_state_rydberg_fraction(omega_probe_rad_s,omega_control_rad_s):
    if omega_probe_rad_s<0 or omega_control_rad_s<=0: raise ValueError("valid Rabi frequencies required")
    return omega_probe_rad_s**2/(omega_probe_rad_s**2+omega_control_rad_s**2)

def blockade_shift_rad_s(c6_j_m6,separation_m):
    if separation_m<=0: raise ValueError("positive separation required")
    return abs(c6_j_m6)/(HBAR*separation_m**6)

def blockade_radius_m(c6_j_m6,linewidth_rad_s):
    if linewidth_rad_s<=0: raise ValueError("positive linewidth required")
    if c6_j_m6==0:return 0.0
    return (abs(c6_j_m6)/(HBAR*linewidth_rad_s))**(1/6)

def rydberg_lifetime_scaling_s(reference_lifetime_s,n,reference_n,exponent=3.0):
    if reference_lifetime_s<=0 or n<=0 or reference_n<=0 or exponent<=0: raise ValueError("positive scaling inputs required")
    return reference_lifetime_s*(n/reference_n)**exponent

@dataclass(frozen=True)
class AtomicEnsemble:
    atom_count:int
    length_m:float
    area_m2:float
    resonant_cross_section_m2:float
    def __post_init__(self):
        if self.atom_count<1 or self.length_m<=0 or self.area_m2<=0 or self.resonant_cross_section_m2<=0:
            raise ValueError("positive ensemble parameters required")
    @property
    def volume_m3(self):return self.length_m*self.area_m2
    @property
    def number_density_m3(self):return self.atom_count/self.volume_m3
    @property
    def optical_depth(self):return self.atom_count*self.resonant_cross_section_m2/self.area_m2

@dataclass(frozen=True)
class EITMemoryEstimate:
    optical_depth:float
    control_rabi_rad_s:float
    excited_decay_rad_s:float
    ground_decoherence_rad_s:float=0.0
    def __post_init__(self):
        if self.optical_depth<0 or self.control_rabi_rad_s<=0 or self.excited_decay_rad_s<=0 or self.ground_decoherence_rad_s<0:
            raise ValueError("invalid EIT parameters")
    @property
    def transparency_bandwidth_rad_s(self):
        return self.control_rabi_rad_s**2/(self.excited_decay_rad_s*math.sqrt(max(self.optical_depth,1.0)))
    @property
    def idealized_efficiency_bound(self):
        # Monotonic OD-limited analytical bound; not a universal memory-efficiency law.
        od=self.optical_depth
        return (od/(1+od))**2 if od>0 else 0.0
    def coherence_survival(self,storage_time_s):
        if storage_time_s<0: raise ValueError("nonnegative storage time required")
        return math.exp(-self.ground_decoherence_rad_s*storage_time_s)

def collective_coupling_enhancement(single_atom_coupling_rad_s,atom_count):
    if single_atom_coupling_rad_s<0 or atom_count<1: raise ValueError("invalid collective coupling inputs")
    return single_atom_coupling_rad_s*math.sqrt(atom_count)
