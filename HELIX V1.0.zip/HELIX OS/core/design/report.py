def engineering_readiness_report(studio,design):
 r=studio.analysis_readiness(design)
 lines=[f"Design: {design.name} [{design.design_type}]",f"Components: {r['components']}",
 f"Physics coverage: {r['physics_coverage']:.1%}",f"Evidence coverage: {r['evidence_coverage']:.1%}",
 f"Provenance coverage: {r['provenance_coverage']:.1%}"]
 if r["validation_issues"]:lines.append("Issues: "+" | ".join(r["validation_issues"]))
 else:lines.append("Structural validation: PASS")
 return "\n".join(lines)
