from __future__ import annotations
from .models import ActionDefinition

class RegistryError(RuntimeError): pass

class ActionRegistry:
    def __init__(self):
        self._actions: dict[str, ActionDefinition] = {}

    def register(self, action: ActionDefinition) -> None:
        aid = action.action_id.strip()
        if not aid or "." not in aid:
            raise RegistryError("Action IDs must be namespaced, e.g. 'project.save'")
        if aid in self._actions:
            raise RegistryError(f"Action already registered: {aid}")
        self._actions[aid] = action

    def get(self, action_id: str) -> ActionDefinition:
        try:
            return self._actions[action_id]
        except KeyError as exc:
            raise RegistryError(f"Unknown action: {action_id}") from exc

    def all(self) -> tuple[ActionDefinition, ...]:
        return tuple(sorted(self._actions.values(), key=lambda a: (a.category, a.title)))

    def by_category(self) -> dict[str, list[ActionDefinition]]:
        result: dict[str, list[ActionDefinition]] = {}
        for action in self.all():
            result.setdefault(action.category, []).append(action)
        return result
