from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import C_M_S,LIGHT_YEAR_M

H_J_S=6.62607015e-34

def photon_energy_j(wavelength_m):
    if wavelength_m<=0:raise ValueError("wavelength positive")
    return H_J_S*C_M_S/wavelength_m

def airy_divergence_rad(wavelength_m,transmitter_diameter_m):
    if wavelength_m<=0 or transmitter_diameter_m<=0:raise ValueError("positive optical dimensions")
    return 1.22*wavelength_m/transmitter_diameter_m

def airy_spot_radius_m(distance_m,wavelength_m,transmitter_diameter_m):
    if distance_m<0:raise ValueError("distance nonnegative")
    return distance_m*airy_divergence_rad(wavelength_m,transmitter_diameter_m)

def receiver_geometric_capture_fraction(receiver_diameter_m,spot_radius_m):
    if receiver_diameter_m<=0 or spot_radius_m<=0:raise ValueError("positive dimensions")
    # Uniform-disc approximation to central diffraction footprint; bounded.
    return min(1.0,(receiver_diameter_m/(2*spot_radius_m))**2)

def pointing_efficiency_gaussian(pointing_error_rad,distance_m,spot_radius_m):
    if pointing_error_rad<0 or distance_m<0 or spot_radius_m<=0:raise ValueError("invalid pointing")
    offset=pointing_error_rad*distance_m
    return math.exp(-2*(offset/spot_radius_m)**2)

def received_optical_power_w(transmit_power_w,tx_efficiency,capture_fraction,pointing_efficiency,rx_efficiency):
    vals=(tx_efficiency,capture_fraction,pointing_efficiency,rx_efficiency)
    if transmit_power_w<0 or not all(0<=x<=1 for x in vals):raise ValueError("invalid power/efficiencies")
    out=transmit_power_w
    for x in vals:out*=x
    return out

def detected_photon_rate_per_s(received_power_w,wavelength_m,detector_efficiency=1.0):
    if received_power_w<0 or not 0<=detector_efficiency<=1:raise ValueError("invalid detector inputs")
    return received_power_w/photon_energy_j(wavelength_m)*detector_efficiency

def background_photon_rate_per_s(background_power_w,wavelength_m,detector_efficiency=1.0):
    return detected_photon_rate_per_s(background_power_w,wavelength_m,detector_efficiency)

def photon_signal_to_background(signal_rate_per_s,background_rate_per_s):
    if signal_rate_per_s<0 or background_rate_per_s<0:raise ValueError("rates nonnegative")
    return math.inf if background_rate_per_s==0 else signal_rate_per_s/background_rate_per_s

def ideal_photon_limited_bit_rate_bps(detected_signal_photons_per_s,photons_per_bit):
    if detected_signal_photons_per_s<0 or photons_per_bit<=0:raise ValueError("invalid photon budget")
    return detected_signal_photons_per_s/photons_per_bit

def phased_array_effective_diameter_m(element_diameter_m,element_count,fill_factor=1.0):
    if element_diameter_m<=0 or element_count<1 or int(element_count)!=element_count or not 0<fill_factor<=1:
        raise ValueError("invalid array")
    # Equal collecting/emitting-area diameter, not coherent-baseline diameter.
    return element_diameter_m*math.sqrt(int(element_count)*fill_factor)

def phased_array_total_power_w(element_power_w,element_count,combining_efficiency=1.0):
    if element_power_w<0 or element_count<1 or int(element_count)!=element_count or not 0<=combining_efficiency<=1:
        raise ValueError("invalid array")
    return element_power_w*int(element_count)*combining_efficiency

def pointing_requirement_rad(spot_radius_m,distance_m,max_offset_fraction=.1):
    if spot_radius_m<0 or distance_m<=0 or not 0<max_offset_fraction<=1:raise ValueError("invalid requirement")
    return max_offset_fraction*spot_radius_m/distance_m

@dataclass(frozen=True)
class InterstellarOpticalLink:
    distance_ly:float
    wavelength_m:float
    transmit_power_w:float
    transmitter_diameter_m:float
    receiver_diameter_m:float
    pointing_error_rad:float=0.0
    tx_efficiency:float=1.0
    rx_efficiency:float=1.0
    detector_efficiency:float=1.0
    background_power_w:float=0.0
    photons_per_bit:float=10.0
    def __post_init__(self):
        if self.distance_ly<=0 or self.wavelength_m<=0 or self.transmit_power_w<0 or self.transmitter_diameter_m<=0 or self.receiver_diameter_m<=0 or self.pointing_error_rad<0 or self.background_power_w<0 or self.photons_per_bit<=0:
            raise ValueError("invalid link")
        if not all(0<=x<=1 for x in (self.tx_efficiency,self.rx_efficiency,self.detector_efficiency)):raise ValueError("efficiencies in [0,1]")
    @property
    def distance_m(self):return self.distance_ly*LIGHT_YEAR_M
    @property
    def divergence_rad(self):return airy_divergence_rad(self.wavelength_m,self.transmitter_diameter_m)
    @property
    def spot_radius_m(self):return airy_spot_radius_m(self.distance_m,self.wavelength_m,self.transmitter_diameter_m)
    @property
    def capture_fraction(self):return receiver_geometric_capture_fraction(self.receiver_diameter_m,self.spot_radius_m)
    @property
    def pointing_efficiency(self):return pointing_efficiency_gaussian(self.pointing_error_rad,self.distance_m,self.spot_radius_m)
    @property
    def received_power_w(self):return received_optical_power_w(self.transmit_power_w,self.tx_efficiency,self.capture_fraction,self.pointing_efficiency,self.rx_efficiency)
    @property
    def detected_signal_photons_per_s(self):return detected_photon_rate_per_s(self.received_power_w,self.wavelength_m,self.detector_efficiency)
    @property
    def detected_background_photons_per_s(self):return background_photon_rate_per_s(self.background_power_w,self.wavelength_m,self.detector_efficiency)
    @property
    def signal_to_background(self):return photon_signal_to_background(self.detected_signal_photons_per_s,self.detected_background_photons_per_s)
    @property
    def ideal_bit_rate_bps(self):return ideal_photon_limited_bit_rate_bps(self.detected_signal_photons_per_s,self.photons_per_bit)
