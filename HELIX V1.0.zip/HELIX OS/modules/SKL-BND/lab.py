from __future__ import annotations
from dataclasses import dataclass,asdict
from enum import Enum
import hashlib,json,math,random,statistics
from .foundation import BoundaryEvidence,C_M_S
from .axion import photon_axion_conversion_probability
from .dark_photon import photon_dark_photon_probability
from .qft_vacuum import causal_message_latency_s
from .curved_spacetime import flat_light_time_s
from .wormhole import wormhole_transit_time_s
from .warp_metric import effective_transit_time_s
from .causality import local_vs_effective_ftl,FTLClaimClass

class BoundaryFamily(str,Enum):
    ORDINARY_RELATIVISTIC="ORDINARY_RELATIVISTIC"
    QFT_VACUUM="QFT_VACUUM"
    AXION_ALP="AXION_ALP"
    DARK_PHOTON="DARK_PHOTON"
    CURVED_SPACETIME="CURVED_SPACETIME"
    WORMHOLE="WORMHOLE"
    WARP_METRIC="WARP_METRIC"

@dataclass(frozen=True)
class BoundaryScenario:
    family:BoundaryFamily
    distance_m:float
    evidence:BoundaryEvidence
    local_signal_speed_m_s:float=C_M_S
    effective_endpoint_speed_m_s:float=C_M_S
    viability_metric:float=1.0
    engineering_metric:float=1.0
    notes:str=""
    def __post_init__(self):
        if self.distance_m<0 or self.local_signal_speed_m_s<0 or self.effective_endpoint_speed_m_s<=0:raise ValueError("invalid scenario")
        if not 0<=self.viability_metric<=1 or not 0<=self.engineering_metric<=1:raise ValueError("metrics normalized to [0,1]")
    @property
    def latency_s(self):return self.distance_m/self.effective_endpoint_speed_m_s
    @property
    def ftl_class(self):return local_vs_effective_ftl(self.local_signal_speed_m_s,self.effective_endpoint_speed_m_s)

@dataclass(frozen=True)
class BoundaryExperimentRecord:
    experiment_id:str
    scenario:BoundaryScenario
    seed:int
    model_version:str="BND-09"
    source_state:str="SIMULATION"
    def fingerprint(self):
        payload=json.dumps({"id":self.experiment_id,"scenario":asdict(self.scenario),"seed":self.seed,"model":self.model_version,"source":self.source_state},sort_keys=True,default=str)
        return hashlib.sha256(payload.encode()).hexdigest()

def compare_scenarios(scenarios):
    """Returns transparent dimensions only; never collapses them into an arbitrary feasibility score."""
    return sorted([{
        "family":s.family.value,"latency_s":s.latency_s,"evidence":s.evidence.value,
        "physics_viability":s.viability_metric,"engineering_feasibility":s.engineering_metric,
        "ftl_class":s.ftl_class.value
    } for s in scenarios],key=lambda x:(x["latency_s"],x["family"]))

def pareto_front(scenarios):
    """Minimize latency, maximize physics viability and engineering feasibility."""
    out=[]
    for a in scenarios:
        dominated=False
        for b in scenarios:
            if a is b:continue
            no_worse=b.latency_s<=a.latency_s and b.viability_metric>=a.viability_metric and b.engineering_metric>=a.engineering_metric
            strict=b.latency_s<a.latency_s or b.viability_metric>a.viability_metric or b.engineering_metric>a.engineering_metric
            if no_worse and strict:dominated=True;break
        if not dominated:out.append(a)
    return out

def parameter_sweep(factory,values):
    return [factory(v) for v in values]

def monte_carlo_latency(base_scenario,relative_sigma=0.05,samples=1000,seed=0):
    if relative_sigma<0 or samples<1:raise ValueError("invalid Monte Carlo")
    rng=random.Random(seed); vals=[]
    for _ in range(samples):
        speed=max(1e-30,rng.gauss(base_scenario.effective_endpoint_speed_m_s,abs(base_scenario.effective_endpoint_speed_m_s)*relative_sigma))
        vals.append(base_scenario.distance_m/speed)
    vals.sort()
    def pct(p):return vals[min(len(vals)-1,max(0,int(round(p*(len(vals)-1)))))]
    return {"mean_s":statistics.fmean(vals),"median_s":statistics.median(vals),"p05_s":pct(.05),"p95_s":pct(.95),"samples":samples,"seed":seed}

def evidence_partition(scenarios):
    out={}
    for s in scenarios:out.setdefault(s.evidence.value,[]).append(s)
    return out

def visualization_dataset(scenarios):
    return [{"family":s.family.value,"latency_s":s.latency_s,"physics_viability":s.viability_metric,
             "engineering_feasibility":s.engineering_metric,"evidence":s.evidence.value,
             "effective_speed_over_c":s.effective_endpoint_speed_m_s/C_M_S} for s in scenarios]

def guardian_summary(scenarios):
    rows=compare_scenarios(scenarios)
    speculative=sum(r["evidence"] in ("SPECULATIVE_UNRESOLVED","NEW_PHYSICS_REQUIRED") for r in rows)
    effective=sum(r["ftl_class"]!="NONE" for r in rows)
    return {"scenario_count":len(rows),"speculative_or_new_physics_count":speculative,
            "effective_or_local_ftl_count":effective,
            "warning":"Simulation output is not empirical evidence. Physics viability and engineering feasibility remain separate dimensions."}

class BoundaryPhysicsLab:
    def __init__(self):self._records={}
    def add(self,record):
        if record.experiment_id in self._records:raise ValueError("duplicate experiment id")
        self._records[record.experiment_id]=record;return record
    def get(self,experiment_id):return self._records[experiment_id]
    def all(self):return tuple(self._records.values())
    def compare(self):return compare_scenarios([r.scenario for r in self._records.values()])
    def visualization_dataset(self):return visualization_dataset([r.scenario for r in self._records.values()])
    def guardian_summary(self):return guardian_summary([r.scenario for r in self._records.values()])
