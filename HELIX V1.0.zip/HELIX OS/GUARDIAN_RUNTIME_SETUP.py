from __future__ import annotations
import importlib.util, subprocess, sys

def has_llama():
    return importlib.util.find_spec("llama_cpp") is not None

def main():
    if has_llama():
        print("llama-cpp-python already available.")
        print("GUARDIAN_LLAMA_STATUS=READY")
        return 0

    print("llama-cpp-python is not installed yet.")
    print("Checking for a prebuilt llama-cpp-python wheel (no source compilation)...")
    p=subprocess.run(
        [sys.executable,"-m","pip","install","--only-binary=:all:","llama-cpp-python>=0.3.0"],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True
    )
    if p.returncode==0 and has_llama():
        print(p.stdout, end="")
        print("Prebuilt llama-cpp-python installed and import verified.")
        print("GUARDIAN_LLAMA_STATUS=READY")
    else:
        # Do not echo pip's expected ERROR stream back as an error. Summarize cleanly.
        print("No compatible prebuilt llama-cpp-python wheel is available for this Windows/Python environment.")
        print("This is an expected optional-runtime result, NOT a HELIX installation failure.")
        print("Guardian will continue to hardware diagnostics for hardware-specific runtime selection.")
        print("GUARDIAN_LLAMA_STATUS=PENDING")
    return 0

if __name__=="__main__":
    raise SystemExit(main())
