from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import H,C,K_B,photon_energy_j_from_wavelength

Q_E=1.602176634e-19

def telescope_collection_area_m2(diameter_m,obscuration_ratio=0.0):
    if diameter_m<=0 or not 0<=obscuration_ratio<1: raise ValueError("invalid telescope")
    return math.pi*(diameter_m/2)**2*(1-obscuration_ratio**2)

def photodiode_responsivity_a_per_w(wavelength_m,quantum_efficiency):
    if wavelength_m<=0 or not 0<=quantum_efficiency<=1: raise ValueError("invalid detector")
    return quantum_efficiency*Q_E*wavelength_m/(H*C)

def photocurrent_a(optical_power_w,responsivity_a_per_w):
    if optical_power_w<0 or responsivity_a_per_w<0: raise ValueError("invalid optical power/responsivity")
    return optical_power_w*responsivity_a_per_w

def shot_noise_current_rms_a(average_current_a,bandwidth_hz):
    if average_current_a<0 or bandwidth_hz<0: raise ValueError("invalid current/bandwidth")
    return math.sqrt(2*Q_E*average_current_a*bandwidth_hz)

def thermal_noise_current_rms_a(temperature_k,bandwidth_hz,resistance_ohm):
    if temperature_k<0 or bandwidth_hz<0 or resistance_ohm<=0: raise ValueError("invalid thermal inputs")
    return math.sqrt(4*K_B*temperature_k*bandwidth_hz/resistance_ohm)

def photon_count_rate_per_s(optical_power_w,wavelength_m,quantum_efficiency=1.0):
    if optical_power_w<0 or wavelength_m<=0 or not 0<=quantum_efficiency<=1: raise ValueError("invalid count inputs")
    return optical_power_w/photon_energy_j_from_wavelength(wavelength_m)*quantum_efficiency

def total_count_rate_per_s(signal_rate,dark_rate,background_rate):
    if min(signal_rate,dark_rate,background_rate)<0: raise ValueError("rates nonnegative")
    return signal_rate+dark_rate+background_rate

def photon_counting_snr(signal_rate,dark_rate,background_rate,integration_time_s):
    if min(signal_rate,dark_rate,background_rate)<0 or integration_time_s<=0: raise ValueError("invalid count SNR inputs")
    ns=signal_rate*integration_time_s
    nt=total_count_rate_per_s(signal_rate,dark_rate,background_rate)*integration_time_s
    return ns/math.sqrt(nt) if nt>0 else 0.0

def noise_equivalent_power_w_per_sqrt_hz(noise_current_a_per_sqrt_hz,responsivity_a_per_w):
    if noise_current_a_per_sqrt_hz<0 or responsivity_a_per_w<=0: raise ValueError("invalid NEP inputs")
    return noise_current_a_per_sqrt_hz/responsivity_a_per_w

def apd_excess_noise_factor(gain,k_ionization):
    if gain<1 or not 0<=k_ionization<=1: raise ValueError("invalid APD")
    return k_ionization*gain+(1-k_ionization)*(2-1/gain)

def apd_signal_current_a(primary_photocurrent_a,gain):
    if primary_photocurrent_a<0 or gain<1: raise ValueError("invalid APD")
    return primary_photocurrent_a*gain

def minimum_power_for_photon_count_snr_w(target_snr,wavelength_m,quantum_efficiency,integration_time_s,dark_rate=0.0,background_rate=0.0):
    if target_snr<0 or wavelength_m<=0 or not 0<quantum_efficiency<=1 or integration_time_s<=0 or min(dark_rate,background_rate)<0:
        raise ValueError("invalid sensitivity inputs")
    if target_snr==0:return 0.0
    b=(dark_rate+background_rate)*integration_time_s
    # Solve S/sqrt(S+B)=gamma for expected signal counts S.
    g2=target_snr**2
    s=(g2+math.sqrt(g2*g2+4*g2*b))/2
    rate=s/integration_time_s
    return rate*photon_energy_j_from_wavelength(wavelength_m)/quantum_efficiency

@dataclass(frozen=True)
class PhotonCountingReceiver:
    wavelength_m:float
    quantum_efficiency:float
    dark_count_rate_per_s:float=0.0
    background_count_rate_per_s:float=0.0
    integration_time_s:float=1.0
    telescope_diameter_m:float=1.0
    obscuration_ratio:float=0.0
    optical_efficiency:float=1.0
    def __post_init__(self):
        if self.wavelength_m<=0 or not 0<self.quantum_efficiency<=1 or min(self.dark_count_rate_per_s,self.background_count_rate_per_s)<0 or self.integration_time_s<=0 or self.telescope_diameter_m<=0:
            raise ValueError("invalid receiver")
        if not 0<=self.obscuration_ratio<1 or not 0<=self.optical_efficiency<=1: raise ValueError("invalid optical geometry/efficiency")
    @property
    def collection_area_m2(self): return telescope_collection_area_m2(self.telescope_diameter_m,self.obscuration_ratio)
    def signal_rate_per_s(self,incident_collected_power_w):
        return photon_count_rate_per_s(incident_collected_power_w*self.optical_efficiency,self.wavelength_m,self.quantum_efficiency)
    def snr(self,incident_collected_power_w):
        return photon_counting_snr(self.signal_rate_per_s(incident_collected_power_w),self.dark_count_rate_per_s,self.background_count_rate_per_s,self.integration_time_s)
    def sensitivity_w(self,target_snr):
        detector_input=minimum_power_for_photon_count_snr_w(target_snr,self.wavelength_m,self.quantum_efficiency,self.integration_time_s,self.dark_count_rate_per_s,self.background_count_rate_per_s)
        if self.optical_efficiency==0:return math.inf
        return detector_input/self.optical_efficiency
