from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

@dataclass
class ExperimentRecord:
    experiment_id: str
    name: str
    created_utc: str
    modified_utc: str
    state: str = "DRAFT"
    mode: str = "SIMULATION"
    notes: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def create(cls, name: str, mode: str = "SIMULATION"):
        now = utc_now()
        return cls(
            experiment_id=f"EXP-{uuid4().hex[:12].upper()}",
            name=name, created_utc=now, modified_utc=now, mode=mode
        )

    def to_dict(self):
        return asdict(self)

@dataclass
class ProjectRecord:
    project_id: str
    name: str
    created_utc: str
    modified_utc: str
    description: str = ""
    experiments: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def create(cls, name: str, description: str = ""):
        now = utc_now()
        return cls(
            project_id=f"PRJ-{uuid4().hex[:12].upper()}",
            name=name, description=description,
            created_utc=now, modified_utc=now
        )

    def to_dict(self):
        return asdict(self)

@dataclass
class SessionRecord:
    session_id: str
    started_utc: str
    modified_utc: str
    project_path: str | None = None
    active_experiment_id: str | None = None
    workspace_layout: str | None = None
    dirty: bool = False

    @classmethod
    def create(cls):
        now = utc_now()
        return cls(
            session_id=f"SES-{uuid4().hex[:12].upper()}",
            started_utc=now, modified_utc=now
        )

    def to_dict(self):
        return asdict(self)
