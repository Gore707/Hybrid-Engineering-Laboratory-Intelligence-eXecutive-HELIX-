import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ECC"
sp=importlib.util.spec_from_file_location("skl_ecc",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_ecc"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 M=1.67262192369e-27
 def test_gamma_rest(self):self.assertEqual(q.lorentz_gamma_from_kinetic_energy_j(0,self.M),1)
 def test_beta(self):self.assertAlmostEqual(q.beta_from_gamma(1),0)
 def test_speed_sub_c(self):self.assertLess(q.speed_from_kinetic_energy_j(1e-9,self.M),q.C_M_S)
 def test_ev(self):self.assertAlmostEqual(q.kinetic_energy_j_from_ev(1),q.EV_J)
 def test_latency_gt_light(self):
  e=q.kinetic_energy_j_from_ev(1e12);self.assertGreater(q.particle_latency_s(q.C_M_S,e,self.M),1)
 def test_beam_area(self):self.assertAlmostEqual(q.beam_area_m2(1e6,1e-6),math.pi)
 def test_momentum(self):self.assertGreater(q.relativistic_momentum_kg_m_s(self.M,1e-9),0)
 def test_gyroradius(self):self.assertGreater(q.magnetic_gyroradius_m(1e-18,q.E_CHARGE_C,1e-9),0)
 def test_deflection(self):self.assertEqual(q.small_angle_magnetic_deflection_rad(10,100),.1)
 def test_survival(self):self.assertAlmostEqual(q.survival_probability(100,100),math.exp(-1))
 def test_detect(self):self.assertEqual(q.detected_particle_rate_s(1000,100,10,.5,.5),25)
 def test_rate(self):self.assertEqual(q.ideal_particle_bit_rate_bps(100,10),10)
 def test_power(self):self.assertEqual(q.beam_power_w(100,2,.5),400)
 def test_perveance_decreases_relativistic(self):self.assertLess(q.generalized_perveance(1,.99,7,1e7),q.generalized_perveance(1,.5,1.15,1e7))
 def test_link(self):
  a=q.ParticleBeamLink(self.M,1e-8,1e15,1e9,1e-9,10,.9,.8,10);self.assertTrue(0<a.beta<1);self.assertGreater(a.detected_rate_s,0)
 def test_hep_preserved(self):self.assertGreater(q.photon_energy_kev_from_wavelength(1e-10),0)
 def test_neutrino_preserved(self):self.assertGreater(q.approximate_cc_cross_section_m2(1),0)
 def test_causality_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ECC-PB-GAMMA","ECC-PB-BETA","ECC-PB-GYRO","ECC-PB-SURV","ECC-PB-RX","ECC-PB-PERVEANCE"}<={x.model_id for x in q.ExtremeCarrierRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-ECC-04")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
