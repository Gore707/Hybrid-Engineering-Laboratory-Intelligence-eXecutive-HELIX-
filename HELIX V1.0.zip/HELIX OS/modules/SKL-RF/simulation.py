from __future__ import annotations
from dataclasses import dataclass,replace
from enum import Enum
import math
from .foundation import K_B,db_to_linear,linear_to_db,w_to_dbm
from .propagation import PropagationLossBudget
from .digital import Modulation,ber_bpsk_awgn,ber_qpsk_awgn,ber_square_mqam_awgn_approx,packet_error_rate_from_ber,goodput_bps,symbol_rate_baud,nyquist_baseband_bandwidth_hz

class LinkStatus(str,Enum):
    PASS="PASS"; MARGINAL="MARGINAL"; FAIL="FAIL"

@dataclass(frozen=True)
class IntegratedRFScenario:
    transmit_power_w:float
    tx_gain_linear:float
    rx_gain_linear:float
    propagation:PropagationLossBudget
    receiver_noise_factor:float
    receiver_temperature_k:float
    bit_rate_bps:float
    modulation:Modulation
    code_rate:float=1.0
    rolloff:float=0.0
    required_ebn0_db:float=0.0
    coding_gain_db:float=0.0
    packet_bits:int=1024
    protocol_efficiency:float=1.0
    tx_misc_loss_db:float=0.0
    rx_misc_loss_db:float=0.0
    marginal_threshold_db:float=3.0
    def __post_init__(self):
        if self.transmit_power_w<0 or self.tx_gain_linear<0 or self.rx_gain_linear<0: raise ValueError("invalid power/gain")
        if self.receiver_noise_factor<1 or self.receiver_temperature_k<0 or self.bit_rate_bps<=0: raise ValueError("invalid receiver/data inputs")
        if not 0<self.code_rate<=1 or not 0<=self.rolloff<=1 or self.packet_bits<0 or not 0<=self.protocol_efficiency<=1:
            raise ValueError("invalid digital inputs")
        if min(self.tx_misc_loss_db,self.rx_misc_loss_db,self.marginal_threshold_db)<0: raise ValueError("loss/threshold nonnegative")

@dataclass(frozen=True)
class IntegratedRFResult:
    received_power_w:float
    received_power_dbm:float
    noise_power_w:float
    bandwidth_hz:float
    snr_linear:float
    ebn0_linear:float
    ebn0_db:float
    link_margin_db:float
    ber:float
    packet_error_rate:float
    goodput_bps:float
    status:LinkStatus
    evidence:str="SIMULATION"

def _ber(mod,ebn0):
    if mod==Modulation.BPSK:return ber_bpsk_awgn(ebn0)
    if mod==Modulation.QPSK:return ber_qpsk_awgn(ebn0)
    return ber_square_mqam_awgn_approx(ebn0,{Modulation.QAM16:16,Modulation.QAM64:64,Modulation.QAM256:256}[mod])

def simulate_rf_link(s):
    if not isinstance(s,IntegratedRFScenario): raise TypeError("IntegratedRFScenario required")
    total_loss_db=s.propagation.total_loss_db+s.tx_misc_loss_db+s.rx_misc_loss_db
    pr=s.transmit_power_w*s.tx_gain_linear*s.rx_gain_linear*10**(-total_loss_db/10)
    rs=symbol_rate_baud(s.bit_rate_bps,s.modulation,s.code_rate)
    bw=nyquist_baseband_bandwidth_hz(rs,s.rolloff)
    noise=K_B*s.receiver_temperature_k*bw*s.receiver_noise_factor
    snr=pr/noise if noise>0 else math.inf
    ebn0=snr*bw/s.bit_rate_bps
    ebn0_db=linear_to_db(ebn0) if ebn0>0 else -math.inf
    effective_ebn0=ebn0*10**(s.coding_gain_db/10)
    effective_ebn0_db=ebn0_db+s.coding_gain_db
    margin=effective_ebn0_db-s.required_ebn0_db
    ber=_ber(s.modulation,effective_ebn0)
    per=packet_error_rate_from_ber(ber,s.packet_bits)
    gp=goodput_bps(s.bit_rate_bps,per,s.protocol_efficiency)
    status=LinkStatus.PASS if margin>=s.marginal_threshold_db else (LinkStatus.MARGINAL if margin>=0 else LinkStatus.FAIL)
    return IntegratedRFResult(pr,w_to_dbm(pr) if pr>0 else -math.inf,noise,bw,snr,ebn0,ebn0_db,margin,ber,per,gp,status)

def sweep_distance(scenario,distances_m):
    out=[]
    for d in distances_m:
        p=replace(scenario.propagation,distance_m=float(d))
        out.append((float(d),simulate_rf_link(replace(scenario,propagation=p))))
    return tuple(out)

def sweep_transmit_power(scenario,powers_w):
    return tuple((float(p),simulate_rf_link(replace(scenario,transmit_power_w=float(p)))) for p in powers_w)

def minimum_transmit_power_for_margin_w(scenario,target_margin_db=0.0):
    if target_margin_db < -300: raise ValueError("unreasonable target")
    base=simulate_rf_link(replace(scenario,transmit_power_w=1.0))
    required_delta_db=target_margin_db-base.link_margin_db
    return 10**(required_delta_db/10)
