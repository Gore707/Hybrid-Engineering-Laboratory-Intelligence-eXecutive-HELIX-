import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QCOM"
sp=importlib.util.spec_from_file_location("skl_qcom",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qcom"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_bell_norm(self):
  for b in q.BellState:self.assertAlmostEqual(q.state_vector_norm_squared(q.bell_state_vector(b)),1)
 def test_bell_concurrence(self):
  for b in q.BellState:self.assertAlmostEqual(q.pure_two_qubit_concurrence(q.bell_state_vector(b)),1)
 def test_product_concurrence(self):self.assertEqual(q.pure_two_qubit_concurrence((1,0,0,0)),0)
 def test_bad_concurrence(self):
  with self.assertRaises(ValueError):q.pure_two_qubit_concurrence((1,1,0,0))
 def test_werner_fidelity(self):self.assertEqual(q.bell_fidelity_from_visibility(1),1)
 def test_werner_mixed(self):self.assertEqual(q.bell_fidelity_from_visibility(0),.25)
 def test_werner_concurrence(self):self.assertEqual(q.werner_concurrence(1),1)
 def test_coincidence(self):self.assertEqual(q.coincidence_rate_per_s(1000,.5,.4),200)
 def test_herald(self):self.assertEqual(q.herald_rate_per_s(1000,.5),500)
 def test_conditional(self):self.assertEqual(q.conditional_signal_probability(.8),.8)
 def test_accidental(self):self.assertEqual(q.accidental_coincidence_rate_per_s(1000,2000,1e-9),.002)
 def test_visibility(self):self.assertAlmostEqual(q.measured_visibility(9,1),.9)
 def test_distribution_probability(self):self.assertEqual(q.distribution_success_probability(.5,.5,.5),.125)
 def test_source(self):self.assertEqual(q.EntangledPairSource(1000,1,.5,.5).collected_pair_rate_per_s,250)
 def test_distribution(self):
  s=q.EntangledPairSource(1000,1,.8,.7);d=q.EntanglementDistribution(s,.5,.4,.9,.8)
  self.assertAlmostEqual(d.detected_coincidence_rate_per_s,1000*(.8*.5*.9)*(.7*.4*.8))
 def test_foundation_preserved(self):self.assertEqual(q.binary_entropy_bits(.5),1)
 def test_no_signalling_preserved(self):self.assertEqual(q.no_signalling_remote_probability("anything"),(.5,.5))
 def test_registry(self):self.assertTrue({"QCOM-BELL","QCOM-CONCURRENCE","QCOM-COINC","QCOM-DIST"}<={x.model_id for x in q.QuantumCommRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QCOM-02")
 def test_opt_complete(self):self.assertEqual(json.loads((R/"OPT_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
