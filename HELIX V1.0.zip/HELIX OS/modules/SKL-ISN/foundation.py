from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

C_M_S=299792458.0
LIGHT_YEAR_M=9460730472580800.0
PARSEC_M=3.085677581491367e16

class InterstellarNodeKind(str,Enum):
    STELLAR_SYSTEM="STELLAR_SYSTEM"
    RELAY="RELAY"
    OBSERVATORY="OBSERVATORY"
    DEEP_SPACE_TERMINAL="DEEP_SPACE_TERMINAL"
    GRAVITATIONAL_LENS_TERMINAL="GRAVITATIONAL_LENS_TERMINAL"

def light_years_to_m(light_years):
    if light_years<0:raise ValueError("distance nonnegative")
    return light_years*LIGHT_YEAR_M

def parsecs_to_m(parsecs):
    if parsecs<0:raise ValueError("distance nonnegative")
    return parsecs*PARSEC_M

def one_way_latency_s(distance_m,propagation_speed_m_s=C_M_S):
    if distance_m<0 or not 0<propagation_speed_m_s<=C_M_S:raise ValueError("invalid causal propagation")
    return distance_m/propagation_speed_m_s

def one_way_latency_years_from_ly(distance_ly,propagation_fraction_c=1.0):
    if distance_ly<0 or not 0<propagation_fraction_c<=1:raise ValueError("invalid causal propagation")
    return distance_ly/propagation_fraction_c

def round_trip_latency_years_from_ly(distance_ly,propagation_fraction_c=1.0):
    return 2*one_way_latency_years_from_ly(distance_ly,propagation_fraction_c)

def free_space_power_flux_w_m2(transmit_power_w,distance_m):
    if transmit_power_w<0 or distance_m<=0:raise ValueError("invalid power/distance")
    return transmit_power_w/(4*math.pi*distance_m**2)

def inverse_square_relative_flux(distance_a_m,distance_b_m):
    if distance_a_m<=0 or distance_b_m<=0:raise ValueError("distances positive")
    return (distance_a_m/distance_b_m)**2

def store_and_forward_delivery_time_s(segment_distances_m,processing_delays_s=0.0,propagation_speed_m_s=C_M_S):
    if not segment_distances_m or any(d<0 for d in segment_distances_m) or processing_delays_s<0:
        raise ValueError("invalid route")
    if not 0<propagation_speed_m_s<=C_M_S:raise ValueError("causal speed required")
    return sum(segment_distances_m)/propagation_speed_m_s + max(0,len(segment_distances_m)-1)*processing_delays_s

def relay_count_for_max_segment(total_distance_m,max_segment_m):
    if total_distance_m<0 or max_segment_m<=0:raise ValueError("invalid distances")
    segments=max(1,math.ceil(total_distance_m/max_segment_m))
    return max(0,segments-1)

def equal_relay_segment_length_m(total_distance_m,relay_count):
    if total_distance_m<0 or relay_count<0 or int(relay_count)!=relay_count:raise ValueError("invalid route")
    return total_distance_m/(int(relay_count)+1)

def clock_drift_uncertainty_s(elapsed_s,fractional_frequency_error):
    if elapsed_s<0 or fractional_frequency_error<0:raise ValueError("nonnegative inputs")
    return elapsed_s*fractional_frequency_error

def required_fractional_clock_stability(max_timing_error_s,elapsed_s):
    if max_timing_error_s<0 or elapsed_s<=0:raise ValueError("invalid timing")
    return max_timing_error_s/elapsed_s

def causality_bypass_available(): return False

@dataclass(frozen=True)
class StellarNetworkNode:
    node_id:str
    kind:InterstellarNodeKind
    x_ly:float
    y_ly:float
    z_ly:float
    processing_delay_s:float=0.0
    def __post_init__(self):
        if not self.node_id or self.processing_delay_s<0:raise ValueError("invalid node")
    def distance_ly_to(self,other:"StellarNetworkNode"):
        return math.sqrt((self.x_ly-other.x_ly)**2+(self.y_ly-other.y_ly)**2+(self.z_ly-other.z_ly)**2)
    def latency_years_to(self,other:"StellarNetworkNode"):
        return one_way_latency_years_from_ly(self.distance_ly_to(other))

@dataclass(frozen=True)
class InterstellarRouteAssessment:
    total_distance_ly:float
    hop_count:int
    relay_count:int
    propagation_latency_years:float
    processing_latency_s:float
    longest_segment_ly:float

def assess_route(segment_distances_ly,processing_delay_s=0.0):
    if not segment_distances_ly or any(x<0 for x in segment_distances_ly) or processing_delay_s<0:raise ValueError("invalid route")
    return InterstellarRouteAssessment(sum(segment_distances_ly),len(segment_distances_ly),
      max(0,len(segment_distances_ly)-1),sum(segment_distances_ly),
      max(0,len(segment_distances_ly)-1)*processing_delay_s,max(segment_distances_ly))
