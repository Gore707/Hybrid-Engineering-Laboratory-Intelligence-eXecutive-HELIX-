# HELIX Core Schemas

Reserved for the canonical JSON Schema Draft 2020-12 contracts introduced in
SKL-CORE-C09. C01 creates the stable resource location only; it does not
prematurely implement later-patch schema behavior.
