import os
import threading
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from core.bootstrap.config import load_config
from core.bootstrap.identity import IDENTITY
from core.bus.bus import HelixBus, MessageValidationError, TypeRegistrationError
from core.bus.factory import create_core_bus
from core.bus.messages import (
    Provenance, TelemetrySample, ExperimentStateEvent, DataReferenceEvent
)

ROOT = Path(__file__).resolve().parents[1]

class C05Tests(unittest.TestCase):
    def setUp(self):
        self.prov = Provenance("SIMULATION", "test.solver", 0.95, "TEST")

    def test_identity_config(self):
        cfg = load_config(ROOT/"skl.config")
        self.assertEqual(IDENTITY.patch_id, "SKL-CORE-C05")
        self.assertTrue(cfg["bus"]["typed"])

    def test_typed_publish_subscribe(self):
        bus = create_core_bus()
        got = []
        sub = bus.subscribe("telemetry.sample", got.append)
        msg = TelemetrySample(
            topic="telemetry.sample", provenance=self.prov,
            quantity="temperature", value=4.2, unit="K"
        )
        self.assertEqual(bus.publish(msg), 1)
        self.assertIs(got[0], msg)
        bus.unsubscribe(sub)
        self.assertEqual(bus.publish(msg), 0)

    def test_wrong_type_rejected(self):
        bus = create_core_bus()
        msg = ExperimentStateEvent(
            topic="telemetry.sample", provenance=self.prov,
            experiment_id="EXP-X", state="RUNNING"
        )
        with self.assertRaises(MessageValidationError):
            bus.publish(msg)

    def test_unregistered_topic_rejected(self):
        bus = create_core_bus()
        msg = TelemetrySample(
            topic="unknown.topic", provenance=self.prov,
            quantity="x", value=1.0, unit="m"
        )
        with self.assertRaises(MessageValidationError):
            bus.publish(msg)

    def test_provenance_validation(self):
        with self.assertRaises(ValueError):
            Provenance("INVENTED", "bad")
        with self.assertRaises(ValueError):
            Provenance("HARDWARE", "sensor", 1.5)

    def test_bulk_data_is_reference(self):
        bus = create_core_bus()
        msg = DataReferenceEvent(
            topic="data.reference", provenance=self.prov,
            dataset_id="DS-001", uri="hdf5://run.h5/spectrum",
            media_type="application/x-hdf5"
        )
        bus.publish(msg)
        self.assertEqual(bus.history("data.reference")[0].dataset_id, "DS-001")

    def test_threaded_publish(self):
        bus = create_core_bus(history_per_topic=100)
        count = 40
        def worker(i):
            bus.publish(TelemetrySample(
                topic="telemetry.sample", provenance=self.prov,
                quantity="q", value=float(i), unit="arb"
            ))
        threads = [threading.Thread(target=worker, args=(i,)) for i in range(count)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        self.assertEqual(len(bus.history("telemetry.sample")), count)

    def test_ui_construct_if_pyside_available(self):
        try:
            from PySide6.QtWidgets import QApplication
            from core.ui.main_window import HelixMainWindow
        except ImportError:
            self.skipTest("PySide6 not installed in test environment")
        app = QApplication.instance() or QApplication([])
        w = HelixMainWindow(load_config(ROOT/"skl.config"), ROOT)
        self.assertIn("experiment.state", w.bus.registered_topics())

if __name__ == "__main__":
    unittest.main()
