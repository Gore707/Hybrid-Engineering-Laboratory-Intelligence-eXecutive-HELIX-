import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ISN"
sp=importlib.util.spec_from_file_location("skl_isn",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_isn"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def net(self):
  n=q.GalacticNetwork(["A","B","C","D"])
  n.add_edge(q.GalacticEdge("A","B",2,100,.99,1));n.add_edge(q.GalacticEdge("B","D",2,80,.99,1))
  n.add_edge(q.GalacticEdge("A","C",3,200,.95,1));n.add_edge(q.GalacticEdge("C","D",3,200,.95,1))
  return n
 def test_route(self):
  r=q.simulate_route(self.net(),"A","D",800);self.assertTrue(r.route_found);self.assertEqual(r.hops,2);self.assertEqual(r.distance_ly,4);self.assertEqual(r.bottleneck_capacity_bps,80);self.assertEqual(r.message_serialization_s,10)
 def test_latency(self):self.assertEqual(q.simulate_route(self.net(),"A","D").propagation_latency_years,4)
 def test_failure_reroute(self):
  r=q.simulate_route(self.net(),"A","D",failed_edges=(0,));self.assertTrue(r.route_found);self.assertEqual(r.distance_ly,6)
 def test_total_failure(self):
  r=q.simulate_route(self.net(),"A","D",failed_edges=(0,2));self.assertFalse(r.route_found)
 def test_failure_sweep(self):
  b,s=q.sweep_failed_edges(self.net(),"A","D");self.assertTrue(b.route_found);self.assertEqual(len(s),4)
 def test_mc_seed(self):
  a=q.monte_carlo_network_failures(self.net(),"A","D",200,42);b=q.monte_carlo_network_failures(self.net(),"A","D",200,42);self.assertEqual(a,b);self.assertGreater(a.connected_fraction,.8)
 def test_opt_sweep(self):
  x=q.optical_distance_sweep([1,2],wavelength_m=1e-6,transmit_power_w=1e9,transmitter_diameter_m=100,receiver_diameter_m=30)
  self.assertGreater(x[0][1],x[1][1])
 def test_sgl_sweep(self):
  x=q.sgl_distance_sweep([550,650],1e-6,1000);self.assertEqual(len(x),2);self.assertLess(x[1][2],x[0][2])
 def test_compare(self):
  n=self.net();a=q.simulate_route(n,"A","D");b=q.simulate_route(n,"A","D",failed_edges=(0,))
  c=q.compare_architectures([("directish",a),("alternate",b)]);self.assertEqual(c["lowest_latency"],"directish")
 def test_galactic_preserved(self):self.assertEqual(q.average_node_degree(10,20),4)
 def test_pulsar_preserved(self):self.assertEqual(q.minimum_pulsars_for_3d_position_and_clock(),4)
 def test_sgl_preserved(self):self.assertTrue(540<q.minimum_solar_focal_distance_au()<560)
 def test_optical_preserved(self):self.assertAlmostEqual(q.airy_divergence_rad(1e-6,1),1.22e-6)
 def test_relay_preserved(self):self.assertEqual(q.hop_delivery_capacity_bps([100,20]),20)
 def test_causality_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ISN-SIM-ROUTE","ISN-SIM-MC","ISN-SIM-OPT-SWEEP","ISN-SIM-SGL-SWEEP","ISN-SIM-COMPARE"}<={x.model_id for x in q.InterstellarNetworkRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-ISN-07")
 def test_dependencies(self):self.assertTrue({"SKL-OPT","SKL-QCOM"}<=set(json.loads((M/"module.json").read_text())["dependencies"]))
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
