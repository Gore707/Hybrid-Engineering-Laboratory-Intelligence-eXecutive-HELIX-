from __future__ import annotations
from .models import *
import time
class DriverHardwareDevice:
 def __init__(self,descriptor,driver):
  if descriptor.source!=HALSource.HARDWARE:raise ValueError("source mismatch")
  self.descriptor=descriptor;self.driver=driver;self.state=DeviceState.DISCONNECTED
 def connect(self):
  self.driver.connect();self.state=DeviceState.CONNECTED
 def disconnect(self):
  try:self.driver.disconnect()
  finally:self.state=DeviceState.DISCONNECTED
 def read(self,channel):
  if self.state==DeviceState.DISCONNECTED:raise RuntimeError("device disconnected")
  value,unit=self.driver.read(channel)
  return Measurement(self.descriptor.device_id,channel,float(value),str(unit),time.time(),HALSource.HARDWARE,
   provenance_id="HAL:"+self.descriptor.device_id)
 def write(self,channel,value):
  if self.state==DeviceState.DISCONNECTED:raise RuntimeError("device disconnected")
  self.driver.write(channel,value)
