from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
class FeasibilityClass(str,Enum):
 A="A";B="B";C="C";D="D";E="E";F="F"
@dataclass(frozen=True)
class EngineeringAssessment:
 feasibility:FeasibilityClass;physics_coverage:float;evidence_coverage:float;provenance_coverage:float
 integrity_passed:bool;reasons:tuple[str,...]
def assess_design(studio,design):
 r=studio.analysis_readiness(design);reasons=[]
 integrity=not r["validation_issues"]
 if not integrity:reasons.extend(r["validation_issues"])
 pc,ec,pr=r["physics_coverage"],r["evidence_coverage"],r["provenance_coverage"]
 score=min(pc,ec,pr)
 # Structural/evidence readiness only; never presented as proof that the physical concept works.
 if not integrity:f=FeasibilityClass.F
 elif score>=.95:f=FeasibilityClass.A
 elif score>=.80:f=FeasibilityClass.B
 elif score>=.60:f=FeasibilityClass.C
 elif score>=.40:f=FeasibilityClass.D
 elif score>0:f=FeasibilityClass.E
 else:f=FeasibilityClass.F
 reasons.append("Class reflects HELIX engineering-document readiness/evidence coverage, not proof of physical feasibility.")
 return EngineeringAssessment(f,pc,ec,pr,integrity,tuple(reasons))
