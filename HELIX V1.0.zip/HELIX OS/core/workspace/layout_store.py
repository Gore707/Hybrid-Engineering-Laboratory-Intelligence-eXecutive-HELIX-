from __future__ import annotations
import json
from pathlib import Path
from typing import Any

class LayoutStore:
    def __init__(self, user_root: Path):
        self.path = user_root / "workspaces.json"

    def load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"schema_version": 1, "last_layout": None, "layouts": {}}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {"schema_version": 1, "last_layout": None, "layouts": {}}
        if not isinstance(data.get("layouts"), dict):
            data["layouts"] = {}
        data.setdefault("schema_version", 1)
        data.setdefault("last_layout", None)
        return data

    def save(self, data: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def put(self, name: str, geometry_hex: str, state_hex: str) -> None:
        data = self.load()
        data["layouts"][name] = {
            "geometry": geometry_hex,
            "state": state_hex
        }
        data["last_layout"] = name
        self.save(data)

    def get(self, name: str):
        return self.load()["layouts"].get(name)

    def names(self) -> list[str]:
        return sorted(self.load()["layouts"])

    def delete(self, name: str) -> None:
        data = self.load()
        data["layouts"].pop(name, None)
        if data.get("last_layout") == name:
            data["last_layout"] = None
        self.save(data)
