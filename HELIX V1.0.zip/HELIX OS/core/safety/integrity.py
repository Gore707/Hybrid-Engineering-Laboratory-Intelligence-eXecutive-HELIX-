from pathlib import Path
import os,hashlib
def atomic_write_bytes(path:Path,data:bytes):
 path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+".tmp")
 tmp.write_bytes(data);os.replace(tmp,path);return hashlib.sha256(data).hexdigest()
def verify_bytes(path:Path,checksum):
 return hashlib.sha256(path.read_bytes()).hexdigest()==checksum
