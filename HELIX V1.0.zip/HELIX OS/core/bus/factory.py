from .bus import HelixBus
from .messages import TelemetrySample, ExperimentStateEvent, DataReferenceEvent, WarningEvent

CORE_TOPICS = {
    "telemetry.sample": TelemetrySample,
    "experiment.state": ExperimentStateEvent,
    "data.reference": DataReferenceEvent,
    "system.warning": WarningEvent,
}

def create_core_bus(history_per_topic: int = 256) -> HelixBus:
    bus = HelixBus(history_per_topic=history_per_topic)
    for topic, message_type in CORE_TOPICS.items():
        bus.register_type(topic, message_type)
    return bus
