param(
 [string]$InstallDir = "$env:LOCALAPPDATA\SierraKiloLabs\HELIX",
 [switch]$SkipDependencies
)
$ErrorActionPreference = "Stop"
Write-Host "Installing Sierra Kilo Labs HELIX Core 1.0 to $InstallDir"
if (-not (Get-Command py -ErrorAction SilentlyContinue)) { throw "Python launcher 'py' not found. Install Python 3.11+ first." }
$ver = & py -3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
$parts=$ver.Split('.'); if ([int]$parts[0] -lt 3 -or ([int]$parts[0] -eq 3 -and [int]$parts[1] -lt 11)) { throw "Python 3.11+ required." }
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
$source = Split-Path -Parent $MyInvocation.MyCommand.Path
Get-ChildItem $source -Force | Where-Object { $_.Name -ne ".venv" } | Copy-Item -Destination $InstallDir -Recurse -Force
Push-Location $InstallDir
try {
 & py -3 -m venv .venv
 if (-not $SkipDependencies) {
  & .\.venv\Scripts\python.exe -m pip install --upgrade pip
  & .\.venv\Scripts\python.exe -m pip install -r requirements.txt
 }
 & .\.venv\Scripts\python.exe HELIX_SELFTEST.py
 if ($LASTEXITCODE -ne 0) { throw "HELIX Core self-test failed." }
 "@echo off`r`n`"%~dp0.venv\Scripts\python.exe`" `"%~dp0HELIX.py`" %*" | Set-Content -Encoding ASCII HELIX-Core.bat
 Write-Host "HELIX Core 1.0 installed and self-tested successfully."
 Write-Host "HELIX dependencies installed from canonical requirements.txt."
} finally { Pop-Location }
