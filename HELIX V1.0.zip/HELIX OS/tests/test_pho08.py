import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-PHO";sp=importlib.util.spec_from_file_location("skl_pho",M/"__init__.py",submodule_search_locations=[str(M)]);p=importlib.util.module_from_spec(sp);sys.modules["skl_pho"]=p;sp.loader.exec_module(p)
class T(unittest.TestCase):
 def test_qe_roundtrip(self):
  x=p.responsivity_from_qe(.8,1e-6);self.assertAlmostEqual(p.qe_from_responsivity(x,1e-6),.8)
 def test_current(self):self.assertEqual(p.photocurrent_a(2,.5),1)
 def test_shot(self):self.assertAlmostEqual(p.shot_noise_current_rms_a(1,1),math.sqrt(2*p.Q_E))
 def test_johnson(self):self.assertGreater(p.johnson_noise_voltage_rms_v(50,300,1e6),0)
 def test_rss(self):self.assertEqual(p.total_current_noise_rms_a(3,4),5)
 def test_snr(self):self.assertEqual(p.snr_current(10,2),5)
 def test_nep(self):self.assertEqual(p.nep_w_sqrt_hz(1e-12,.5),2e-12)
 def test_detectivity(self):self.assertGreater(p.specific_detectivity_jones(1e-6,1e-12),0)
 def test_photodiode_saturation(self):
  d=p.Photodiode(.5,1e-9,1e6,.1);self.assertEqual(d.signal_current(1),.1);self.assertGreater(d.shot_noise(1),0)
 def test_counts(self):
  n=p.photon_count_mean(1e-9,1e-6,1);self.assertGreater(n,0);self.assertAlmostEqual(p.poisson_count_snr(100),10)
 def test_registry(self):self.assertEqual(p.PhotonicsRegistry().get("PHO-DETECT-SHOT").evidence_class,"ESTABLISHED_PHYSICS")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-PHO-08")
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
