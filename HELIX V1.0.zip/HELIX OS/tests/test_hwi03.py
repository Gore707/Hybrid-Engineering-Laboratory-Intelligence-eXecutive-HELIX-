import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HWI"
sp=importlib.util.spec_from_file_location("skl_hwi",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_hwi"]=q;sp.loader.exec_module(q)
class FakeClient:
 def __init__(self,reply="1.25"):self.reply=reply;self.commands=[];self.queries=[]
 def query(self,x):self.queries.append(x);return self.reply
 def command(self,x):self.commands.append(x)
def build(reply="1.25",w=True):
 i=q.HardwareIdentity("D1","Sierra Kilo","Meter X")
 c=q.CapabilityDescriptor("voltage","Voltage","V",0,10,.001,1000,w)
 mp=q.CommandMapping("voltage","MEAS:VOLT?","SOUR:VOLT {value}","V")
 return q.SCPIDriver("drv",q.IdentityMatcher("Sierra","Meter"),(c,),(mp,),FakeClient(reply),i,q.CalibrationState.VALID)
class T(unittest.TestCase):
 def test_match(self):self.assertTrue(q.IdentityMatcher("sierra","meter").matches(q.HardwareIdentity("d","Sierra Kilo","Meter X")))
 def test_no_match(self):self.assertFalse(q.IdentityMatcher("foo").matches(q.HardwareIdentity("d","SKL","Meter")))
 def test_mapping_query_validation(self):
  with self.assertRaises(ValueError):q.CommandMapping("x","READ")
 def test_mapping_write_validation(self):
  with self.assertRaises(ValueError):q.CommandMapping("x",None,"SET")
 def test_driver_identity_mismatch(self):
  with self.assertRaises(ValueError):q.SCPIDriver("d",q.IdentityMatcher("NO"),(),(),FakeClient(),q.HardwareIdentity("x","SKL","M"))
 def test_read(self):
  d=build();x=d.read("voltage","E1",123);self.assertEqual(x.value,1.25);self.assertEqual(x.unit,"V");self.assertEqual(x.provenance.source_state,q.SourceState.HARDWARE);self.assertEqual(x.provenance.timestamp_unix_s,123)
 def test_read_history(self):d=build();d.read("voltage",timestamp_unix_s=1);self.assertEqual(d.command_history[-1].operation,"READ")
 def test_bad_numeric(self):
  with self.assertRaises(q.TransportProtocolError):build("oops").read("voltage")
 def test_out_of_range_read(self):
  with self.assertRaises(q.TransportProtocolError):build("11").read("voltage")
 def test_write(self):
  d=build();r=d.write("voltage",2.5,"V","E1",5);self.assertEqual(r.command_text,"SOUR:VOLT 2.5");self.assertEqual(d.client.commands[-1],"SOUR:VOLT 2.5")
 def test_read_only(self):
  with self.assertRaises(PermissionError):build(w=False).write("voltage",1)
 def test_unit_guard(self):
  with self.assertRaises(ValueError):build().write("voltage",1,"A")
 def test_write_range(self):
  with self.assertRaises(ValueError):build().write("voltage",20,"V")
 def test_registry_select(self):
  r=q.DriverRegistry();r.register("d",q.IdentityMatcher("SKL"),lambda:1);self.assertEqual(r.select(q.HardwareIdentity("x","SKL","M"))[0],"d")
 def test_registry_none(self):
  with self.assertRaises(LookupError):q.DriverRegistry().select(q.HardwareIdentity("x","SKL","M"))
 def test_registry_ambiguous(self):
  r=q.DriverRegistry();r.register("a",q.IdentityMatcher("SKL"),lambda:1);r.register("b",q.IdentityMatcher("SKL"),lambda:2)
  with self.assertRaises(LookupError):r.select(q.HardwareIdentity("x","SKL","M"))
 def test_transport_preserved(self):self.assertEqual(q.TransportKind.TCP.value,"TCP")
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/driver.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HWI-03")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
