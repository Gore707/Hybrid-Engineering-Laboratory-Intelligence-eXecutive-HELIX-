import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QCOM"
sp=importlib.util.spec_from_file_location("skl_qcom",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qcom"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_rt(self):self.assertAlmostEqual(q.memory_round_trip_efficiency(.8,.5,.75),.3)
 def test_survival(self):self.assertAlmostEqual(q.exponential_memory_survival(1,1),math.exp(-1))
 def test_stored_efficiency(self):self.assertAlmostEqual(q.memory_efficiency_after_storage(.8,.75,1,1),.6*math.exp(-1))
 def test_modes(self):self.assertEqual(q.multimode_throughput_limit_per_s(100,.01),10000)
 def test_sync(self):self.assertAlmostEqual(q.synchronization_success_probability(.5,.4,.8,.5),.08)
 def test_required_coherence(self):self.assertAlmostEqual(q.required_coherence_time_s(1,math.exp(-1)),1)
 def test_required_zero(self):self.assertEqual(q.required_coherence_time_s(0,.9),0)
 def test_swap_rate(self):self.assertEqual(q.memory_assisted_swap_rate_per_s(100,.5,.5),25)
 def test_memory(self):
  m=q.QuantumRepeaterMemory(.8,.75,1,100,.01,"TEST")
  self.assertAlmostEqual(m.round_trip_efficiency(0),.6);self.assertEqual(m.mode_throughput_limit_per_s,10000)
 def test_node(self):
  a=q.QuantumRepeaterMemory(.8,.8,1,10,.01);b=q.QuantumRepeaterMemory(.9,.9,2,20,.01)
  n=q.MemoryAssistedRepeaterNode(a,b,.1,.2,.5,100)
  self.assertGreater(n.output_rate_per_s,0);self.assertEqual(n.bottleneck_mode_throughput_per_s,1000)
 def test_long_wait_hurts(self):
  m=q.QuantumRepeaterMemory(.9,.9,1);self.assertLess(m.round_trip_efficiency(2),m.round_trip_efficiency(.1))
 def test_bad_efficiency(self):
  with self.assertRaises(ValueError):q.QuantumRepeaterMemory(1.1,.5,1)
 def test_repeater_preserved(self):self.assertEqual(q.nested_swap_success_probability(.5,.5,1),.125)
 def test_teleport_preserved(self):self.assertEqual(q.pre_classical_message_receiver_state_information_bits(),0)
 def test_no_signalling_preserved(self):self.assertEqual(q.no_signalling_remote_probability("memory"),(.5,.5))
 def test_registry(self):self.assertTrue({"QCOM-MEM-RT","QCOM-MEM-MODE","QCOM-MEM-TREQ","QCOM-MEM-SYNC","QCOM-MEM-SWAP-R"}<={x.model_id for x in q.QuantumCommRegistry().all()})
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-QCOM-07");self.assertIn("SKL-QMEM",x["dependencies"])
 def test_qmem_complete(self):self.assertEqual(json.loads((R/"QMEM_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
