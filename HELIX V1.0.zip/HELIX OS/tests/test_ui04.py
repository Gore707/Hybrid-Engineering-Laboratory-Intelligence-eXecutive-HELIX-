import unittest,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];G=(R/"core/ui/guardian_console.py").read_text();T=(R/"core/ui/theme.py").read_text()
class X(unittest.TestCase):
 def test_tabs(self):
  for n in ("Console","Observations","Intelligence","Memory","Research","Journal","Proposals","Permissions"):self.assertIn(n,G)
 def test_operational_engine(self):self.assertIn("reply=self.engine.handle(text)",G);self.assertIn("self.engine.render_menu()",G)
 def test_breadcrumb(self):self.assertIn("self.breadcrumb.setText(self.engine.breadcrumb)",G)
 def test_voice_preserved(self):self.assertIn("recognize_once_windows()",G)
 def test_permissions_boundary(self):self.assertIn("Guardian authority: ADVISORY",G);self.assertIn("Deterministic safety",G)
 def test_no_fake_observations(self):self.assertIn("No observation stream is active.",G)
 def test_no_fake_memory(self):self.assertIn("No memory record selected.",G)
 def test_no_fake_proposals(self):self.assertIn("No Guardian proposal selected.",G)
 def test_theme(self):self.assertIn("QFrame#GuardianHeader",T);self.assertIn("QPlainTextEdit#GuardianTranscript",T)
 def test_markers(self):
  for n in range(1,5):self.assertTrue((R/f"UI_{n:02d}_COMPLETE.json").exists())
  self.assertEqual(json.loads((R/"UI_04_COMPLETE.json").read_text())["sequence"],"4/6")
 def test_backend(self):self.assertEqual(json.loads((R/"HELIX_136_COMPLETE.json").read_text())["patches_completed"],136)
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
