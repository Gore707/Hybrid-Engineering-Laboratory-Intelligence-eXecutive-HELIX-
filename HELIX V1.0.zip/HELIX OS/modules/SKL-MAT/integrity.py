from __future__ import annotations
def check_property_curve_against_dataset(curve,dataset,tolerance_fraction=None):
 issues=[];comparisons=[]
 for x,y in zip(dataset.x,dataset.y):
  try:pred=curve.evaluate(x)
  except ValueError:
   issues.append({"level":"ERROR","code":"OUTSIDE_CURVE_DOMAIN","x":x});continue
  delta=pred-y;frac=abs(delta)/abs(y) if y else (0 if delta==0 else float("inf"))
  comparisons.append({"x":x,"predicted":pred,"observed":y,"residual":delta,"fractional_error":frac})
  if tolerance_fraction is not None and frac>tolerance_fraction:
   issues.append({"level":"WARNING","code":"TOLERANCE_EXCEEDED","x":x,"fractional_error":frac})
 return {"passed":not any(i["level"]=="ERROR" for i in issues),"issues":issues,"comparisons":comparisons}
