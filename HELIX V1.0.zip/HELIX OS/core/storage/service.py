from __future__ import annotations
class ResourceService:
    SCHEMAS={
      "material":"material.schema.json","model":"model.schema.json","equation":"equation.schema.json",
      "experiment":"experiment.schema.json","device":"device.schema.json","provenance":"provenance.schema.json",
      "module":"module.schema.json","component":"component.schema.json","hardware":"hardware.schema.json",
      "dataset":"dataset.schema.json","visualization":"visualization.schema.json","unit":"units.schema.json",
      "command":"command.schema.json"
    }
    def __init__(self,schemas,catalog):
        self.schemas=schemas;self.catalog=catalog
    def put(self,resource_type,data):
        if resource_type not in self.SCHEMAS: raise ValueError(f"Unknown resource type: {resource_type}")
        self.schemas.validate(self.SCHEMAS[resource_type],data)
        return self.catalog.upsert(resource_type,data)
    def get(self,rid): return self.catalog.get(rid)
