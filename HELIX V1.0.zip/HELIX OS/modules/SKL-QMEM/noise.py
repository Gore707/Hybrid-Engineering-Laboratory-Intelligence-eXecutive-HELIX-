from __future__ import annotations
from dataclasses import dataclass
import math

KB=1.380649e-23
HBAR=1.054571817e-34

def thermal_boson_occupation(angular_frequency_rad_s,temperature_k):
    if angular_frequency_rad_s<=0 or temperature_k<0: raise ValueError("invalid frequency/temperature")
    if temperature_k==0:return 0.0
    x=HBAR*angular_frequency_rad_s/(KB*temperature_k)
    if x>700:return 0.0
    return 1/math.expm1(x)

def white_noise_phase_variance(rate_rad2_s,elapsed_s):
    if rate_rad2_s<0 or elapsed_s<0: raise ValueError("nonnegative inputs required")
    return rate_rad2_s*elapsed_s

def gaussian_phase_coherence(phase_variance_rad2):
    if phase_variance_rad2<0: raise ValueError("nonnegative variance required")
    return math.exp(-0.5*phase_variance_rad2)

def field_noise_dephasing_rate_s_inv(sensitivity_rad_s_per_unit,field_noise_std_unit,correlation_time_s):
    if field_noise_std_unit<0 or correlation_time_s<0: raise ValueError("nonnegative noise inputs required")
    return (sensitivity_rad_s_per_unit*field_noise_std_unit)**2*correlation_time_s

def spectral_diffusion_coherence(elapsed_s,characteristic_time_s,stretch_exponent=2.0):
    if elapsed_s<0 or characteristic_time_s<=0 or stretch_exponent<=0: raise ValueError("invalid diffusion inputs")
    return math.exp(-(elapsed_s/characteristic_time_s)**stretch_exponent)

def combine_independent_rates_s_inv(*rates):
    if any(r<0 for r in rates): raise ValueError("rates must be nonnegative")
    return sum(rates)

def effective_coherence_time_s(*rates):
    total=combine_independent_rates_s_inv(*rates)
    return math.inf if total==0 else 1/total

def combined_survival(elapsed_s,*rates):
    if elapsed_s<0: raise ValueError("nonnegative elapsed time required")
    return math.exp(-combine_independent_rates_s_inv(*rates)*elapsed_s)

@dataclass(frozen=True)
class NoiseSource:
    name:str
    rate_s_inv:float
    provenance:str="SIMULATION"
    def __post_init__(self):
        if not self.name.strip() or self.rate_s_inv<0 or not self.provenance.strip():
            raise ValueError("invalid noise source")

@dataclass(frozen=True)
class DecoherenceBudget:
    sources:tuple[NoiseSource,...]
    def __post_init__(self):
        if not isinstance(self.sources,tuple): raise ValueError("sources must be a tuple")
    @property
    def total_rate_s_inv(self):return sum(s.rate_s_inv for s in self.sources)
    @property
    def effective_t2_s(self):return math.inf if self.total_rate_s_inv==0 else 1/self.total_rate_s_inv
    def survival(self,elapsed_s):
        if elapsed_s<0: raise ValueError("nonnegative elapsed time required")
        return math.exp(-self.total_rate_s_inv*elapsed_s)
    def fractional_contributions(self):
        total=self.total_rate_s_inv
        if total==0:return {s.name:0.0 for s in self.sources}
        return {s.name:s.rate_s_inv/total for s in self.sources}

@dataclass(frozen=True)
class PlatformNoiseAssessment:
    platform:str
    intrinsic_rate_s_inv:float
    thermal_rate_s_inv:float=0.0
    field_rate_s_inv:float=0.0
    diffusion_rate_s_inv:float=0.0
    loss_rate_s_inv:float=0.0
    def __post_init__(self):
        if not self.platform.strip() or any(x<0 for x in (self.intrinsic_rate_s_inv,self.thermal_rate_s_inv,self.field_rate_s_inv,self.diffusion_rate_s_inv,self.loss_rate_s_inv)):
            raise ValueError("invalid platform noise assessment")
    @property
    def total_rate_s_inv(self):
        return sum((self.intrinsic_rate_s_inv,self.thermal_rate_s_inv,self.field_rate_s_inv,self.diffusion_rate_s_inv,self.loss_rate_s_inv))
    @property
    def effective_time_s(self):return math.inf if self.total_rate_s_inv==0 else 1/self.total_rate_s_inv
