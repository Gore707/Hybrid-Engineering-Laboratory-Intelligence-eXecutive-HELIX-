from __future__ import annotations
from dataclasses import dataclass,asdict
from enum import Enum
class EvidenceClass(str,Enum):
    DEMONSTRATED_TECHNOLOGY="DEMONSTRATED_TECHNOLOGY"
    ESTABLISHED_PHYSICS="ESTABLISHED_PHYSICS"
    EXTRAPOLATED_ENGINEERING="EXTRAPOLATED_ENGINEERING"
    SPECULATIVE_UNRESOLVED="SPECULATIVE_UNRESOLVED"
    NEW_PHYSICS="NEW_PHYSICS"
class SourceClass(str,Enum):
    HARDWARE="HARDWARE";IMPORTED="IMPORTED";SIMULATION="SIMULATION";SOFTWARE="SOFTWARE"
    EXTRAPOLATED="EXTRAPOLATED";SPECULATIVE="SPECULATIVE";NEW_PHYSICS="NEW_PHYSICS"
@dataclass(frozen=True)
class SourceRecord:
    source_id:str;source_class:SourceClass;title:str
    uri:str|None=None;retrieved_utc:str|None=None;checksum_sha256:str|None=None
    license:str|None=None;notes:str=""
    def dict(self):
        d=asdict(self);d["source_class"]=self.source_class.value;return d
@dataclass(frozen=True)
class TruthRecord:
    record_id:str;subject_id:str;claim:str;evidence_class:EvidenceClass;source_class:SourceClass
    confidence:float;source_ids:tuple[str,...]=();model_ids:tuple[str,...]=();dataset_ids:tuple[str,...]=()
    experiment_ids:tuple[str,...]=();equation_ids:tuple[str,...]=();value:float|None=None;unit:str|None=None
    timestamp_utc:str|None=None;status:str="ACTIVE"
    def __post_init__(self):
        if not 0<=self.confidence<=1:raise ValueError("confidence must be within [0,1]")
    def dict(self):
        d=asdict(self);d["evidence_class"]=self.evidence_class.value;d["source_class"]=self.source_class.value
        for k in ("source_ids","model_ids","dataset_ids","experiment_ids","equation_ids"):d[k]=list(d[k])
        return d
@dataclass(frozen=True)
class LineageEdge:
    parent_id:str;child_id:str;relation:str
@dataclass(frozen=True)
class Contradiction:
    left_record_id:str;right_record_id:str;subject_id:str;reason:str
