import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-BND"
sp=importlib.util.spec_from_file_location("skl_bnd",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_bnd"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_causal_speed(self):self.assertEqual(q.signal_velocity_status(q.C_M_S),q.CausalityStatus.CAUSAL)
 def test_ftl_speed_flag(self):self.assertEqual(q.signal_velocity_status(q.C_M_S*1.01),q.CausalityStatus.FTL_INFORMATION_CLAIM)
 def test_no_signalling(self):self.assertFalse(q.no_signalling_entanglement_allows_message_without_classical_channel())
 def test_no_established_bypass(self):self.assertFalse(q.established_physics_causality_bypass_available())
 def test_classifier_demo(self):self.assertEqual(q.classify_boundary_candidate(True,True,True,False),q.BoundaryEvidence.DEMONSTRATED_TECHNOLOGY)
 def test_classifier_new(self):self.assertEqual(q.classify_boundary_candidate(False,False,False,True),q.BoundaryEvidence.NEW_PHYSICS_REQUIRED)
 def test_classifier_spec(self):self.assertEqual(q.classify_boundary_candidate(False,False,False,False),q.BoundaryEvidence.SPECULATIVE_UNRESOLVED)
 def test_claim_warning(self):
  c=q.BoundaryClaim("x","test",q.ClaimType.HYPOTHESIS,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED,q.CausalityStatus.UNRESOLVED);self.assertTrue(c.requires_explicit_boundary_warning)
 def test_falsifiable(self):
  c=q.BoundaryClaim("x","test",q.ClaimType.HYPOTHESIS,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED,q.CausalityStatus.CAUSAL,falsification_test="measure null result");self.assertTrue(q.falsifiability_ready(c))
 def test_reject_established_ftl(self):
  with self.assertRaises(ValueError):q.BoundaryModel("x","x","v>c",q.BoundaryEvidence.ESTABLISHED_PHYSICS,(),(),True)
 def test_registry(self):self.assertEqual(len(q.default_registry().all()),3)
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/boundary_claim.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-BND-01")
 def test_ecc_complete(self):self.assertEqual(json.loads((R/"ECC_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
