import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-STO";sp=importlib.util.spec_from_file_location("skl_sto",M/"__init__.py",submodule_search_locations=[str(M)]);s=importlib.util.module_from_spec(sp);sys.modules["skl_sto"]=s;sp.loader.exec_module(s)
class T(unittest.TestCase):
 def test_cross_validation(self):
  r=s.run_cross_engine_validation();self.assertTrue(r.passed);self.assertEqual(r.total_count,10);self.assertEqual(r.passed_count,10)
 def test_5d(self):self.assertEqual(s.FiveDEncoding(4,4).integer_payload_bits_per_voxel,4)
 def test_holo(self):self.assertGreater(s.fringe_spacing_m(500e-9,1.5,1.0),0)
 def test_spectral(self):self.assertEqual(s.AtomicFrequencyComb(1e6,1e5,4).finesse,10)
 def test_dna(self):self.assertEqual(s.dna_ideal_bits_per_base(),2)
 def test_magnetic(self):self.assertGreater(s.thermal_stability_factor(1e6,1e-24,300),0)
 def test_capacity_units(self):
  with self.assertRaises(TypeError):s.aggregate_classical_capacity([s.CapacityMetric(1,s.InformationUnit.QUBIT)])
 def test_ecc(self):self.assertGreaterEqual(s.block_uncorrectable_probability(64,1e-3,1),0)
 def test_design(self):self.assertEqual(len(s.technology_model_ids(s.StorageTechnology.MOLECULAR_DNA)),3)
 def test_registry_models(self):
  ids={x.model_id for x in s.StorageRegistry().all()};self.assertTrue({"STO-5D-VOXELS","STO-HOLO-FRINGE","STO-AFC-ECHO","STO-DNA-CAP","STO-MAG-STABILITY","STO-ECC-BLOCK-FAIL","STO-DESIGN-READINESS"}<=ids)
 def test_complete_marker(self):
  x=json.loads((R/"STO_COMPLETE.json").read_text());self.assertEqual((x["patches_complete"],x["patches_total"],x["status"]),(10,10,"COMPLETE"))
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-STO-10");self.assertIn("storage.complete",x["capabilities"])
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
