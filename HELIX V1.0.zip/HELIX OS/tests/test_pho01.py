import unittest,importlib.util,sys,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-PHO"
spec=importlib.util.spec_from_file_location("skl_pho",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
p=importlib.util.module_from_spec(spec);sys.modules["skl_pho"]=p;spec.loader.exec_module(p)
class PHO01(unittest.TestCase):
 def test_frequency(self):
  w=p.OpticalWave(1e-6);self.assertAlmostEqual(w.vacuum_frequency_hz,299792458/1e-6)
 def test_medium_wavelength(self):
  self.assertAlmostEqual(p.OpticalWave(1e-6,refractive_index=1.5).medium_wavelength_m,1e-6/1.5)
 def test_photon_energy_flux(self):
  w=p.OpticalWave(1e-6,1);self.assertGreater(w.photon_energy_j,0);self.assertAlmostEqual(w.photon_flux_s*w.photon_energy_j,1)
 def test_snell(self):
  t=p.snell_angle(1,1.5,math.radians(30));self.assertAlmostEqual(math.sin(t),1/3)
 def test_total_internal_reflection(self):
  r=p.dielectric_interface(1.5,1,math.radians(60));self.assertTrue(r.total_internal_reflection);self.assertEqual(r.reflectance,1)
 def test_fresnel_normal_energy(self):
  r=p.fresnel_normal(1,1.5);self.assertAlmostEqual(r.reflectance+r.transmittance,1)
 def test_opl_phase(self):
  self.assertEqual(p.optical_path_length(2,1.5),3);self.assertAlmostEqual(p.phase_delay_rad(1e-6,1e-6,1),2*math.pi)
 def test_registry(self):self.assertEqual(p.PhotonicsRegistry().get("PHO-SNELL").evidence_class,"ESTABLISHED_PHYSICS")
 def test_manifest_dependency(self):
  m=json.loads((MOD/"module.json").read_text());self.assertEqual(m["patch_id"],"SKL-PHO-01");self.assertEqual(m["dependencies"],["SKL-MAT"])
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
