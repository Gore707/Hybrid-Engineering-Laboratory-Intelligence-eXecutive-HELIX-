import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-OPT"
sp=importlib.util.spec_from_file_location("skl_opt",M/"__init__.py",submodule_search_locations=[str(M)])
o=importlib.util.module_from_spec(sp);sys.modules["skl_opt"]=o;sp.loader.exec_module(o)
class T(unittest.TestCase):
 def scenario(self,**kw):
  d=dict(wavelength_m=1550e-9,distance_m=1e9,transmit_aperture_m=.2,receive_aperture_m=1,transmitted_optical_power_w=10,bit_rate_bps=1000,required_snr=5)
  d.update(kw);return o.IntegratedOpticalScenario(**d)
 def test_nominal(self):
  r=o.simulate(self.scenario());self.assertGreater(r.received_power_w,0);self.assertGreater(r.detected_signal_photon_rate_per_s,0)
 def test_provenance(self):self.assertEqual(o.simulate(self.scenario()).evidence,o.EvidenceState.SIMULATION)
 def test_photons_bit_identity(self):
  r=o.simulate(self.scenario());self.assertAlmostEqual(r.photons_per_information_bit,r.detected_signal_photon_rate_per_s/1000)
 def test_pointing_hurts(self):self.assertLess(o.simulate(self.scenario(pointing_error_rad=10e-6)).received_power_w,o.simulate(self.scenario()).received_power_w)
 def test_atmosphere_hurts(self):self.assertLess(o.simulate(self.scenario(atmospheric_transmission=.5)).received_power_w,o.simulate(self.scenario()).received_power_w)
 def test_distance_hurts(self):self.assertLess(o.simulate(self.scenario(distance_m=2e9)).received_power_w,o.simulate(self.scenario()).received_power_w)
 def test_power_helps(self):self.assertGreater(o.simulate(self.scenario(transmitted_optical_power_w=20)).photon_counting_snr_per_bit,o.simulate(self.scenario()).photon_counting_snr_per_bit)
 def test_ppm_metrics(self):
  r=o.simulate(self.scenario());self.assertTrue(0<=r.ber<=1);self.assertTrue(0<=r.packet_error<=1);self.assertTrue(0<=r.goodput_bps<=1000)
 def test_coding_gain_helps(self):self.assertLessEqual(o.simulate(self.scenario(coding_gain_db=3)).ber,o.simulate(self.scenario()).ber)
 def test_ook_no_fake_ber(self):
  r=o.simulate(self.scenario(modulation=o.OpticalModulation.OOK));self.assertIsNone(r.ber);self.assertIsNone(r.goodput_bps)
 def test_distance_sweep(self):
  x=o.sweep_distance(self.scenario(),[1e9,2e9]);self.assertGreater(x[0][1].received_power_w,x[1][1].received_power_w)
 def test_power_sweep(self):
  x=o.sweep_transmit_power(self.scenario(),[1,2]);self.assertLess(x[0][1].received_power_w,x[1][1].received_power_w)
 def test_min_power(self):
  s=self.scenario(dark_count_rate_per_s=10,background_count_rate_per_s=20);p=o.minimum_transmit_power_for_snr(s,5)
  r=o.simulate(o.IntegratedOpticalScenario(**{**s.__dict__,"transmitted_optical_power_w":p}))
  self.assertAlmostEqual(r.photon_counting_snr_per_bit,5,places=9)
 def test_min_power_zero(self):self.assertEqual(o.minimum_transmit_power_for_snr(self.scenario(),0),0)
 def test_status_type(self):self.assertIn(o.simulate(self.scenario()).status,list(o.OpticalLinkStatus))
 def test_invalid(self):
  with self.assertRaises(ValueError):self.scenario(atmospheric_transmission=0)
 def test_digital_preserved(self):self.assertEqual(o.bits_per_ppm_symbol(16),4)
 def test_atmosphere_preserved(self):self.assertEqual(o.transmission_from_optical_depth(0),1)
 def test_pat_preserved(self):self.assertEqual(o.gaussian_pointing_coupling(0,1e-6),1)
 def test_receiver_preserved(self):self.assertGreater(o.telescope_collection_area_m2(1),0)
 def test_transmitter_preserved(self):self.assertGreater(o.rayleigh_range_m(1e-6,1),0)
 def test_registry(self):self.assertTrue({"OPT-LINK-END2END","OPT-LINK-MARGIN","OPT-LINK-MIN-PT"}<={x.model_id for x in o.OpticalRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-OPT-07")
 def test_rf_complete(self):self.assertEqual(json.loads((R/"RF_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
