import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ISN"
sp=importlib.util.spec_from_file_location("skl_isn",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_isn"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_ly(self):self.assertEqual(q.light_years_to_m(1),q.LIGHT_YEAR_M)
 def test_pc(self):self.assertAlmostEqual(q.parsecs_to_m(1),q.PARSEC_M)
 def test_light_second(self):self.assertEqual(q.one_way_latency_s(q.C_M_S),1)
 def test_ly_latency(self):self.assertEqual(q.one_way_latency_years_from_ly(4.24),4.24)
 def test_rtt(self):self.assertEqual(q.round_trip_latency_years_from_ly(4.24),8.48)
 def test_no_superluminal(self):
  with self.assertRaises(ValueError):q.one_way_latency_s(1,1.1*q.C_M_S)
 def test_flux_scaling(self):self.assertAlmostEqual(q.inverse_square_relative_flux(1,2),.25)
 def test_store_forward(self):self.assertAlmostEqual(q.store_and_forward_delivery_time_s([q.C_M_S,q.C_M_S],.5),2.5)
 def test_relays(self):self.assertEqual(q.relay_count_for_max_segment(10,3),3)
 def test_segment(self):self.assertEqual(q.equal_relay_segment_length_m(10,3),2.5)
 def test_clock(self):self.assertEqual(q.clock_drift_uncertainty_s(1e6,1e-12),1e-6)
 def test_clock_req(self):self.assertEqual(q.required_fractional_clock_stability(1e-6,1e6),1e-12)
 def test_node_geometry(self):
  a=q.StellarNetworkNode("A",q.InterstellarNodeKind.STELLAR_SYSTEM,0,0,0)
  b=q.StellarNetworkNode("B",q.InterstellarNodeKind.RELAY,3,4,0)
  self.assertEqual(a.distance_ly_to(b),5);self.assertEqual(a.latency_years_to(b),5)
 def test_route(self):
  a=q.assess_route([1,2,1],.5);self.assertEqual(a.hop_count,3);self.assertEqual(a.relay_count,2);self.assertEqual(a.propagation_latency_years,4);self.assertEqual(a.processing_latency_s,1);self.assertEqual(a.longest_segment_ly,2)
 def test_causality(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ISN-LATENCY","ISN-FLUX","ISN-RELAY-COUNT","ISN-STORE-FWD","ISN-CLOCK-DRIFT"}<={x.model_id for x in q.InterstellarNetworkRegistry().all()})
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-ISN-01");self.assertEqual(x["status"],"ISN-01 of 8")
 def test_dependencies(self):
  self.assertTrue({"SKL-OPT","SKL-QCOM"}<=set(json.loads((M/"module.json").read_text())["dependencies"]))
 def test_qcom_complete(self):self.assertEqual(json.loads((R/"QCOM_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/interstellar_network.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
