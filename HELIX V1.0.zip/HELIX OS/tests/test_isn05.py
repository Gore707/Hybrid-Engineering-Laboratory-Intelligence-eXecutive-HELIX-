import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ISN"
sp=importlib.util.spec_from_file_location("skl_isn",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_isn"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_phase(self):self.assertEqual(q.pulse_phase_cycles(10,2),5)
 def test_count(self):self.assertEqual(q.pulse_count(10.9,2),5)
 def test_residual(self):self.assertAlmostEqual(q.timing_residual_s(10.001,10),.001)
 def test_range_equiv(self):self.assertEqual(q.range_equivalent_from_timing_residual_m(1),q.C_M_S)
 def test_inverse(self):self.assertAlmostEqual(q.timing_residual_from_range_m(q.C_M_S),1)
 def test_uncertainty(self):self.assertEqual(q.combined_toa_uncertainty_s(3,4),5)
 def test_weighted_offset_equal(self):self.assertEqual(q.weighted_clock_offset_s([1,3],[1,1]),2)
 def test_weighted_unc(self):self.assertAlmostEqual(q.weighted_offset_uncertainty_s([1,1]),1/math.sqrt(2))
 def test_fractional(self):self.assertEqual(q.fractional_frequency_error_from_drift(1e-6,1e6),1e-12)
 def test_projection(self):self.assertEqual(q.position_projection_error_m(1),q.C_M_S)
 def test_four_sources(self):self.assertEqual(q.minimum_pulsars_for_3d_position_and_clock(),4)
 def test_gdop_orthogonal(self):self.assertAlmostEqual(q.gdop_from_unit_vectors([(1,0,0),(0,1,0),(0,0,1)]),math.sqrt(3))
 def test_gdop_singular(self):self.assertTrue(math.isinf(q.gdop_from_unit_vectors([(1,0,0),(1,0,0),(0,1,0)])))
 def test_source(self):
  s=q.PulsarTimingSource("P1",.01,1e-6,(1,0,0));self.assertEqual(s.period_s,.01)
 def test_observation(self):
  s=q.PulsarTimingSource("P1",.01,1e-6,(1,0,0));o=q.PulsarTimingObservation(s,1.000001,1)
  self.assertAlmostEqual(o.residual_s,1e-6);self.assertGreater(o.line_of_sight_range_equivalent_m,299)
 def test_clock_solution(self):
  s1=q.PulsarTimingSource("P1",1,1,(1,0,0));s2=q.PulsarTimingSource("P2",1,1,(0,1,0))
  self.assertEqual(q.clock_solution_from_observations([q.PulsarTimingObservation(s1,2,1),q.PulsarTimingObservation(s2,4,1)]),2)
 def test_sgl_preserved(self):self.assertTrue(540<q.minimum_solar_focal_distance_au()<560)
 def test_relay_preserved(self):self.assertEqual(q.hop_delivery_capacity_bps([10,5]),5)
 def test_causality_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ISN-PSR-PHASE","ISN-PSR-RESID","ISN-PSR-RANGE","ISN-PSR-TOA","ISN-PSR-CLOCK"}<={x.model_id for x in q.InterstellarNetworkRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-ISN-05")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
