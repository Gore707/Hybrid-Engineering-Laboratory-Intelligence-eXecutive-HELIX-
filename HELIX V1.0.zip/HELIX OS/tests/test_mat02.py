import unittest,tempfile,importlib.util,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-MAT"
spec=importlib.util.spec_from_file_location("skl_mat",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
pkg=importlib.util.module_from_spec(spec);sys.modules["skl_mat"]=pkg;spec.loader.exec_module(pkg)
class MAT02(unittest.TestCase):
 def catalog(self):
  c=pkg.AtomicCatalog();c.add(pkg.ElementRecord("Si","Silicon",14,28.085,("SRC-SI",)));c.add(pkg.ElementRecord("O","Oxygen",8,15.999,("SRC-O",)));return c
 def test_formula(self):
  x=pkg.parse_formula("SiO2");d={e.element_symbol:e.atomic_fraction for e in x};self.assertAlmostEqual(d["O"],2/3)
 def test_counts(self):self.assertEqual(pkg.stoichiometric_counts("SiO2"),{"Si":1.0,"O":2.0})
 def test_molar_mass_from_atomic_fractions(self):
  c=self.catalog();self.assertAlmostEqual(c.molar_mass(pkg.parse_formula("SiO2")),(28.085+2*15.999)/3)
 def test_unknown_element_rejected(self):
  with self.assertRaises(KeyError):self.catalog().molar_mass(pkg.parse_formula("GeO2"))
 def test_doped_profile(self):
  p=pkg.CompositionProfile("M",pkg.parse_formula("SiO2"),(pkg.DopantRecord("Er","network",.001,"3+",("SRC-ER",)),))
  x=p.effective_atomic_fractions();self.assertAlmostEqual(sum(x.values()),1);self.assertAlmostEqual(x["Er"],.001)
 def test_defect_validation(self):
  with self.assertRaises(ValueError):pkg.DefectRecord("V","vacancy",concentration_m3=-1)
 def test_profile_persistence(self):
  with tempfile.TemporaryDirectory() as td:
   s=pkg.MaterialsService(Path(td)/"m.sqlite");p=pkg.CompositionProfile("M",pkg.parse_formula("SiO2"),(),(pkg.DefectRecord("V-O","vacancy"),))
   s.set_composition(p);q=s.composition("M");self.assertEqual(q.defects[0].defect_id,"V-O")
 def test_manifest(self):
  m=json.loads((MOD/"module.json").read_text());self.assertEqual(m["patch_id"],"SKL-MAT-02");self.assertIn("materials.dopants",m["capabilities"])
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
