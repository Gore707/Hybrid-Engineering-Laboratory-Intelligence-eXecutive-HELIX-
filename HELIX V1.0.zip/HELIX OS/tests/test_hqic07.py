import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HQIC"
sp=importlib.util.spec_from_file_location("skl_hqic",M/"__init__.py",submodule_search_locations=[str(M)])
h=importlib.util.module_from_spec(sp);sys.modules["skl_hqic"]=h;sp.loader.exec_module(h)
class T(unittest.TestCase):
 def good(self,**kw):
  d=dict(scenario_id="GEN-I",classical_raw_ber=1e-4,classical_code_distance=3,quantum_physical_error=.01,
   quantum_code_distance=3,quantum_cycles=10,transduction_efficiencies=(.8,.8),transducer_noise_probabilities=(.01,.01),
   cooling_capacity_w=10,conductive_load_w=1,radiative_load_w=1,active_load_w=2,alignment_error_m=1e-7,
   optical_spot_radius_m=1e-6,manufacturing_tolerances_m=(1e-6,1e-6),max_tolerance_stack_m=3e-6,
   min_transduction_efficiency=.1,min_quantum_survival=.5,max_classical_logical_ber=1e-6)
  d.update(kw);return h.HQICScenario(**d)
 def test_pass(self):self.assertEqual(h.run_hqic_scenario(self.good()).status,h.SimulationStatus.PASS)
 def test_classical_fail(self):self.assertIn("classical_integrity",h.run_hqic_scenario(self.good(classical_raw_ber=.1)).failures)
 def test_quantum_fail(self):self.assertIn("quantum_survival",h.run_hqic_scenario(self.good(quantum_physical_error=.3,quantum_cycles=20)).failures)
 def test_transduction_fail(self):self.assertIn("transduction_efficiency",h.run_hqic_scenario(self.good(transduction_efficiencies=(.1,.1))).failures)
 def test_thermal_fail(self):self.assertIn("thermal_capacity",h.run_hqic_scenario(self.good(cooling_capacity_w=2)).failures)
 def test_alignment_fail(self):self.assertIn("optical_alignment",h.run_hqic_scenario(self.good(alignment_error_m=2e-6)).failures)
 def test_tolerance_fail(self):self.assertIn("manufacturing_tolerance",h.run_hqic_scenario(self.good(max_tolerance_stack_m=1e-7)).failures)
 def test_provenance(self):self.assertEqual(h.run_hqic_scenario(self.good()).provenance,"SIMULATION")
 def test_eta(self):self.assertAlmostEqual(h.run_hqic_scenario(self.good()).transduction_efficiency,.64)
 def test_noise_survival(self):self.assertAlmostEqual(h.run_hqic_scenario(self.good()).transduction_noise_survival,.9801)
 def test_thermal_margin(self):self.assertEqual(h.run_hqic_scenario(self.good()).thermal_margin_w,6)
 def test_alignment_fraction(self):self.assertAlmostEqual(h.run_hqic_scenario(self.good()).alignment_fraction,.1)
 def test_sweep(self):self.assertEqual(len(h.sweep_parameter(self.good(),"cooling_capacity_w",[2,5,10])),3)
 def test_sweep_unknown(self):
  with self.assertRaises(ValueError):h.sweep_parameter(self.good(),"nope",[1])
 def test_summary(self):
  x=h.sweep_parameter(self.good(),"cooling_capacity_w",[2,10]);self.assertEqual(h.summarize_results(x)["count"],2)
 def test_engineering_preserved(self):self.assertEqual(h.rss_tolerance(3,4),5)
 def test_integrity_preserved(self):self.assertAlmostEqual(h.repetition_logical_error_probability(.1,3),.028)
 def test_controller_preserved(self):self.assertEqual(h.DeviceState.IDLE.value,"IDLE")
 def test_transduction_preserved(self):self.assertAlmostEqual(h.cascaded_efficiency(.8,.5),.4)
 def test_registry(self):self.assertTrue({"HQIC-SIM-END2END","HQIC-SIM-QSURV","HQIC-SIM-SWEEP"}<={x.model_id for x in h.HQICRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HQIC-07")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO","SKL-QMEM"])
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
