import unittest,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
THEME=(R/"core/ui/theme.py").read_text()
MAIN=(R/"core/ui/main_window.py").read_text()
class T(unittest.TestCase):
 def test_theme_design_system(self):
  for token in ("QMenuBar","QToolBar#CommandBar","QDockWidget","QTabBar::tab","QStatusBar","ToolbarAbort"):self.assertIn(token,THEME)
 def test_main_window_toolbar_source(self):self.assertIn("def _build_toolbar",MAIN);self.assertIn('bar.addAction("ABORT")',MAIN)
 def test_workspace_identity(self):self.assertIn("SIERRA KILO LABS  /  THE ARCHIMEDES PROJECT",MAIN)
 def test_no_fake_toolbar_execution(self):
  self.assertNotIn('ToolbarRun").triggered.connect',MAIN);self.assertNotIn('ToolbarAbort").triggered.connect',MAIN)
 def test_guardian_toolbar_real(self):self.assertIn("guardian.triggered.connect(self._show_guardian_console)",MAIN)
 def test_marker(self):
  x=json.loads((R/"UI_01_COMPLETE.json").read_text());self.assertEqual(x["status"],"COMPLETE");self.assertEqual(x["sequence"],"1/6")
 def test_backend_completion_preserved(self):self.assertEqual(json.loads((R/"HELIX_136_COMPLETE.json").read_text())["patches_completed"],136)
 def test_hwi_completion_preserved(self):self.assertTrue((R/"HWI_COMPLETE.json").exists())
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
