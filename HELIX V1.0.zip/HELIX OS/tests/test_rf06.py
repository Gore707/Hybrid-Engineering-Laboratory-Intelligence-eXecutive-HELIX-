import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-RF"
sp=importlib.util.spec_from_file_location("skl_rf",M/"__init__.py",submodule_search_locations=[str(M)])
r=importlib.util.module_from_spec(sp);sys.modules["skl_rf"]=r;sp.loader.exec_module(r)
class T(unittest.TestCase):
 def test_bps(self):self.assertEqual(r.bits_per_symbol(r.Modulation.QAM64),6)
 def test_symbol_rate(self):self.assertEqual(r.symbol_rate_baud(1e6,r.Modulation.QPSK,.5),1e6)
 def test_bandwidth(self):self.assertEqual(r.nyquist_baseband_bandwidth_hz(1e6,.25),1.25e6)
 def test_spectral_eff(self):self.assertEqual(r.spectral_efficiency_bps_hz(r.Modulation.QPSK,.5,0),1)
 def test_ebn0(self):self.assertEqual(r.ebn0_from_snr_linear(10,1e6,2e6),5)
 def test_snr_inverse(self):self.assertEqual(r.snr_from_ebn0_linear(5,2e6,1e6),10)
 def test_q0(self):self.assertEqual(r.q_function(0),.5)
 def test_bpsk_zero(self):self.assertEqual(r.ber_bpsk_awgn(0),.5)
 def test_qpsk_equals_bpsk(self):self.assertEqual(r.ber_qpsk_awgn(10),r.ber_bpsk_awgn(10))
 def test_ber_improves(self):self.assertLess(r.ber_bpsk_awgn(10),r.ber_bpsk_awgn(1))
 def test_qam_valid(self):self.assertGreater(r.ber_square_mqam_awgn_approx(10,16),0)
 def test_coding_gain(self):self.assertAlmostEqual(r.coding_gain_adjusted_ebn0(1,3),10**.3)
 def test_packet_zero(self):self.assertEqual(r.packet_error_rate_from_ber(0,1000),0)
 def test_packet_one_bit(self):self.assertAlmostEqual(r.packet_error_rate_from_ber(.1,1),.1)
 def test_goodput(self):self.assertEqual(r.goodput_bps(1000,.1,.8),720)
 def test_link(self):
  d=r.DigitalLink(1e6,r.Modulation.QPSK,.5,.25,10,2,1024,.9)
  self.assertGreater(d.symbol_rate_baud,0);self.assertGreater(d.occupied_bandwidth_hz,0);self.assertGreater(d.goodput_bps,0)
 def test_link_efficiency_consistency(self):
  d=r.DigitalLink(1e6,r.Modulation.QAM16,.8,.2,10)
  self.assertAlmostEqual(d.bit_rate_bps/d.occupied_bandwidth_hz,d.spectral_efficiency_bps_hz)
 def test_invalid_code(self):
  with self.assertRaises(ValueError):r.symbol_rate_baud(1,r.Modulation.BPSK,0)
 def test_invalid_qam(self):
  with self.assertRaises(ValueError):r.ber_square_mqam_awgn_approx(1,32)
 def test_coherent_preserved(self):self.assertAlmostEqual(r.phase_coherence_factor((0,0)),1)
 def test_frontend_preserved(self):self.assertEqual(r.dc_power_for_rf_output_w(100,.5),200)
 def test_registry(self):self.assertTrue({"RF-SYMBOL-RATE","RF-SPECTRAL-EFF","RF-EBN0","RF-BER-BPSK","RF-BER-MQAM","RF-PACKET-ERR","RF-GOODPUT"}<={x.model_id for x in r.RFRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-RF-06")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-HQIC"])
 def test_hqic_complete(self):self.assertEqual(json.loads((R/"HQIC_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
