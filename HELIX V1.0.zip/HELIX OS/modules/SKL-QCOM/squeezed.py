from __future__ import annotations
from dataclasses import dataclass
import math

def squeezed_quadrature_variance(r):
    if r<0:raise ValueError("r>=0")
    return math.exp(-2*r)

def antisqueezed_quadrature_variance(r):
    if r<0:raise ValueError("r>=0")
    return math.exp(2*r)

def squeezing_db_from_variance(variance):
    if variance<=0:raise ValueError("variance>0")
    return -10*math.log10(variance)

def variance_from_squeezing_db(squeezing_db):
    return 10**(-squeezing_db/10)

def loss_degraded_variance(input_variance,transmission):
    if input_variance<0 or not 0<=transmission<=1:raise ValueError("invalid variance/transmission")
    # Vacuum-normalized loss channel: Vout=eta Vin+(1-eta).
    return transmission*input_variance+(1-transmission)

def loss_degraded_squeezing_db(input_squeezing_db,transmission):
    return squeezing_db_from_variance(loss_degraded_variance(variance_from_squeezing_db(input_squeezing_db),transmission))

def ideal_snr_improvement_factor(noise_variance):
    if noise_variance<=0:raise ValueError("variance>0")
    return 1/math.sqrt(noise_variance)

def ideal_snr_improvement_db(noise_variance):
    if noise_variance<=0:raise ValueError("variance>0")
    return -10*math.log10(noise_variance)

def phase_mismatch_variance(r,phase_error_rad):
    if r<0:raise ValueError("r>=0")
    vs=math.exp(-2*r); va=math.exp(2*r)
    return vs*math.cos(phase_error_rad)**2+va*math.sin(phase_error_rad)**2

def detected_variance(r,channel_transmission,detector_efficiency,phase_error_rad=0.0):
    if not 0<=channel_transmission<=1 or not 0<=detector_efficiency<=1:raise ValueError("efficiencies in [0,1]")
    vin=phase_mismatch_variance(r,phase_error_rad)
    return loss_degraded_variance(vin,channel_transmission*detector_efficiency)

def sensitivity_improvement_factor(r,channel_transmission,detector_efficiency,phase_error_rad=0.0):
    return ideal_snr_improvement_factor(detected_variance(r,channel_transmission,detector_efficiency,phase_error_rad))

def causality_or_capacity_bypass_available(): return False

@dataclass(frozen=True)
class SqueezedReceiver:
    squeeze_parameter_r:float
    channel_transmission:float
    detector_efficiency:float
    phase_error_rad:float=0.0
    classical_shot_noise_variance:float=1.0
    def __post_init__(self):
        if self.squeeze_parameter_r<0 or not 0<=self.channel_transmission<=1 or not 0<=self.detector_efficiency<=1 or self.classical_shot_noise_variance<=0:
            raise ValueError("invalid receiver inputs")
    @property
    def detected_noise_variance(self):
        return detected_variance(self.squeeze_parameter_r,self.channel_transmission,self.detector_efficiency,self.phase_error_rad)
    @property
    def detected_squeezing_db(self):return squeezing_db_from_variance(self.detected_noise_variance)
    @property
    def ideal_sensitivity_improvement(self):return ideal_snr_improvement_factor(self.detected_noise_variance)
