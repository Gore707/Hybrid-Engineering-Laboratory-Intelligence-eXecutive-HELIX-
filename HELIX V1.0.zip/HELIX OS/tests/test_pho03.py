import unittest,importlib.util,sys,json,math,cmath
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-PHO"
spec=importlib.util.spec_from_file_location("skl_pho",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
p=importlib.util.module_from_spec(spec);sys.modules["skl_pho"]=p;spec.loader.exec_module(p)
class PHO03(unittest.TestCase):
 def test_field_intensity_phase(self):
  f=p.ComplexField(1j,500e-9);self.assertEqual(f.intensity_arb,1);self.assertAlmostEqual(f.phase_rad,math.pi/2)
 def test_propagation_one_wavelength(self):
  f=p.ComplexField(1+0j,1e-6).propagate(1e-6);self.assertAlmostEqual(f.amplitude.real,1,places=12);self.assertAlmostEqual(f.amplitude.imag,0,places=12)
 def test_superposition(self):
  f=p.superpose([p.ComplexField(1+0j,500e-9),p.ComplexField(-1+0j,500e-9)]);self.assertAlmostEqual(f.intensity_arb,0)
 def test_two_beam(self):
  self.assertAlmostEqual(p.two_beam_intensity(1,1,0),4);self.assertAlmostEqual(p.two_beam_intensity(1,1,math.pi),0)
 def test_visibility(self):self.assertAlmostEqual(p.fringe_visibility(4,0),1)
 def test_coherence_length(self):self.assertAlmostEqual(p.temporal_coherence_length(1e-9),p.C0*1e-9)
 def test_single_slit_center(self):self.assertEqual(p.rectangular_single_slit_intensity(0,500e-9,10e-6,2),2)
 def test_single_slit_first_zero(self):
  th=math.asin(500e-9/10e-6);self.assertAlmostEqual(p.rectangular_single_slit_intensity(th,500e-9,10e-6),0,places=12)
 def test_double_slit_center(self):self.assertEqual(p.double_slit_intensity(0,500e-9,10e-6,i0=1),4)
 def test_grating(self):
  t=p.grating_principal_angle(1,500e-9,1e-6);self.assertAlmostEqual(math.sin(t),.5);self.assertIsNone(p.grating_principal_angle(3,500e-9,1e-6))
 def test_airy_center(self):self.assertEqual(p.airy_intensity(0,500e-9,1e-3),1)
 def test_registry_manifest(self):
  self.assertEqual(p.PhotonicsRegistry().get("PHO-SINGLE-SLIT").evidence_class,"ESTABLISHED_PHYSICS")
  self.assertEqual(json.loads((MOD/"module.json").read_text())["patch_id"],"SKL-PHO-03")
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
