import unittest,importlib.util,sys,json,math,cmath
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-PHO"
spec=importlib.util.spec_from_file_location("skl_pho",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
p=importlib.util.module_from_spec(spec);sys.modules["skl_pho"]=p;spec.loader.exec_module(p)
class PHO05(unittest.TestCase):
 def test_jones_normalize(self):self.assertAlmostEqual(p.JonesVector(1,1).normalized().intensity,1)
 def test_horizontal_stokes(self):
  s=p.JonesVector(1,0).stokes();self.assertEqual((s.s0,s.s1,s.s2,s.s3),(1,1,0,0));self.assertEqual(s.degree_of_polarization,1)
 def test_linear_45(self):
  s=p.JonesVector(1/math.sqrt(2),1/math.sqrt(2)).stokes();self.assertAlmostEqual(s.linear_angle_rad,math.pi/4)
 def test_circular(self):
  s=p.JonesVector(1/math.sqrt(2),1j/math.sqrt(2)).stokes();self.assertAlmostEqual(abs(s.s3),1);self.assertAlmostEqual(abs(s.ellipticity_angle_rad),math.pi/4)
 def test_polarizer(self):
  out=p.linear_polarizer(0)@p.JonesVector(1,1);self.assertEqual(out.ey,0)
 def test_malus(self):self.assertAlmostEqual(p.malus_law(2,math.pi/4),1)
 def test_qwp(self):
  o=p.quarter_wave_plate(0)@p.JonesVector(1/math.sqrt(2),1/math.sqrt(2));self.assertAlmostEqual(abs(o.stokes().s3),1)
 def test_hwp(self):
  o=p.half_wave_plate(math.pi/8)@p.JonesVector(1,0);self.assertAlmostEqual(abs(o.normalized().ex),abs(o.normalized().ey))
 def test_mueller_polarizer(self):
  o=p.mueller_linear_polarizer(0).apply(p.Stokes(1,0,0,0));self.assertAlmostEqual(o.s0,.5);self.assertAlmostEqual(o.s1,.5)
 def test_partial_dop(self):self.assertAlmostEqual(p.Stokes(1,.5,0,0).degree_of_polarization,.5)
 def test_registry_manifest(self):
  self.assertEqual(p.PhotonicsRegistry().get("PHO-MALUS").evidence_class,"ESTABLISHED_PHYSICS")
  self.assertEqual(json.loads((MOD/"module.json").read_text())["patch_id"],"SKL-PHO-05")
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
