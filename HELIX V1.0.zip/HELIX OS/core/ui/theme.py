# HELIX UI/UX 1.0 — UI-01 visual foundation.
# Deliberately restrained: laboratory/CAD hierarchy rather than neon/game styling.
HELIX_DARK = """
QMainWindow, QWidget {
    background: #0b1016;
    color: #dce5ed;
    font-family: "Segoe UI";
    font-size: 10pt;
}
QMainWindow { background: #080d12; }
QMenuBar {
    background: #111820;
    color: #d6e0e8;
    border-bottom: 1px solid #27323d;
    padding: 4px 7px;
    spacing: 4px;
}
QMenuBar::item { padding: 5px 9px; border-radius: 3px; }
QMenuBar::item:selected { background: #1c2935; color: #ffffff; }
QMenu {
    background: #121a22;
    color: #dce5ed;
    border: 1px solid #33414e;
    padding: 5px;
}
QMenu::item { padding: 6px 28px 6px 10px; border-radius: 3px; }
QMenu::item:selected { background: #203344; color: #ffffff; }
QMenu::separator { height: 1px; background: #2a3540; margin: 5px 8px; }

QToolBar#CommandBar {
    background: #0f161e;
    border: 0;
    border-bottom: 1px solid #25313c;
    spacing: 3px;
    padding: 5px 8px;
}
QToolBar#CommandBar QToolButton {
    background: transparent;
    color: #bfcbd5;
    border: 1px solid transparent;
    border-radius: 3px;
    padding: 5px 9px;
}
QToolBar#CommandBar QToolButton:hover { background: #182631; border-color: #2c3d4b; color: #ffffff; }
QToolBar#CommandBar QToolButton:pressed { background: #203747; }
QToolBar#CommandBar QToolButton#ToolbarAbort {
    color: #ffb4b4; border-color: #713c40; background: #2b171b; font-weight: 700;
}
QToolBar#CommandBar QToolButton#ToolbarAbort:hover { background: #472126; border-color: #a34d55; color: #ffffff; }
QToolBar::separator { background: #2b3742; width: 1px; margin: 5px 7px; }

QFrame#Workspace {
    background: #0a0f15;
    border: 1px solid #202b35;
}
QLabel#Eyebrow { color: #5f829d; font-size: 8pt; font-weight: 700; letter-spacing: 1px; }
QLabel#Brand { color: #edf4f9; font-size: 21pt; font-weight: 650; letter-spacing: 2px; }
QLabel#Subtitle { color: #8fa3b5; font-size: 9pt; }
QFrame#WorkspaceRule { color: #23303b; background: #23303b; max-height: 1px; }

QDockWidget {
    color: #cfd9e2;
    font-weight: 600;
    titlebar-close-icon: none;
    titlebar-normal-icon: none;
}
QDockWidget::title {
    background: #10171f;
    border: 1px solid #222e39;
    padding: 7px 8px;
    text-align: left;
}
QDockWidget > QWidget { background: #0d131a; }
QTabWidget::pane { border: 1px solid #27333e; background: #0d131a; }
QTabBar::tab {
    background: #111922; color: #8194a5; border: 1px solid #26323d;
    border-bottom: 0; padding: 6px 11px; margin-right: 1px;
}
QTabBar::tab:selected { background: #17232e; color: #e4edf4; border-top: 2px solid #4d86ad; }
QTabBar::tab:hover:!selected { color: #c3d0da; background: #141f28; }

QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox, QComboBox {
    background: #080d12; color: #dce5ed; border: 1px solid #34424f;
    border-radius: 3px; padding: 5px; selection-background-color: #28506b;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus { border-color: #4c83a8; }
QPushButton {
    background: #17232d; color: #d9e4ec; border: 1px solid #344553;
    border-radius: 3px; padding: 6px 11px;
}
QPushButton:hover { background: #1e3040; border-color: #4b6579; }
QPushButton:pressed { background: #263d4e; }
QPushButton:disabled { color: #566573; background: #10161c; border-color: #202a33; }

QScrollBar:vertical { background: #0b1117; width: 11px; margin: 0; }
QScrollBar::handle:vertical { background: #33424e; min-height: 28px; border-radius: 4px; margin: 2px; }
QScrollBar::handle:vertical:hover { background: #465a69; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: #0b1117; height: 11px; }
QScrollBar::handle:horizontal { background: #33424e; min-width: 28px; border-radius: 4px; margin: 2px; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }

QStatusBar {
    background: #0d141b; color: #9eafbd;
    border-top: 1px solid #27333e; min-height: 23px;
}
QStatusBar::item { border: 0; }
QToolTip { background: #17222c; color: #edf3f7; border: 1px solid #3b4c59; padding: 4px; }
QLabel#StatusGood { color: #b9d8c3; font-weight: 600; }

QFrame#HomeCard {
    background: #0f161e;
    border: 1px solid #26333e;
    border-radius: 4px;
    min-height: 96px;
}
QFrame#HomeCard:hover { border-color: #38566b; background: #111b24; }
QLabel#CardHeading { color: #6387a2; font-size: 8pt; font-weight: 700; letter-spacing: 1px; }
QLabel#CardValue { color: #edf4f8; font-size: 13pt; font-weight: 600; }
QLabel#CardDetail { color: #7f92a3; font-size: 9pt; }
QGroupBox#QuickStart {
    color: #7e95a7; border: 1px solid #25313b; border-radius: 4px;
    margin-top: 9px; padding: 12px 8px 7px 8px; font-size: 8pt; font-weight: 700;
}
QGroupBox#QuickStart::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
QTreeWidget#ProjectTree {
    background: #0b1117; alternate-background-color: #0e151c;
    border: 0; outline: 0; padding: 5px;
}
QTreeWidget#ProjectTree::item { color: #aebdca; min-height: 24px; padding: 2px 4px; border-radius: 2px; }
QTreeWidget#ProjectTree::item:hover { background: #15232e; color: #e2ebf2; }
QTreeWidget#ProjectTree::item:selected { background: #1d3546; color: #ffffff; }
QTreeWidget#ProjectTree::branch { background: transparent; }
QDialog#LabLauncher { background: #0b1016; }
QFrame#LabCard {
    background: #0f171f; border: 1px solid #293743; border-radius: 4px; min-width: 190px; min-height: 135px;
}
QFrame#LabCard:hover { background: #121e27; border-color: #416079; }
QWidget#LabWorkspace { background: #0b1117; }
QLabel#LabTitle { color: #edf4f9; font-size: 15pt; font-weight: 650; letter-spacing: 1px; }
QLabel#LabNotice {
    color: #8497a7; background: #0e161d; border: 1px solid #25333e; border-radius: 3px; padding: 8px;
}
QScrollArea { background: transparent; border: 0; }

QWidget#GuardianSurface { background: #090f14; }
QFrame#GuardianHeader { background: #0d151c; border-bottom: 1px solid #293641; }
QLabel#GuardianBrand { color: #dcebf5; font-weight: 750; font-size: 10pt; letter-spacing: 2px; }
QLabel#GuardianBreadcrumb { color: #7891a5; padding-left: 10px; }
QLabel#GuardianMode {
    color: #9fc0d6; background: #122532; border: 1px solid #2e536b;
    border-radius: 3px; padding: 3px 7px; font-size: 8pt; font-weight: 700;
}
QTabWidget#GuardianTabs::pane { border: 0; border-top: 1px solid #222f39; }
QTabWidget#GuardianTabs QTabBar::tab { min-width: 72px; }
QPlainTextEdit#GuardianTranscript {
    background: #070c11; color: #cbd7df; border: 1px solid #27343f;
    font-family: "Cascadia Mono", "Consolas"; font-size: 9pt; padding: 7px;
}
QLineEdit#GuardianInput { min-height: 25px; background: #0a1117; }
QPushButton#GuardianExecute { font-weight: 650; min-width: 78px; }
QLabel#GuardianTabTitle { color: #6f91aa; font-size: 8pt; font-weight: 750; letter-spacing: 1px; }
QLabel#GuardianState { color: #e4edf3; font-size: 12pt; font-weight: 600; margin-top: 6px; }
QLabel#GuardianDetail {
    color: #8194a4; background: #0d151c; border: 1px solid #25323c;
    border-radius: 3px; padding: 9px; margin-top: 5px;
}
QStatusBar#HelixStatusBar { min-height: 25px; }
QLabel#StatusExperiment, QLabel#StatusSystem, QLabel#StatusEnvironment {
    color: #93a5b3; padding: 2px 10px; border-right: 1px solid #28343e; font-size: 8pt;
}
QLabel#StatusExperiment { color: #b8cfbf; font-weight: 650; }
QLabel#StatusEnvironment { border-right: 0; color: #a9bed0; }

QFrame#MeasurementCard { background: #0d151c; border: 1px solid #293640; border-radius: 4px; }
QLabel#MeasurementTitle { color: #7895aa; font-size: 8pt; font-weight: 700; letter-spacing: 1px; }
QLabel#MeasurementValue { color: #eef5f9; font-size: 17pt; font-weight: 600; }
QLabel#MeasurementMeta { color: #7d909f; font-size: 8pt; }
QLabel#ProvenanceBadge {
    color: #b9cfdd; background: #142532; border: 1px solid #315169;
    border-radius: 3px; padding: 2px 5px; font-size: 7pt; font-weight: 750;
}
QLabel#ProvenanceBadge[provenance="HARDWARE"] { background: #162a20; border-color: #3d684c; color: #bcd8c5; }
QLabel#ProvenanceBadge[provenance="IMPORTED"] { background: #24231a; border-color: #68613b; color: #ddd3a6; }
QLabel#ProvenanceBadge[provenance="SIMULATION"] { background: #142532; border-color: #315169; color: #b9cfdd; }
QLabel#ProvenanceBadge[provenance="EXTRAPOLATED"] { background: #2b2316; border-color: #765b31; color: #e1c48e; }
QLabel#ProvenanceBadge[provenance="SPECULATIVE"] { background: #2b1d2e; border-color: #714879; color: #d9b8df; }
QLabel#ProvenanceBadge[provenance="NEW PHYSICS"] { background: #301b20; border-color: #7c414b; color: #e2b5bc; }
QFrame#ScientificFigure { background: #0a1117; border: 1px solid #2b3944; border-radius: 4px; }
QLabel#FigureTitle { color: #dbe6ed; font-weight: 650; }
QLabel#FigureCaption { color: #738796; font-size: 8pt; }
"""
