from core.truth.models import SourceRecord,SourceClass
def artifact_to_source(artifact):
 return SourceRecord(source_id=artifact.artifact_id,source_class=SourceClass.IMPORTED,
  title=artifact.title or artifact.source_url,uri=artifact.source_url,
  retrieved_utc=artifact.retrieved_utc,checksum_sha256=artifact.checksum_sha256,
  license=artifact.license,notes="Retrieved by HELIX Open Research Gateway.")
