from __future__ import annotations
from pathlib import Path
import json,platform,sys,importlib.util,os
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))

def module(name):return importlib.util.find_spec(name) is not None
def main():
    from core.compute import ComputeBackendManager
    from core.guardian.ai_hardware import probe_ai_runtimes,derive_budget
    cm=ComputeBackendManager(ROOT/"user"/"compute_profile.json")
    errors=[]
    try:devices=cm.detect()
    except Exception as exc:
        devices=[];errors.append(f"compute detection: {type(exc).__name__}: {exc}")
    runtimes=probe_ai_runtimes(devices);budget=derive_budget(devices)
    report={
      "platform":platform.platform(),"python":sys.version.split()[0],
      "logical_cores":os.cpu_count(),
      "modules":{"llama_cpp":module("llama_cpp"),"numpy":module("numpy"),"PySide6":module("PySide6")},
      "devices":[d.to_dict() for d in devices],
      "compute":cm.summary() if devices else {},
      "ai_runtimes":[x.__dict__ for x in runtimes],
      "guardian_budget":budget.__dict__,
      "errors":errors,
      "model_installed":False,
      "note":"GACT-01 validates runtime capability only. No model selection claim is made."
    }
    out=ROOT/"user"/"guardian_ai_diagnostic.json";out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))
    print(f"\nSaved: {out}")
    return 0
if __name__=="__main__":raise SystemExit(main())
