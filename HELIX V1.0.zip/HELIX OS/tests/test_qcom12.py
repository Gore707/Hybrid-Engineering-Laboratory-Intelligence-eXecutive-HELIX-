import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QCOM"
sp=importlib.util.spec_from_file_location("skl_qcom",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qcom"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_percentile(self):self.assertEqual(q.percentile([1,2,3,4,5],.5),3)
 def test_mc_seeded(self):
  a=q.monte_carlo_link_rate(1e6,.1,.01,10,500,42);b=q.monte_carlo_link_rate(1e6,.1,.01,10,500,42)
  self.assertEqual(a,b);self.assertEqual(a.samples,500);self.assertGreater(a.p95,a.p05)
 def test_mc_zero_sigma(self):
  a=q.monte_carlo_link_rate(100,.5,0,2,10,1);self.assertEqual(a.mean,52);self.assertEqual(a.stdev,0)
 def test_sensitivity_linear(self):
  pts=q.normalized_local_sensitivity(lambda x:2*x,"x",{"x":10},.01)
  for p in pts:self.assertAlmostEqual(p.normalized_sensitivity,1)
 def test_gates_pass(self):
  g=q.quantum_link_failure_gates(1e-6,.01,.9,100,10);self.assertTrue(q.all_critical_gates_pass(g));self.assertTrue(all(x.passed for x in g))
 def test_qber_gate_fails(self):
  g=q.quantum_link_failure_gates(1e-6,.2,.9,100,10);self.assertFalse(q.all_critical_gates_pass(g))
 def test_channel_gate_fails(self):
  g=q.quantum_link_failure_gates(1e-15,.01,.9,100,10);self.assertFalse(q.all_critical_gates_pass(g))
 def test_cross_validation(self):
  x=q.run_cross_engine_validation();self.assertEqual(len(x),11);self.assertTrue(all(x.values()),x)
 def test_network_preserved(self):
  a=q.QuantumNetworkLink("A","B",q.QuantumLinkKind.FREE_SPACE,100,.9,.8,.1,50)
  b=q.QuantumNetworkLink("B","C",q.QuantumLinkKind.REPEATER,20,.9,.8,.1,10)
  self.assertEqual(q.path_bottleneck_rate_per_s([a,b]),20)
 def test_squeezing_preserved(self):self.assertFalse(q.causality_or_capacity_bypass_available())
 def test_interplanetary_preserved(self):self.assertEqual(q.one_way_light_time_s(q.C_M_S),1)
 def test_repeater_preserved(self):self.assertEqual(q.nested_swap_success_probability(.5,.5,1),.125)
 def test_teleport_preserved(self):self.assertEqual(q.pre_classical_message_receiver_state_information_bits(),0)
 def test_no_signalling_preserved(self):self.assertEqual(q.no_signalling_remote_probability("complete"),(.5,.5))
 def test_registry(self):self.assertTrue({"QCOM-VAL-MC","QCOM-VAL-SENS","QCOM-VAL-GATES"}<={x.model_id for x in q.QuantumCommRegistry().all()})
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-QCOM-12");self.assertEqual(x["status"],"COMPLETE — QCOM 12/12")
 def test_complete_marker(self):
  x=json.loads((R/"QCOM_COMPLETE.json").read_text());self.assertEqual(x["status"],"COMPLETE");self.assertEqual(x["sequence"],{"complete":12,"total":12})
 def test_upstream_markers(self):
  for f in ("PHO_COMPLETE.json","QMEM_COMPLETE.json","OPT_COMPLETE.json"):self.assertEqual(json.loads((R/f).read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
