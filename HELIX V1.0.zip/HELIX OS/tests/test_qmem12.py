import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM"
sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def rec(self,p=q.QuantumMemoryPlatform.RAMAN,t=1,e=.8,f=.9,b=1e6,ev=q.EvidenceState.SIMULATION):
  return q.MemoryLabRecord(p,t,e,f,b,ev)
 def test_record_tbp(self):self.assertEqual(self.rec().time_bandwidth_product,1e6)
 def test_quality(self):self.assertAlmostEqual(self.rec().end_to_end_quality,.72)
 def test_requirement_pass(self):self.assertTrue(q.assess_requirement(self.rec(),q.MemoryRequirement(.5,.7,.8,1e5)).passes)
 def test_requirement_fail(self):
  a=q.assess_requirement(self.rec(),q.MemoryRequirement(2,.9,.95,2e6));self.assertEqual(set(a.failed_constraints),{"storage_time","efficiency","fidelity","bandwidth"})
 def test_compare(self):self.assertEqual(q.compare_records([self.rec()])[0]["platform"],"RAMAN")
 def test_lab_filters(self):
  l=q.QuantumMemoryLab();l.add(self.rec());self.assertEqual(len(l.by_evidence(q.EvidenceState.SIMULATION)),1)
 def test_pareto_dominated(self):
  a=self.rec(t=1,e=.5,f=.5,b=1);b=self.rec(p=q.QuantumMemoryPlatform.BEC,t=2,e=.6,f=.6,b=2);self.assertEqual(q.pareto_front([a,b]),(b,))
 def test_pareto_tradeoff(self):
  a=self.rec(t=2,e=.5,f=.9,b=1);b=self.rec(p=q.QuantumMemoryPlatform.BEC,t=1,e=.9,f=.8,b=2);self.assertEqual(len(q.pareto_front([a,b])),2)
 def test_all_platforms(self):self.assertEqual(len(q.QuantumMemoryPlatform),6)
 def test_evidence(self):self.assertTrue({"HARDWARE","IMPORTED","SIMULATION","EXTRAPOLATED","SPECULATIVE"}<={x.value for x in q.EvidenceState})
 def test_cross_validation(self):
  ok,c=q.validation_passes();self.assertTrue(ok);self.assertEqual(len(c),13)
 def test_no_cloning_validation(self):self.assertTrue(q.run_cross_engine_validation()["no_cloning_guard"])
 def test_qec_preserved(self):self.assertAlmostEqual(q.majority_vote_logical_error_probability(.1,3),.028)
 def test_noise_preserved(self):self.assertEqual(q.combine_independent_rates_s_inv(1,2),3)
 def test_bec_preserved(self):self.assertEqual(q.ideal_condensate_fraction(0,1),1)
 def test_registry(self):
  ids={x.model_id for x in q.QuantumMemoryRegistry().all()};self.assertTrue({"QMEM-LAB-TBP","QMEM-LAB-QUALITY"}<=ids)
 def test_manifest_complete(self):
  m=json.loads((M/"module.json").read_text());self.assertEqual(m["patch_id"],"SKL-QMEM-12");self.assertIn("COMPLETE",m["status"])
 def test_complete_marker(self):
  x=json.loads((R/"QMEM_COMPLETE.json").read_text());self.assertEqual(x["sequence"],{"complete":12,"total":12});self.assertEqual(x["status"],"COMPLETE")
 def test_core_manifest_root_only(self):
  self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO"])
 def test_completed_prior_modules(self):self.assertTrue((R/"PHO_COMPLETE.json").exists() and (R/"STO_COMPLETE.json").exists())
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
