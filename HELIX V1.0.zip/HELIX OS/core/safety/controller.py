import time,uuid
from .models import *
class SafetyViolation(RuntimeError):pass
class SafetyController:
 def __init__(self,audit):
  self.audit=audit;self.hold=False;self.alerts=[]
 def evaluate_preflight(self,result,actor="SafetyController"):
  self.audit.append("PREFLIGHT",actor,{"passed":result.passed,"highest_level":result.highest_level.name})
  if not result.passed:self.hold=True
  return result.passed
 def alert(self,level,code,message,source):
  hold=level>=AlertLevel.CRITICAL
  a=SafetyAlert("ALT-"+uuid.uuid4().hex[:12].upper(),level,code,message,time.time(),source,hold)
  self.alerts.append(a)
  if hold:self.hold=True
  self.audit.append("ALERT","SafetyController",{"id":a.alert_id,"level":level.name,"code":code,"source":source,"hold":hold})
  return a
 def authorize_experiment_start(self,preflight):
  if not preflight.passed:raise SafetyViolation("preflight failed")
  if self.hold:raise SafetyViolation("safety hold active")
  self.audit.append("EXPERIMENT_START_AUTHORIZED","SafetyController",{});return True
 def clear_hold(self,confirmation=False,actor="operator"):
  if not confirmation:raise SafetyViolation("explicit confirmation required to clear hold")
  self.hold=False;self.audit.append("HOLD_CLEARED",actor,{})
 def guardian_recommendation(self,text):
  # Recorded as advisory only; never changes authoritative safety state.
  self.audit.append("GUARDIAN_SAFETY_ADVISORY","Guardian",{"recommendation":text})
  return {"advisory":True,"authoritative":False,"hold_changed":False}
