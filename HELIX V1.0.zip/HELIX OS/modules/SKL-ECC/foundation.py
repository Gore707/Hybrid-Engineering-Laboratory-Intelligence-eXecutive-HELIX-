from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

C_M_S=299792458.0
H_J_S=6.62607015e-34
EV_J=1.602176634e-19

class CarrierFamily(str,Enum):
    ELECTROMAGNETIC="ELECTROMAGNETIC"
    NEUTRINO="NEUTRINO"
    MASSIVE_PARTICLE="MASSIVE_PARTICLE"
    GRAVITATIONAL_WAVE="GRAVITATIONAL_WAVE"

class EvidenceClass(str,Enum):
    DEMONSTRATED_TECHNOLOGY="DEMONSTRATED_TECHNOLOGY"
    ESTABLISHED_PHYSICS="ESTABLISHED_PHYSICS"
    EXTRAPOLATED_ENGINEERING="EXTRAPOLATED_ENGINEERING"
    SPECULATIVE_UNRESOLVED="SPECULATIVE_UNRESOLVED"
    NEW_PHYSICS="NEW_PHYSICS"

def photon_energy_j_from_frequency(frequency_hz):
    if frequency_hz<=0:raise ValueError("frequency positive")
    return H_J_S*frequency_hz

def photon_energy_j_from_wavelength(wavelength_m):
    if wavelength_m<=0:raise ValueError("wavelength positive")
    return H_J_S*C_M_S/wavelength_m

def particle_energy_j_from_ev(energy_ev):
    if energy_ev<0:raise ValueError("energy nonnegative")
    return energy_ev*EV_J

def isotropic_flux_per_m2(emission_rate_per_s,distance_m):
    if emission_rate_per_s<0 or distance_m<=0:raise ValueError("invalid flux inputs")
    return emission_rate_per_s/(4*math.pi*distance_m**2)

def directed_flux_per_m2(emission_rate_per_s,beam_area_m2):
    if emission_rate_per_s<0 or beam_area_m2<=0:raise ValueError("invalid beam inputs")
    return emission_rate_per_s/beam_area_m2

def thin_target_interaction_probability(cross_section_m2,target_column_density_per_m2):
    if cross_section_m2<0 or target_column_density_per_m2<0:raise ValueError("nonnegative inputs")
    tau=cross_section_m2*target_column_density_per_m2
    return 1-math.exp(-tau)

def expected_detected_events_per_s(incident_flux_per_m2,detector_area_m2,interaction_probability,detector_efficiency=1.0):
    if incident_flux_per_m2<0 or detector_area_m2<0 or not 0<=interaction_probability<=1 or not 0<=detector_efficiency<=1:
        raise ValueError("invalid detector inputs")
    return incident_flux_per_m2*detector_area_m2*interaction_probability*detector_efficiency

def poisson_snr(signal_events,background_events):
    if signal_events<0 or background_events<0:raise ValueError("events nonnegative")
    total=signal_events+background_events
    return 0.0 if total==0 else signal_events/math.sqrt(total)

def ideal_event_limited_bit_rate_bps(detected_events_per_s,events_per_bit):
    if detected_events_per_s<0 or events_per_bit<=0:raise ValueError("invalid event budget")
    return detected_events_per_s/events_per_bit

def transmitter_energy_per_bit_j(carrier_energy_j,emitted_quanta_per_bit,wall_to_carrier_efficiency=1.0):
    if carrier_energy_j<0 or emitted_quanta_per_bit<0 or not 0<wall_to_carrier_efficiency<=1:
        raise ValueError("invalid energy budget")
    return carrier_energy_j*emitted_quanta_per_bit/wall_to_carrier_efficiency

def propagation_time_s(distance_m,speed_m_s=C_M_S):
    if distance_m<0 or speed_m_s<=0 or speed_m_s>C_M_S*(1+1e-12):raise ValueError("established-physics propagation requires 0 < v <= c")
    return distance_m/speed_m_s

def causality_bypass_available():
    return False

@dataclass(frozen=True)
class ExtremeCarrierAssessment:
    family:CarrierFamily
    evidence:EvidenceClass
    carrier_energy_j:float
    emitted_quanta_per_s:float
    distance_m:float
    detector_area_m2:float
    interaction_probability:float
    detector_efficiency:float=1.0
    events_per_bit:float=10.0
    beam_area_m2:float|None=None
    def __post_init__(self):
        if self.carrier_energy_j<0 or self.emitted_quanta_per_s<0 or self.distance_m<=0 or self.detector_area_m2<0:
            raise ValueError("invalid assessment")
        if not 0<=self.interaction_probability<=1 or not 0<=self.detector_efficiency<=1 or self.events_per_bit<=0:
            raise ValueError("invalid probability/efficiency")
        if self.beam_area_m2 is not None and self.beam_area_m2<=0:raise ValueError("beam area positive")
    @property
    def incident_flux_per_m2(self):
        return directed_flux_per_m2(self.emitted_quanta_per_s,self.beam_area_m2) if self.beam_area_m2 is not None else isotropic_flux_per_m2(self.emitted_quanta_per_s,self.distance_m)
    @property
    def detected_events_per_s(self):
        return expected_detected_events_per_s(self.incident_flux_per_m2,self.detector_area_m2,self.interaction_probability,self.detector_efficiency)
    @property
    def ideal_bit_rate_bps(self):
        return ideal_event_limited_bit_rate_bps(self.detected_events_per_s,self.events_per_bit)
    @property
    def carrier_power_w(self):
        return self.carrier_energy_j*self.emitted_quanta_per_s
