from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
import time,json
from .local_llm import LocalLLMRuntime,load_model_config
from .reasoning import GuardianReasoner
from .rag import ScientificKnowledgeIndex
from .analytics_service import GuardianAnalyticsService
from .memory import GuardianMemoryStore
from .scientific_intelligence import ScientificIntelligenceService
from .tools import GuardianToolBridge

@dataclass(frozen=True)
class GuardianDiagnostic:
    name:str;ok:bool;detail:str;elapsed_ms:float

class GuardianAIServices:
    """Wires Guardian AI services without making model availability a HELIX boot requirement."""
    def __init__(self,root,command_service,context_provider):
        self.root=Path(root);self.diagnostics=[]
        self.knowledge=ScientificKnowledgeIndex()
        self.analytics=GuardianAnalyticsService()
        self.memory=GuardianMemoryStore(self.root/"user"/"guardian"/"memory.json")
        self.intelligence=ScientificIntelligenceService(self.memory,self.analytics)
        self.tools=GuardianToolBridge(command_service,context_provider)
        config=load_model_config(self.root/"user"/"guardian"/"local_model.json")
        self.runtime=LocalLLMRuntime(config)
        self.reasoner=GuardianReasoner(self.runtime,self.knowledge,self.tools)

    def initialize(self,auto_load_model=False):
        self.diagnostics=[]
        flag=self.root/"user"/"guardian"/"autoload_model"
        auto_load_model=bool(auto_load_model or flag.exists())
        self._check("scientific-index",lambda:f"{self.knowledge.index_helix_resources(self.root)} resource(s) indexed")
        self._check("memory",lambda:f"{len(self.memory.records)} persistent record(s)")
        self._check("tool-catalog",lambda:f"{len(self.tools.catalog())} deterministic action(s)")
        if self.runtime.config is None:
            self.diagnostics.append(GuardianDiagnostic("local-llm-config",True,"Not configured; deterministic Guardian remains available.",0))
        elif not self.runtime.available():
            self.diagnostics.append(GuardianDiagnostic("local-llm-runtime",False,"Model configured but llama-cpp-python is not installed.",0))
        elif auto_load_model:
            self._check("local-llm-load",lambda:("loaded" if self.runtime.load() else "not loaded"))
        else:
            self.diagnostics.append(GuardianDiagnostic("local-llm-load",True,"Configured; deferred load.",0))
        return self

    def _check(self,name,fn):
        start=time.perf_counter()
        try:detail=str(fn());ok=True
        except Exception as exc:detail=f"{type(exc).__name__}: {exc}";ok=False
        self.diagnostics.append(GuardianDiagnostic(name,ok,detail,(time.perf_counter()-start)*1000))
        return ok

    def benchmark_retrieval(self,query="quantum memory",iterations=25):
        start=time.perf_counter();hits=[]
        for _ in range(max(1,iterations)):hits=self.knowledge.search(query)
        elapsed=time.perf_counter()-start
        return {"query":query,"iterations":max(1,iterations),"elapsed_seconds":elapsed,
                "queries_per_second":max(1,iterations)/max(elapsed,1e-9),"last_hit_count":len(hits)}

    def status(self):
        return {"llm_configured":self.runtime.config is not None,"llm_loaded":self.reasoner.ready,"runtime_available":self.runtime.available(),
                "knowledge_chunks":len(self.knowledge.chunks),"memory_records":len(self.memory.records),
                "diagnostics":[asdict(x) for x in self.diagnostics]}
