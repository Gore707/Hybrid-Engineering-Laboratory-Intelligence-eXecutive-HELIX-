from dataclasses import dataclass
@dataclass(frozen=True)
class RFModel:
    model_id:str; name:str; equation:str; inputs:tuple[str,...]; outputs:tuple[str,...]
class RFRegistry:
    def __init__(self):
        self._models=(
          RFModel("RF-FREQ-WAVE","Frequency-wavelength relation","lambda=c/f",("frequency_hz",),("wavelength_m",)),
          RFModel("RF-FSPL","Free-space path loss","L=(4*pi*R/lambda)^2",("distance_m","frequency_hz"),("loss_linear","loss_db")),
          RFModel("RF-ANT-GAIN","Circular aperture antenna gain","G=eta*(pi*D/lambda)^2",("efficiency","diameter_m","frequency_hz"),("gain_linear",)),
          RFModel("RF-FRIIS","Friis received power","Pr=Pt*Gt*Gr/Lfs",("Pt","Gt","Gr","distance","frequency","efficiency"),("Pr",)),
          RFModel("RF-NOISE-KTB","Thermal noise","N=k*T*B",("temperature_k","bandwidth_hz"),("noise_w",)),
          RFModel("RF-SNR","Signal-to-noise ratio","SNR=Ps/Pn",("signal_w","noise_w"),("snr",)),
          RFModel("RF-SHANNON","Shannon AWGN capacity","C=B*log2(1+SNR)",("bandwidth_hz","snr"),("capacity_bps",)),
          RFModel("RF-APERTURE","Effective receive aperture","Ae=G*lambda^2/(4*pi)",("gain","frequency"),("area_m2",)),
          RFModel("RF-BEAM-HPBW","Dish half-power beamwidth approximation","theta=k*lambda/D",("diameter","frequency","k"),("hpbw_rad",)),
          RFModel("RF-EIRP","Effective isotropic radiated power","EIRP=Pt*G*eta",("power","gain","efficiency"),("eirp_w",)),
          RFModel("RF-POL-MISMATCH","Linear polarization mismatch","eta_pol=cos^2(psi)",("angle",),("factor",)),
          RFModel("RF-POINT-GAUSS","Gaussian pointing loss approximation","Lp=exp[-4 ln2 (e/HPBW)^2]",("pointing_error","hpbw"),("factor",)),
          RFModel("RF-ARRAY-PHASE","ULA progressive steering phase","beta=-2*pi*d*sin(theta0)/lambda",("spacing","frequency","steering_angle"),("phase_rad",)),
          RFModel("RF-ARRAY-FACTOR","Normalized uniform linear array factor","AF=|sum exp(j n psi)|/N",("N","spacing","frequency","angle","steering"),("array_factor",)),
          RFModel("RF-PROP-DELAY","Vacuum propagation delay","t=R/c",("distance",),("delay_s",)),
          RFModel("RF-DOPPLER-1","First-order one-way Doppler","df=f*v_r/c",("carrier_frequency","radial_velocity"),("shift_hz",)),
          RFModel("RF-DOPPLER-REL","Relativistic radial Doppler","f_r=f_t*sqrt((1+beta)/(1-beta))",("carrier_frequency","radial_velocity"),("received_frequency",)),
          RFModel("RF-FRESNEL","Fresnel-zone radius","r_n=sqrt(n*lambda*d1*d2/(d1+d2))",("order","d1","d2","frequency"),("radius_m",)),
          RFModel("RF-ATM-SPEC","Specific attenuation path loss","L=gamma*ell",("specific_db_per_km","path_km"),("loss_db",)),
          RFModel("RF-DELAY-SPREAD","Two-ray delay spread","dt=|L1-L2|/c",("path1","path2"),("delay_s",)),
          RFModel("RF-COHERENCE-BW","Coherence bandwidth approximation","Bc=1/(k*tau_rms)",("rms_delay","factor"),("bandwidth_hz",)),
          RFModel("RF-RAYLEIGH-OUTAGE","Rayleigh power outage","Pout=1-exp(-Pth/Pmean)",("threshold_over_mean",),("probability",)),
          RFModel("RF-NF-CASCADE","Friis cascaded noise factor","F=F1+(F2-1)/G1+...",("stages",),("noise_factor",)),
          RFModel("RF-RX-SENS","Receiver sensitivity","Pmin=k*T*B*SNRreq*F",("temperature","bandwidth","snr","noise_factor"),("sensitivity_w",)),
          RFModel("RF-SFDR","Third-order SFDR approximation","SFDR=2/3*(IIP3-Nfloor)",("iip3","noise_floor","bandwidth"),("sfdr_db",)),
          RFModel("RF-MIXER","Ideal mixer output","fIF=|fRF-fLO| or fRF+fLO",("rf","lo","side"),("output_frequency",)),
          RFModel("RF-ADC-QSNR","Ideal ADC quantization SNR","SNRq=6.02N+1.76 dB",("bits",),("snr_db",)),
          RFModel("RF-PA-DC","PA DC power","Pdc=Prf/eta",("rf_power","efficiency"),("dc_power",)),
          RFModel("RF-MASER-PHOTON","Microwave photon energy","E=h*f",("frequency",),("energy_j",)),
          RFModel("RF-RESONATOR-Q","Resonator quality factor","Q=f0/df",("frequency","linewidth"),("Q",)),
          RFModel("RF-COHERENCE-T","Lorentzian coherence time","tau_c=1/(pi*df)",("linewidth",),("coherence_time",)),
          RFModel("RF-MASER-INVERSION","Two-level inversion fraction","I=(Nu-Nl)/(Nu+Nl)",("upper","lower"),("inversion",)),
          RFModel("RF-MASER-GAIN","Small-signal power gain","G=exp(g*L)",("gain_coefficient","length"),("gain",)),
          RFModel("RF-PHASE-COHERENCE","Array phase coherence","C=|sum exp(j phi)|/N",("phase_errors",),("coherence",)),
          RFModel("RF-COHERENT-COMBINE","Normalized coherent combining peak","Ppeak=N*P*C^2",("per_source_power","phases"),("peak_power",)),
          RFModel("RF-PHASE-DRIFT","Phase drift from frequency error","dphi=2*pi*df*t",("frequency_error","time"),("phase_drift",)),
          RFModel("RF-SYMBOL-RATE","Coded symbol rate","Rs=Rb/(k*Rc)",("bit_rate","bits_per_symbol","code_rate"),("symbol_rate",)),
          RFModel("RF-SPECTRAL-EFF","Spectral efficiency","eta=k*Rc/(1+alpha)",("modulation","code_rate","rolloff"),("bps_per_hz",)),
          RFModel("RF-EBN0","Eb/N0 from SNR","EbN0=SNR*B/Rb",("snr","bandwidth","bit_rate"),("ebn0",)),
          RFModel("RF-BER-BPSK","Coherent BPSK AWGN BER","Pb=Q(sqrt(2*EbN0))",("ebn0",),("ber",)),
          RFModel("RF-BER-MQAM","Square M-QAM AWGN BER approximation","Pb~4/k*(1-1/sqrt(M))*Q(sqrt(3kEbN0/(M-1)))",("ebn0","M"),("ber",)),
          RFModel("RF-PACKET-ERR","Independent-bit packet error","PER=1-(1-BER)^N",("ber","packet_bits"),("per",)),
          RFModel("RF-GOODPUT","Packet goodput","G=Rb*(1-PER)*eta_protocol",("bit_rate","per","protocol_efficiency"),("goodput",)),
          RFModel("RF-LINK-END2END","Integrated RF link simulation","Pt,Gt,loss,Gr -> Pr -> SNR -> Eb/N0 -> BER/PER/goodput",("scenario",),("result",)),
          RFModel("RF-LINK-MARGIN","Effective Eb/N0 margin","M=EbN0+coding_gain-required_EbN0",("ebn0","coding_gain","requirement"),("margin_db",)),
          RFModel("RF-LINK-MIN-PT","Minimum transmitter power for target margin","Pt_req=Pt_ref*10^((Mtarget-Mref)/10)",("scenario","target_margin"),("power_w",)),
        )
    def get(self,model_id):
        for x in self._models:
            if x.model_id==model_id:return x
        raise KeyError(model_id)
    def all(self):return self._models
