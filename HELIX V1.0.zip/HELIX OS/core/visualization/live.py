from __future__ import annotations
from collections import deque
class LiveSeries:
    def __init__(self,max_points=10000):
        if max_points<1:raise ValueError("max_points must be positive")
        self.x=deque(maxlen=max_points);self.y=deque(maxlen=max_points)
    def append(self,x,y):self.x.append(float(x));self.y.append(float(y))
    def arrays(self):
        import numpy as np
        return np.asarray(self.x,dtype=float),np.asarray(self.y,dtype=float)
    def __len__(self):return len(self.x)
