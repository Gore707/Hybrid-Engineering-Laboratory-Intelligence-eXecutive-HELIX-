param(
 [string]$HelixDir = "$PSScriptRoot",
 [switch]$CpuOnly
)
$ErrorActionPreference="Stop"
$python=Join-Path $HelixDir ".venv\Scripts\python.exe"
if (-not (Test-Path $python)) { throw "HELIX virtual environment not found at $python. Install HELIX first." }

Write-Host "HELIX Guardian AI runtime setup"
& $python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "pip upgrade failed." }

# Portable baseline. GPU-specific llama.cpp wheels/builds vary by hardware and driver stack,
# so acceleration is validated separately rather than falsely assumed here.
& $python -m pip install -r (Join-Path $HelixDir "requirements.txt")
if ($LASTEXITCODE -ne 0) { throw "HELIX/Guardian dependency installation failed." }

& $python (Join-Path $HelixDir "GUARDIAN_AI_DIAGNOSTIC.py")
if ($LASTEXITCODE -ne 0) { throw "Guardian AI diagnostic failed." }

Write-Host "Guardian AI runtime installed. No GGUF model was downloaded or selected."
