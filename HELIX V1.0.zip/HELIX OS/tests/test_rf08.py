import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-RF"
sp=importlib.util.spec_from_file_location("skl_rf",M/"__init__.py",submodule_search_locations=[str(M)])
r=importlib.util.module_from_spec(sp);sys.modules["skl_rf"]=r;sp.loader.exec_module(r)
class T(unittest.TestCase):
 def test_validation_passes(self):
  v=r.run_cross_engine_validation();self.assertTrue(v.passed)
 def test_validation_count(self):
  v=r.run_cross_engine_validation();self.assertEqual(v.total_count,24);self.assertEqual(v.passed_count,24)
 def test_validation_names_unique(self):
  v=r.run_cross_engine_validation();self.assertEqual(len({x.name for x in v.checks}),v.total_count)
 def test_frequency(self):self.assertAlmostEqual(r.wavelength_m(10e9)*10e9,r.C)
 def test_antenna(self):self.assertGreater(r.effective_aperture_m2(100,10e9),0)
 def test_propagation(self):self.assertAlmostEqual(r.propagation_delay_s(r.C),1)
 def test_receiver(self):self.assertGreater(r.ReceiverChain((r.RFStage("a",10,1.2),),290,1e6,10).sensitivity_w,0)
 def test_coherent(self):self.assertEqual(r.CoherentMicrowaveArray(1,(0,0),1e9).peak_combined_power_w,2)
 def test_digital(self):self.assertEqual(r.bits_per_symbol(r.Modulation.QPSK),2)
 def test_integrated(self):
  p=r.PropagationLossBudget(1000,1e9);s=r.IntegratedRFScenario(100,100,100,p,1.5,290,1e6,r.Modulation.QPSK,.8,.2,-10,2)
  self.assertEqual(r.simulate_rf_link(s).evidence,"SIMULATION")
 def test_manifest_patch(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-RF-08")
 def test_manifest_complete(self):self.assertIn("COMPLETE",json.loads((M/"module.json").read_text())["status"])
 def test_completion_exists(self):self.assertTrue((R/"RF_COMPLETE.json").exists())
 def test_completion_status(self):self.assertEqual(json.loads((R/"RF_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_completion_count(self):
  x=json.loads((R/"RF_COMPLETE.json").read_text());self.assertEqual((x["patches_completed"],x["patches_total"]),(8,8))
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-HQIC"])
 def test_hqic_complete(self):self.assertEqual(json.loads((R/"HQIC_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_qmem_complete(self):self.assertEqual(json.loads((R/"QMEM_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_sto_complete(self):self.assertEqual(json.loads((R/"STO_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_pho_complete(self):self.assertEqual(json.loads((R/"PHO_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
 def test_no_acceptance(self):self.assertFalse(list(R.rglob("acceptance.md")))
if __name__=="__main__":unittest.main()
