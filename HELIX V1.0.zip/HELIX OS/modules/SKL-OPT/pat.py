from __future__ import annotations
from dataclasses import dataclass
import math

def angular_to_lateral_displacement_m(angle_rad,distance_m):
    if distance_m<0: raise ValueError("distance nonnegative")
    return math.tan(angle_rad)*distance_m

def small_angle_displacement_m(angle_rad,distance_m):
    if distance_m<0: raise ValueError("distance nonnegative")
    return angle_rad*distance_m

def gaussian_pointing_coupling(offset_rad,beam_half_angle_rad):
    if beam_half_angle_rad<=0: raise ValueError("beam angle positive")
    # Gaussian intensity with beam_half_angle interpreted as 1/e^2 intensity radius.
    return math.exp(-2*(offset_rad/beam_half_angle_rad)**2)

def gaussian_pointing_loss_db(offset_rad,beam_half_angle_rad):
    c=gaussian_pointing_coupling(offset_rad,beam_half_angle_rad)
    return -10*math.log10(c) if c>0 else math.inf

def rss_pointing_error_rad(*independent_rms_errors_rad):
    if not independent_rms_errors_rad: return 0.0
    if any(x<0 for x in independent_rms_errors_rad): raise ValueError("RMS errors nonnegative")
    return math.sqrt(sum(x*x for x in independent_rms_errors_rad))

def total_bias_plus_rms_rad(boresight_bias_rad,rms_jitter_rad):
    if rms_jitter_rad<0: raise ValueError("RMS jitter nonnegative")
    return math.sqrt(boresight_bias_rad**2+rms_jitter_rad**2)

def diffraction_to_pointing_ratio(pointing_rms_rad,diffraction_half_angle_rad):
    if pointing_rms_rad<0 or diffraction_half_angle_rad<=0: raise ValueError("invalid ratio inputs")
    return pointing_rms_rad/diffraction_half_angle_rad

def acquisition_grid_points(field_of_regard_half_angle_rad,step_rad):
    if field_of_regard_half_angle_rad<0 or step_rad<=0: raise ValueError("invalid acquisition geometry")
    n=math.ceil(2*field_of_regard_half_angle_rad/step_rad)+1
    return n*n

def acquisition_scan_time_s(grid_points,dwell_time_s,settle_time_s=0.0):
    if grid_points<1 or int(grid_points)!=grid_points or dwell_time_s<0 or settle_time_s<0: raise ValueError("invalid acquisition timing")
    return grid_points*(dwell_time_s+settle_time_s)

def max_rms_pointing_for_min_coupling_rad(min_coupling,beam_half_angle_rad):
    if not 0<min_coupling<=1 or beam_half_angle_rad<=0: raise ValueError("invalid coupling/beam")
    return beam_half_angle_rad*math.sqrt(-math.log(min_coupling)/2)

@dataclass(frozen=True)
class PATBudget:
    beam_half_angle_rad:float
    sensor_noise_rms_rad:float=0.0
    platform_jitter_rms_rad:float=0.0
    actuator_rms_rad:float=0.0
    ephemeris_rms_rad:float=0.0
    boresight_bias_rad:float=0.0
    def __post_init__(self):
        if self.beam_half_angle_rad<=0 or min(self.sensor_noise_rms_rad,self.platform_jitter_rms_rad,self.actuator_rms_rad,self.ephemeris_rms_rad)<0:
            raise ValueError("invalid PAT budget")
    @property
    def random_rms_rad(self):
        return rss_pointing_error_rad(self.sensor_noise_rms_rad,self.platform_jitter_rms_rad,self.actuator_rms_rad,self.ephemeris_rms_rad)
    @property
    def effective_error_rad(self):
        return total_bias_plus_rms_rad(self.boresight_bias_rad,self.random_rms_rad)
    @property
    def nominal_coupling(self):
        return gaussian_pointing_coupling(self.effective_error_rad,self.beam_half_angle_rad)
    @property
    def nominal_loss_db(self):
        return gaussian_pointing_loss_db(self.effective_error_rad,self.beam_half_angle_rad)
    @property
    def error_to_beam_ratio(self):
        return diffraction_to_pointing_ratio(self.random_rms_rad,self.beam_half_angle_rad)
    def meets_coupling(self,minimum):
        return self.nominal_coupling>=minimum
