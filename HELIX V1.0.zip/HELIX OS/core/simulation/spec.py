from dataclasses import dataclass,field
from enum import Enum
class SimulationMode(str,Enum):
 POINT="POINT";TIME_DOMAIN="TIME_DOMAIN";SWEEP="SWEEP";MONTE_CARLO="MONTE_CARLO"
 SENSITIVITY="SENSITIVITY";OPTIMIZATION="OPTIMIZATION";FAILURE="FAILURE";SUITE="SUITE"
@dataclass(frozen=True)
class SimulationSpec:
 model_id:str;mode:SimulationMode;inputs:dict
 output_key:str|None=None;sweep_parameter:str|None=None;sweep_values:tuple=()
 time_parameter:str|None=None;time_values:tuple=()
 distributions:dict=field(default_factory=dict);samples:int=0;seed:int|None=None
 objective:str="max";failure_rules:dict=field(default_factory=dict)
