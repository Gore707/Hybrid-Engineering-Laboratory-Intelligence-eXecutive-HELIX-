import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ECC"
sp=importlib.util.spec_from_file_location("skl_ecc",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_ecc"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_photon_freq(self):self.assertAlmostEqual(q.photon_energy_j_from_frequency(1e9),q.H_J_S*1e9)
 def test_photon_wave(self):self.assertGreater(q.photon_energy_j_from_wavelength(1e-9),1e-16)
 def test_ev(self):self.assertAlmostEqual(q.particle_energy_j_from_ev(1),q.EV_J)
 def test_iso_inverse_square(self):self.assertAlmostEqual(q.isotropic_flux_per_m2(1e12,2)/q.isotropic_flux_per_m2(1e12,1),.25)
 def test_beam(self):self.assertEqual(q.directed_flux_per_m2(100,10),10)
 def test_interaction_small(self):self.assertAlmostEqual(q.thin_target_interaction_probability(1e-10,1e6),1-math.exp(-1e-4))
 def test_detect(self):self.assertEqual(q.expected_detected_events_per_s(100,2,.1,.5),10)
 def test_snr(self):self.assertGreater(q.poisson_snr(100,25),8)
 def test_rate(self):self.assertEqual(q.ideal_event_limited_bit_rate_bps(100,10),10)
 def test_energy_bit(self):self.assertEqual(q.transmitter_energy_per_bit_j(2,10,.5),40)
 def test_latency(self):self.assertEqual(q.propagation_time_s(q.C_M_S),1)
 def test_superluminal_rejected(self):
  with self.assertRaises(ValueError):q.propagation_time_s(1,q.C_M_S*1.1)
 def test_no_bypass(self):self.assertFalse(q.causality_bypass_available())
 def test_assessment(self):
  a=q.ExtremeCarrierAssessment(q.CarrierFamily.NEUTRINO,q.EvidenceClass.EXTRAPOLATED_ENGINEERING,1e-10,1e20,1e9,100,1e-12,.5,10)
  self.assertGreater(a.incident_flux_per_m2,0);self.assertGreater(a.detected_events_per_s,0);self.assertGreater(a.ideal_bit_rate_bps,0)
 def test_directed_assessment(self):
  a=q.ExtremeCarrierAssessment(q.CarrierFamily.MASSIVE_PARTICLE,q.EvidenceClass.EXTRAPOLATED_ENGINEERING,1e-9,1e12,1e9,10,.1,1,10,100)
  self.assertEqual(a.incident_flux_per_m2,1e10)
 def test_registry(self):self.assertEqual(len(q.ExtremeCarrierRegistry().all()),9);self.assertIsNotNone(q.ExtremeCarrierRegistry().get("ECC-DETECT"))
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/extreme_carrier.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-ECC-01");self.assertEqual(x["status"],"ECC-01 of 8")
 def test_dependencies(self):self.assertTrue({"SKL-OPT","SKL-RF","SKL-ISN"}<=set(json.loads((M/"module.json").read_text())["dependencies"]))
 def test_isn_complete(self):self.assertEqual(json.loads((R/"ISN_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
