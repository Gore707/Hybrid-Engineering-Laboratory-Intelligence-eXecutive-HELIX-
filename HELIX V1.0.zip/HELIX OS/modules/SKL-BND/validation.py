from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .foundation import BoundaryEvidence,C_M_S
from .axion import photon_axion_conversion_probability
from .dark_photon import photon_dark_photon_probability
from .qft_vacuum import spacelike_vacuum_correlation_implies_controllable_signal
from .curved_spacetime import schwarzschild_radius_m
from .wormhole import physically_demonstrated_traversable_wormhole_available
from .warp_metric import physically_demonstrated_warp_metric_engineering_available
from .causality import demonstrated_ftl_information_gate
from .lab import BoundaryFamily,BoundaryScenario

class GateSeverity(str,Enum):
    INFO="INFO"; WARNING="WARNING"; KILL="KILL"

@dataclass(frozen=True)
class ValidationGate:
    gate_id:str
    passed:bool
    severity:GateSeverity
    message:str

def relative_sensitivity(function,x,relative_step=1e-6):
    if x==0 or relative_step<=0:raise ValueError("nonzero x and positive step required")
    h=abs(x)*relative_step
    yp=function(x+h); ym=function(x-h); y0=function(x)
    if y0==0:return math.inf
    derivative=(yp-ym)/(2*h)
    return derivative*x/y0

def domain_gate(condition,gate_id,message,severity=GateSeverity.KILL):
    return ValidationGate(gate_id,bool(condition),severity,message)

def evidence_gate(scenario):
    if scenario.family in (BoundaryFamily.WORMHOLE,BoundaryFamily.WARP_METRIC,
                           BoundaryFamily.AXION_ALP,BoundaryFamily.DARK_PHOTON):
        ok=scenario.evidence not in (BoundaryEvidence.DEMONSTRATED_TECHNOLOGY,)
        return ValidationGate("BND-EVIDENCE-SPEC",ok,GateSeverity.KILL,
          "Unconfirmed boundary carrier/geometry must not be labeled demonstrated technology.")
    return ValidationGate("BND-EVIDENCE-BASE",True,GateSeverity.INFO,"Evidence classification accepted.")

def causality_gate(scenario):
    ftl=scenario.effective_endpoint_speed_m_s>C_M_S or scenario.local_signal_speed_m_s>C_M_S
    demonstrated=demonstrated_ftl_information_gate(
        scenario.evidence,
        scenario.local_signal_speed_m_s>C_M_S,
        scenario.effective_endpoint_speed_m_s>C_M_S)
    return ValidationGate("BND-CAUSALITY",not(ftl and demonstrated),GateSeverity.KILL,
      "Apparent, coordinate, modeled or hypothetical FTL must not be promoted to demonstrated FTL information.")

def candidate_failure_gates(scenario):
    gates=[evidence_gate(scenario),causality_gate(scenario)]
    if scenario.family==BoundaryFamily.WORMHOLE:
        gates.append(ValidationGate("BND-WH-HARDWARE",not physically_demonstrated_traversable_wormhole_available(),
          GateSeverity.KILL,"No demonstrated traversable-wormhole hardware exists."))
    if scenario.family==BoundaryFamily.WARP_METRIC:
        gates.append(ValidationGate("BND-WARP-HARDWARE",not physically_demonstrated_warp_metric_engineering_available(),
          GateSeverity.KILL,"No demonstrated engineered warp spacetime exists."))
    if scenario.family==BoundaryFamily.QFT_VACUUM:
        gates.append(ValidationGate("BND-QFT-NOSIGNAL",not spacelike_vacuum_correlation_implies_controllable_signal(),
          GateSeverity.KILL,"Vacuum/spacelike correlations are not a controllable FTL signal channel."))
    return gates

def cross_engine_validation():
    checks={}
    checks["axion_zero_coupling"]=photon_axion_conversion_probability(0.0,10.0,10.0)==0.0
    checks["dark_photon_zero_mixing"]=photon_dark_photon_probability(0.0,10.0,1e-3,1.0)==0.0
    checks["qft_no_spacelike_signal"]=not spacelike_vacuum_correlation_implies_controllable_signal()
    checks["schwarzschild_solar_scale"]=2900<schwarzschild_radius_m(1.98847e30)<3000
    checks["wormhole_not_demonstrated"]=not physically_demonstrated_traversable_wormhole_available()
    checks["warp_not_demonstrated"]=not physically_demonstrated_warp_metric_engineering_available()
    checks["speculative_ftl_gate"]=not demonstrated_ftl_information_gate(BoundaryEvidence.SPECULATIVE_UNRESOLVED,False,True)
    checks["c_light_positive"]=C_M_S>0
    return checks

def cross_engine_passed():
    c=cross_engine_validation()
    return all(c.values()),c

def validate_scenarios(scenarios):
    report=[]
    for s in scenarios:
        report.extend(candidate_failure_gates(s))
    ok=all(g.passed for g in report if g.severity==GateSeverity.KILL)
    return ok,tuple(report)
