import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QCOM"
sp=importlib.util.spec_from_file_location("skl_qcom",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qcom"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_beam_waist(self):self.assertEqual(q.gaussian_beam_radius_m(.1,1e-6,0),.1)
 def test_beam_expands(self):self.assertGreater(q.gaussian_beam_radius_m(.1,1e-6,1e6),.1)
 def test_capture_bounds(self):self.assertTrue(0<q.circular_aperture_capture_fraction(1,2)<1)
 def test_point_perfect(self):self.assertEqual(q.gaussian_pointing_efficiency(0,1e6,1),1)
 def test_point_hurts(self):self.assertLess(q.gaussian_pointing_efficiency(1e-6,1e6,2),1)
 def test_atmosphere(self):self.assertAlmostEqual(q.atmospheric_transmission_from_optical_depth(1),math.exp(-1))
 def test_eff_product(self):self.assertAlmostEqual(q.free_space_channel_efficiency(.8,.9,.5,.9,.8),.8*.9*.5*.9*.8)
 def test_db(self):self.assertEqual(q.link_loss_db(.1),10)
 def test_slant_zenith(self):self.assertAlmostEqual(q.slant_range_m(6371e3,500e3,math.pi/2),500e3,places=6)
 def test_light_time(self):self.assertEqual(q.light_time_s(q.C_M_S),1)
 def test_link(self):
  x=q.FreeSpaceQuantumLink(800e-9,.1,500e3,1.0,1e-7,.8,.9,.9,.7,1e6,100,.01)
  self.assertGreater(x.beam_radius_m,0);self.assertTrue(0<x.channel_efficiency<1);self.assertGreater(x.signal_detection_rate_per_s,0);self.assertTrue(0<=x.qber<=.5);self.assertGreaterEqual(x.idealized_bb84_secret_rate_bps,0)
 def test_background_hurts(self):
  a=q.FreeSpaceQuantumLink(800e-9,.1,500e3,1,source_rate_per_s=1e6,background_rate_per_s=0,intrinsic_error=.01)
  b=q.FreeSpaceQuantumLink(800e-9,.1,500e3,1,source_rate_per_s=1e6,background_rate_per_s=10000,intrinsic_error=.01)
  self.assertGreater(b.qber,a.qber)
 def test_memory_preserved(self):self.assertEqual(q.multimode_throughput_limit_per_s(10,.01),1000)
 def test_repeater_preserved(self):self.assertEqual(q.nested_swap_success_probability(.5,.5,1),.125)
 def test_no_signalling_preserved(self):self.assertEqual(q.no_signalling_remote_probability("satellite"),(.5,.5))
 def test_registry(self):self.assertTrue({"QCOM-FS-BEAM","QCOM-FS-APERTURE","QCOM-FS-POINT","QCOM-FS-ATM","QCOM-FS-LINK","QCOM-SAT-RANGE"}<={x.model_id for x in q.QuantumCommRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QCOM-08")
 def test_opt_dependency(self):self.assertIn("SKL-OPT",json.loads((M/"module.json").read_text())["dependencies"])
 def test_opt_complete(self):self.assertEqual(json.loads((R/"OPT_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_pho_complete(self):self.assertEqual(json.loads((R/"PHO_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
