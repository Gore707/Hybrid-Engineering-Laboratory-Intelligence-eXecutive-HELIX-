from __future__ import annotations
from dataclasses import dataclass
import math
from .architecture import *
from .layering import *
from .transduction import *
from .controller import *
from .integrity import *
from .engineering import *
from .simulation import *

@dataclass(frozen=True)
class ValidationCheck:
    check_id:str
    passed:bool
    detail:str

@dataclass(frozen=True)
class ValidationReport:
    checks:tuple[ValidationCheck,...]
    @property
    def passed(self): return all(x.passed for x in self.checks)
    @property
    def passed_count(self): return sum(x.passed for x in self.checks)
    @property
    def total_count(self): return len(self.checks)
    def as_dict(self):
        return {"passed":self.passed,"passed_count":self.passed_count,"total_count":self.total_count,
                "checks":[{"check_id":x.check_id,"passed":x.passed,"detail":x.detail} for x in self.checks]}

def run_cross_engine_validation():
    checks=[]
    def ck(i,ok,d): checks.append(ValidationCheck(i,bool(ok),d))
    # HQIC-01: unlike information domains must remain separate.
    try:
        aggregate_capacity_same_domain([Capacity(1,InformationDomain.CLASSICAL,"bit"),Capacity(1,InformationDomain.QUANTUM,"qubit")])
        sep=False
    except ValueError: sep=True
    ck("architecture.capacity_separation",sep,"classical bits and quantum units cannot be summed")
    # HQIC-02: geometry and optics.
    lg=LayerGeometry("g",PhysicalLayerRole.CLASSICAL_5D_ARCHIVE,1e-3,.1,.05,1.5)
    ck("layering.volume",math.isclose(lg.volume_m3,5e-6),"layer volume t*w*h")
    oi=OpticalInterface("a","b",1.0,1.5)
    ck("layering.fresnel",math.isclose(oi.normal_incidence_reflectance,.04),"normal-incidence Fresnel reflectance")
    ck("layering.addressing",layer_address_capacity(.01,.01,.001,.001)==100,"planar address count")
    # HQIC-03: transduction.
    ck("transduction.cascade",math.isclose(cascaded_efficiency(.8,.5,.9),.36),"stage efficiencies multiply")
    e=.37
    ck("transduction.loss_inverse",math.isclose(efficiency_from_insertion_loss_db(insertion_loss_db(e)),e,rel_tol=1e-12),"loss/efficiency inverse")
    # HQIC-04: deterministic controller boundary.
    caps=DeviceCapabilities(True,True,True,True,True,True,99,4)
    ok,_=validate_command(HQICCommand("r",CommandKind.READ_CLASSICAL,DeviceAddress(classical_address=5)),caps,DeviceState.IDLE)
    ck("controller.valid_read",ok,"in-range supported read accepted")
    ok,reason=validate_command(HQICCommand("q",CommandKind.STORE_QUANTUM,DeviceAddress(quantum_slot=1)),caps,DeviceState.IDLE)
    ck("controller.confirmation_gate",(not ok and reason=="confirmation_required"),"quantum store requires confirmation")
    # HQIC-05: integrity.
    ck("integrity.repetition",math.isclose(repetition_logical_error_probability(.1,3),.028),"3-bit repetition analytical result")
    try:
        no_cloning_integrity_guard(True,2); nc=False
    except ValueError: nc=True
    ck("integrity.no_cloning",nc,"unknown state cloning rejected")
    # HQIC-06: engineering.
    ck("engineering.rss",math.isclose(rss_tolerance(3,4),5),"RSS tolerance identity")
    stage=CryogenicStage("test",4,10,1,1,2)
    ck("engineering.thermal_margin",(stage.passes and math.isclose(stage.margin_w,6)),"cryogenic load margin")
    # HQIC-07: integrated scenario.
    sc=HQICScenario("validation",1e-4,3,.01,3,10,(.8,.8),(.01,.01),10,1,1,2,1e-7,1e-6,(1e-6,1e-6),3e-6,.1,.5,1e-6)
    result=run_hqic_scenario(sc)
    ck("simulation.nominal_pass",result.status==SimulationStatus.PASS,"nominal integrated scenario passes")
    bad=HQICScenario("thermal-fail",1e-4,3,.01,3,10,(.8,.8),(.01,.01),2,1,1,2,1e-7,1e-6,(1e-6,1e-6),3e-6,.1,.5,1e-6)
    br=run_hqic_scenario(bad)
    ck("simulation.thermal_kill_gate","thermal_capacity" in br.failures,"insufficient cooling trips explicit failure")
    ck("simulation.provenance",result.provenance=="SIMULATION","integrated result remains source-labeled")
    return ValidationReport(tuple(checks))
