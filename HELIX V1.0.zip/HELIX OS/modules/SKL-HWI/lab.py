from __future__ import annotations
from dataclasses import dataclass
from .validation import build_validation_report,GateStatus
from .orchestration import HardwareExperimentOrchestrator,ExperimentRunState

@dataclass(frozen=True)
class HardwareLabSummary:
    experiment_id:str
    run_id:str
    run_state:str
    validation_passed:bool
    gate_count:int
    warning_count:int
    failure_count:int
    device_count:int
    acquisition_dataset_count:int
    provenance_sources:tuple[str,...]

class IntegratedHardwareLab:
    """Unified facade over HELIX HWI services. It does not replace deterministic services beneath it."""
    def __init__(self,orchestrator):
        if not isinstance(orchestrator,HardwareExperimentOrchestrator):raise TypeError("HardwareExperimentOrchestrator required")
        self.orchestrator=orchestrator;self._gates=[]
    def add_validation_gate(self,gate):self._gates.append(gate);return gate
    def validation_report(self):
        return build_validation_report(self.orchestrator.experiment_id,self.orchestrator.run_id,self._gates)
    def summary(self):
        rec=self.orchestrator.record();report=self.validation_report()
        return HardwareLabSummary(rec.experiment_id,rec.run_id,rec.state.value,report.passed,len(report.gates),
            len(report.warnings),len(report.failures),len(rec.device_ids),len(rec.acquisition_manifest_refs),rec.provenance_sources)
    def guardian_summary(self):
        """Structured evidence for Guardian; Guardian does not become the safety/validation authority."""
        s=self.summary()
        return {"experiment_id":s.experiment_id,"run_id":s.run_id,"run_state":s.run_state,
                "validation_passed":s.validation_passed,"gate_count":s.gate_count,
                "warnings":s.warning_count,"failures":s.failure_count,"device_count":s.device_count,
                "acquisition_dataset_count":s.acquisition_dataset_count,
                "provenance_sources":list(s.provenance_sources),
                "authority":"ADVISORY_VIEW_OF_DETERMINISTIC_RESULTS"}
    def visualization_dataset(self):
        report=self.validation_report()
        return tuple({"gate_id":g.gate_id,"status":g.status.value,"severity":g.severity.value,
                      "reason":g.reason,"evidence":list(g.evidence)} for g in report.gates)

def cross_engine_validation():
    """Deterministic HWI completion checks spanning foundation through validation."""
    from .foundation import SourceState,HardwareIdentity,ConnectionState,CalibrationState
    from .transports import TransportKind
    from .drivers import IdentityMatcher
    from .metrology import UncertaintyComponent,UncertaintyBudget,UncertaintyType
    from .acquisition import ChannelConfiguration,ClockSource,Sample,missing_sequences
    from .coordination import Interlock,InterlockState,interlocks_allow_execution
    from .safety import guardian_can_override_safety,OperatingEnvelope,evaluate_value,SafetyDecision
    from .validation import calibration_gate,GateStatus
    checks=[]
    checks.append(("source_hardware",SourceState.HARDWARE.value=="HARDWARE"))
    checks.append(("transport_tcp",TransportKind.TCP.value=="TCP"))
    checks.append(("identity_match",IdentityMatcher("SKL").matches(HardwareIdentity("D","SKL","Meter"))))
    b=UncertaintyBudget((UncertaintyComponent("u",1,UncertaintyType.TYPE_B),),2)
    checks.append(("expanded_uncertainty",b.expanded_uncertainty==2))
    checks.append(("dropped_sample_detection",missing_sequences((Sample(0,0,1),Sample(2,1,1)))==(1,)))
    checks.append(("interlock_blocks",not interlocks_allow_execution((Interlock("i","test",InterlockState.TRIPPED),))))
    checks.append(("guardian_no_override",guardian_can_override_safety() is False))
    ev=evaluate_value("D",11,OperatingEnvelope("x","V",0,5,0,10),0)
    checks.append(("hard_limit_shutdown",ev.decision==SafetyDecision.EMERGENCY_SHUTDOWN))
    checks.append(("invalid_calibration_kill",calibration_gate("D",CalibrationState.INVALID).status==GateStatus.FAIL))
    return tuple(checks)

def cross_engine_passed():
    return all(ok for _,ok in cross_engine_validation())
