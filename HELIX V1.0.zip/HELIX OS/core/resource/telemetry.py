from __future__ import annotations
from dataclasses import dataclass
import os,time,shutil,subprocess

@dataclass(frozen=True)
class ResourceTelemetry:
    timestamp:float
    cpu_fraction:float|None
    ram_fraction:float|None
    ram_total:int|None
    ram_available:int|None
    gpu_util_fraction:float|None
    vram_fraction:float|None
    gpu_temperature_c:float|None

def _nvidia():
    exe=shutil.which("nvidia-smi")
    if not exe:return None,None,None
    try:
        p=subprocess.run([exe,"--query-gpu=utilization.gpu,memory.used,memory.total,temperature.gpu",
                          "--format=csv,noheader,nounits"],capture_output=True,text=True,timeout=3)
        if p.returncode:return None,None,None
        rows=[]
        for line in p.stdout.splitlines():
            a=[x.strip() for x in line.split(",")]
            if len(a)>=4:rows.append(tuple(float(x) for x in a[:4]))
        if not rows:return None,None,None
        util=max(r[0] for r in rows)/100
        vram=max((r[1]/r[2] if r[2] else 0) for r in rows)
        temp=max(r[3] for r in rows)
        return util,vram,temp
    except (OSError,ValueError,subprocess.SubprocessError):
        return None,None,None

def sample():
    cpu=ram_frac=ram_total=ram_avail=None
    try:
        import psutil
        cpu=psutil.cpu_percent(interval=None)/100.0
        vm=psutil.virtual_memory()
        ram_frac=vm.percent/100.0;ram_total=int(vm.total);ram_avail=int(vm.available)
    except ImportError:
        pass
    gu,gv,gt=_nvidia()
    return ResourceTelemetry(time.time(),cpu,ram_frac,ram_total,ram_avail,gu,gv,gt)
