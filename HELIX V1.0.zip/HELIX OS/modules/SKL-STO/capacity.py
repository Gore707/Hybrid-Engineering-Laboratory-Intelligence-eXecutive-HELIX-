from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
class InformationUnit(str,Enum):
 CLASSICAL_BIT="CLASSICAL_BIT";QUBIT="QUBIT";QUDIT="QUDIT"
@dataclass(frozen=True)
class CapacityMetric:
 value:float;unit:InformationUnit
 def __post_init__(self):
  if self.value<0 or not math.isfinite(self.value):raise ValueError("capacity nonnegative finite")
@dataclass(frozen=True)
class PhysicalEnvelope:
 area_m2:float;volume_m3:float;mass_kg:float
 def __post_init__(self):
  if self.area_m2<=0 or self.volume_m3<=0 or self.mass_kg<=0:raise ValueError("positive envelope required")
@dataclass(frozen=True)
class DensityReport:
 capacity:CapacityMetric;bits_per_m2:float|None;bits_per_m3:float|None;bits_per_kg:float|None
def density_report(capacity,envelope):
 if capacity.unit!=InformationUnit.CLASSICAL_BIT:return DensityReport(capacity,None,None,None)
 return DensityReport(capacity,capacity.value/envelope.area_m2,capacity.value/envelope.volume_m3,capacity.value/envelope.mass_kg)
def encoding_efficiency(payload_bits,raw_bits):
 if raw_bits<=0 or payload_bits<0 or payload_bits>raw_bits:raise ValueError("invalid payload/raw")
 return payload_bits/raw_bits
def aggregate_classical_capacity(metrics):
 metrics=tuple(metrics)
 if any(x.unit!=InformationUnit.CLASSICAL_BIT for x in metrics):raise TypeError("cannot aggregate unlike classical/quantum information units")
 return CapacityMetric(sum(x.value for x in metrics),InformationUnit.CLASSICAL_BIT)
def compare_same_unit(a,b):
 if a.unit!=b.unit:raise TypeError("information units are not directly comparable")
 if b.value==0:raise ZeroDivisionError("reference capacity is zero")
 return a.value/b.value
def geometric_scaling_capacity(reference_capacity,linear_scale,dimension=3):
 if reference_capacity<0 or linear_scale<=0 or dimension not in (1,2,3):raise ValueError("invalid scaling inputs")
 return reference_capacity*linear_scale**dimension
def effective_density(raw_density,encoding_efficiency_fraction,ecc_fraction,reserved_fraction):
 if raw_density<0 or not 0<=encoding_efficiency_fraction<=1 or not 0<=ecc_fraction<1 or not 0<=reserved_fraction<1:raise ValueError("invalid density factors")
 if ecc_fraction+reserved_fraction>=1:raise ValueError("combined overhead must be <1")
 return raw_density*encoding_efficiency_fraction*(1-ecc_fraction-reserved_fraction)
def shannon_binary_channel_capacity_bits_per_symbol(bit_error_probability):
 if not 0<=bit_error_probability<=.5:raise ValueError("BER must be 0..0.5")
 if bit_error_probability in (0,.5):return 1.0 if bit_error_probability==0 else 0.0
 p=bit_error_probability
 h=-p*math.log2(p)-(1-p)*math.log2(1-p)
 return 1-h
