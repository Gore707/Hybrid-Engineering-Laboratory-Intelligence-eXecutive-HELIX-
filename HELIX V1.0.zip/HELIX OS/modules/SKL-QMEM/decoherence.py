from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np
from .state_engine import _as_density_matrix, state_fidelity, purity

_TOL=1e-10

def apply_kraus_channel(rho,operators):
    a=_as_density_matrix(rho)
    ops=tuple(np.asarray(k,dtype=complex) for k in operators)
    if not ops: raise ValueError("at least one Kraus operator required")
    n=a.shape[0]
    if any(k.shape!=(n,n) for k in ops): raise ValueError("Kraus dimensions must match state")
    completeness=sum((k.conj().T@k for k in ops),np.zeros((n,n),complex))
    if not np.allclose(completeness,np.eye(n),atol=1e-9):
        raise ValueError("Kraus operators must satisfy sum K†K = I")
    out=sum((k@a@k.conj().T for k in ops),np.zeros_like(a))
    return _as_density_matrix(out)

def depolarizing_qubit(rho,p):
    if not 0<=p<=1: raise ValueError("p 0..1")
    a=_as_density_matrix(rho)
    if a.shape!=(2,2): raise ValueError("qubit channel requires 2x2 state")
    return (1-p)*a+p*np.eye(2,dtype=complex)/2

def phase_flip_qubit(rho,p):
    if not 0<=p<=1: raise ValueError("p 0..1")
    z=np.array([[1,0],[0,-1]],complex)
    return apply_kraus_channel(rho,(math.sqrt(1-p)*np.eye(2),math.sqrt(p)*z))

def bit_flip_qubit(rho,p):
    if not 0<=p<=1: raise ValueError("p 0..1")
    x=np.array([[0,1],[1,0]],complex)
    return apply_kraus_channel(rho,(math.sqrt(1-p)*np.eye(2),math.sqrt(p)*x))

def thermal_excited_population(energy_gap_j,temperature_k):
    if energy_gap_j<0 or temperature_k<=0: raise ValueError("invalid thermal inputs")
    kb=1.380649e-23
    if energy_gap_j==0:return .5
    x=energy_gap_j/(kb*temperature_k)
    if x>700:return 0.0
    return 1/(1+math.exp(x))

def generalized_amplitude_damping_qubit(rho,gamma,ground_population):
    if not 0<=gamma<=1 or not 0<=ground_population<=1: raise ValueError("fractions 0..1")
    p=ground_population; g=gamma
    k0=math.sqrt(p)*np.array([[1,0],[0,math.sqrt(1-g)]],complex)
    k1=math.sqrt(p)*np.array([[0,math.sqrt(g)],[0,0]],complex)
    k2=math.sqrt(1-p)*np.array([[math.sqrt(1-g),0],[0,1]],complex)
    k3=math.sqrt(1-p)*np.array([[0,0],[math.sqrt(g),0]],complex)
    return apply_kraus_channel(rho,(k0,k1,k2,k3))

@dataclass(frozen=True)
class CoherenceBudget:
    t1_s:float
    pure_dephasing_time_s:float|None=None
    def __post_init__(self):
        if self.t1_s<=0 or (self.pure_dephasing_time_s is not None and self.pure_dephasing_time_s<=0):
            raise ValueError("times must be positive")
    @property
    def t2_s(self):
        rate=1/(2*self.t1_s)
        if self.pure_dephasing_time_s is not None: rate+=1/self.pure_dephasing_time_s
        return 1/rate
    @property
    def satisfies_markovian_bound(self): return self.t2_s<=2*self.t1_s+_TOL

@dataclass(frozen=True)
class ChannelAssessment:
    fidelity:float
    input_purity:float
    output_purity:float
    trace_preserved:bool

def assess_channel(input_rho,output_rho):
    a=_as_density_matrix(input_rho);b=_as_density_matrix(output_rho)
    if a.shape!=b.shape: raise ValueError("state dimensions must match")
    return ChannelAssessment(state_fidelity(a,b),purity(a),purity(b),
                             math.isclose(float(np.trace(b).real),1.0,abs_tol=1e-10))
