from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .foundation import C

AU_M=149_597_870_700.0

class TerminalRole(str,Enum):
    GROUND="GROUND"; SPACECRAFT="SPACECRAFT"; RELAY="RELAY"

def one_way_light_time_s(distance_m):
    if distance_m<0: raise ValueError("distance nonnegative")
    return distance_m/C

def round_trip_light_time_s(distance_m):
    return 2*one_way_light_time_s(distance_m)

def data_volume_bits(goodput_bps,contact_time_s,duty_cycle=1.0):
    if goodput_bps<0 or contact_time_s<0 or not 0<=duty_cycle<=1: raise ValueError("invalid data-volume inputs")
    return goodput_bps*contact_time_s*duty_cycle

def data_volume_bytes(goodput_bps,contact_time_s,duty_cycle=1.0):
    return data_volume_bits(goodput_bps,contact_time_s,duty_cycle)/8

def inverse_square_power_scale(reference_power_w,reference_range_m,target_range_m):
    if reference_power_w<0 or reference_range_m<=0 or target_range_m<=0: raise ValueError("invalid power/range")
    return reference_power_w*(target_range_m/reference_range_m)**2

def aperture_diameter_for_equal_link(reference_diameter_m,reference_range_m,target_range_m):
    if reference_diameter_m<=0 or reference_range_m<=0 or target_range_m<=0: raise ValueError("invalid aperture/range")
    # Holding the other terminal, wavelength and power fixed, received power ∝ D^2/R^2.
    return reference_diameter_m*(target_range_m/reference_range_m)

def combined_aperture_product_for_range(tx_diameter_m,rx_diameter_m,reference_range_m,target_range_m):
    if min(tx_diameter_m,rx_diameter_m,reference_range_m,target_range_m)<=0: raise ValueError("positive inputs")
    # Since Pr ∝ Dt^2 Dr^2 / R^2, equal-link aperture product Dt*Dr scales linearly with R.
    return tx_diameter_m*rx_diameter_m*(target_range_m/reference_range_m)

def contact_fraction(contact_time_s,period_s):
    if contact_time_s<0 or period_s<=0 or contact_time_s>period_s: raise ValueError("invalid contact period")
    return contact_time_s/period_s

def contacts_required_for_volume(target_bits,goodput_bps,contact_time_s,duty_cycle=1.0):
    if target_bits<0: raise ValueError("target nonnegative")
    per=data_volume_bits(goodput_bps,contact_time_s,duty_cycle)
    if target_bits==0:return 0
    if per<=0:return math.inf
    return math.ceil(target_bits/per)

def store_and_forward_latency_s(leg_distances_m,relay_processing_delays_s=()):
    if any(d<0 for d in leg_distances_m) or any(t<0 for t in relay_processing_delays_s): raise ValueError("nonnegative distances/delays")
    return sum(leg_distances_m)/C+sum(relay_processing_delays_s)

@dataclass(frozen=True)
class OpticalTerminal:
    name:str
    role:TerminalRole
    aperture_diameter_m:float
    optical_power_w:float=0.0
    duty_cycle:float=1.0
    def __post_init__(self):
        if not self.name.strip() or self.aperture_diameter_m<=0 or self.optical_power_w<0 or not 0<=self.duty_cycle<=1:
            raise ValueError("invalid terminal")

@dataclass(frozen=True)
class MissionContact:
    source:OpticalTerminal
    destination:OpticalTerminal
    distance_m:float
    contact_time_s:float
    goodput_bps:float
    link_availability:float=1.0
    def __post_init__(self):
        if self.distance_m<0 or self.contact_time_s<0 or self.goodput_bps<0 or not 0<=self.link_availability<=1:
            raise ValueError("invalid mission contact")
    @property
    def one_way_light_time_s(self): return one_way_light_time_s(self.distance_m)
    @property
    def expected_data_bits(self):
        return data_volume_bits(self.goodput_bps,self.contact_time_s,self.link_availability)
    @property
    def expected_data_bytes(self): return self.expected_data_bits/8

@dataclass(frozen=True)
class RelayPath:
    leg_distances_m:tuple[float,...]
    processing_delays_s:tuple[float,...]=()
    def __post_init__(self):
        if not self.leg_distances_m or any(d<0 for d in self.leg_distances_m) or any(t<0 for t in self.processing_delays_s):
            raise ValueError("invalid relay path")
        if len(self.processing_delays_s) not in (0,len(self.leg_distances_m)-1):
            raise ValueError("one processing delay per intermediate relay")
    @property
    def latency_s(self): return store_and_forward_latency_s(self.leg_distances_m,self.processing_delays_s)
    @property
    def total_distance_m(self): return sum(self.leg_distances_m)
