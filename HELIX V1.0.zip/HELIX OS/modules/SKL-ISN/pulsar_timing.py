from __future__ import annotations
from dataclasses import dataclass
import math

C_M_S=299792458.0

def pulse_phase_cycles(elapsed_s,period_s,phase0_cycles=0.0):
    if elapsed_s<0 or period_s<=0:raise ValueError("invalid timing")
    return phase0_cycles+elapsed_s/period_s

def pulse_count(elapsed_s,period_s):
    return math.floor(pulse_phase_cycles(elapsed_s,period_s))

def timing_residual_s(observed_toa_s,predicted_toa_s):
    return observed_toa_s-predicted_toa_s

def range_equivalent_from_timing_residual_m(residual_s):
    return C_M_S*residual_s

def timing_residual_from_range_m(range_error_m):
    return range_error_m/C_M_S

def combined_toa_uncertainty_s(*uncertainties_s):
    if not uncertainties_s or any(x<0 for x in uncertainties_s):raise ValueError("nonnegative uncertainties required")
    return math.sqrt(sum(x*x for x in uncertainties_s))

def weighted_clock_offset_s(residuals_s,uncertainties_s):
    if not residuals_s or len(residuals_s)!=len(uncertainties_s) or any(x<=0 for x in uncertainties_s):
        raise ValueError("invalid observations")
    w=[1/(s*s) for s in uncertainties_s]
    return sum(r*wi for r,wi in zip(residuals_s,w))/sum(w)

def weighted_offset_uncertainty_s(uncertainties_s):
    if not uncertainties_s or any(x<=0 for x in uncertainties_s):raise ValueError("positive uncertainties required")
    return 1/math.sqrt(sum(1/(s*s) for s in uncertainties_s))

def fractional_frequency_error_from_drift(clock_drift_s,elapsed_s):
    if elapsed_s<=0:raise ValueError("elapsed time positive")
    return clock_drift_s/elapsed_s

def position_projection_error_m(timing_residual_s):
    return C_M_S*timing_residual_s

def minimum_pulsars_for_3d_position_and_clock():
    return 4

def gdop_from_unit_vectors(unit_vectors):
    # Educational geometric conditioning proxy: sqrt(trace((A^T A)^-1)) for 3-D position only.
    if len(unit_vectors)<3:raise ValueError("at least three vectors")
    A=[]
    for v in unit_vectors:
        if len(v)!=3:raise ValueError("3D vectors required")
        n=math.sqrt(sum(x*x for x in v))
        if n==0:raise ValueError("nonzero vector")
        A.append([x/n for x in v])
    ata=[[sum(row[i]*row[j] for row in A) for j in range(3)] for i in range(3)]
    a,b,c=ata[0];d,e,f=ata[1];g,h,i=ata[2]
    det=a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g)
    if abs(det)<1e-15:return math.inf
    inv=[[ (e*i-f*h)/det,(c*h-b*i)/det,(b*f-c*e)/det],
         [ (f*g-d*i)/det,(a*i-c*g)/det,(c*d-a*f)/det],
         [ (d*h-e*g)/det,(b*g-a*h)/det,(a*e-b*d)/det]]
    return math.sqrt(inv[0][0]+inv[1][1]+inv[2][2])

@dataclass(frozen=True)
class PulsarTimingSource:
    source_id:str
    period_s:float
    toa_uncertainty_s:float
    direction_unit:tuple
    def __post_init__(self):
        if not self.source_id or self.period_s<=0 or self.toa_uncertainty_s<=0 or len(self.direction_unit)!=3:
            raise ValueError("invalid source")
        n=math.sqrt(sum(float(x)**2 for x in self.direction_unit))
        if n==0:raise ValueError("direction nonzero")

@dataclass(frozen=True)
class PulsarTimingObservation:
    source:PulsarTimingSource
    observed_toa_s:float
    predicted_toa_s:float
    @property
    def residual_s(self):return timing_residual_s(self.observed_toa_s,self.predicted_toa_s)
    @property
    def line_of_sight_range_equivalent_m(self):return range_equivalent_from_timing_residual_m(self.residual_s)

def clock_solution_from_observations(observations):
    if not observations:raise ValueError("observations required")
    return weighted_clock_offset_s([o.residual_s for o in observations],[o.source.toa_uncertainty_s for o in observations])
