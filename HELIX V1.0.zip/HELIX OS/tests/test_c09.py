import tempfile,unittest,os
from pathlib import Path
import numpy as np
from core.bootstrap.identity import IDENTITY
from core.storage.schema_store import SchemaStore,SchemaValidationError
from core.storage.catalog import ResourceCatalog
from core.storage.arrays import ScientificArrayStore
from core.storage.service import ResourceService

ROOT=Path(__file__).resolve().parents[1]
class C09Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C09")
 def test_all_13_schemas_exist(self):
  s=SchemaStore(ROOT/"core/resources/schemas");self.assertEqual(len(s.names()),13)
 def test_schema_validation(self):
  s=SchemaStore(ROOT/"core/resources/schemas")
  d={"schema_version":"1","resource_version":"1","resource_id":"MAT-1","name":"Silica",
     "evidence_class":"DEMONSTRATED","properties":{"density":2200},"sources":[]}
  self.assertTrue(s.validate("material.schema.json",d))
  bad=dict(d);bad["extra"]="x"
  with self.assertRaises(Exception):s.validate("material.schema.json",bad)
 def test_catalog_roundtrip_and_relation(self):
  with tempfile.TemporaryDirectory() as td:
   c=ResourceCatalog(Path(td)/"c.sqlite3")
   a={"schema_version":"1","resource_version":"1","resource_id":"A-1","name":"A"}
   b={"schema_version":"1","resource_version":"1","resource_id":"B-1","name":"B"}
   c.upsert("test",a);c.upsert("test",b);c.relate("A-1","uses","B-1")
   self.assertEqual(c.get("A-1")[1]["name"],"A")
   self.assertEqual(c.relations("A-1"),[("uses","B-1")]);c.close()
 def test_binary_array_roundtrip(self):
  with tempfile.TemporaryDirectory() as td:
   st=ScientificArrayStore(Path(td));a=np.arange(12,dtype=np.float64).reshape(3,4)
   meta=st.write("DS1",a,"V");b=st.read(meta["storage_uri"])
   np.testing.assert_array_equal(a,b)
   self.assertEqual(meta["shape"],[3,4]);self.assertEqual(len(meta["checksum_sha256"]),64)
 def test_resource_service_validates(self):
  with tempfile.TemporaryDirectory() as td:
   ss=SchemaStore(ROOT/"core/resources/schemas");c=ResourceCatalog(Path(td)/"c.db");rs=ResourceService(ss,c)
   d={"schema_version":"1","resource_version":"1","resource_id":"EQ-1","name":"Test",
      "latex":"E=mc^2","variables":{},"model_id":None,"book_reference":None}
   rs.put("equation",d);self.assertEqual(rs.get("EQ-1")[0],"equation");c.close()
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
