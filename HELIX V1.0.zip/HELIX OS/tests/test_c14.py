import tempfile,unittest
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.truth import *
from core.truth.source_utils import sha256_file
ROOT=Path(__file__).resolve().parents[1]
class C14Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C14")
 def test_confidence_bounds(self):
  with self.assertRaises(ValueError):TruthRecord("R","S","c",EvidenceClass.ESTABLISHED_PHYSICS,SourceClass.SOFTWARE,1.1)
 def test_import_requires_source(self):
  with tempfile.TemporaryDirectory() as td:
   s=TruthStore(Path(td)/"t.json")
   with self.assertRaises(ValueError):s.add_record(TruthRecord("R","S","c",EvidenceClass.DEMONSTRATED_TECHNOLOGY,SourceClass.IMPORTED,.9))
 def test_source_record_and_reload(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/"t.json";s=TruthStore(p)
   s.add_source(SourceRecord("SRC-1",SourceClass.IMPORTED,"paper","https://example.invalid"))
   s.add_record(TruthRecord("R1","SUB","claim",EvidenceClass.ESTABLISHED_PHYSICS,SourceClass.IMPORTED,.95,("SRC-1",)))
   q=TruthStore(p);self.assertIn("R1",q.records);self.assertIn("SRC-1",q.sources)
 def test_lineage(self):
  with tempfile.TemporaryDirectory() as td:
   s=TruthStore(Path(td)/"t.json");s.add_lineage("DATASET-1","EXPERIMENT-1","INPUT_TO")
   self.assertEqual(s.lineage("DATASET-1")[0].child_id,"EXPERIMENT-1")
 def test_quantitative_contradiction(self):
  with tempfile.TemporaryDirectory() as td:
   s=TruthStore(Path(td)/"t.json")
   s.add_record(TruthRecord("A","X","value a",EvidenceClass.ESTABLISHED_PHYSICS,SourceClass.SOFTWARE,.9,value=1,unit="m"))
   s.add_record(TruthRecord("B","X","value b",EvidenceClass.ESTABLISHED_PHYSICS,SourceClass.SIMULATION,.9,value=2,unit="m"))
   self.assertEqual(len(s.contradictions()),1)
 def test_truth_panel(self):
  with tempfile.TemporaryDirectory() as td:
   s=TruthStore(Path(td)/"t.json")
   s.add_record(TruthRecord("A","X","c",EvidenceClass.SPECULATIVE_UNRESOLVED,SourceClass.SPECULATIVE,.4))
   p=s.truth_panel("X");self.assertEqual(p["evidence_composition"]["SPECULATIVE_UNRESOLVED"],1)
 def test_hash(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/"x";p.write_bytes(b"abc")
   self.assertEqual(sha256_file(p),"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
