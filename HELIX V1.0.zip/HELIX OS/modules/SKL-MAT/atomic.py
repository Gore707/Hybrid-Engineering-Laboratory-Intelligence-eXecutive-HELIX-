from __future__ import annotations
from dataclasses import dataclass
import math,re
@dataclass(frozen=True)
class ElementRecord:
 symbol:str;name:str;atomic_number:int;standard_atomic_weight:float
 source_ids:tuple[str,...]=();evidence_class:str="ESTABLISHED_PHYSICS"
 def __post_init__(self):
  if not re.fullmatch(r"[A-Z][a-z]?",self.symbol):raise ValueError("invalid element symbol")
  if self.atomic_number<=0 or self.standard_atomic_weight<=0 or not math.isfinite(self.standard_atomic_weight):raise ValueError("invalid atomic data")
@dataclass(frozen=True)
class CompositionEntry:
 element_symbol:str;atomic_fraction:float
 def __post_init__(self):
  if not 0<=self.atomic_fraction<=1 or not math.isfinite(self.atomic_fraction):raise ValueError("invalid atomic fraction")
@dataclass(frozen=True)
class DopantRecord:
 species:str;host_site:str;fraction:float;charge_state:str="";source_ids:tuple[str,...]=()
 def __post_init__(self):
  if not 0<=self.fraction<1 or not math.isfinite(self.fraction):raise ValueError("invalid dopant fraction")
@dataclass(frozen=True)
class DefectRecord:
 defect_id:str;kind:str;charge_state:str="";concentration_m3:float|None=None;source_ids:tuple[str,...]=()
 def __post_init__(self):
  if self.concentration_m3 is not None and (self.concentration_m3<0 or not math.isfinite(self.concentration_m3)):raise ValueError("invalid concentration")
class AtomicCatalog:
 def __init__(self):self.elements={}
 def add(self,e:ElementRecord):
  if e.symbol in self.elements and self.elements[e.symbol]!=e:raise ValueError("conflicting element record")
  self.elements[e.symbol]=e
 def get(self,symbol):
  if symbol not in self.elements:raise KeyError(symbol)
  return self.elements[symbol]
 def molar_mass(self,composition):
  total=sum(x.atomic_fraction for x in composition)
  if not math.isclose(total,1.0,rel_tol=0,abs_tol=1e-9):raise ValueError("atomic fractions must sum to 1")
  return sum(self.get(x.element_symbol).standard_atomic_weight*x.atomic_fraction for x in composition)
 def validate_composition(self,composition):
  self.molar_mass(composition);return True
