import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HQIC"
sp=importlib.util.spec_from_file_location("skl_hqic",M/"__init__.py",submodule_search_locations=[str(M)])
h=importlib.util.module_from_spec(sp);sys.modules["skl_hqic"]=h;sp.loader.exec_module(h)
class T(unittest.TestCase):
 def test_validation_all(self):
  r=h.run_cross_engine_validation();self.assertTrue(r.passed);self.assertEqual(r.passed_count,r.total_count)
 def test_validation_count(self):self.assertEqual(h.run_cross_engine_validation().total_count,15)
 def test_validation_ids_unique(self):
  ids=[x.check_id for x in h.run_cross_engine_validation().checks];self.assertEqual(len(ids),len(set(ids)))
 def test_capacity_separation(self):
  with self.assertRaises(ValueError):h.aggregate_capacity_same_domain([h.Capacity(1,h.InformationDomain.CLASSICAL,"bit"),h.Capacity(1,h.InformationDomain.QUANTUM,"qubit")])
 def test_geometry(self):self.assertAlmostEqual(h.LayerGeometry("x",h.PhysicalLayerRole.PROTECTIVE,1e-3,.1,.05).volume_m3,5e-6)
 def test_fresnel(self):self.assertAlmostEqual(h.OpticalInterface("a","b",1,1.5).normal_incidence_reflectance,.04)
 def test_transduction(self):self.assertAlmostEqual(h.cascaded_efficiency(.8,.5),.4)
 def test_controller(self):
  c=h.DeviceCapabilities(True,False,max_classical_address=9);ok,_=h.validate_command(h.HQICCommand("r",h.CommandKind.READ_CLASSICAL,h.DeviceAddress(classical_address=1)),c,h.DeviceState.IDLE);self.assertTrue(ok)
 def test_integrity(self):self.assertAlmostEqual(h.repetition_logical_error_probability(.1,3),.028)
 def test_no_cloning(self):
  with self.assertRaises(ValueError):h.no_cloning_integrity_guard(True,2)
 def test_engineering(self):self.assertEqual(h.rss_tolerance(3,4),5)
 def test_simulation_source(self):
  s=h.HQICScenario("x",1e-4,3,.01,3,10,(.8,.8),(.01,.01),10,1,1,2,1e-7,1e-6,(1e-6,1e-6),3e-6,.1,.5,1e-6);self.assertEqual(h.run_hqic_scenario(s).provenance,"SIMULATION")
 def test_complete_marker(self):
  x=json.loads((R/"HQIC_COMPLETE.json").read_text());self.assertEqual(x["status"],"COMPLETE");self.assertEqual(x["patches_completed"],8)
 def test_manifest_complete(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-HQIC-08");self.assertIn("COMPLETE",x["status"])
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO","SKL-QMEM"])
 def test_previous_complete_markers(self):
  self.assertTrue((R/"PHO_COMPLETE.json").exists());self.assertTrue((R/"STO_COMPLETE.json").exists());self.assertTrue((R/"QMEM_COMPLETE.json").exists())
 def test_core_manifest_root_only(self):
  self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
 def test_registry_accumulated(self):
  ids={x.model_id for x in h.HQICRegistry().all()}
  for i in ["HQIC-CAP-SAME","HQIC-OPT-FRESNEL","HQIC-XDUCE-ETA","HQIC-CTL-STATE","HQIC-ECC-RATE","HQIC-THERM-COND","HQIC-SIM-END2END"]:self.assertIn(i,ids)
 def test_module_files(self):
  for f in ["architecture.py","layering.py","transduction.py","controller.py","integrity.py","engineering.py","simulation.py","validation.py"]:self.assertTrue((M/f).exists())
if __name__=="__main__":unittest.main()
