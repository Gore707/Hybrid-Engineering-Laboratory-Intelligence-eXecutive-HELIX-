from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import C

def optical_linewidth_from_q_hz(frequency_hz,q_factor):
    if frequency_hz<=0 or q_factor<=0: raise ValueError("positive frequency/Q required")
    return frequency_hz/q_factor

def coherence_time_s(linewidth_hz):
    if linewidth_hz<=0: raise ValueError("linewidth positive")
    return 1/(math.pi*linewidth_hz)

def coherence_length_m(linewidth_hz):
    return C*coherence_time_s(linewidth_hz)

def rayleigh_range_m(wavelength_m,waist_radius_m,m2=1.0):
    if wavelength_m<=0 or waist_radius_m<=0 or m2<1: raise ValueError("invalid beam")
    return math.pi*waist_radius_m**2/(m2*wavelength_m)

def gaussian_beam_radius_m(z_m,wavelength_m,waist_radius_m,m2=1.0):
    if z_m<0: raise ValueError("z nonnegative")
    zr=rayleigh_range_m(wavelength_m,waist_radius_m,m2)
    return waist_radius_m*math.sqrt(1+(z_m/zr)**2)

def gaussian_divergence_half_angle_rad(wavelength_m,waist_radius_m,m2=1.0):
    if wavelength_m<=0 or waist_radius_m<=0 or m2<1: raise ValueError("invalid beam")
    return m2*wavelength_m/(math.pi*waist_radius_m)

def gaussian_aperture_transmitted_fraction(aperture_radius_m,beam_radius_m):
    if aperture_radius_m<0 or beam_radius_m<=0: raise ValueError("invalid radii")
    return 1-math.exp(-2*(aperture_radius_m/beam_radius_m)**2)

def strehl_ratio_marechal(rms_wavefront_error_m,wavelength_m):
    if rms_wavefront_error_m<0 or wavelength_m<=0: raise ValueError("invalid wavefront inputs")
    return math.exp(-(2*math.pi*rms_wavefront_error_m/wavelength_m)**2)

def transmitter_optical_output_w(electrical_input_w,wall_plug_efficiency,optical_train_efficiency=1.0):
    if electrical_input_w<0 or not 0<wall_plug_efficiency<=1 or not 0<=optical_train_efficiency<=1: raise ValueError("invalid transmitter efficiency")
    return electrical_input_w*wall_plug_efficiency*optical_train_efficiency

def transmitter_waste_heat_w(electrical_input_w,wall_plug_efficiency):
    if electrical_input_w<0 or not 0<wall_plug_efficiency<=1: raise ValueError("invalid efficiency")
    return electrical_input_w*(1-wall_plug_efficiency)

def telescope_coupled_power_w(laser_power_w,coupling_efficiency,truncation_fraction,strehl_ratio=1.0):
    if laser_power_w<0 or not all(0<=x<=1 for x in (coupling_efficiency,truncation_fraction,strehl_ratio)): raise ValueError("invalid coupling")
    return laser_power_w*coupling_efficiency*truncation_fraction*strehl_ratio

@dataclass(frozen=True)
class LaserTransmitter:
    wavelength_m:float
    electrical_input_w:float
    wall_plug_efficiency:float
    optical_train_efficiency:float
    waist_radius_m:float
    m2:float=1.0
    linewidth_hz:float=1e6
    aperture_radius_m:float|None=None
    coupling_efficiency:float=1.0
    rms_wavefront_error_m:float=0.0
    def __post_init__(self):
        if self.wavelength_m<=0 or self.electrical_input_w<0 or self.waist_radius_m<=0 or self.m2<1 or self.linewidth_hz<=0: raise ValueError("invalid laser transmitter")
        if not 0<self.wall_plug_efficiency<=1 or not 0<=self.optical_train_efficiency<=1 or not 0<=self.coupling_efficiency<=1: raise ValueError("invalid efficiency")
        if self.aperture_radius_m is not None and self.aperture_radius_m<0: raise ValueError("invalid aperture")
        if self.rms_wavefront_error_m<0: raise ValueError("invalid WFE")
    @property
    def raw_laser_output_w(self): return self.electrical_input_w*self.wall_plug_efficiency
    @property
    def optical_output_w(self): return transmitter_optical_output_w(self.electrical_input_w,self.wall_plug_efficiency,self.optical_train_efficiency)
    @property
    def waste_heat_w(self): return transmitter_waste_heat_w(self.electrical_input_w,self.wall_plug_efficiency)
    @property
    def rayleigh_range_m(self): return rayleigh_range_m(self.wavelength_m,self.waist_radius_m,self.m2)
    @property
    def divergence_half_angle_rad(self): return gaussian_divergence_half_angle_rad(self.wavelength_m,self.waist_radius_m,self.m2)
    @property
    def coherence_time_s(self): return coherence_time_s(self.linewidth_hz)
    @property
    def coherence_length_m(self): return coherence_length_m(self.linewidth_hz)
    @property
    def truncation_fraction(self):
        return 1.0 if self.aperture_radius_m is None else gaussian_aperture_transmitted_fraction(self.aperture_radius_m,self.waist_radius_m)
    @property
    def strehl_ratio(self): return strehl_ratio_marechal(self.rms_wavefront_error_m,self.wavelength_m)
    @property
    def delivered_telescope_power_w(self):
        return telescope_coupled_power_w(self.optical_output_w,self.coupling_efficiency,self.truncation_fraction,self.strehl_ratio)
