param(
 [string]$HelixDir = $PSScriptRoot,
 [switch]$CpuOnly
)
$ErrorActionPreference="Stop"

function Resolve-HelixDir([string]$Requested) {
    $requestedFull=[System.IO.Path]::GetFullPath($Requested)
    if (Test-Path (Join-Path $requestedFull ".venv\Scripts\python.exe")) { return $requestedFull }

    $legacy=Join-Path $env:LOCALAPPDATA "SierraKiloLabs\HELIX"
    if (Test-Path (Join-Path $legacy ".venv\Scripts\python.exe")) {
        Write-Host "Using existing HELIX installation: $legacy"
        return $legacy
    }
    throw "HELIX virtual environment not found. Run .\install_helix.ps1 first."
}

$HelixDir=Resolve-HelixDir $HelixDir
$python=Join-Path $HelixDir ".venv\Scripts\python.exe"

Write-Host "HELIX Guardian AI runtime setup"
Write-Host "HELIX directory: $HelixDir"

& $python -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "pip upgrade failed." }

# Install ordinary dependencies from the ONE canonical requirements.txt, excluding
# llama-cpp-python for this pass so Windows never falls into an unconfigured C++ source build.
$req=Join-Path $HelixDir "requirements.txt"
if (-not (Test-Path $req)) {
    # When resolving a legacy installed copy, use the patched source manifest if needed.
    $req=Join-Path $PSScriptRoot "requirements.txt"
}
if (-not (Test-Path $req)) { throw "Canonical requirements.txt not found." }

$tmp=Join-Path $env:TEMP "helix-guardian-requirements-$PID.txt"
Get-Content $req |
    Where-Object { $_ -notmatch '^\s*llama-cpp-python(?:\s*[<>=!~].*)?\s*$' } |
    Set-Content -Encoding ASCII $tmp
try {
    & $python -m pip install -r $tmp
    if ($LASTEXITCODE -ne 0) { throw "HELIX/Guardian dependency installation failed." }
} finally {
    Remove-Item $tmp -Force -ErrorAction SilentlyContinue
}

# Try ONLY a prebuilt llama-cpp-python wheel. Never compile from source here.
$llamaReady=$false
$runtimeSetup=Join-Path $PSScriptRoot "GUARDIAN_RUNTIME_SETUP.py"
if (-not (Test-Path $runtimeSetup)) { throw "GUARDIAN_RUNTIME_SETUP.py not found." }

# PowerShell never probes a missing Python module directly. The helper owns the
# optional-runtime check and always returns success when only the optional wheel
# is unavailable, avoiding Windows PowerShell NativeCommandError behavior.
$runtimeOutput = & $python $runtimeSetup
$runtimeExit = $LASTEXITCODE
$runtimeOutput | ForEach-Object { Write-Host $_ }
if ($runtimeExit -ne 0) { throw "Guardian runtime setup helper failed unexpectedly." }
if ($runtimeOutput -match "GUARDIAN_LLAMA_STATUS=READY") { $llamaReady=$true }

$diag=Join-Path $HelixDir "GUARDIAN_AI_DIAGNOSTIC.py"
if (-not (Test-Path $diag)) {
    $diag=Join-Path $PSScriptRoot "GUARDIAN_AI_DIAGNOSTIC.py"
}
if (-not (Test-Path $diag)) { throw "GUARDIAN_AI_DIAGNOSTIC.py not found." }

Push-Location $HelixDir
try {
    & $python $diag
    if ($LASTEXITCODE -ne 0) { throw "Guardian AI diagnostic failed." }
} finally { Pop-Location }

Write-Host ""
Write-Host "Guardian AI setup completed."
if ($llamaReady) {
    Write-Host "Local LLM Python runtime: READY"
} else {
    Write-Host "Local LLM Python runtime: PENDING HARDWARE-SPECIFIC ACTIVATION"
}
Write-Host "Diagnostic: $HelixDir\user\guardian_ai_diagnostic.json"
Write-Host "No GGUF model was downloaded or selected."
