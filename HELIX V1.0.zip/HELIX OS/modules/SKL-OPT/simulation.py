from __future__ import annotations
from dataclasses import dataclass,replace
from enum import Enum
import math
from .foundation import EvidenceState,circular_aperture_gain_linear,received_power_friis_w
from .pat import gaussian_pointing_coupling
from .receiver import photon_count_rate_per_s,photon_counting_snr
from .digital import OpticalModulation,bits_per_ppm_symbol,ideal_ppm_symbol_error_poisson,approximate_ppm_ber_from_ser,packet_error_rate,goodput_bps

class OpticalLinkStatus(str,Enum):
    PASS="PASS"; MARGINAL="MARGINAL"; FAIL="FAIL"

@dataclass(frozen=True)
class IntegratedOpticalScenario:
    wavelength_m:float
    distance_m:float
    transmit_aperture_m:float
    receive_aperture_m:float
    transmitted_optical_power_w:float
    tx_aperture_efficiency:float=.7
    rx_aperture_efficiency:float=.7
    optical_train_efficiency:float=.8
    atmospheric_transmission:float=1.0
    pointing_error_rad:float=0.0
    beam_half_angle_rad:float=10e-6
    detector_quantum_efficiency:float=.7
    dark_count_rate_per_s:float=0.0
    background_count_rate_per_s:float=0.0
    bit_rate_bps:float=1000.0
    modulation:OpticalModulation=OpticalModulation.PPM
    ppm_order:int=16
    code_rate:float=1.0
    coding_gain_db:float=0.0
    packet_bits:int=1024
    required_snr:float=5.0
    margin_threshold_db:float=0.0
    def __post_init__(self):
        if min(self.wavelength_m,self.distance_m,self.transmit_aperture_m,self.receive_aperture_m,self.beam_half_angle_rad,self.bit_rate_bps)<=0 or self.transmitted_optical_power_w<0:
            raise ValueError("invalid scenario")
        for x in (self.tx_aperture_efficiency,self.rx_aperture_efficiency,self.optical_train_efficiency,self.atmospheric_transmission,self.detector_quantum_efficiency,self.code_rate):
            if not 0<x<=1: raise ValueError("efficiency/transmission/code rate must be (0,1]")
        if min(self.dark_count_rate_per_s,self.background_count_rate_per_s,self.required_snr)<0 or self.packet_bits<1:
            raise ValueError("invalid noise/requirement")
        if self.modulation==OpticalModulation.PPM: bits_per_ppm_symbol(self.ppm_order)

@dataclass(frozen=True)
class IntegratedOpticalResult:
    status:OpticalLinkStatus
    received_power_w:float
    detected_signal_photon_rate_per_s:float
    photons_per_information_bit:float
    integration_time_per_bit_s:float
    photon_counting_snr_per_bit:float
    snr_margin_db:float
    pointing_coupling:float
    total_channel_efficiency:float
    ber:float|None
    packet_error:float|None
    goodput_bps:float|None
    evidence:EvidenceState=EvidenceState.SIMULATION

def simulate(s:IntegratedOpticalScenario):
    gt=circular_aperture_gain_linear(s.transmit_aperture_m,s.wavelength_m,s.tx_aperture_efficiency)
    gr=circular_aperture_gain_linear(s.receive_aperture_m,s.wavelength_m,s.rx_aperture_efficiency)
    point=gaussian_pointing_coupling(s.pointing_error_rad,s.beam_half_angle_rad)
    channel=s.optical_train_efficiency*s.atmospheric_transmission*point
    pr=received_power_friis_w(s.transmitted_optical_power_w,gt,gr,s.distance_m,s.wavelength_m,channel)
    rate=photon_count_rate_per_s(pr,s.wavelength_m,s.detector_quantum_efficiency)
    tbit=1/s.bit_rate_bps
    snr=photon_counting_snr(rate,s.dark_count_rate_per_s,s.background_count_rate_per_s,tbit)
    if s.required_snr==0: margin=math.inf
    elif snr==0: margin=-math.inf
    else: margin=20*math.log10(snr/s.required_snr)
    ber=per=good=None
    if s.modulation==OpticalModulation.PPM:
        bps=bits_per_ppm_symbol(s.ppm_order)
        symbol_rate=s.bit_rate_bps/(bps*s.code_rate)
        photons_symbol=rate/symbol_rate
        # Coding gain abstracted as an equivalent increase in effective detected signal photons.
        effective_photons=photons_symbol*10**(s.coding_gain_db/10)
        ser=ideal_ppm_symbol_error_poisson(s.ppm_order,effective_photons)
        ber=approximate_ppm_ber_from_ser(s.ppm_order,ser)
        per=packet_error_rate(ber,s.packet_bits)
        good=goodput_bps(s.bit_rate_bps,per)
    status=OpticalLinkStatus.PASS if margin>=s.margin_threshold_db else (OpticalLinkStatus.MARGINAL if margin>=s.margin_threshold_db-3 else OpticalLinkStatus.FAIL)
    return IntegratedOpticalResult(status,pr,rate,rate/s.bit_rate_bps,tbit,snr,margin,point,channel,ber,per,good)

def sweep_distance(s:IntegratedOpticalScenario,distances_m):
    return [(d,simulate(replace(s,distance_m=d))) for d in distances_m]

def sweep_transmit_power(s:IntegratedOpticalScenario,powers_w):
    return [(p,simulate(replace(s,transmitted_optical_power_w=p))) for p in powers_w]

def minimum_transmit_power_for_snr(s:IntegratedOpticalScenario,target_snr=None):
    target=s.required_snr if target_snr is None else target_snr
    if target<0: raise ValueError("target SNR nonnegative")
    if target==0:return 0.0
    unit=simulate(replace(s,transmitted_optical_power_w=1.0))
    # Signal count rate scales linearly with power. Solve S/sqrt(S+B)=target per bit.
    b=(s.dark_count_rate_per_s+s.background_count_rate_per_s)/s.bit_rate_bps
    g2=target*target
    required_signal_counts=(g2+math.sqrt(g2*g2+4*g2*b))/2
    if unit.detected_signal_photon_rate_per_s<=0:return math.inf
    unit_signal_counts=unit.detected_signal_photon_rate_per_s/s.bit_rate_bps
    return required_signal_counts/unit_signal_counts
