from __future__ import annotations
from dataclasses import dataclass
import math
from .framework import CapacityEstimate,EvidenceClass
DNA_ALPHABET=("A","C","G","T")
def ideal_bits_per_symbol(alphabet_size):
 if alphabet_size<2:raise ValueError("alphabet >=2")
 return math.log2(alphabet_size)
def dna_ideal_bits_per_base():return 2.0
def sequence_raw_bits(base_count,bits_per_base=2.0):
 if base_count<0 or int(base_count)!=base_count or bits_per_base<0:raise ValueError("invalid sequence inputs")
 return int(base_count)*bits_per_base
@dataclass(frozen=True)
class SequenceOverhead:
 address_fraction:float=0.0;primer_fraction:float=0.0;ecc_fraction:float=0.0;constraint_fraction:float=0.0
 def __post_init__(self):
  if any(x<0 for x in (self.address_fraction,self.primer_fraction,self.ecc_fraction,self.constraint_fraction)):raise ValueError("overheads nonnegative")
  if self.total_fraction>=1:raise ValueError("total overhead must be <1")
 @property
 def total_fraction(self):return self.address_fraction+self.primer_fraction+self.ecc_fraction+self.constraint_fraction
@dataclass(frozen=True)
class DNAStoragePlan:
 oligo_count:int;bases_per_oligo:int;overhead:SequenceOverhead=SequenceOverhead();coding_bits_per_base:float=2.0
 def __post_init__(self):
  if self.oligo_count<1 or self.bases_per_oligo<1 or self.coding_bits_per_base<=0 or self.coding_bits_per_base>2:raise ValueError("invalid DNA plan")
 @property
 def total_bases(self):return self.oligo_count*self.bases_per_oligo
 def capacity(self,evidence_class=EvidenceClass.EXTRAPOLATED_ENGINEERING):
  raw=self.total_bases*self.coding_bits_per_base;usable=raw*(1-self.overhead.total_fraction)
  return CapacityEstimate(usable,raw,self.overhead.total_fraction,"DNA bases × coding bits/base with explicit overhead",evidence_class)
def substitution_channel_capacity_bits_per_base(error_probability,alphabet_size=4):
 if not 0<=error_probability<1 or alphabet_size<2:raise ValueError("invalid channel")
 if error_probability==0:return math.log2(alphabet_size)
 q=alphabet_size
 if error_probability==1:return 0.0
 h=-(1-error_probability)*math.log2(1-error_probability)-error_probability*math.log2(error_probability/(q-1))
 return max(0.0,math.log2(q)-h)
def copies_for_target_recovery(single_copy_success,target_success):
 if not 0<single_copy_success<=1 or not 0<target_success<1:raise ValueError("invalid probabilities")
 if single_copy_success==1:return 1
 return math.ceil(math.log(1-target_success)/math.log(1-single_copy_success))
def mass_limited_ideal_capacity_bits(mass_g,average_molar_mass_per_base_g_mol=330.0):
 if mass_g<0 or average_molar_mass_per_base_g_mol<=0:raise ValueError("invalid mass parameters")
 NA=6.02214076e23
 return (mass_g/average_molar_mass_per_base_g_mol)*NA*2
def exponential_survival_fraction(time_s,mean_lifetime_s):
 if time_s<0 or mean_lifetime_s<=0:raise ValueError("invalid lifetime")
 return math.exp(-time_s/mean_lifetime_s)
