import unittest,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
M=(R/"core/ui/main_window.py").read_text();G=(R/"core/ui/guardian_console.py").read_text();W=(R/"core/ui/scientific_widgets.py").read_text();A=(R/"core/bootstrap/app.py").read_text()
class FinalUI(unittest.TestCase):
 def test_all_six_markers(self):
  for n in range(1,7):self.assertTrue((R/f"UI_{n:02d}_COMPLETE.json").exists())
 def test_final_marker(self):
  d=json.loads((R/"HELIX_UI_1_0_COMPLETE.json").read_text());self.assertEqual(d["patches_completed"],6);self.assertEqual(d["status"],"COMPLETE")
 def test_backend_preserved(self):self.assertEqual(json.loads((R/"HELIX_136_COMPLETE.json").read_text())["patches_completed"],136)
 def test_command_center(self):self.assertIn("HELIX COMMAND CENTER",M)
 def test_project_tree(self):self.assertIn("QTreeWidget()",M)
 def test_labs(self):self.assertIn("def _show_lab_launcher",M);self.assertIn('manifest=folder/"module.json"',M)
 def test_guardian_tabs(self):
  for x in ("Console","Observations","Intelligence","Memory","Research","Journal","Proposals","Permissions"):self.assertIn(x,G)
 def test_scientific_primitives(self):self.assertIn("class MeasurementCard",W);self.assertIn("class ScientificFigureFrame",W);self.assertIn("class ProvenanceBadge",W)
 def test_status(self):
  for x in ("StatusExperiment","StatusSystem","StatusEnvironment"):self.assertIn(x,M)
 def test_shortcuts(self):self.assertIn("QKeySequence.StandardKey.New",M);self.assertIn("QKeySequence.StandardKey.Open",M);self.assertIn("QKeySequence.StandardKey.Save",M)
 def test_real_toolbar_wiring(self):self.assertIn("new.triggered.connect(self._new_project)",M);self.assertIn("labs.triggered.connect(self._show_lab_launcher)",M);self.assertIn("guardian.triggered.connect(self._show_guardian_console)",M)
 def test_unsafe_unavailable_controls_disabled(self):self.assertIn("self.toolbar_abort.setEnabled(False)",M);self.assertNotIn("self.toolbar_abort.triggered.connect",M)
 def test_display_identity(self):self.assertIn('app.setApplicationDisplayName("HELIX — THE ARCHIMEDES PROJECT")',A)
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
 def test_no_caches(self):self.assertFalse(list(R.rglob("*.pyc")))
if __name__=="__main__":unittest.main()
