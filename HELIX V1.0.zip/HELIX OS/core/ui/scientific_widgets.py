from __future__ import annotations
from PySide6.QtWidgets import QWidget,QFrame,QLabel,QVBoxLayout,QHBoxLayout
from PySide6.QtCore import Qt

PROVENANCE_STATES=("HARDWARE","IMPORTED","SIMULATION","SOFTWARE","EXTRAPOLATED","SPECULATIVE","NEW PHYSICS")

class ProvenanceBadge(QLabel):
    def __init__(self,state="SOFTWARE",parent=None):
        super().__init__(parent);self.setObjectName("ProvenanceBadge");self.set_state(state)
    def set_state(self,state):
        state=str(state).upper()
        if state not in PROVENANCE_STATES: state="SOFTWARE"
        self.state=state;self.setText(state);self.setProperty("provenance",state)
        self.style().unpolish(self);self.style().polish(self)

class MeasurementCard(QFrame):
    def __init__(self,title,value="—",unit="",uncertainty="",provenance="SOFTWARE",source="",parent=None):
        super().__init__(parent);self.setObjectName("MeasurementCard")
        v=QVBoxLayout(self);v.setContentsMargins(11,9,11,9);v.setSpacing(3)
        top=QHBoxLayout();h=QLabel(title.upper());h.setObjectName("MeasurementTitle")
        self.badge=ProvenanceBadge(provenance);top.addWidget(h);top.addStretch(1);top.addWidget(self.badge)
        self.value=QLabel();self.value.setObjectName("MeasurementValue")
        self.meta=QLabel();self.meta.setObjectName("MeasurementMeta");self.meta.setWordWrap(True)
        v.addLayout(top);v.addWidget(self.value);v.addWidget(self.meta)
        self.set_measurement(value,unit,uncertainty,source)
    def set_measurement(self,value,unit="",uncertainty="",source=""):
        self.value.setText(f"{value} {unit}".strip())
        parts=[]
        if uncertainty:parts.append(f"Uncertainty: {uncertainty}")
        if source:parts.append(f"Source: {source}")
        self.meta.setText(" · ".join(parts) if parts else "No measurement metadata")

class ScientificFigureFrame(QFrame):
    """Standard host frame for real plot/diagram widgets supplied by HELIX visualization services."""
    def __init__(self,title,model_id="",provenance="SOFTWARE",parent=None):
        super().__init__(parent);self.setObjectName("ScientificFigure")
        self.layout=QVBoxLayout(self);self.layout.setContentsMargins(9,8,9,8)
        top=QHBoxLayout();t=QLabel(title);t.setObjectName("FigureTitle")
        self.badge=ProvenanceBadge(provenance);top.addWidget(t,1);top.addWidget(self.badge)
        self.caption=QLabel(f"Model / Equation: {model_id or 'not assigned'}");self.caption.setObjectName("FigureCaption")
        self.layout.addLayout(top);self.layout.addWidget(self.caption)
    def set_plot_widget(self,widget):
        self.layout.insertWidget(1,widget,1)
