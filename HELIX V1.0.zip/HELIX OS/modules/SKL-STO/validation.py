from __future__ import annotations
from dataclasses import dataclass
import math
from .glass5d import FiveDEncoding,FiveDLayout,VoxelPitch
from .holographic import fringe_spacing_m,bragg_angle_rad
from .spectral import AtomicFrequencyComb,coherence_time_from_homogeneous_linewidth_s
from .molecular import dna_ideal_bits_per_base,DNAStoragePlan,SequenceOverhead
from .magnetic import thermal_stability_factor,required_stability_factor,neel_arrhenius_retention_s
from .capacity import CapacityMetric,InformationUnit,aggregate_classical_capacity
from .readwrite import code_rate,effective_throughput_bps,sha256_bytes,verify_sha256
from .design_studio import StorageDesign,StorageTechnology,DesignRequirement,assess_design,Readiness
@dataclass(frozen=True)
class ValidationCheck:
 name:str;passed:bool;detail:str
@dataclass(frozen=True)
class ValidationReport:
 checks:tuple[ValidationCheck,...]
 @property
 def passed(self):return all(c.passed for c in self.checks)
 @property
 def passed_count(self):return sum(c.passed for c in self.checks)
 @property
 def total_count(self):return len(self.checks)
def run_cross_engine_validation():
 c=[]
 def ck(name,ok,detail):c.append(ValidationCheck(name,bool(ok),detail))
 enc=FiveDEncoding(4,4);lay=FiveDLayout(1e-3,1e-3,1e-3,VoxelPitch(1e-4,1e-4,1e-4),enc)
 ck("5D geometry/capacity",lay.voxel_count==1000 and lay.capacity().raw_bits==4000,"10×10×10 voxels, 4 bits/voxel")
 lam=1e-6;period=fringe_spacing_m(lam,1,math.pi);theta=bragg_angle_rad(lam,1,period)
 ck("holographic reciprocal geometry",abs(period-5e-7)<1e-15 and abs(theta-math.pi/2)<1e-12,"counter-propagating fringe/Bragg boundary")
 afc=AtomicFrequencyComb(1e6,1e5,10)
 ck("AFC timing/finesse",abs(afc.nominal_echo_time_s-1e-6)<1e-15 and afc.finesse==10,"1 MHz spacing -> 1 us nominal echo")
 ck("spectral coherence",abs(coherence_time_from_homogeneous_linewidth_s(1e3)-1/(math.pi*1e3))<1e-15,"T2 linewidth reciprocal")
 dna=DNAStoragePlan(100,100,SequenceOverhead(.05,.05,.1,0),2)
 ck("DNA payload ceiling",dna_ideal_bits_per_base()==2 and dna.capacity().usable_bits==16000,"4-symbol ceiling with explicit overhead")
 d=required_stability_factor(1e6,1e-9)
 ck("magnetic retention inverse",abs(neel_arrhenius_retention_s(1e-9,d)/1e6-1)<1e-12,"Neel-Arrhenius inverse consistency")
 agg=aggregate_classical_capacity([CapacityMetric(10,InformationUnit.CLASSICAL_BIT),CapacityMetric(20,InformationUnit.CLASSICAL_BIT)])
 ck("capacity aggregation",agg.value==30 and agg.unit==InformationUnit.CLASSICAL_BIT,"classical-only aggregation")
 r=code_rate(8,10);ck("read/write throughput",effective_throughput_bps(1000,r,.1)==720,"coding and retry overhead")
 blob=b"SKL-STO-10";ck("integrity",verify_sha256(blob,sha256_bytes(blob)),"SHA-256 roundtrip")
 des=StorageDesign("validation",StorageTechnology.GLASS_5D,{"capacity_bits":4000},("EV-VALID",),("SRC-VALID",))
 a=assess_design(des,{"capacity_bits":4000},[DesignRequirement("capacity_bits",minimum=1000)])
 ck("Design Studio integration",a.readiness==Readiness.ENGINEERING_CANDIDATE,"requirements + evidence + source present")
 return ValidationReport(tuple(c))
