from __future__ import annotations
from dataclasses import dataclass,asdict
from enum import Enum
from datetime import datetime,timezone
import json,hashlib,uuid
from .foundation import EvidenceClass
from .comparison import CarrierScenario,compare_architectures,parameter_sweep

class DataSourceState(str,Enum):
    HARDWARE="HARDWARE"
    IMPORTED="IMPORTED"
    SIMULATION="SIMULATION"
    EXTRAPOLATED="EXTRAPOLATED"
    SPECULATIVE="SPECULATIVE"

@dataclass(frozen=True)
class ExperimentProvenance:
    source_state:DataSourceState
    evidence:EvidenceClass
    model_ids:tuple[str,...]
    source_refs:tuple[str,...]=()
    notes:str=""
    def __post_init__(self):
        if not self.model_ids:raise ValueError("at least one model id required")

@dataclass(frozen=True)
class ExtremeCarrierExperimentRecord:
    experiment_id:str
    name:str
    created_utc:str
    scenario:CarrierScenario
    provenance:ExperimentProvenance
    parameters:dict
    outputs:dict
    schema_version:str="1.0"
    @staticmethod
    def create(name,scenario,provenance,parameters=None,outputs=None,experiment_id=None,created_utc=None):
        if not name:raise ValueError("name required")
        return ExtremeCarrierExperimentRecord(
          experiment_id or f"ECC-{uuid.uuid4().hex[:12].upper()}",name,
          created_utc or datetime.now(timezone.utc).isoformat(),scenario,provenance,
          dict(parameters or {}),dict(outputs or {}))
    def canonical_json(self):
        d=asdict(self);d["scenario"]["evidence"]=self.scenario.evidence.value
        d["provenance"]["source_state"]=self.provenance.source_state.value
        d["provenance"]["evidence"]=self.provenance.evidence.value
        return json.dumps(d,sort_keys=True,separators=(",",":"))
    def checksum_sha256(self):return hashlib.sha256(self.canonical_json().encode()).hexdigest()

def visualization_rows(records):
    rows=[]
    for r in records:
        s=r.scenario
        rows.append({"experiment_id":r.experiment_id,"name":r.name,"evidence":s.evidence.value,
          "source_state":r.provenance.source_state.value,"latency_s":s.latency_s,
          "information_rate_bps":s.information_rate_bps,"total_power_w":s.total_power_w,
          "joules_per_bit":s.joules_per_bit,"detector_mass_kg":s.detector_mass_kg,
          "detector_area_m2":s.detector_area_m2,"transmission":s.survival_or_transmission})
    return tuple(rows)

def guardian_summary(record):
    s=record.scenario;p=record.provenance
    return {"experiment_id":record.experiment_id,"name":record.name,
      "source_state":p.source_state.value,"evidence":p.evidence.value,
      "model_ids":p.model_ids,"latency_s":s.latency_s,"rate_bps":s.information_rate_bps,
      "total_power_w":s.total_power_w,"joules_per_bit":s.joules_per_bit,
      "warning":"Modeled result is not experimental confirmation." if p.source_state in
        (DataSourceState.SIMULATION,DataSourceState.EXTRAPOLATED,DataSourceState.SPECULATIVE) else None}

class ExtremeCarrierLab:
    def __init__(self):self._records={}
    def add(self,record):
        if record.experiment_id in self._records:raise ValueError("duplicate experiment id")
        self._records[record.experiment_id]=record;return record
    def get(self,experiment_id):return self._records.get(experiment_id)
    def all(self):return tuple(self._records.values())
    def compare(self,experiment_ids=None):
        recs=self.all() if experiment_ids is None else tuple(self._records[i] for i in experiment_ids)
        return compare_architectures([r.scenario for r in recs])
    def visualization_dataset(self,experiment_ids=None):
        recs=self.all() if experiment_ids is None else tuple(self._records[i] for i in experiment_ids)
        return visualization_rows(recs)
    def sweep(self,values,builder):
        records=tuple(builder(v) for v in values)
        for r in records:self.add(r)
        return records
