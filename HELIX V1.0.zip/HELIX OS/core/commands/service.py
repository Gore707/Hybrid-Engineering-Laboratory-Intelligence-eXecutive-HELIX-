from __future__ import annotations
from collections import deque
from threading import RLock
from typing import Any

from .models import CommandRequest, CommandResult, ConfirmationLevel
from .registry import ActionRegistry, RegistryError

class CommandService:
    def __init__(self, registry: ActionRegistry, history_limit: int = 1000):
        self.registry = registry
        self._history = deque(maxlen=max(1, history_limit))
        self._lock = RLock()

    def _validate_parameters(self, request: CommandRequest):
        action = self.registry.get(request.action_id)
        known = {p.name for p in action.parameters}
        unknown = set(request.parameters) - known
        if unknown:
            raise ValueError(f"Unknown parameter(s): {', '.join(sorted(unknown))}")
        values: dict[str, Any] = {}
        for spec in action.parameters:
            raw = request.parameters.get(spec.name, None)
            values[spec.name] = spec.validate(raw)
        return action, values

    def execute(self, request: CommandRequest) -> CommandResult:
        try:
            action, params = self._validate_parameters(request)
            if action.confirmation != ConfirmationLevel.NONE and not request.confirmed:
                result = CommandResult(
                    request.request_id, request.action_id, False,
                    "CONFIRMATION_REQUIRED",
                    f"Action '{action.title}' requires explicit confirmation.",
                    {"confirmation_level": action.confirmation.value}
                )
            else:
                payload = action.handler(params, request.context) or {}
                if not isinstance(payload, dict):
                    raise TypeError("Action handlers must return dict or None")
                result = CommandResult(
                    request.request_id, request.action_id, True,
                    "COMPLETED", f"Action completed: {action.title}", payload
                )
        except (RegistryError, ValueError, TypeError) as exc:
            result = CommandResult(
                request.request_id, request.action_id, False,
                "REJECTED", str(exc), {}
            )
        except Exception as exc:
            result = CommandResult(
                request.request_id, request.action_id, False,
                "FAILED", f"{type(exc).__name__}: {exc}", {}
            )
        with self._lock:
            self._history.append(result)
        return result

    def history(self) -> tuple[CommandResult, ...]:
        with self._lock:
            return tuple(self._history)
