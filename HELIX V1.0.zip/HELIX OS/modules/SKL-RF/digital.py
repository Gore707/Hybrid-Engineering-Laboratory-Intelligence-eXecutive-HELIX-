from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

class Modulation(str,Enum):
    BPSK="BPSK"; QPSK="QPSK"; QAM16="16-QAM"; QAM64="64-QAM"; QAM256="256-QAM"

def bits_per_symbol(modulation):
    m=Modulation(modulation)
    return {Modulation.BPSK:1,Modulation.QPSK:2,Modulation.QAM16:4,Modulation.QAM64:6,Modulation.QAM256:8}[m]

def symbol_rate_baud(bit_rate_bps,modulation,code_rate=1.0):
    if bit_rate_bps<0 or not 0<code_rate<=1: raise ValueError("invalid bit/code rate")
    return bit_rate_bps/(bits_per_symbol(modulation)*code_rate)

def nyquist_baseband_bandwidth_hz(symbol_rate_baud_value,rolloff=0.0):
    if symbol_rate_baud_value<0 or not 0<=rolloff<=1: raise ValueError("invalid symbol rate/rolloff")
    return symbol_rate_baud_value*(1+rolloff)

def spectral_efficiency_bps_hz(modulation,code_rate=1.0,rolloff=0.0):
    if not 0<code_rate<=1 or not 0<=rolloff<=1: raise ValueError("invalid code rate/rolloff")
    return bits_per_symbol(modulation)*code_rate/(1+rolloff)

def ebn0_from_snr_linear(snr_linear,bandwidth_hz,bit_rate_bps):
    if snr_linear<0 or bandwidth_hz<0 or bit_rate_bps<=0: raise ValueError("invalid SNR/B/Rb")
    return snr_linear*bandwidth_hz/bit_rate_bps

def snr_from_ebn0_linear(ebn0_linear,bit_rate_bps,bandwidth_hz):
    if ebn0_linear<0 or bit_rate_bps<0 or bandwidth_hz<=0: raise ValueError("invalid Eb/N0/Rb/B")
    return ebn0_linear*bit_rate_bps/bandwidth_hz

def q_function(x):
    return 0.5*math.erfc(x/math.sqrt(2))

def ber_bpsk_awgn(ebn0_linear):
    if ebn0_linear<0: raise ValueError("Eb/N0 nonnegative")
    return q_function(math.sqrt(2*ebn0_linear))

def ber_qpsk_awgn(ebn0_linear):
    return ber_bpsk_awgn(ebn0_linear)

def ber_square_mqam_awgn_approx(ebn0_linear,M):
    if ebn0_linear<0 or M not in (16,64,256): raise ValueError("invalid Eb/N0 or QAM order")
    k=math.log2(M)
    return (4/k)*(1-1/math.sqrt(M))*q_function(math.sqrt(3*k*ebn0_linear/(M-1)))

def coding_gain_adjusted_ebn0(ebn0_linear,coding_gain_db):
    if ebn0_linear<0: raise ValueError("Eb/N0 nonnegative")
    return ebn0_linear*10**(coding_gain_db/10)

def packet_error_rate_from_ber(bit_error_rate,packet_bits):
    if not 0<=bit_error_rate<=1 or packet_bits<0 or int(packet_bits)!=packet_bits: raise ValueError("invalid BER/packet size")
    return 1-(1-bit_error_rate)**packet_bits

def goodput_bps(raw_bit_rate_bps,packet_error_rate,protocol_efficiency=1.0):
    if raw_bit_rate_bps<0 or not 0<=packet_error_rate<=1 or not 0<=protocol_efficiency<=1: raise ValueError("invalid goodput inputs")
    return raw_bit_rate_bps*(1-packet_error_rate)*protocol_efficiency

@dataclass(frozen=True)
class DigitalLink:
    bit_rate_bps:float
    modulation:Modulation
    code_rate:float=1.0
    rolloff:float=0.0
    ebn0_linear:float=1.0
    coding_gain_db:float=0.0
    packet_bits:int=1024
    protocol_efficiency:float=1.0
    def __post_init__(self):
        if self.bit_rate_bps<0 or not 0<self.code_rate<=1 or not 0<=self.rolloff<=1 or self.ebn0_linear<0 or self.packet_bits<0 or not 0<=self.protocol_efficiency<=1:
            raise ValueError("invalid digital link")
    @property
    def bits_per_symbol(self): return bits_per_symbol(self.modulation)
    @property
    def symbol_rate_baud(self): return symbol_rate_baud(self.bit_rate_bps,self.modulation,self.code_rate)
    @property
    def occupied_bandwidth_hz(self): return nyquist_baseband_bandwidth_hz(self.symbol_rate_baud,self.rolloff)
    @property
    def spectral_efficiency_bps_hz(self): return spectral_efficiency_bps_hz(self.modulation,self.code_rate,self.rolloff)
    @property
    def effective_ebn0_linear(self): return coding_gain_adjusted_ebn0(self.ebn0_linear,self.coding_gain_db)
    @property
    def ber(self):
        if self.modulation==Modulation.BPSK:return ber_bpsk_awgn(self.effective_ebn0_linear)
        if self.modulation==Modulation.QPSK:return ber_qpsk_awgn(self.effective_ebn0_linear)
        return ber_square_mqam_awgn_approx(self.effective_ebn0_linear,{Modulation.QAM16:16,Modulation.QAM64:64,Modulation.QAM256:256}[self.modulation])
    @property
    def packet_error_rate(self): return packet_error_rate_from_ber(self.ber,self.packet_bits)
    @property
    def goodput_bps(self): return goodput_bps(self.bit_rate_bps,self.packet_error_rate,self.protocol_efficiency)
