from __future__ import annotations
from dataclasses import dataclass,asdict
from datetime import datetime,timezone
import uuid

def _utc():return datetime.now(timezone.utc).isoformat()

@dataclass(frozen=True)
class GuardianObservation:
    observation_id:str;title:str;text:str;provenance:str;confidence:float
    source_ids:tuple[str,...];created_utc:str;project_id:str|None=None;experiment_id:str|None=None

@dataclass(frozen=True)
class GuardianProposal:
    proposal_id:str;title:str;rationale:str;status:str;created_utc:str
    action_id:str|None=None;parameters:dict|None=None;source_ids:tuple[str,...]=()

class ScientificIntelligenceService:
    """Coordinates observations, journal/memory and reviewable proposals.
    Proposals are inert records until an operator separately approves execution."""
    def __init__(self,memory_store,analytics_service=None):
        self.memory=memory_store;self.analytics=analytics_service;self.observations=[];self.proposals=[]

    def observe(self,title,text,provenance="SOFTWARE",confidence=.5,source_ids=(),project_id=None,experiment_id=None):
        confidence=max(0.0,min(1.0,float(confidence)))
        o=GuardianObservation("OBS-"+uuid.uuid4().hex[:16].upper(),title,text,provenance,confidence,
                              tuple(source_ids),_utc(),project_id,experiment_id)
        self.observations.append(o)
        self.memory.add("OBSERVATION",title,text,provenance,project_id,experiment_id,source_ids,confidence)
        return o

    def journal(self,title,text,project_id=None,experiment_id=None,source_ids=()):
        return self.memory.add("JOURNAL",title,text,"OPERATOR",project_id,experiment_id,source_ids,1.0)

    def propose(self,title,rationale,action_id=None,parameters=None,source_ids=()):
        p=GuardianProposal("PROP-"+uuid.uuid4().hex[:16].upper(),title,rationale,"PENDING_REVIEW",_utc(),
                           action_id,parameters or {},tuple(source_ids))
        self.proposals.append(p);return p

    def set_proposal_status(self,proposal_id,status):
        allowed={"PENDING_REVIEW","APPROVED","DENIED","INSTALLED"}
        if status not in allowed:raise ValueError("Unsupported proposal status.")
        for i,p in enumerate(self.proposals):
            if p.proposal_id==proposal_id:
                q=GuardianProposal(p.proposal_id,p.title,p.rationale,status,p.created_utc,p.action_id,p.parameters,p.source_ids)
                self.proposals[i]=q;return q
        raise KeyError(proposal_id)

    def snapshot(self):
        return {"observations":[asdict(x) for x in self.observations[-100:]],
                "memory":[asdict(x) for x in self.memory.records[-100:]],
                "journal":[asdict(x) for x in self.memory.query(kind="JOURNAL",limit=100)],
                "proposals":[asdict(x) for x in self.proposals[-100:]]}
