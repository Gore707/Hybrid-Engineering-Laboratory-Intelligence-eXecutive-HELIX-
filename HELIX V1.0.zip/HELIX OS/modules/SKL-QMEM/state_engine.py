from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np

_TOL = 1e-10

def _as_density_matrix(rho):
    a=np.asarray(rho,dtype=complex)
    if a.ndim!=2 or a.shape[0]!=a.shape[1] or a.shape[0]<2:
        raise ValueError("density matrix must be square with dimension >=2")
    if not np.allclose(a,a.conj().T,atol=_TOL):
        raise ValueError("density matrix must be Hermitian")
    tr=np.trace(a)
    if abs(tr.imag)>_TOL or not math.isclose(float(tr.real),1.0,abs_tol=_TOL):
        raise ValueError("density matrix must have unit trace")
    if np.min(np.linalg.eigvalsh(a)) < -_TOL:
        raise ValueError("density matrix must be positive semidefinite")
    return a

def ket_to_density(ket):
    v=np.asarray(ket,dtype=complex).reshape(-1)
    if len(v)<2: raise ValueError("state dimension >=2 required")
    n=np.linalg.norm(v)
    if n<=0: raise ValueError("zero ket invalid")
    v=v/n
    return np.outer(v,v.conj())

def purity(rho):
    a=_as_density_matrix(rho)
    return float(np.trace(a@a).real)

def von_neumann_entropy_bits(rho):
    a=_as_density_matrix(rho)
    vals=np.clip(np.linalg.eigvalsh(a).real,0,1)
    nz=vals[vals>_TOL]
    return float(-np.sum(nz*np.log2(nz)))

@dataclass(frozen=True)
class BlochVector:
    x:float;y:float;z:float
    def __post_init__(self):
        if self.radius > 1+_TOL: raise ValueError("Bloch vector radius cannot exceed 1")
    @property
    def radius(self): return math.sqrt(self.x*self.x+self.y*self.y+self.z*self.z)
    def density_matrix(self):
        return np.array([[1+self.z,self.x-1j*self.y],
                         [self.x+1j*self.y,1-self.z]],dtype=complex)/2

def bloch_from_density(rho):
    a=_as_density_matrix(rho)
    if a.shape!=(2,2): raise ValueError("Bloch representation is qubit-only")
    return BlochVector(float(2*a[0,1].real),float(-2*a[0,1].imag),float((a[0,0]-a[1,1]).real))

def trace_distance(rho,sigma):
    a=_as_density_matrix(rho); b=_as_density_matrix(sigma)
    if a.shape!=b.shape: raise ValueError("state dimensions must match")
    vals=np.linalg.eigvalsh(a-b)
    return float(0.5*np.sum(np.abs(vals)))

def state_fidelity(rho,sigma):
    a=_as_density_matrix(rho); b=_as_density_matrix(sigma)
    if a.shape!=b.shape: raise ValueError("state dimensions must match")
    vals,vec=np.linalg.eigh(a)
    sa=(vec*np.sqrt(np.clip(vals,0,None)))@vec.conj().T
    c=sa@b@sa
    ev=np.linalg.eigvalsh((c+c.conj().T)/2)
    return float(np.sum(np.sqrt(np.clip(ev,0,None)))**2)

def amplitude_damping_qubit(rho,gamma):
    if not 0<=gamma<=1: raise ValueError("gamma 0..1")
    a=_as_density_matrix(rho)
    if a.shape!=(2,2): raise ValueError("qubit channel requires 2x2 state")
    e0=np.array([[1,0],[0,math.sqrt(1-gamma)]],complex)
    e1=np.array([[0,math.sqrt(gamma)],[0,0]],complex)
    return e0@a@e0.conj().T + e1@a@e1.conj().T

def phase_damping_qubit(rho,lambda_phase):
    if not 0<=lambda_phase<=1: raise ValueError("phase damping 0..1")
    a=_as_density_matrix(rho)
    if a.shape!=(2,2): raise ValueError("qubit channel requires 2x2 state")
    out=a.copy(); out[0,1]*=(1-lambda_phase); out[1,0]*=(1-lambda_phase)
    return out

def t1_relaxation_probability(time_s,t1_s):
    if time_s<0 or t1_s<=0: raise ValueError("invalid T1 inputs")
    return 1-math.exp(-time_s/t1_s)

def t2_coherence_factor(time_s,t2_s):
    if time_s<0 or t2_s<=0: raise ValueError("invalid T2 inputs")
    return math.exp(-time_s/t2_s)

def evolve_t1_t2_qubit(rho,time_s,t1_s,t2_s):
    if t2_s>2*t1_s+_TOL:
        raise ValueError("for simple Markovian relaxation/dephasing, T2 <= 2*T1")
    out=amplitude_damping_qubit(rho,t1_relaxation_probability(time_s,t1_s))
    # Amplitude damping already contributes exp[-t/(2T1)] to coherence.
    extra_rate=max(0.0,1/t2_s-1/(2*t1_s))
    lam=1-math.exp(-time_s*extra_rate) if extra_rate else 0.0
    return phase_damping_qubit(out,lam)
