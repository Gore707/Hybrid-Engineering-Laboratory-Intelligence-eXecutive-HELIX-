from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import C,wavelength_m,free_space_path_loss_db,db_to_linear,linear_to_db
from .antennas import effective_aperture_m2,dish_half_power_beamwidth_rad,polarization_mismatch_factor,PhasedArray
from .propagation import PropagationLossBudget,propagation_delay_s,relativistic_received_frequency_hz,fresnel_zone_radius_m
from .front_end import RFStage,ReceiverChain,TransmitterChain
from .coherent import MaserResonator,CoherentMicrowaveArray,phase_drift_rad
from .digital import Modulation,DigitalLink,ber_bpsk_awgn
from .simulation import IntegratedRFScenario,simulate_rf_link,LinkStatus

@dataclass(frozen=True)
class ValidationCheck:
    name:str
    passed:bool
    detail:str

@dataclass(frozen=True)
class ValidationReport:
    checks:tuple[ValidationCheck,...]
    @property
    def passed(self): return all(c.passed for c in self.checks)
    @property
    def passed_count(self): return sum(c.passed for c in self.checks)
    @property
    def total_count(self): return len(self.checks)

def run_cross_engine_validation():
    c=[]
    def check(name,ok,detail): c.append(ValidationCheck(name,bool(ok),detail))

    f=10e9; lam=wavelength_m(f)
    check("frequency-wavelength",abs(f*lam-C)/C<1e-12,"f*lambda=c")

    x=17.3
    check("db-roundtrip",abs(linear_to_db(db_to_linear(x))-x)<1e-12,"dB/linear inverse")

    d=1e6
    fspl=free_space_path_loss_db(d,f)
    expected=20*math.log10(4*math.pi*d/lam)
    check("fspl-identity",abs(fspl-expected)<1e-10,"FSPL matches 4*pi*R/lambda")

    gain=1000
    ae=effective_aperture_m2(gain,f)
    check("gain-aperture",abs(ae-gain*lam*lam/(4*math.pi))<1e-15,"Ae=G lambda^2/(4pi)")

    check("beamwidth-scaling",dish_half_power_beamwidth_rad(2,f)<dish_half_power_beamwidth_rad(1,f),"larger dish narrows HPBW")
    check("polarization-orthogonal",abs(polarization_mismatch_factor(math.pi/2))<1e-12,"orthogonal linear polarization rejects ideal power")

    pa=PhasedArray(4,lam/2,f,1.0,10.0,1.0)
    check("array-coherent-gain",abs(pa.coherent_peak_gain_linear-4)<1e-12,"ideal coherent element gain scales N")

    p=PropagationLossBudget(C,f,environment="DEEP_SPACE")
    check("propagation-delay",abs(p.one_way_delay_s-1)<1e-12,"distance c gives one second")
    check("propagation-loss",abs(p.total_loss_db-p.fspl_db)<1e-12,"vacuum budget has no implicit excess loss")
    check("relativistic-doppler",relativistic_received_frequency_hz(f,1000)>f,"closing convention increases received frequency")
    check("fresnel-positive",fresnel_zone_radius_m(1,1000,1000,f)>0,"first Fresnel zone positive")

    rx=ReceiverChain((RFStage("LNA",100,1.2),RFStage("IF",10,3)),290,1e6,10)
    check("receiver-gain",abs(rx.total_gain_linear-1000)<1e-12,"receiver gain product")
    check("friis-noise",abs(rx.noise_factor-1.22)<1e-12,"Friis cascade F=1.2+(3-1)/100")

    tx=TransmitterChain(100,.5,.8)
    check("tx-energy-accounting",abs(tx.dc_input_w-(tx.requested_rf_output_w+tx.waste_heat_w))<1e-12,"PA DC input equals RF output plus modeled waste heat")

    maser=MaserResonator(f,1e7,3,1,.5,2)
    check("maser-q-linewidth",abs(maser.linewidth_hz-1000)<1e-12,"linewidth=f/Q")
    check("maser-inversion",maser.inversion_fraction>0,"upper population exceeds lower")

    ca=CoherentMicrowaveArray(100,(0,0,0,0),f)
    check("coherent-energy-guard",abs(ca.peak_combined_power_w-ca.total_generated_rf_power_w)<1e-12,"coherence does not create RF energy")
    check("phase-drift",abs(phase_drift_rad(1,.5)-math.pi)<1e-12,"1 Hz error for 0.5 s gives pi radians")

    dl=DigitalLink(1e6,Modulation.QPSK,.8,.2,10,2,1024,.9)
    check("digital-rate-bandwidth",abs(dl.bit_rate_bps/dl.occupied_bandwidth_hz-dl.spectral_efficiency_bps_hz)<1e-12,"rate/B equals modeled spectral efficiency")
    check("ber-monotonic",ber_bpsk_awgn(10)<ber_bpsk_awgn(1),"BPSK BER improves with Eb/N0")

    prop=PropagationLossBudget(1000,1e9)
    sc=IntegratedRFScenario(100,100,100,prop,1.5,290,1e6,Modulation.QPSK,.8,.2,-10,2,1024,.9)
    res=simulate_rf_link(sc)
    check("end-to-end-provenance",res.evidence=="SIMULATION","integrated analytical result provenance")
    check("end-to-end-bounds",0<=res.ber<=.5 and 0<=res.packet_error_rate<=1 and 0<=res.goodput_bps<=sc.bit_rate_bps,"BER/PER/goodput physical bounds")

    sc2=IntegratedRFScenario(1000,100,100,prop,1.5,290,1e6,Modulation.QPSK,.8,.2,-10,2,1024,.9)
    check("power-margin-monotonic",simulate_rf_link(sc2).link_margin_db>res.link_margin_db,"more transmitter power increases margin")

    far=PropagationLossBudget(10000,1e9)
    sc3=IntegratedRFScenario(100,100,100,far,1.5,290,1e6,Modulation.QPSK,.8,.2,-10,2,1024,.9)
    check("distance-margin-monotonic",simulate_rf_link(sc3).link_margin_db<res.link_margin_db,"greater free-space distance decreases margin")

    return ValidationReport(tuple(c))
