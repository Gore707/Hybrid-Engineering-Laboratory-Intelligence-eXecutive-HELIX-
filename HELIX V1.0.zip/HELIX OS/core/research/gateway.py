from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,urllib.parse,urllib.request,urllib.robotparser

class GatewayPolicyError(RuntimeError):pass

@dataclass(frozen=True)
class ResearchArtifact:
 artifact_id:str;source_url:str;retrieved_utc:str;content_type:str|None
 size_bytes:int;checksum_sha256:str;cache_file:str;license:str|None=None
 title:str|None=None
 def dict(self):return asdict(self)

class OpenResearchGateway:
 def __init__(self,cache_path:Path,index_path:Path,user_agent="HELIX Research Gateway",
              timeout_seconds=20,max_download_bytes=104857600,respect_robots=True,opener=None):
  self.cache=cache_path;self.index_path=index_path;self.ua=user_agent;self.timeout=timeout_seconds
  self.max_bytes=max_download_bytes;self.respect_robots=respect_robots;self.opener=opener or urllib.request.urlopen
  self.cache.mkdir(parents=True,exist_ok=True);self.index=self._load()

 def _load(self):
  if not self.index_path.exists():return {}
  return json.loads(self.index_path.read_text(encoding="utf-8"))

 def _save(self):
  self.index_path.parent.mkdir(parents=True,exist_ok=True);tmp=self.index_path.with_suffix(".tmp")
  tmp.write_text(json.dumps(self.index,indent=2),encoding="utf-8");os.replace(tmp,self.index_path)

 def validate_url(self,url):
  u=urllib.parse.urlparse(url)
  if u.scheme!="https":raise GatewayPolicyError("Only HTTPS retrieval is permitted.")
  if not u.hostname:raise GatewayPolicyError("URL must include a hostname.")
  if u.username or u.password:raise GatewayPolicyError("Credential-bearing URLs are not permitted.")
  return u

 def robots_allowed(self,url):
  if not self.respect_robots:return True
  u=self.validate_url(url);robots=f"{u.scheme}://{u.netloc}/robots.txt"
  rp=urllib.robotparser.RobotFileParser()
  try:
   req=urllib.request.Request(robots,headers={"User-Agent":self.ua})
   with self.opener(req,timeout=self.timeout) as r:
    text=r.read(1024*1024).decode("utf-8","replace")
   rp.set_url(robots);rp.parse(text.splitlines());return rp.can_fetch(self.ua,url)
  except Exception:
   # Fail closed when policy status cannot be determined.
   return False

 def fetch(self,url,license=None,title=None,check_robots=True):
  self.validate_url(url)
  if check_robots and not self.robots_allowed(url):
   raise GatewayPolicyError("Retrieval denied because robots permission was unavailable or disallowed.")
  req=urllib.request.Request(url,headers={"User-Agent":self.ua,"Accept":"*/*"})
  h=hashlib.sha256();chunks=[];size=0;ctype=None
  with self.opener(req,timeout=self.timeout) as r:
   ctype=r.headers.get("Content-Type")
   length=r.headers.get("Content-Length")
   if length and int(length)>self.max_bytes:raise GatewayPolicyError("Remote artifact exceeds configured size limit.")
   while True:
    chunk=r.read(min(1024*1024,self.max_bytes-size+1))
    if not chunk:break
    size+=len(chunk)
    if size>self.max_bytes:raise GatewayPolicyError("Downloaded artifact exceeds configured size limit.")
    h.update(chunk);chunks.append(chunk)
  digest=h.hexdigest();suffix=self._suffix(url,ctype);name=digest+suffix;path=self.cache/name
  if not path.exists():
   tmp=path.with_suffix(path.suffix+".tmp");tmp.write_bytes(b"".join(chunks));os.replace(tmp,path)
  aid="RES-"+digest[:20].upper()
  art=ResearchArtifact(aid,url,datetime.now(timezone.utc).isoformat(),ctype,size,digest,str(path),license,title)
  self.index[aid]=art.dict();self._save();return art

 def cached(self,artifact_id):
  d=self.index.get(artifact_id);return ResearchArtifact(**d) if d else None

 @staticmethod
 def _suffix(url,ctype):
  p=Path(urllib.parse.urlparse(url).path);s=p.suffix.lower()
  if s and len(s)<=8:return s
  if ctype and "pdf" in ctype.lower():return ".pdf"
  if ctype and "json" in ctype.lower():return ".json"
  return ".bin"
