import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ISN"
sp=importlib.util.spec_from_file_location("skl_isn",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_isn"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_rs(self):self.assertTrue(2900<q.schwarzschild_radius_m()<3000)
 def test_focal(self):self.assertTrue(540<q.minimum_solar_focal_distance_au()<560)
 def test_impact_at_min(self):self.assertAlmostEqual(q.impact_parameter_for_focal_distance_m(q.minimum_solar_focal_distance_m())/q.R_SUN_M,1,places=6)
 def test_deflection(self):self.assertGreater(q.weak_field_deflection_rad(q.R_SUN_M),8e-6)
 def test_gain(self):self.assertGreater(q.sgl_on_axis_wave_optics_gain(1e-6),1e10)
 def test_gain_db(self):self.assertGreater(q.sgl_gain_db(1e-6),100)
 def test_ring_angle(self):
  z=650*q.AU_M;self.assertGreater(q.einstein_ring_angular_radius_rad(z),0)
 def test_scale(self):self.assertEqual(q.image_plane_scale_m_per_rad(650*q.AU_M),650*q.AU_M)
 def test_offset(self):self.assertAlmostEqual(q.transverse_offset_for_angle_m(1e12,1e-9),1000)
 def test_pointing(self):self.assertEqual(q.required_angular_pointing_rad(1000,1e12),1e-9)
 def test_corona_ratio(self):self.assertEqual(q.signal_to_corona_ratio(10,2),5)
 def test_corona_penalty(self):self.assertEqual(q.corona_noise_penalty(10,2),.2)
 def test_cruise(self):self.assertGreater(q.cruise_time_years(550,20),100)
 def test_terminal(self):
  x=q.SolarGravitationalLensTerminal(650,1e-6,1000,10,2)
  self.assertTrue(x.above_minimum_focal_distance);self.assertGreater(x.ideal_gain_db,100);self.assertEqual(x.signal_to_corona,5);self.assertGreater(x.ring_angle_rad,0)
 def test_below_min(self):self.assertFalse(q.SolarGravitationalLensTerminal(500,1e-6,1000).above_minimum_focal_distance)
 def test_relay_preserved(self):self.assertEqual(q.hop_delivery_capacity_bps([100,20]),20)
 def test_optical_preserved(self):self.assertAlmostEqual(q.airy_divergence_rad(1e-6,1),1.22e-6)
 def test_causality_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ISN-SGL-RS","ISN-SGL-FMIN","ISN-SGL-DEFLECT","ISN-SGL-GAIN","ISN-SGL-POINT"}<={x.model_id for x in q.InterstellarNetworkRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-ISN-04")
 def test_dependencies(self):self.assertTrue({"SKL-OPT","SKL-QCOM"}<=set(json.loads((M/"module.json").read_text())["dependencies"]))
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
