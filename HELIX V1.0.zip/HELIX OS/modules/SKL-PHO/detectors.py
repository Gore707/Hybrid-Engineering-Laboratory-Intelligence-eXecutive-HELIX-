from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import H,C0
Q_E=1.602176634e-19
K_B=1.380649e-23
def responsivity_from_qe(qe,wavelength_m):
 if not 0<=qe<=1 or wavelength_m<=0:raise ValueError("invalid QE/wavelength")
 return qe*Q_E*wavelength_m/(H*C0)
def qe_from_responsivity(responsivity_a_w,wavelength_m):
 if responsivity_a_w<0 or wavelength_m<=0:raise ValueError("invalid responsivity/wavelength")
 return responsivity_a_w*H*C0/(Q_E*wavelength_m)
def photocurrent_a(optical_power_w,responsivity_a_w):
 if optical_power_w<0 or responsivity_a_w<0:raise ValueError("nonnegative power/responsivity required")
 return optical_power_w*responsivity_a_w
def shot_noise_current_rms_a(current_a,bandwidth_hz):
 if current_a<0 or bandwidth_hz<0:raise ValueError("nonnegative current/bandwidth required")
 return math.sqrt(2*Q_E*current_a*bandwidth_hz)
def johnson_noise_voltage_rms_v(resistance_ohm,temperature_k,bandwidth_hz):
 if resistance_ohm<=0 or temperature_k<=0 or bandwidth_hz<0:raise ValueError("invalid Johnson parameters")
 return math.sqrt(4*K_B*temperature_k*resistance_ohm*bandwidth_hz)
def total_current_noise_rms_a(*noise_terms_a):
 if any(x<0 for x in noise_terms_a):raise ValueError("noise terms must be nonnegative")
 return math.sqrt(sum(x*x for x in noise_terms_a))
def snr_current(signal_current_a,noise_current_rms_a):
 if signal_current_a<0 or noise_current_rms_a<=0:raise ValueError("invalid signal/noise")
 return signal_current_a/noise_current_rms_a
def nep_w_sqrt_hz(noise_current_density_a_sqrt_hz,responsivity_a_w):
 if noise_current_density_a_sqrt_hz<0 or responsivity_a_w<=0:raise ValueError("invalid NEP parameters")
 return noise_current_density_a_sqrt_hz/responsivity_a_w
def specific_detectivity_jones(area_m2,nep_w_sqrt_hz_value):
 if area_m2<=0 or nep_w_sqrt_hz_value<=0:raise ValueError("invalid detectivity parameters")
 return math.sqrt(area_m2)*100/nep_w_sqrt_hz_value
@dataclass(frozen=True)
class Photodiode:
 responsivity_a_w:float;dark_current_a:float=0.0;bandwidth_hz:float=1.0;saturation_current_a:float|None=None
 def __post_init__(self):
  if self.responsivity_a_w<0 or self.dark_current_a<0 or self.bandwidth_hz<0:raise ValueError("invalid photodiode")
 def signal_current(self,power_w):
  i=photocurrent_a(power_w,self.responsivity_a_w)
  return min(i,self.saturation_current_a) if self.saturation_current_a is not None else i
 def shot_noise(self,power_w):
  return shot_noise_current_rms_a(self.signal_current(power_w)+self.dark_current_a,self.bandwidth_hz)
def photon_count_mean(power_w,wavelength_m,integration_s,quantum_efficiency=1.0):
 if power_w<0 or wavelength_m<=0 or integration_s<0 or not 0<=quantum_efficiency<=1:raise ValueError("invalid counting parameters")
 return power_w*integration_s/(H*C0/wavelength_m)*quantum_efficiency
def poisson_count_snr(mean_signal_counts,mean_background_counts=0.0):
 if mean_signal_counts<0 or mean_background_counts<0:raise ValueError("counts nonnegative")
 total=mean_signal_counts+mean_background_counts
 return 0.0 if total==0 else mean_signal_counts/math.sqrt(total)
