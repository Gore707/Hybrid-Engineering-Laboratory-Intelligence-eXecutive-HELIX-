from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math, cmath

class EvidenceState(str,Enum):
    HARDWARE="HARDWARE"; IMPORTED="IMPORTED"; SIMULATION="SIMULATION"
    EXTRAPOLATED="EXTRAPOLATED"; SPECULATIVE="SPECULATIVE"; NEW_PHYSICS="NEW PHYSICS"

class QuantumEncoding(str,Enum):
    POLARIZATION="POLARIZATION"; TIME_BIN="TIME_BIN"; PATH="PATH"; PHASE="PHASE"; FREQUENCY_BIN="FREQUENCY_BIN"

@dataclass(frozen=True)
class Qubit:
    alpha:complex
    beta:complex
    def __post_init__(self):
        n=abs(self.alpha)**2+abs(self.beta)**2
        if not math.isclose(n,1.0,rel_tol=1e-9,abs_tol=1e-12): raise ValueError("qubit must be normalized")
    @property
    def probabilities(self): return (abs(self.alpha)**2,abs(self.beta)**2)

def qubit_from_angles(theta_rad,phi_rad):
    if not 0<=theta_rad<=math.pi: raise ValueError("theta must be in [0,pi]")
    return Qubit(complex(math.cos(theta_rad/2)),cmath.exp(1j*phi_rad)*math.sin(theta_rad/2))

def bloch_vector(q:Qubit):
    a,b=q.alpha,q.beta
    return (2*(a.conjugate()*b).real,2*(a.conjugate()*b).imag,abs(a)**2-abs(b)**2)

def pure_density_matrix(q:Qubit):
    a,b=q.alpha,q.beta
    return ((a*a.conjugate(),a*b.conjugate()),(b*a.conjugate(),b*b.conjugate()))

def density_trace(rho): return (rho[0][0]+rho[1][1]).real

def pure_state_fidelity(a:Qubit,b:Qubit):
    return abs(a.alpha.conjugate()*b.alpha+a.beta.conjugate()*b.beta)**2

def pure_state_trace_distance(a:Qubit,b:Qubit):
    return math.sqrt(max(0.0,1-pure_state_fidelity(a,b)))

def binary_entropy_bits(p):
    if not 0<=p<=1: raise ValueError("probability in [0,1]")
    if p in (0,1): return 0.0
    return -p*math.log2(p)-(1-p)*math.log2(1-p)

def qubit_pure_measurement_entropy_bits(q:Qubit):
    return binary_entropy_bits(q.probabilities[0])

def attenuation_transmissivity(loss_db):
    if loss_db<0: raise ValueError("loss dB nonnegative")
    return 10**(-loss_db/10)

def photon_survival_probability(channel_transmissivity,detector_efficiency=1.0):
    if not 0<=channel_transmissivity<=1 or not 0<=detector_efficiency<=1: raise ValueError("efficiencies in [0,1]")
    return channel_transmissivity*detector_efficiency

def depolarizing_fidelity(p):
    if not 0<=p<=1: raise ValueError("p in [0,1]")
    # Convention: rho'=(1-p)rho+p I/2.
    return 1-p/2

def dephasing_coherence_factor(p):
    if not 0<=p<=1: raise ValueError("p in [0,1]")
    # Convention: rho'=(1-p)rho+p Z rho Z.
    return abs(1-2*p)

def amplitude_damping_excited_population(initial_excited_probability,gamma):
    if not 0<=initial_excited_probability<=1 or not 0<=gamma<=1: raise ValueError("probabilities in [0,1]")
    return initial_excited_probability*(1-gamma)

def no_signalling_remote_probability(local_operation_choice,shared_state="bell_phi_plus"):
    # Explicit invariant placeholder with real semantics: for a maximally entangled Bell pair,
    # either remote computational-basis outcome remains 1/2 regardless of local basis/operation choice.
    if shared_state!="bell_phi_plus": raise ValueError("QCOM-01 supports Bell Phi+ invariant only")
    return (0.5,0.5)

@dataclass(frozen=True)
class QuantumChannel:
    transmissivity:float=1.0
    depolarizing_probability:float=0.0
    dephasing_probability:float=0.0
    amplitude_damping_probability:float=0.0
    evidence:EvidenceState=EvidenceState.SIMULATION
    def __post_init__(self):
        for x in (self.transmissivity,self.depolarizing_probability,self.dephasing_probability,self.amplitude_damping_probability):
            if not 0<=x<=1: raise ValueError("channel probabilities in [0,1]")
    @property
    def loss_db(self):
        return math.inf if self.transmissivity==0 else -10*math.log10(self.transmissivity)
