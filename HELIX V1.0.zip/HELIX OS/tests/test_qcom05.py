import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QCOM"
sp=importlib.util.spec_from_file_location("skl_qcom",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qcom"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_two_bits_unique(self):self.assertEqual(len({q.classical_bits_for_bell_outcome(x) for x in q.BellMeasurementOutcome}),4)
 def test_corrections(self):self.assertEqual({q.required_pauli_correction(x) for x in q.BellMeasurementOutcome},{"I","X","Z","XZ"})
 def test_pauli_x(self):self.assertEqual(q.apply_pauli(q.Qubit(1+0j,0j),"X").probabilities,(0,1))
 def test_pauli_z_fidelity(self):self.assertEqual(q.pure_state_fidelity(q.Qubit(1+0j,0j),q.apply_pauli(q.Qubit(1+0j,0j),"Z")),1)
 def test_fidelity_perfect(self):self.assertEqual(q.teleportation_fidelity_from_bell_fidelity(1),1)
 def test_classical_threshold(self):self.assertAlmostEqual(q.classical_fidelity_threshold_qubit(),2/3)
 def test_resource_threshold(self):self.assertAlmostEqual(q.teleportation_fidelity_from_bell_fidelity(.5),2/3)
 def test_success(self):self.assertEqual(q.teleportation_success_probability(.5,.5,.8),.2)
 def test_rate(self):self.assertEqual(q.teleportation_rate_per_s(1000,.2),200)
 def test_light_time(self):self.assertEqual(q.classical_message_transmission_time_s(q.C_M_S),1)
 def test_processing(self):self.assertEqual(q.classical_message_transmission_time_s(0,processing_delay_s=.1),.1)
 def test_no_superluminal_classical(self):
  with self.assertRaises(ValueError):q.classical_message_transmission_time_s(1,q.C_M_S*1.01)
 def test_pre_message_information(self):self.assertEqual(q.pre_classical_message_receiver_state_information_bits(),0)
 def test_link(self):
  x=q.TeleportationLink(q.C_M_S,1000,.5,.5,.9,processing_delay_s=.01)
  self.assertEqual(x.successful_rate_per_s,250);self.assertAlmostEqual(x.minimum_usable_latency_s,1.01);self.assertGreater(x.average_fidelity,2/3)
 def test_no_signalling_preserved(self):self.assertEqual(q.no_signalling_remote_probability("teleport"),(.5,.5))
 def test_decoy_preserved(self):self.assertGreater(q.poisson_single_photon_probability(.5),0)
 def test_entanglement_preserved(self):self.assertAlmostEqual(q.pure_two_qubit_concurrence(q.bell_state_vector(q.BellState.PHI_PLUS)),1)
 def test_registry(self):self.assertTrue({"QCOM-TELE-CLASSICAL","QCOM-TELE-FID","QCOM-TELE-SUCCESS","QCOM-TELE-RATE","QCOM-TELE-LATENCY"}<={x.model_id for x in q.QuantumCommRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QCOM-05")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
