from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .foundation import causality_bypass_available,C_M_S
from .neutrino import approximate_cc_cross_section_m2,NeutrinoLink
from .high_energy_photon import HighEnergyPhotonLink
from .particle_beam import ParticleBeamLink
from .gravitational_wave import GravitationalWaveLink
from .comparison import CarrierScenario

class GateSeverity(str,Enum):
    INFO="INFO";NOTICE="NOTICE";WARNING="WARNING";ERROR="ERROR";CRITICAL="CRITICAL"

@dataclass(frozen=True)
class GateFinding:
    gate_id:str
    severity:GateSeverity
    passed:bool
    message:str

def normalized_local_sensitivity(fn,x,relative_step=1e-4):
    if x==0 or relative_step<=0:raise ValueError("nonzero x and positive step required")
    h=abs(x)*relative_step;y0=fn(x)
    if y0==0:return math.inf
    return ((fn(x+h)-fn(x-h))/(2*h))*(x/y0)

def neutrino_gates(link:NeutrinoLink,min_event_rate_s=1.0,min_bit_rate_bps=.1):
    return (
      GateFinding("ECC-NU-EVENT",GateSeverity.ERROR,link.detected_events_s>=min_event_rate_s,f"Detected neutrino event rate >= {min_event_rate_s:g}/s."),
      GateFinding("ECC-NU-RATE",GateSeverity.ERROR,link.ideal_bit_rate_bps>=min_bit_rate_bps,f"Ideal event-limited rate >= {min_bit_rate_bps:g} bit/s."),
    )

def high_energy_photon_gates(link:HighEnergyPhotonLink,min_detected_rate_s=1.0,min_transmission=.01):
    return (
      GateFinding("ECC-HEP-DETECT",GateSeverity.ERROR,link.detected_photon_rate_s>=min_detected_rate_s,f"Detected photon rate >= {min_detected_rate_s:g}/s."),
      GateFinding("ECC-HEP-TRANSMISSION",GateSeverity.WARNING,link.transmission>=min_transmission,f"Transmission >= {min_transmission:g}."),
    )

def particle_beam_gates(link:ParticleBeamLink,min_survival=.01,min_bit_rate_bps=.1):
    return (
      GateFinding("ECC-PB-SUBLUMINAL",GateSeverity.CRITICAL,link.speed_m_s<C_M_S,"Massive-particle propagation must remain below c."),
      GateFinding("ECC-PB-SURVIVAL",GateSeverity.ERROR,link.survival>=min_survival,f"Particle survival >= {min_survival:g}."),
      GateFinding("ECC-PB-RATE",GateSeverity.ERROR,link.ideal_bit_rate_bps>=min_bit_rate_bps,f"Ideal event-limited rate >= {min_bit_rate_bps:g} bit/s."),
    )

def gravitational_wave_gates(link:GravitationalWaveLink,min_snr=5.0):
    return (
      GateFinding("ECC-GW-SNR",GateSeverity.ERROR,link.ideal_coherent_snr>=min_snr,f"Ideal coherent SNR >= {min_snr:g}."),
      GateFinding("ECC-GW-CAUSAL",GateSeverity.CRITICAL,abs(link.propagation_time_s-link.distance_m/C_M_S)<=1e-12*max(1,link.propagation_time_s),"GW propagation remains causal at c."),
    )

def global_gates():
    return (GateFinding("ECC-GLOBAL-CAUSALITY",GateSeverity.CRITICAL,not causality_bypass_available(),
      "Established-physics ECC solvers must not expose a causality bypass."),)

def all_critical_gates_pass(findings):
    return all(x.passed for x in findings if x.severity==GateSeverity.CRITICAL)

def run_cross_engine_validation(root_path=None):
    checks={}
    checks["global_no_causality_bypass"]=not causality_bypass_available()
    checks["neutrino_cross_section_energy_scaling"]=abs(approximate_cc_cross_section_m2(10)/approximate_cc_cross_section_m2(1)-10)<1e-12
    nu=NeutrinoLink(10,1e20,1e6,1e-3,1e6,.8,10)
    checks["neutrino_positive_event_yield"]=nu.detected_events_s>0
    x1=HighEnergyPhotonLink(10,1e15,1e6,1e-6,1,.8,.8,10)
    x2=HighEnergyPhotonLink(10,1e15,2e6,1e-6,1,.8,.8,10)
    checks["high_energy_photon_distance_loss"]=x2.detected_photon_rate_s<x1.detected_photon_rate_s
    pb=ParticleBeamLink(1.67262192369e-27,1e-8,1e15,1e9,1e-9,10,.9,.8,10)
    checks["massive_particle_subluminal"]=0<pb.speed_m_s<C_M_S
    checks["massive_particle_latency_gt_light"]=pb.latency_s>pb.distance_m/C_M_S
    gw=GravitationalWaveLink(1e-22,100,1e16,1e-23,100,4000)
    checks["gw_positive_flux"]=gw.energy_flux_w_m2>0
    checks["gw_causal_latency"]=abs(gw.propagation_time_s-gw.distance_m/C_M_S)<1e-9
    sc=CarrierScenario("validation",__import__(__package__,fromlist=["EvidenceClass"]).EvidenceClass.ESTABLISHED_PHYSICS,1,10,100)
    checks["comparison_energy_per_bit"]=abs(sc.joules_per_bit-10)<1e-12
    if root_path is not None:
        from pathlib import Path
        r=Path(root_path)
        checks["isn_complete"]=(r/"ISN_COMPLETE.json").exists()
        checks["opt_complete"]=(r/"OPT_COMPLETE.json").exists()
        checks["qcom_complete"]=(r/"QCOM_COMPLETE.json").exists()
    return checks
