from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math, random, statistics
from .foundation import EvidenceClass

@dataclass(frozen=True)
class CarrierScenario:
    name:str
    evidence:EvidenceClass
    latency_s:float
    information_rate_bps:float
    transmitter_power_w:float
    detector_mass_kg:float=0.0
    detector_area_m2:float=0.0
    pointing_requirement_rad:float|None=None
    survival_or_transmission:float=1.0
    infrastructure_power_w:float=0.0
    notes:str=""
    def __post_init__(self):
        if self.latency_s<0 or self.information_rate_bps<0 or self.transmitter_power_w<0 or self.detector_mass_kg<0 or self.detector_area_m2<0 or self.infrastructure_power_w<0:
            raise ValueError("nonnegative scenario metrics required")
        if self.pointing_requirement_rad is not None and self.pointing_requirement_rad<0:raise ValueError("pointing nonnegative")
        if not 0<=self.survival_or_transmission<=1:raise ValueError("survival/transmission in [0,1]")
    @property
    def total_power_w(self):return self.transmitter_power_w+self.infrastructure_power_w
    @property
    def joules_per_bit(self):
        return math.inf if self.information_rate_bps<=0 else self.total_power_w/self.information_rate_bps

def lowest_latency(scenarios):
    return min(scenarios,key=lambda s:s.latency_s) if scenarios else None
def highest_information_rate(scenarios):
    return max(scenarios,key=lambda s:s.information_rate_bps) if scenarios else None
def lowest_energy_per_bit(scenarios):
    valid=[s for s in scenarios if s.information_rate_bps>0]
    return min(valid,key=lambda s:s.joules_per_bit) if valid else None
def lowest_detector_mass(scenarios):
    return min(scenarios,key=lambda s:s.detector_mass_kg) if scenarios else None

def dominates(a,b):
    """Physical multi-objective dominance: lower latency/power/detector mass, higher rate/transmission."""
    no_worse=(a.latency_s<=b.latency_s and a.total_power_w<=b.total_power_w and
              a.detector_mass_kg<=b.detector_mass_kg and a.information_rate_bps>=b.information_rate_bps and
              a.survival_or_transmission>=b.survival_or_transmission)
    strictly=(a.latency_s<b.latency_s or a.total_power_w<b.total_power_w or
              a.detector_mass_kg<b.detector_mass_kg or a.information_rate_bps>b.information_rate_bps or
              a.survival_or_transmission>b.survival_or_transmission)
    return no_worse and strictly

def pareto_front(scenarios):
    return tuple(s for s in scenarios if not any(dominates(o,s) for o in scenarios if o is not s))

def evidence_partition(scenarios):
    out={}
    for s in scenarios:out.setdefault(s.evidence,[]).append(s)
    return {k:tuple(v) for k,v in out.items()}

def parameter_sweep(values,builder):
    return tuple(builder(v) for v in values)

@dataclass(frozen=True)
class UncertaintySummary:
    trials:int
    mean_rate_bps:float
    stdev_rate_bps:float
    p05_rate_bps:float
    p50_rate_bps:float
    p95_rate_bps:float

def _percentile(values,p):
    x=sorted(values);k=(len(x)-1)*p;lo=math.floor(k);hi=math.ceil(k)
    return x[lo] if lo==hi else x[lo]*(hi-k)+x[hi]*(k-lo)

def monte_carlo_rate(base_rate_bps,relative_sigma,trials=1000,seed=1):
    if base_rate_bps<0 or relative_sigma<0 or trials<2:raise ValueError("invalid uncertainty inputs")
    rng=random.Random(seed);x=[max(0.0,rng.gauss(base_rate_bps,base_rate_bps*relative_sigma)) for _ in range(trials)]
    return UncertaintySummary(trials,statistics.mean(x),statistics.stdev(x),_percentile(x,.05),_percentile(x,.5),_percentile(x,.95))

def compare_architectures(scenarios):
    s=tuple(scenarios)
    return {
      "lowest_latency":lowest_latency(s),
      "highest_information_rate":highest_information_rate(s),
      "lowest_energy_per_bit":lowest_energy_per_bit(s),
      "lowest_detector_mass":lowest_detector_mass(s),
      "pareto_front":pareto_front(s),
      "by_evidence":evidence_partition(s)
    }
