from __future__ import annotations
from dataclasses import dataclass
import cmath,math
@dataclass(frozen=True)
class JonesVector:
 ex:complex;ey:complex
 @property
 def intensity(self):return abs(self.ex)**2+abs(self.ey)**2
 def normalized(self):
  n=math.sqrt(self.intensity)
  if n==0:raise ValueError("zero Jones vector")
  return JonesVector(self.ex/n,self.ey/n)
 def stokes(self):
  ex,ey=self.ex,self.ey
  s0=abs(ex)**2+abs(ey)**2;s1=abs(ex)**2-abs(ey)**2
  cross=ex*ey.conjugate()
  return Stokes(s0,s1,2*cross.real,-2*cross.imag)
@dataclass(frozen=True)
class JonesMatrix:
 a:complex;b:complex;c:complex;d:complex
 def apply(self,v):return JonesVector(self.a*v.ex+self.b*v.ey,self.c*v.ex+self.d*v.ey)
 def __matmul__(self,o):
  if isinstance(o,JonesVector):return self.apply(o)
  return JonesMatrix(self.a*o.a+self.b*o.c,self.a*o.b+self.b*o.d,self.c*o.a+self.d*o.c,self.c*o.b+self.d*o.d)
@dataclass(frozen=True)
class Stokes:
 s0:float;s1:float;s2:float;s3:float
 def __post_init__(self):
  if self.s0<0 or any(not math.isfinite(x) for x in (self.s0,self.s1,self.s2,self.s3)):raise ValueError("invalid Stokes vector")
 @property
 def degree_of_polarization(self):
  if self.s0==0:return 0.0
  return min(1.0,math.sqrt(self.s1**2+self.s2**2+self.s3**2)/self.s0)
 @property
 def linear_angle_rad(self):return .5*math.atan2(self.s2,self.s1)
 @property
 def ellipticity_angle_rad(self):
  if self.s0==0:return 0.0
  return .5*math.asin(max(-1,min(1,self.s3/self.s0)))
def rotation(theta):
 c=math.cos(theta);s=math.sin(theta);return JonesMatrix(c,s,-s,c)
def linear_polarizer(theta):
 c=math.cos(theta);s=math.sin(theta);return JonesMatrix(c*c,c*s,c*s,s*s)
def retarder(theta,retardance_rad):
 # R(-theta) diag(1,e^{i delta}) R(theta)
 r=rotation(theta);rm=rotation(-theta);q=JonesMatrix(1,0,0,cmath.exp(1j*retardance_rad))
 return rm@q@r
def quarter_wave_plate(theta=0):return retarder(theta,math.pi/2)
def half_wave_plate(theta=0):return retarder(theta,math.pi)
def malus_law(input_intensity,angle_rad):
 if input_intensity<0:raise ValueError("intensity must be nonnegative")
 return input_intensity*math.cos(angle_rad)**2
@dataclass(frozen=True)
class MuellerMatrix:
 rows:tuple[tuple[float,float,float,float],tuple[float,float,float,float],tuple[float,float,float,float],tuple[float,float,float,float]]
 def apply(self,s):
  v=(s.s0,s.s1,s.s2,s.s3);o=tuple(sum(r[j]*v[j] for j in range(4)) for r in self.rows);return Stokes(*o)
def mueller_linear_polarizer(theta):
 c=math.cos(2*theta);s=math.sin(2*theta)
 return MuellerMatrix(((.5,.5*c,.5*s,0),(.5*c,.5*c*c,.5*c*s,0),(.5*s,.5*c*s,.5*s*s,0),(0,0,0,0)))
