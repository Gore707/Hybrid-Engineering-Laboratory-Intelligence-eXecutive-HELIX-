import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HWI"
sp=importlib.util.spec_from_file_location("skl_hwi",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_hwi"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_type_a(self):self.assertGreater(q.type_a_standard_uncertainty([1,2,3]),0)
 def test_rectangular(self):self.assertAlmostEqual(q.rectangular_standard_uncertainty(math.sqrt(3)),1)
 def test_propagate(self):self.assertAlmostEqual(q.propagate_uncertainty([1,1],[3,4]),5)
 def test_budget(self):
  b=q.UncertaintyBudget((q.UncertaintyComponent("a",3,q.UncertaintyType.TYPE_A),q.UncertaintyComponent("b",4,q.UncertaintyType.TYPE_B)),2)
  self.assertEqual(b.combined_standard_uncertainty,5);self.assertEqual(b.expanded_uncertainty,10)
 def test_trace_chain(self):
  a=q.TraceabilityReference("A","NMI");b=q.TraceabilityReference("B","Lab",parent_reference_id="A");self.assertTrue(q.validate_traceability_chain((a,b)))
 def test_trace_missing(self):self.assertFalse(q.validate_traceability_chain((q.TraceabilityReference("B","Lab",parent_reference_id="A"),)))
 def test_trace_cycle(self):
  a=q.TraceabilityReference("A","x",parent_reference_id="B");b=q.TraceabilityReference("B","x",parent_reference_id="A");self.assertFalse(q.validate_traceability_chain((a,b)))
 def test_certificate(self):
  c=q.CalibrationCertificate("C","D",10,20,"Lab");self.assertTrue(c.valid_at(15));self.assertFalse(c.valid_at(21))
 def test_bad_certificate(self):
  with self.assertRaises(ValueError):q.CalibrationCertificate("C","D",20,10,"Lab")
 def test_history(self):
  h=q.CalibrationHistory();h.add(q.CalibrationCertificate("C2","D",20,None,"L"));h.add(q.CalibrationCertificate("C1","D",10,None,"L"));self.assertEqual(h.latest().certificate_id,"C2")
 def test_history_duplicate(self):
  h=q.CalibrationHistory();c=q.CalibrationCertificate("C","D",1,None,"L");h.add(c)
  with self.assertRaises(ValueError):h.add(c)
 def test_drift(self):self.assertEqual(q.linear_drift_rate_per_s(0,0,10,1),.1);self.assertTrue(q.drift_exceeds_limit(0,0,10,1,.05))
 def test_flags_valid(self):self.assertEqual(q.measurement_quality_flags(5,0,10,None,0),(q.QualityFlag.VALID,))
 def test_flags_range(self):self.assertIn(q.QualityFlag.OUT_OF_RANGE,q.measurement_quality_flags(11,0,10,None,0))
 def test_flags_expired(self):
  c=q.CalibrationCertificate("C","D",0,10,"L");self.assertIn(q.QualityFlag.CALIBRATION_EXPIRED,q.measurement_quality_flags(1,0,2,c,11))
 def test_flags_uncertainty(self):self.assertIn(q.QualityFlag.UNCERTAINTY_HIGH,q.measurement_quality_flags(1,0,2,None,0,relative_uncertainty=.2,max_relative_uncertainty=.1))
 def test_rounding(self):self.assertEqual(q.round_value_to_uncertainty(1.23456,.0123),(1.235,.012))
 def test_driver_preserved(self):self.assertTrue(hasattr(q,"SCPIDriver"))
 def test_transport_preserved(self):self.assertEqual(q.TransportKind.USB.value,"USB")
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/calibration_certificate.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HWI-04")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
