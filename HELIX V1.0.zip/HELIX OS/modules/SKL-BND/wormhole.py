from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import BoundaryEvidence,C_M_S

G=6.67430e-11

def morris_thorne_radial_metric_factor(radius_m,shape_b_m):
    """g_rr = 1/(1-b(r)/r), valid where r>b(r)."""
    if radius_m<=0 or shape_b_m<0 or shape_b_m>=radius_m:raise ValueError("require r>b(r)>=0")
    return 1/(1-shape_b_m/radius_m)

def redshift_time_factor(phi):
    """sqrt(-g_tt)=exp(Phi), c=1 convention for dimensionless metric coefficient."""
    if not math.isfinite(phi):raise ValueError("finite redshift function required")
    return math.exp(phi)

def throat_condition(radius_m,shape_b_m,tol=1e-12):
    if radius_m<=0:return False
    return abs(shape_b_m-radius_m)<=tol*max(1.0,radius_m)

def flare_out_condition_at_throat(shape_derivative):
    """Morris-Thorne flare-out requirement b'(r0)<1."""
    return shape_derivative<1

def nec_radial_indicator_at_throat(radius_m,shape_derivative):
    """At the throat, rho+p_r/c^2 is proportional to (b'-1)/(8*pi*G*r0^2).
    Returns the geometric SI-scaled indicator; negative means radial NEC violation."""
    if radius_m<=0:raise ValueError("positive throat radius")
    return (shape_derivative-1)/(8*math.pi*G*radius_m**2)

def radial_nec_violated_at_throat(shape_derivative):
    return shape_derivative<1

def proper_radial_distance_numeric(r_start_m,r_end_m,shape_function,steps=10000):
    """Midpoint quadrature of integral dr/sqrt(1-b(r)/r); endpoints must stay outside throat."""
    if r_end_m<=r_start_m or steps<1:raise ValueError("ordered radii and positive steps")
    h=(r_end_m-r_start_m)/steps; total=0.0
    for i in range(steps):
        r=r_start_m+(i+.5)*h;b=shape_function(r)
        if b<0 or b>=r:raise ValueError("integration domain requires 0<=b(r)<r")
        total += h/math.sqrt(1-b/r)
    return total

def effective_path_saving_m(external_separation_m,through_throat_path_m):
    if external_separation_m<0 or through_throat_path_m<0:raise ValueError("nonnegative paths")
    return external_separation_m-through_throat_path_m

def wormhole_transit_time_s(through_throat_path_m,local_signal_speed_m_s=C_M_S):
    if through_throat_path_m<0 or local_signal_speed_m_s<=0 or local_signal_speed_m_s>C_M_S:
        raise ValueError("local propagation must satisfy 0<v<=c")
    return through_throat_path_m/local_signal_speed_m_s

def apparent_effective_speed_m_s(external_separation_m,transit_time_s):
    """Endpoint distance divided by transit time; may exceed c without local superluminal motion."""
    if external_separation_m<0 or transit_time_s<=0:raise ValueError("invalid endpoint timing")
    return external_separation_m/transit_time_s

def mouth_clock_arrival_offset_s(transit_time_s,receiver_mouth_clock_offset_s):
    """Receiver-mouth clock reading relative to emitter departure clock under an imposed synchronization offset."""
    if transit_time_s<0:raise ValueError("transit time nonnegative")
    return transit_time_s+receiver_mouth_clock_offset_s

def chronology_risk_from_clock_offset(transit_time_s,receiver_mouth_clock_offset_s):
    return mouth_clock_arrival_offset_s(transit_time_s,receiver_mouth_clock_offset_s)<0

def physically_demonstrated_traversable_wormhole_available():
    return False

@dataclass(frozen=True)
class MorrisThorneCommunicationLink:
    throat_radius_m:float
    shape_derivative_at_throat:float
    through_throat_path_m:float
    external_separation_m:float
    receiver_mouth_clock_offset_s:float=0.0
    evidence:BoundaryEvidence=BoundaryEvidence.SPECULATIVE_UNRESOLVED
    def __post_init__(self):
        if self.throat_radius_m<=0 or self.through_throat_path_m<0 or self.external_separation_m<0:raise ValueError("invalid wormhole geometry")
    @property
    def flare_out_satisfied(self):return flare_out_condition_at_throat(self.shape_derivative_at_throat)
    @property
    def radial_nec_violated(self):return radial_nec_violated_at_throat(self.shape_derivative_at_throat)
    @property
    def local_transit_time_s(self):return wormhole_transit_time_s(self.through_throat_path_m)
    @property
    def apparent_effective_speed_m_s(self):return apparent_effective_speed_m_s(self.external_separation_m,self.local_transit_time_s) if self.local_transit_time_s>0 else math.inf
    @property
    def arrival_clock_offset_s(self):return mouth_clock_arrival_offset_s(self.local_transit_time_s,self.receiver_mouth_clock_offset_s)
    @property
    def chronology_risk(self):return chronology_risk_from_clock_offset(self.local_transit_time_s,self.receiver_mouth_clock_offset_s)
    @property
    def demonstrated_hardware(self):return False
