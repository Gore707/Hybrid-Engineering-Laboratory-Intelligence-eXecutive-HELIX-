from __future__ import annotations
from dataclasses import dataclass,field
from pathlib import Path
import json

@dataclass(frozen=True)
class FigureSpec:
    figure_id:str
    title:str
    x_label:str=""
    y_label:str=""
    caption:str=""
    equation_ids:tuple[str,...]=()
    dataset_ids:tuple[str,...]=()
    assumptions:tuple[str,...]=()
    provenance:dict=field(default_factory=dict)

class VisualizationEngine:
    def __init__(self,export_dpi=300):
        self.export_dpi=export_dpi

    def _plt(self):
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        return plt

    def line(self,x,y,spec:FigureSpec):
        plt=self._plt();fig,ax=plt.subplots()
        ax.plot(x,y);self._finish(ax,spec);return fig

    def scatter(self,x,y,spec:FigureSpec):
        plt=self._plt();fig,ax=plt.subplots()
        ax.scatter(x,y);self._finish(ax,spec);return fig

    def histogram(self,values,spec:FigureSpec,bins=30):
        plt=self._plt();fig,ax=plt.subplots()
        ax.hist(values,bins=bins);self._finish(ax,spec);return fig

    def heatmap(self,z,spec:FigureSpec,x_extent=None,y_extent=None):
        plt=self._plt();fig,ax=plt.subplots()
        extent=None
        if x_extent and y_extent:extent=[x_extent[0],x_extent[1],y_extent[0],y_extent[1]]
        im=ax.imshow(z,origin="lower",aspect="auto",extent=extent)
        fig.colorbar(im,ax=ax);self._finish(ax,spec);return fig

    def contour(self,x,y,z,spec:FigureSpec,levels=12):
        plt=self._plt();fig,ax=plt.subplots()
        cs=ax.contour(x,y,z,levels=levels);ax.clabel(cs,inline=True,fontsize=8)
        self._finish(ax,spec);return fig

    def spectrum(self,frequency,power,spec:FigureSpec,log_y=False):
        plt=self._plt();fig,ax=plt.subplots()
        if log_y:ax.semilogy(frequency,power)
        else:ax.plot(frequency,power)
        self._finish(ax,spec);return fig

    def phase_space(self,q,p,spec:FigureSpec):
        return self.scatter(q,p,spec)

    def bloch(self,vector,spec:FigureSpec):
        import numpy as np
        v=np.asarray(vector,dtype=float)
        if v.shape!=(3,):raise ValueError("Bloch vector must contain exactly 3 components.")
        if np.linalg.norm(v)>1.0000001:raise ValueError("Bloch vector magnitude cannot exceed 1.")
        plt=self._plt()
        fig=plt.figure();ax=fig.add_subplot(111,projection="3d")
        u=np.linspace(0,2*np.pi,40);w=np.linspace(0,np.pi,20)
        xs=np.outer(np.cos(u),np.sin(w));ys=np.outer(np.sin(u),np.sin(w));zs=np.outer(np.ones_like(u),np.cos(w))
        ax.plot_wireframe(xs,ys,zs,rstride=4,cstride=4,linewidth=.35)
        ax.quiver(0,0,0,*v,length=1.0)
        ax.set_xlabel("x");ax.set_ylabel("y");ax.set_zlabel("z");ax.set_title(spec.title)
        return fig

    def _finish(self,ax,spec):
        ax.set_title(spec.title)
        if spec.x_label:ax.set_xlabel(spec.x_label)
        if spec.y_label:ax.set_ylabel(spec.y_label)
        ax.grid(True,alpha=.25)

    def metadata(self,spec):
        return {"figure_id":spec.figure_id,"title":spec.title,"caption":spec.caption,
                "equation_ids":list(spec.equation_ids),"dataset_ids":list(spec.dataset_ids),
                "assumptions":list(spec.assumptions),"provenance":spec.provenance}

    def export(self,fig,path:Path,spec:FigureSpec):
        ext=path.suffix.lower()
        if ext not in (".png",".svg",".pdf"):raise ValueError("Supported exports: PNG, SVG, PDF.")
        path.parent.mkdir(parents=True,exist_ok=True)
        fig.savefig(path,dpi=self.export_dpi,bbox_inches="tight")
        meta_path=path.with_suffix(path.suffix+".metadata.json")
        meta_path.write_text(json.dumps(self.metadata(spec),indent=2),encoding="utf-8")
        return path,meta_path
