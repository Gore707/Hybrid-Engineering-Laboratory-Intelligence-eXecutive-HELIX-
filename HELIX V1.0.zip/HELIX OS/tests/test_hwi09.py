import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HWI"
sp=importlib.util.spec_from_file_location("skl_hwi",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_hwi"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_cal_valid(self):self.assertEqual(q.calibration_gate("D",q.CalibrationState.VALID).status,q.GateStatus.PASS)
 def test_cal_unknown_warn(self):self.assertEqual(q.calibration_gate("D",q.CalibrationState.UNKNOWN).status,q.GateStatus.WARN)
 def test_cal_expired_fail(self):self.assertEqual(q.calibration_gate("D",q.CalibrationState.EXPIRED).status,q.GateStatus.FAIL)
 def test_unc_pass(self):self.assertEqual(q.uncertainty_gate("x",1,100,.02).status,q.GateStatus.PASS)
 def test_unc_fail(self):self.assertEqual(q.uncertainty_gate("x",3,100,.02).status,q.GateStatus.FAIL)
 def test_unc_zero_warn(self):self.assertEqual(q.uncertainty_gate("x",1,0,.02).status,q.GateStatus.WARN)
 def test_drift_pass(self):self.assertEqual(q.drift_gate("x",.1,.2).status,q.GateStatus.PASS)
 def test_drift_fail(self):self.assertEqual(q.drift_gate("x",.3,.2).status,q.GateStatus.FAIL)
 def test_acq_pass(self):self.assertEqual(q.acquisition_integrity_gate("x",0,0).status,q.GateStatus.PASS)
 def test_acq_fail_drop(self):self.assertEqual(q.acquisition_integrity_gate("x",1,0).status,q.GateStatus.FAIL)
 def test_acq_fail_overwrite(self):self.assertEqual(q.acquisition_integrity_gate("x",0,1).status,q.GateStatus.FAIL)
 def test_sync_pass(self):self.assertEqual(q.synchronization_gate("g",.001,.01).status,q.GateStatus.PASS)
 def test_sync_fail(self):self.assertEqual(q.synchronization_gate("g",.02,.01).status,q.GateStatus.FAIL)
 def test_safety_abort(self):
  e=q.SafetyEvent(0,"D","T",1,"K",q.SafetySeverity.ERROR,q.SafetyDecision.ABORT,q.SafetyAuthority.DETERMINISTIC_CONTROLLER,"abort")
  self.assertEqual(q.safety_event_gate(e).status,q.GateStatus.FAIL)
 def test_safety_hold_warn(self):
  e=q.SafetyEvent(0,"D","T",1,"K",q.SafetySeverity.WARNING,q.SafetyDecision.HOLD,q.SafetyAuthority.DETERMINISTIC_CONTROLLER,"hold")
  self.assertEqual(q.safety_event_gate(e).status,q.GateStatus.WARN)
 def test_report_pass(self):
  r=q.build_validation_report("E","R",(q.calibration_gate("D",q.CalibrationState.VALID),));self.assertTrue(r.passed)
 def test_report_fail(self):
  r=q.build_validation_report("E","R",(q.calibration_gate("D",q.CalibrationState.INVALID),));self.assertFalse(r.passed)
 def test_orchestrator_preserved(self):self.assertTrue(hasattr(q,"HardwareExperimentOrchestrator"))
 def test_guardian_boundary(self):self.assertFalse(q.guardian_can_override_safety())
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/validation_report.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HWI-09")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
