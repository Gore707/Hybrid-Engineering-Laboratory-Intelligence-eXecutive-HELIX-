import tempfile,unittest
from pathlib import Path
import numpy as np
from core.bootstrap.identity import IDENTITY
from core.visualization import VisualizationEngine,FigureSpec,LiveSeries
from core.visualization.model_plot import sweep_model
from core.physics.registry import PhysicsRegistry
ROOT=Path(__file__).resolve().parents[1]
def spec():
 return FigureSpec("FIG-1","Scientific Figure","x","y","Generated from registered model.",
  ("EQ-ARCH-COHERENCE-001",),("DS-1",),("T2=2 s",),{"source_type":"SIMULATION"})
class C13Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C13")
 def test_live_bounded(self):
  s=LiveSeries(3)
  for i in range(5):s.append(i,i*i)
  x,y=s.arrays();self.assertEqual(x.tolist(),[2,3,4]);self.assertEqual(y.tolist(),[4,9,16])
 def test_line_export_metadata(self):
  with tempfile.TemporaryDirectory() as td:
   e=VisualizationEngine(80);f=e.line([0,1],[1,2],spec());p,m=e.export(f,Path(td)/"f.png",spec())
   self.assertTrue(p.exists());self.assertTrue(m.exists());self.assertGreater(p.stat().st_size,100)
 def test_plot_types(self):
  e=VisualizationEngine(60);s=spec()
  figs=[
   e.scatter([0,1],[1,2],s),e.histogram([1,2,2,3],s,3),
   e.heatmap(np.arange(9).reshape(3,3),s),
   e.spectrum([1,2,3],[3,2,1],s),e.phase_space([0,1],[1,0],s),
   e.bloch([0,0,1],s)]
  self.assertEqual(len(figs),6)
 def test_contour(self):
  e=VisualizationEngine();x=np.linspace(-1,1,10);y=np.linspace(-1,1,10);X,Y=np.meshgrid(x,y);Z=X*X+Y*Y
  self.assertIsNotNone(e.contour(X,Y,Z,spec()))
 def test_invalid_bloch(self):
  with self.assertRaises(ValueError):VisualizationEngine().bloch([2,0,0],spec())
 def test_model_sweep_uses_registry(self):
  r=PhysicsRegistry(ROOT/"core/resources/constants/physical_constants.json",ROOT/"core/resources/equations",ROOT/"core/resources/models")
  x,y=sweep_model(r,"MODEL-ARCH-COHERENCE-001","t",[0,1,2],{"C0":1.0,"T2":2.0},"C")
  self.assertEqual(x,[0,1,2]);self.assertAlmostEqual(y[0],1);self.assertGreater(y[1],y[2])
 def test_metadata_has_science_links(self):
  m=VisualizationEngine().metadata(spec());self.assertEqual(m["equation_ids"],["EQ-ARCH-COHERENCE-001"]);self.assertEqual(m["dataset_ids"],["DS-1"])
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
