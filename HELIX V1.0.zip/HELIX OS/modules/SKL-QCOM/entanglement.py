from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

SQRT2=math.sqrt(2)

class BellState(str,Enum):
    PHI_PLUS="PHI_PLUS"; PHI_MINUS="PHI_MINUS"; PSI_PLUS="PSI_PLUS"; PSI_MINUS="PSI_MINUS"

def bell_state_vector(state:BellState):
    s=1/SQRT2
    return {
      BellState.PHI_PLUS:(s,0j,0j,s),
      BellState.PHI_MINUS:(s,0j,0j,-s),
      BellState.PSI_PLUS:(0j,s,s,0j),
      BellState.PSI_MINUS:(0j,s,-s,0j),
    }[state]

def state_vector_norm_squared(v): return sum(abs(x)**2 for x in v)

def pure_two_qubit_concurrence(v):
    if len(v)!=4:raise ValueError("two-qubit vector requires four amplitudes")
    if not math.isclose(state_vector_norm_squared(v),1,rel_tol=1e-9,abs_tol=1e-12):raise ValueError("state must be normalized")
    a,b,c,d=v
    return min(1.0,2*abs(a*d-b*c))

def bell_fidelity_from_visibility(visibility):
    if not 0<=visibility<=1:raise ValueError("visibility in [0,1]")
    # Werner-state convention: V=p and F=<Bell|rho|Bell>=(1+3p)/4.
    return (1+3*visibility)/4

def werner_concurrence(visibility):
    if not 0<=visibility<=1:raise ValueError("visibility in [0,1]")
    return max(0.0,(3*visibility-1)/2)

def coincidence_rate_per_s(pair_rate_per_s,eta_a,eta_b,coincidence_efficiency=1.0):
    if pair_rate_per_s<0 or not all(0<=x<=1 for x in (eta_a,eta_b,coincidence_efficiency)):raise ValueError("invalid rate/efficiency")
    return pair_rate_per_s*eta_a*eta_b*coincidence_efficiency

def herald_rate_per_s(pair_rate_per_s,herald_efficiency):
    if pair_rate_per_s<0 or not 0<=herald_efficiency<=1:raise ValueError("invalid rate/efficiency")
    return pair_rate_per_s*herald_efficiency

def conditional_signal_probability(signal_efficiency):
    if not 0<=signal_efficiency<=1:raise ValueError("efficiency in [0,1]")
    return signal_efficiency

def accidental_coincidence_rate_per_s(singles_a_per_s,singles_b_per_s,window_s):
    if min(singles_a_per_s,singles_b_per_s,window_s)<0:raise ValueError("nonnegative inputs")
    return singles_a_per_s*singles_b_per_s*window_s

def measured_visibility(signal_coincidences_per_s,accidentals_per_s):
    if signal_coincidences_per_s<0 or accidentals_per_s<0:raise ValueError("nonnegative rates")
    total=signal_coincidences_per_s+accidentals_per_s
    return 0.0 if total==0 else signal_coincidences_per_s/total

def distribution_success_probability(source_pair_probability,eta_a,eta_b):
    if not all(0<=x<=1 for x in (source_pair_probability,eta_a,eta_b)):raise ValueError("probabilities in [0,1]")
    return source_pair_probability*eta_a*eta_b

@dataclass(frozen=True)
class EntangledPairSource:
    pair_rate_per_s:float
    intrinsic_visibility:float=1.0
    collection_efficiency_a:float=1.0
    collection_efficiency_b:float=1.0
    def __post_init__(self):
        if self.pair_rate_per_s<0 or not all(0<=x<=1 for x in (self.intrinsic_visibility,self.collection_efficiency_a,self.collection_efficiency_b)):
            raise ValueError("invalid source")
    @property
    def collected_pair_rate_per_s(self):
        return coincidence_rate_per_s(self.pair_rate_per_s,self.collection_efficiency_a,self.collection_efficiency_b)

@dataclass(frozen=True)
class EntanglementDistribution:
    source:EntangledPairSource
    channel_a_transmissivity:float
    channel_b_transmissivity:float
    detector_efficiency_a:float=1.0
    detector_efficiency_b:float=1.0
    coincidence_efficiency:float=1.0
    def __post_init__(self):
        if not all(0<=x<=1 for x in (self.channel_a_transmissivity,self.channel_b_transmissivity,self.detector_efficiency_a,self.detector_efficiency_b,self.coincidence_efficiency)):
            raise ValueError("efficiencies in [0,1]")
    @property
    def eta_a(self):return self.source.collection_efficiency_a*self.channel_a_transmissivity*self.detector_efficiency_a
    @property
    def eta_b(self):return self.source.collection_efficiency_b*self.channel_b_transmissivity*self.detector_efficiency_b
    @property
    def detected_coincidence_rate_per_s(self):
        return coincidence_rate_per_s(self.source.pair_rate_per_s,self.eta_a,self.eta_b,self.coincidence_efficiency)
