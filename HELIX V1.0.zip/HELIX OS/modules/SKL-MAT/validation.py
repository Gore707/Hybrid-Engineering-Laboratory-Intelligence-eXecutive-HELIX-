from __future__ import annotations
from dataclasses import dataclass
import math
@dataclass(frozen=True)
class ValidationIssue:
 level:str;code:str;message:str
@dataclass(frozen=True)
class ValidationReport:
 passed:bool;issues:tuple[ValidationIssue,...];metrics:dict
class MaterialValidator:
 VALID_EVIDENCE={"DEMONSTRATED_TECH","ESTABLISHED_PHYSICS","EXTRAPOLATED_ENGINEERING","SPECULATIVE_UNRESOLVED","NEW_PHYSICS","UNCLASSIFIED"}
 def validate_material(self,m):
  issues=[]
  if not m.source_ids:issues.append(ValidationIssue("WARNING","NO_MATERIAL_SOURCE","material has no source IDs"))
  seen=set()
  for p in m.properties:
   key=(p.property_id,p.unit,p.condition.temperature_k,p.condition.pressure_pa,p.condition.frequency_hz,p.condition.wavelength_m)
   if key in seen:issues.append(ValidationIssue("ERROR","DUPLICATE_PROPERTY_POINT",f"duplicate conditioned property: {p.property_id}"))
   seen.add(key)
   if p.evidence_class not in self.VALID_EVIDENCE:issues.append(ValidationIssue("ERROR","EVIDENCE_CLASS",f"unsupported evidence class {p.evidence_class}"))
   if not p.source_ids:issues.append(ValidationIssue("WARNING","NO_PROPERTY_SOURCE",f"{p.property_id} has no source IDs"))
  return ValidationReport(not any(i.level=="ERROR" for i in issues),tuple(issues),{"property_count":len(m.properties),"source_count":len(m.source_ids)})
 def validate_dataset(self,ds):
  issues=[]
  if any(b<=a for a,b in zip(ds.x,ds.x[1:])):issues.append(ValidationIssue("ERROR","DOMAIN_ORDER","dataset domain must be strictly increasing"))
  if not ds.source_ids:issues.append(ValidationIssue("ERROR","NO_DATASET_SOURCE","dataset must have source IDs"))
  if ds.uncertainty and any(u<0 for u in ds.uncertainty):issues.append(ValidationIssue("ERROR","NEGATIVE_UNCERTAINTY","uncertainty must be nonnegative"))
  return ValidationReport(not any(i.level=="ERROR" for i in issues),tuple(issues),{"points":len(ds.x),"domain_min":min(ds.x),"domain_max":max(ds.x)})
 def compare_reference(self,candidate,reference):
  if (candidate.property_id,candidate.domain_name,candidate.domain_unit,candidate.value_unit)!=(reference.property_id,reference.domain_name,reference.domain_unit,reference.value_unit):
   raise ValueError("datasets are not dimensionally/compositionally comparable")
  ref=dict(zip(reference.x,reference.y));pairs=[(x,y,ref[x]) for x,y in zip(candidate.x,candidate.y) if x in ref]
  if not pairs:raise ValueError("no shared domain points")
  residuals=tuple((x,y-r) for x,y,r in pairs);rmse=math.sqrt(sum((y-r)**2 for _,y,r in pairs)/len(pairs))
  denom=sum(r*r for _,_,r in pairs)
  nrmse=rmse/(math.sqrt(denom/len(pairs)) if denom else 1.0)
  return {"shared_points":len(pairs),"residuals":residuals,"rmse":rmse,"normalized_rmse":nrmse}
 def chi_square(self,candidate,reference):
  if not reference.uncertainty:raise ValueError("reference uncertainty required")
  if (candidate.property_id,candidate.domain_name,candidate.domain_unit,candidate.value_unit)!=(reference.property_id,reference.domain_name,reference.domain_unit,reference.value_unit):
   raise ValueError("datasets are not comparable")
  ref={x:(y,u) for x,y,u in zip(reference.x,reference.y,reference.uncertainty)}
  terms=[]
  for x,y in zip(candidate.x,candidate.y):
   if x in ref:
    r,u=ref[x]
    if u<=0:raise ValueError("reference uncertainty must be positive")
    terms.append(((y-r)/u)**2)
  if not terms:raise ValueError("no shared points")
  return {"chi_square":sum(terms),"dof":len(terms),"reduced_chi_square":sum(terms)/len(terms)}
