from dataclasses import dataclass
from pathlib import Path
import json,importlib,sys
@dataclass(frozen=True)
class HealthReport:
 passed:bool;checks:tuple[dict,...]
class CoreHealthCheck:
 REQUIRED=("core.commands.service","core.guardian.console","core.storage.service","core.physics.registry","core.compute.manager",
 "core.resource.governor","core.visualization.engine","core.truth","core.research.gateway","core.guardian.intelligence.service",
 "core.design","core.simulation","core.hal","core.safety","core.engineering","core.modules","core.multiphysics")
 def __init__(self,root:Path):self.root=root
 def run(self):
  checks=[]
  cfg=self.root/"skl.config"
  try:
   d=json.loads(cfg.read_text());ok=d["core"]["version"]=="1.0.0" and d["core"]["api_version"]=="1.0"
   checks.append({"check":"configuration","passed":ok,"detail":d["core"]["version"]})
  except Exception as e:checks.append({"check":"configuration","passed":False,"detail":str(e)})
  for name in self.REQUIRED:
   try:importlib.import_module(name);checks.append({"check":"import:"+name,"passed":True,"detail":"ok"})
   except Exception as e:checks.append({"check":"import:"+name,"passed":False,"detail":str(e)})
  writable=self.root/"user"/".health-write"
  try:writable.parent.mkdir(parents=True,exist_ok=True);writable.write_text("ok");writable.unlink();checks.append({"check":"user-writable","passed":True,"detail":"ok"})
  except Exception as e:checks.append({"check":"user-writable","passed":False,"detail":str(e)})
  return HealthReport(all(x["passed"] for x in checks),tuple(checks))
