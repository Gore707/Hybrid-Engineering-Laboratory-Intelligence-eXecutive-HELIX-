from pathlib import Path
import zipfile,json,hashlib,shutil,os,tempfile
from .registry import ModuleManifest,ModuleError
class SKPPackage:
 MANIFEST="skp.manifest.json"
 @staticmethod
 def build(source_dir:Path,out_path:Path,manifest:ModuleManifest):
  files=[]
  for p in sorted(source_dir.rglob("*")):
   if p.is_file():
    rel=p.relative_to(source_dir).as_posix();files.append({"path":rel,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()})
  md={"module_id":manifest.module_id,"name":manifest.name,"version":manifest.version,"api_version":manifest.api_version,
      "dependencies":list(manifest.dependencies),"capabilities":list(manifest.capabilities),"files":files}
  with zipfile.ZipFile(out_path,"w",zipfile.ZIP_DEFLATED) as z:
   z.writestr(SKPPackage.MANIFEST,json.dumps(md,indent=2))
   for f in files:z.write(source_dir/f["path"],f["path"])
  return out_path
 @staticmethod
 def inspect(path:Path):
  with zipfile.ZipFile(path) as z:return json.loads(z.read(SKPPackage.MANIFEST))
 @staticmethod
 def verify(path:Path):
  with zipfile.ZipFile(path) as z:
   md=json.loads(z.read(SKPPackage.MANIFEST))
   for f in md["files"]:
    if hashlib.sha256(z.read(f["path"])).hexdigest()!=f["sha256"]:return False
   return True
 @staticmethod
 def install(path:Path,modules_root:Path,registry):
  if not SKPPackage.verify(path):raise ModuleError("package checksum verification failed")
  md=SKPPackage.inspect(path);manifest=ModuleManifest(md["module_id"],md["name"],md["version"],md["api_version"],tuple(md["dependencies"]),tuple(md["capabilities"]))
  if manifest.api_version!=registry.api_version:raise ModuleError("module API incompatibility")
  missing=[x for x in manifest.dependencies if x not in registry.modules]
  if missing:raise ModuleError("missing dependencies: "+", ".join(missing))
  dest=modules_root/manifest.module_id;stage=modules_root/(".stage-"+manifest.module_id);backup=modules_root/(".backup-"+manifest.module_id)
  shutil.rmtree(stage,ignore_errors=True);shutil.rmtree(backup,ignore_errors=True);stage.mkdir(parents=True,exist_ok=True)
  try:
   with zipfile.ZipFile(path) as z:
    for f in md["files"]:
     target=(stage/f["path"]).resolve()
     if stage.resolve() not in target.parents:raise ModuleError("unsafe package path")
     target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(f["path"]))
   if dest.exists():os.replace(dest,backup)
   os.replace(stage,dest)
   try:registry.register(manifest)
   except Exception:
    shutil.rmtree(dest,ignore_errors=True)
    if backup.exists():os.replace(backup,dest)
    raise
   shutil.rmtree(backup,ignore_errors=True);return manifest
  finally:shutil.rmtree(stage,ignore_errors=True)
