import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-STO";sp=importlib.util.spec_from_file_location("skl_sto",M/"__init__.py",submodule_search_locations=[str(M)]);s=importlib.util.module_from_spec(sp);sys.modules["skl_sto"]=s;sp.loader.exec_module(s)
class T(unittest.TestCase):
 def d(self,t=s.StorageTechnology.GLASS_5D,e=True):return s.StorageDesign("candidate",t,{"x":1},("EV-1",) if e else (),("SRC-1",) if e else ())
 def test_models_all(self):
  for t in s.StorageTechnology:self.assertTrue(s.technology_model_ids(t))
 def test_chain(self):self.assertEqual(len(s.analysis_chain(s.StorageTechnology.GLASS_5D)),6)
 def test_pass(self):
  a=s.assess_design(self.d(),{"capacity_bits":100},[s.DesignRequirement("capacity_bits",minimum=50)]);self.assertEqual(a.readiness,s.Readiness.ENGINEERING_CANDIDATE);self.assertTrue(a.passes_known_requirements)
 def test_fail(self):
  a=s.assess_design(self.d(),{"capacity_bits":10},[s.DesignRequirement("capacity_bits",minimum=50)]);self.assertEqual(a.readiness,s.Readiness.INCOMPLETE)
 def test_missing_metric(self):
  a=s.assess_design(self.d(),{},[s.DesignRequirement("capacity_bits",minimum=50)]);self.assertEqual(a.readiness,s.Readiness.ANALYZABLE);self.assertIsNone(a.requirement_results["capacity_bits"])
 def test_missing_provenance(self):self.assertEqual(s.assess_design(self.d(e=False),{},()).readiness,s.Readiness.ANALYZABLE)
 def test_maximum(self):self.assertFalse(s.DesignRequirement("ber",maximum=1e-6).evaluate({"ber":1e-5}))
 def test_compare(self):
  a=s.assess_design(self.d(s.StorageTechnology.GLASS_5D),{"density":10});b=s.assess_design(self.d(s.StorageTechnology.HOLOGRAPHIC),{"density":20});self.assertEqual(s.compare_designs((a,b),"density")[0][0],s.StorageTechnology.HOLOGRAPHIC)
 def test_bad_bounds(self):
  with self.assertRaises(ValueError):s.DesignRequirement("x",10,1)
 def test_registry(self):self.assertEqual(s.StorageRegistry().get("STO-DESIGN-READINESS").evidence_class,"ESTABLISHED_PHYSICS")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-STO-09")
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
