from __future__ import annotations
from dataclasses import dataclass
import math

HBAR=1.054571817e-34
KB=1.380649e-23
C=299792458.0
ZETA_3_2=2.612375348685488

def thermal_de_broglie_wavelength_m(temperature_k,particle_mass_kg):
    if temperature_k<=0 or particle_mass_kg<=0: raise ValueError("positive temperature and mass required")
    return math.sqrt(2*math.pi*HBAR**2/(particle_mass_kg*KB*temperature_k))

def ideal_gas_bec_critical_temperature_k(number_density_m3,particle_mass_kg):
    if number_density_m3<=0 or particle_mass_kg<=0: raise ValueError("positive density and mass required")
    return (2*math.pi*HBAR**2/(particle_mass_kg*KB))*(number_density_m3/ZETA_3_2)**(2/3)

def ideal_condensate_fraction(temperature_k,critical_temperature_k):
    if temperature_k<0 or critical_temperature_k<=0: raise ValueError("invalid temperatures")
    if temperature_k>=critical_temperature_k:return 0.0
    return 1-(temperature_k/critical_temperature_k)**1.5

def s_wave_interaction_strength_j_m3(scattering_length_m,particle_mass_kg):
    if particle_mass_kg<=0: raise ValueError("positive mass required")
    return 4*math.pi*HBAR**2*scattering_length_m/particle_mass_kg

def mean_field_chemical_potential_j(number_density_m3,scattering_length_m,particle_mass_kg):
    if number_density_m3<0: raise ValueError("nonnegative density required")
    return s_wave_interaction_strength_j_m3(scattering_length_m,particle_mass_kg)*number_density_m3

def healing_length_m(number_density_m3,scattering_length_m):
    if number_density_m3<=0 or scattering_length_m<=0: raise ValueError("positive density and repulsive scattering length required")
    return 1/math.sqrt(8*math.pi*number_density_m3*scattering_length_m)

def dark_state_polariton_mixing_angle_rad(collective_coupling_rad_s,control_rabi_rad_s):
    if collective_coupling_rad_s<0 or control_rabi_rad_s<0 or (collective_coupling_rad_s==0 and control_rabi_rad_s==0):
        raise ValueError("invalid couplings")
    return math.atan2(collective_coupling_rad_s,control_rabi_rad_s)

def slow_light_group_velocity_m_s(collective_coupling_rad_s,control_rabi_rad_s):
    theta=dark_state_polariton_mixing_angle_rad(collective_coupling_rad_s,control_rabi_rad_s)
    return C*math.cos(theta)**2

def polariton_photonic_fraction(collective_coupling_rad_s,control_rabi_rad_s):
    theta=dark_state_polariton_mixing_angle_rad(collective_coupling_rad_s,control_rabi_rad_s)
    return math.cos(theta)**2

def polariton_atomic_fraction(collective_coupling_rad_s,control_rabi_rad_s):
    return 1-polariton_photonic_fraction(collective_coupling_rad_s,control_rabi_rad_s)

def matter_wave_coherence_survival(storage_time_s,coherence_time_s):
    if storage_time_s<0 or coherence_time_s<=0: raise ValueError("invalid times")
    return math.exp(-storage_time_s/coherence_time_s)

@dataclass(frozen=True)
class BECEnsemble:
    atom_count:int
    volume_m3:float
    particle_mass_kg:float
    temperature_k:float
    scattering_length_m:float
    def __post_init__(self):
        if self.atom_count<1 or self.volume_m3<=0 or self.particle_mass_kg<=0 or self.temperature_k<0:
            raise ValueError("invalid BEC ensemble parameters")
    @property
    def number_density_m3(self):return self.atom_count/self.volume_m3
    @property
    def critical_temperature_k(self):return ideal_gas_bec_critical_temperature_k(self.number_density_m3,self.particle_mass_kg)
    @property
    def condensate_fraction(self):return ideal_condensate_fraction(self.temperature_k,self.critical_temperature_k)

@dataclass(frozen=True)
class BECMemoryEstimate:
    collective_coupling_rad_s:float
    control_rabi_rad_s:float
    matter_wave_t2_s:float
    write_efficiency:float
    read_efficiency:float
    def __post_init__(self):
        if self.collective_coupling_rad_s<0 or self.control_rabi_rad_s<0 or self.matter_wave_t2_s<=0:
            raise ValueError("invalid BEC-memory parameters")
        if not 0<=self.write_efficiency<=1 or not 0<=self.read_efficiency<=1:
            raise ValueError("efficiencies 0..1")
    @property
    def group_velocity_m_s(self):return slow_light_group_velocity_m_s(self.collective_coupling_rad_s,self.control_rabi_rad_s)
    @property
    def atomic_fraction(self):return polariton_atomic_fraction(self.collective_coupling_rad_s,self.control_rabi_rad_s)
    def total_efficiency(self,storage_time_s):
        return self.write_efficiency*self.read_efficiency*matter_wave_coherence_survival(storage_time_s,self.matter_wave_t2_s)
