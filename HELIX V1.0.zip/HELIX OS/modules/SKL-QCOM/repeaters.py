from __future__ import annotations
from dataclasses import dataclass
import math

def swapped_werner_visibility(v_left,v_right,swap_quality=1.0):
    if not all(0<=x<=1 for x in (v_left,v_right,swap_quality)):raise ValueError("visibilities/quality in [0,1]")
    # Werner/isotropic approximation under independent link errors.
    return v_left*v_right*swap_quality

def swapped_bell_fidelity(v_left,v_right,swap_quality=1.0):
    v=swapped_werner_visibility(v_left,v_right,swap_quality)
    return (1+3*v)/4

def swap_success_probability(p_left,p_right,bsm_success_probability):
    if not all(0<=x<=1 for x in (p_left,p_right,bsm_success_probability)):raise ValueError("probabilities in [0,1]")
    return p_left*p_right*bsm_success_probability

def elementary_link_mean_attempts(success_probability):
    if not 0<success_probability<=1:raise ValueError("success_probability in (0,1]")
    return 1/success_probability

def elementary_link_mean_time_s(attempt_period_s,success_probability):
    if attempt_period_s<=0:raise ValueError("attempt period positive")
    return attempt_period_s*elementary_link_mean_attempts(success_probability)

def two_link_parallel_mean_time_s(attempt_period_s,success_probability):
    if attempt_period_s<=0 or not 0<success_probability<=1:raise ValueError("invalid inputs")
    # Exact E[max(T1,T2)] for two independent geometric waiting times.
    p=success_probability
    return attempt_period_s*((3-2*p)/(p*(2-p)))

def memory_survival_factor(wait_time_s,coherence_time_s):
    if wait_time_s<0 or coherence_time_s<=0:raise ValueError("invalid times")
    return math.exp(-wait_time_s/coherence_time_s)

def purification_success_probability(fidelity):
    if not 0<=fidelity<=1:raise ValueError("fidelity in [0,1]")
    # BBPSSW recurrence for Werner pairs: success normalization.
    return fidelity**2 + 2*fidelity*(1-fidelity)/3 + 5*(1-fidelity)**2/9

def purified_werner_fidelity(fidelity):
    if not 0<=fidelity<=1:raise ValueError("fidelity in [0,1]")
    n=purification_success_probability(fidelity)
    if n==0:return 0.0
    return (fidelity**2 + ((1-fidelity)/3)**2)/n

def purification_pair_consumption_per_success(fidelity):
    p=purification_success_probability(fidelity)
    return math.inf if p==0 else 2/p

def nested_swap_success_probability(elementary_link_probability,swap_probability,levels):
    if not 0<=elementary_link_probability<=1 or not 0<=swap_probability<=1 or levels<0 or int(levels)!=levels:
        raise ValueError("invalid nested repeater inputs")
    # Static all-links-in-one-attempt probability, useful as a baseline rather than an optimized asynchronous rate.
    links=2**int(levels); swaps=links-1
    return elementary_link_probability**links*swap_probability**swaps

@dataclass(frozen=True)
class TwoLinkRepeater:
    attempt_period_s:float
    elementary_success_probability:float
    elementary_visibility:float
    bell_measurement_success_probability:float
    swap_quality:float=1.0
    memory_coherence_time_s:float=1.0
    def __post_init__(self):
        if self.attempt_period_s<=0 or self.memory_coherence_time_s<=0:raise ValueError("times positive")
        if not all(0<=x<=1 for x in (self.elementary_success_probability,self.elementary_visibility,self.bell_measurement_success_probability,self.swap_quality)):
            raise ValueError("probabilities in [0,1]")
    @property
    def mean_parallel_link_ready_time_s(self):
        return two_link_parallel_mean_time_s(self.attempt_period_s,self.elementary_success_probability)
    @property
    def approximate_memory_factor(self):
        return memory_survival_factor(self.mean_parallel_link_ready_time_s,self.memory_coherence_time_s)
    @property
    def output_visibility(self):
        return swapped_werner_visibility(self.elementary_visibility,self.elementary_visibility,self.swap_quality)*self.approximate_memory_factor
    @property
    def output_fidelity(self):return (1+3*self.output_visibility)/4
    @property
    def approximate_output_rate_per_s(self):
        # First-order rate: one pair of links ready in mean time, then probabilistic BSM.
        return self.bell_measurement_success_probability/self.mean_parallel_link_ready_time_s
