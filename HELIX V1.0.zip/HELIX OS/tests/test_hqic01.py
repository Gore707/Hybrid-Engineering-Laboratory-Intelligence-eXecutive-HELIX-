import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HQIC"
sp=importlib.util.spec_from_file_location("skl_hqic",M/"__init__.py",submodule_search_locations=[str(M)])
h=importlib.util.module_from_spec(sp);sys.modules["skl_hqic"]=h;sp.loader.exec_module(h)
class T(unittest.TestCase):
 def test_classical_capacity(self):self.assertEqual(h.Capacity(8,h.InformationDomain.CLASSICAL,"bit").value,8)
 def test_quantum_capacity(self):self.assertEqual(h.Capacity(2,h.InformationDomain.QUANTUM,"qubit").unit,"qubit")
 def test_bad_classical_unit(self):
  with self.assertRaises(ValueError):h.Capacity(1,h.InformationDomain.CLASSICAL,"qubit")
 def test_same_domain_sum(self):
  x=h.aggregate_capacity_same_domain([h.Capacity(2,h.InformationDomain.CLASSICAL,"bit"),h.Capacity(3,h.InformationDomain.CLASSICAL,"bit")]);self.assertEqual(x.value,5)
 def test_mixed_capacity_rejected(self):
  with self.assertRaises(ValueError):h.aggregate_capacity_same_domain([h.Capacity(2,h.InformationDomain.CLASSICAL,"bit"),h.Capacity(1,h.InformationDomain.QUANTUM,"qubit")])
 def test_classical_layer_guard(self):
  with self.assertRaises(ValueError):h.StorageLayer("x",h.LayerKind.CLASSICAL_ARCHIVE,h.InformationDomain.QUANTUM,h.SourceState.SIMULATION)
 def test_quantum_layer_guard(self):
  with self.assertRaises(ValueError):h.StorageLayer("x",h.LayerKind.QUANTUM_ACTIVE,h.InformationDomain.CLASSICAL,h.SourceState.SIMULATION)
 def arch(self):
  a=h.HQICArchitecture("HQIC-GEN-I")
  for x in [h.StorageLayer("archive",h.LayerKind.CLASSICAL_ARCHIVE,h.InformationDomain.CLASSICAL,h.SourceState.SIMULATION),
            h.StorageLayer("qmem",h.LayerKind.QUANTUM_ACTIVE,h.InformationDomain.QUANTUM,h.SourceState.SIMULATION),
            h.StorageLayer("xducer",h.LayerKind.TRANSDUCER,None,h.SourceState.SIMULATION),
            h.StorageLayer("control",h.LayerKind.CONTROL,h.InformationDomain.CLASSICAL,h.SourceState.SIMULATION),
            h.StorageLayer("meta",h.LayerKind.METADATA,h.InformationDomain.CLASSICAL,h.SourceState.SIMULATION)]:a.add_layer(x)
  return a
 def test_minimum_architecture(self):self.assertEqual(self.arch().validate_minimum_hybrid_architecture(),(True,()))
 def test_missing_layer(self):
  a=h.HQICArchitecture("x");a.add_layer(h.StorageLayer("a",h.LayerKind.CLASSICAL_ARCHIVE,h.InformationDomain.CLASSICAL,h.SourceState.SIMULATION));self.assertFalse(a.validate_minimum_hybrid_architecture()[0])
 def test_connect(self):
  a=self.arch();a.connect(h.InterfaceEdge("control","xducer","COMMAND"));self.assertEqual(len(a.edges),1)
 def test_unknown_endpoint(self):
  a=self.arch()
  with self.assertRaises(ValueError):a.connect(h.InterfaceEdge("control","missing","COMMAND"))
 def test_duplicate_layer(self):
  a=self.arch()
  with self.assertRaises(ValueError):a.add_layer(h.StorageLayer("archive",h.LayerKind.METADATA,h.InformationDomain.CLASSICAL,h.SourceState.SIMULATION))
 def test_control_path(self):self.assertEqual(h.windows_control_path()[0],"Windows/HELIX")
 def test_no_direct_quantum_claim(self):self.assertTrue(h.no_direct_quantum_pc_claim())
 def test_registry(self):self.assertTrue({"HQIC-CAP-SAME","HQIC-LAYER-VALID","HQIC-PC-CONTROL"}<={x.model_id for x in h.HQICRegistry().all()})
 def test_manifest(self):
  m=json.loads((M/"module.json").read_text());self.assertEqual(m["patch_id"],"SKL-HQIC-01");self.assertEqual(m["status"],"HQIC-01 of 8")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO","SKL-QMEM"])
 def test_qmem_complete(self):self.assertEqual(json.loads((R/"QMEM_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_schema(self):self.assertTrue((R/"core/resources/schemas/hqic-architecture.schema.json").exists())
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
