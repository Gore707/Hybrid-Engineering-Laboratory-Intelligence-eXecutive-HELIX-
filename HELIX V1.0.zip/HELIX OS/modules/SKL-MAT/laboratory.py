from __future__ import annotations
from pathlib import Path
from dataclasses import asdict
import json,os,hashlib,time
from .service import MaterialsService
from .research import MaterialResearchStore
from .validation import MaterialValidator
class MaterialsLaboratory:
 def __init__(self,data_root:Path):
  self.data_root=data_root;data_root.mkdir(parents=True,exist_ok=True)
  self.materials=MaterialsService(data_root/"materials.sqlite")
  self.research=MaterialResearchStore(data_root/"research.json")
  self.validator=MaterialValidator()
  self.audit=data_root/"materials.audit.jsonl"
 def register_material(self,material,composition=None):
  report=self.validator.validate_material(material)
  if not report.passed:raise ValueError("material failed integrity validation")
  self.materials.add_material(material)
  if composition is not None:
   if composition.material_id!=material.material_id:raise ValueError("composition/material ID mismatch")
   self.materials.set_composition(composition)
  self._audit("REGISTER_MATERIAL",{"material_id":material.material_id,"warnings":[i.code for i in report.issues]})
  return report
 def register_dataset(self,dataset):
  report=self.validator.validate_dataset(dataset)
  if not report.passed:raise ValueError("dataset failed integrity validation")
  self.research.add_dataset(dataset);self._audit("REGISTER_DATASET",{"dataset_id":dataset.dataset_id})
  return report
 def validate_dataset_against(self,candidate_id,reference_id):
  c=self.research.dataset(candidate_id);r=self.research.dataset(reference_id)
  result=self.validator.compare_reference(c,r);self._audit("COMPARE_DATASETS",{"candidate":candidate_id,"reference":reference_id,"rmse":result["rmse"]})
  return result
 def export_material_bundle(self,material_id,out_path:Path):
  m=self.materials.material(material_id);c=self.materials.composition(material_id)
  datasets=self.research.datasets_for(material_id)
  payload={"format":"HELIX-MATERIAL-BUNDLE-1.0","material":self._material_dict(m),
           "composition":asdict(c) if c else None,"datasets":[asdict(d) for d in datasets]}
  raw=json.dumps(payload,indent=2,sort_keys=True).encode()
  digest=hashlib.sha256(raw).hexdigest();wrapper={"sha256":digest,"payload":payload}
  tmp=out_path.with_suffix(out_path.suffix+".tmp");tmp.write_text(json.dumps(wrapper,indent=2,sort_keys=True),encoding="utf-8");os.replace(tmp,out_path)
  self._audit("EXPORT_BUNDLE",{"material_id":material_id,"path":str(out_path),"sha256":digest});return digest
 def verify_bundle(self,path:Path):
  w=json.loads(path.read_text());raw=json.dumps(w["payload"],indent=2,sort_keys=True).encode()
  return hashlib.sha256(raw).hexdigest()==w["sha256"]
 def summary(self,material_id):
  m=self.materials.material(material_id);c=self.materials.composition(material_id);ds=self.research.datasets_for(material_id)
  return {"material_id":m.material_id,"name":m.name,"formula":m.formula,"phase":m.phase.value,
          "property_count":len(m.properties),"has_composition":c is not None,"dataset_count":len(ds),
          "source_ids":m.source_ids}
 def _material_dict(self,m):
  d=asdict(m);d["phase"]=m.phase.value;return d
 def _audit(self,event,data):
  rec={"timestamp":time.time(),"event":event,"data":data}
  with self.audit.open("a",encoding="utf-8") as f:f.write(json.dumps(rec,sort_keys=True)+"\n")
