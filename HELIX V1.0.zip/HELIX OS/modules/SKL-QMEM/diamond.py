from __future__ import annotations
from dataclasses import dataclass
import math

H=6.62607015e-34
MU_B=9.2740100783e-24

def electron_zeeman_shift_hz(g_factor,magnetic_field_t,delta_m_s=1.0):
    if g_factor<0: raise ValueError("nonnegative g factor required")
    return g_factor*MU_B*magnetic_field_t*delta_m_s/H

def lorentzian_t2_from_linewidth_s(linewidth_fwhm_hz):
    if linewidth_fwhm_hz<=0: raise ValueError("positive linewidth required")
    return 1/(math.pi*linewidth_fwhm_hz)

def exponential_spin_survival(storage_time_s,t2_s):
    if storage_time_s<0 or t2_s<=0: raise ValueError("invalid coherence times")
    return math.exp(-storage_time_s/t2_s)

def initialization_readout_success(initialization_fidelity,readout_fidelity):
    if not 0<=initialization_fidelity<=1 or not 0<=readout_fidelity<=1:
        raise ValueError("fidelities must be 0..1")
    return initialization_fidelity*readout_fidelity

def photon_collection_probability(debye_waller_factor,collection_efficiency,detector_efficiency=1.0):
    vals=(debye_waller_factor,collection_efficiency,detector_efficiency)
    if any(v<0 or v>1 for v in vals): raise ValueError("probabilities must be 0..1")
    return math.prod(vals)

def cavity_purcell_factor(quality_factor,mode_volume_m3,wavelength_m,refractive_index):
    if quality_factor<0 or mode_volume_m3<=0 or wavelength_m<=0 or refractive_index<=0:
        raise ValueError("invalid cavity parameters")
    return (3/(4*math.pi**2))*(wavelength_m/refractive_index)**3*(quality_factor/mode_volume_m3)

def beta_factor_from_purcell(purcell_factor,background_rate_ratio=1.0):
    if purcell_factor<0 or background_rate_ratio<0: raise ValueError("nonnegative rates required")
    den=purcell_factor+background_rate_ratio
    return purcell_factor/den if den else 0.0

def ensemble_collective_coupling_rad_s(single_center_coupling_rad_s,center_count):
    if single_center_coupling_rad_s<0 or center_count<1: raise ValueError("invalid ensemble inputs")
    return single_center_coupling_rad_s*math.sqrt(center_count)

@dataclass(frozen=True)
class ColorCenter:
    family:str
    optical_wavelength_m:float
    spin_t2_s:float
    zero_phonon_fraction:float
    g_factor:float=2.0
    def __post_init__(self):
        if not self.family.strip() or self.optical_wavelength_m<=0 or self.spin_t2_s<=0 or not 0<=self.zero_phonon_fraction<=1 or self.g_factor<0:
            raise ValueError("invalid color-center parameters")
    def zeeman_shift_hz(self,magnetic_field_t,delta_m_s=1.0):
        return electron_zeeman_shift_hz(self.g_factor,magnetic_field_t,delta_m_s)
    def spin_survival(self,storage_time_s):
        return exponential_spin_survival(storage_time_s,self.spin_t2_s)

@dataclass(frozen=True)
class DiamondMemoryEstimate:
    initialization_fidelity:float
    mapping_efficiency:float
    retrieval_efficiency:float
    readout_fidelity:float
    spin_t2_s:float
    def __post_init__(self):
        vals=(self.initialization_fidelity,self.mapping_efficiency,self.retrieval_efficiency,self.readout_fidelity)
        if any(v<0 or v>1 for v in vals) or self.spin_t2_s<=0:
            raise ValueError("invalid diamond-memory parameters")
    def total_success_probability(self,storage_time_s):
        return (self.initialization_fidelity*self.mapping_efficiency*
                exponential_spin_survival(storage_time_s,self.spin_t2_s)*
                self.retrieval_efficiency*self.readout_fidelity)
