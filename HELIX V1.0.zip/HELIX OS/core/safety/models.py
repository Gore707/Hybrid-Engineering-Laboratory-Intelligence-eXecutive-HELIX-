from dataclasses import dataclass
from enum import IntEnum
class AlertLevel(IntEnum):
 INFO=10;NOTICE=20;WARNING=30;ERROR=40;CRITICAL=50;EMERGENCY=60
@dataclass(frozen=True)
class SafetyAlert:
 alert_id:str;level:AlertLevel;code:str;message:str;timestamp_unix:float;source:str
 requires_hold:bool=False
@dataclass(frozen=True)
class CheckResult:
 check_id:str;passed:bool;level:AlertLevel;message:str
@dataclass(frozen=True)
class PreflightResult:
 passed:bool;checks:tuple[CheckResult,...];highest_level:AlertLevel
