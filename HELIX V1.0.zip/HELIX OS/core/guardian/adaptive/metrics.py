from dataclasses import dataclass,asdict
@dataclass(frozen=True)
class IntelligenceMetrics:
 knowledge_items:int;memories:int;observations:int;grounded_queries:int=0;ungrounded_queries:int=0
 tool_successes:int=0;tool_failures:int=0
 def grounding_rate(self):
  n=self.grounded_queries+self.ungrounded_queries
  return self.grounded_queries/n if n else None
 def tool_success_rate(self):
  n=self.tool_successes+self.tool_failures
  return self.tool_successes/n if n else None
 def dict(self):
  d=asdict(self);d["grounding_rate"]=self.grounding_rate();d["tool_success_rate"]=self.tool_success_rate();return d
