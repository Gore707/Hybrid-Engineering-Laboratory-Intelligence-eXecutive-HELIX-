import unittest,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];MAIN=(R/"core/ui/main_window.py").read_text();THEME=(R/"core/ui/theme.py").read_text()
class T(unittest.TestCase):
 def test_labs_wire(self):self.assertIn("self._wire_labs_menu()",MAIN)
 def test_manifest_discovery(self):self.assertIn('manifest=folder/"module.json"',MAIN)
 def test_launcher(self):self.assertIn("def _show_lab_launcher",MAIN);self.assertIn("HELIX LABORATORIES",MAIN)
 def test_dock_open(self):self.assertIn("def _open_lab",MAIN);self.assertIn('self.workspace.create_dock(dock_id,lab["name"]',MAIN)
 def test_no_duplicate_dock(self):self.assertIn("if dock_id in self.workspace.docks",MAIN)
 def test_no_fake_controls(self):self.assertIn("does not fabricate controls",MAIN)
 def test_actual_modules(self):
  ids={p.parent.name for p in (R/"modules").glob("*/module.json")}
  for x in ("SKL-MAT","SKL-PHO","SKL-STO","SKL-QMEM","SKL-HQIC","SKL-RF","SKL-OPT","SKL-QCOM","SKL-ISN","SKL-ECC","SKL-BND","SKL-HWI"):self.assertIn(x,ids)
 def test_theme(self):self.assertIn("QDialog#LabLauncher",THEME);self.assertIn("QFrame#LabCard",THEME)
 def test_ui_markers(self):self.assertTrue((R/"UI_01_COMPLETE.json").exists());self.assertTrue((R/"UI_02_COMPLETE.json").exists());self.assertEqual(json.loads((R/"UI_03_COMPLETE.json").read_text())["sequence"],"3/6")
 def test_backend_preserved(self):self.assertEqual(json.loads((R/"HELIX_136_COMPLETE.json").read_text())["patches_completed"],136)
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
