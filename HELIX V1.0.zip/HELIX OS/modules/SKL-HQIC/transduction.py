from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

H=6.62607015e-34
C=299792458.0

class SignalDomain(str,Enum):
    OPTICAL="OPTICAL"
    MICROWAVE="MICROWAVE"
    ELECTRICAL="ELECTRICAL"
    QUANTUM_OPTICAL="QUANTUM_OPTICAL"
    QUANTUM_MICROWAVE="QUANTUM_MICROWAVE"

def photon_energy_j(frequency_hz):
    if frequency_hz<=0: raise ValueError("positive frequency required")
    return H*frequency_hz

def wavelength_to_frequency_hz(wavelength_m):
    if wavelength_m<=0: raise ValueError("positive wavelength required")
    return C/wavelength_m

def frequency_to_wavelength_m(frequency_hz):
    if frequency_hz<=0: raise ValueError("positive frequency required")
    return C/frequency_hz

def power_efficiency(input_power_w,output_power_w):
    if input_power_w<=0 or output_power_w<0 or output_power_w>input_power_w:
        raise ValueError("require 0 <= output <= input and positive input")
    return output_power_w/input_power_w

def insertion_loss_db(efficiency):
    if not 0<efficiency<=1: raise ValueError("efficiency must be in (0,1]")
    return -10*math.log10(efficiency)

def efficiency_from_insertion_loss_db(loss_db):
    if loss_db<0: raise ValueError("loss must be nonnegative")
    return 10**(-loss_db/10)

def cascaded_efficiency(*efficiencies):
    if not efficiencies: raise ValueError("at least one stage required")
    if any(not 0<=x<=1 for x in efficiencies): raise ValueError("efficiencies must be 0..1")
    return math.prod(efficiencies)

def signal_to_noise_ratio(signal_power,noise_power):
    if signal_power<0 or noise_power<=0: raise ValueError("invalid signal/noise powers")
    return signal_power/noise_power

def added_noise_equivalent_input(output_noise,input_to_output_gain):
    if output_noise<0 or input_to_output_gain<=0: raise ValueError("invalid noise/gain")
    return output_noise/input_to_output_gain

def fidelity_after_depolarizing_noise(input_fidelity,depolarizing_probability,dimension=2):
    if not 0<=input_fidelity<=1 or not 0<=depolarizing_probability<=1 or dimension<2:
        raise ValueError("invalid fidelity/noise/dimension")
    return (1-depolarizing_probability)*input_fidelity+depolarizing_probability/dimension

@dataclass(frozen=True)
class TransducerStage:
    stage_id:str
    input_domain:SignalDomain
    output_domain:SignalDomain
    efficiency:float
    added_noise_probability:float=0.0
    source_state:str="SIMULATION"
    def __post_init__(self):
        if not self.stage_id.strip() or not 0<=self.efficiency<=1 or not 0<=self.added_noise_probability<=1:
            raise ValueError("invalid transducer stage")
    @property
    def insertion_loss_db(self):
        return math.inf if self.efficiency==0 else insertion_loss_db(self.efficiency)

@dataclass(frozen=True)
class TransductionChain:
    stages:tuple[TransducerStage,...]
    def __post_init__(self):
        if not self.stages: raise ValueError("nonempty chain required")
        for a,b in zip(self.stages,self.stages[1:]):
            if a.output_domain!=b.input_domain: raise ValueError("transducer domain mismatch")
    @property
    def efficiency(self): return cascaded_efficiency(*(s.efficiency for s in self.stages))
    @property
    def total_insertion_loss_db(self):
        return math.inf if self.efficiency==0 else insertion_loss_db(self.efficiency)
    @property
    def survival_against_independent_added_noise(self):
        return math.prod(1-s.added_noise_probability for s in self.stages)
    def output_fidelity(self,input_fidelity,dimension=2):
        f=input_fidelity
        for s in self.stages:
            f=fidelity_after_depolarizing_noise(f,s.added_noise_probability,dimension)
        return f
