from __future__ import annotations
from dataclasses import dataclass
from core.commands import ConfirmationLevel

@dataclass(frozen=True)
class PermissionDecision:
    allowed:bool
    requires_operator_confirmation:bool
    reason:str

class GuardianPermissionPolicy:
    """Guardian is advisory. Deterministic HELIX confirmation/safety remains authoritative."""
    def __init__(self,allow_unconfirmed_readonly=True):
        self.allow_unconfirmed_readonly=allow_unconfirmed_readonly

    def evaluate(self,action,proposal_valid=True):
        if not proposal_valid:return PermissionDecision(False,False,"Proposal validation failed.")
        level=action.confirmation
        if level in (ConfirmationLevel.HARDWARE,ConfirmationLevel.DESTRUCTIVE):
            return PermissionDecision(True,True,f"{level.value} action requires explicit operator confirmation.")
        if level==ConfirmationLevel.CONFIRM:
            return PermissionDecision(True,True,"Action requires explicit operator confirmation.")
        return PermissionDecision(True,False,"Action is eligible for deterministic HELIX execution.")

    @staticmethod
    def guardian_can_override_safety():return False
