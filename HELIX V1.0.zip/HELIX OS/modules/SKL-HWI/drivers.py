from __future__ import annotations
from dataclasses import dataclass
import time
from .foundation import HardwareIdentity,CapabilityDescriptor,Measurement,make_provenance,SourceState,CalibrationState
from .transports import SCPIClient,TransportProtocolError

@dataclass(frozen=True)
class IdentityMatcher:
    vendor_contains:str=""
    model_contains:str=""
    def matches(self,identity):
        v=self.vendor_contains.lower() in identity.vendor.lower() if self.vendor_contains else True
        m=self.model_contains.lower() in identity.model.lower() if self.model_contains else True
        return v and m

@dataclass(frozen=True)
class CommandMapping:
    capability_id:str
    read_query:str|None=None
    write_command_template:str|None=None
    response_unit:str=""
    def __post_init__(self):
        if not self.capability_id:raise ValueError("capability_id required")
        if self.read_query is not None and "?" not in self.read_query:raise ValueError("read_query must be a SCPI query")
        if self.write_command_template is not None and "{value}" not in self.write_command_template:raise ValueError("write template requires {value}")

@dataclass(frozen=True)
class CommandProvenance:
    device_id:str
    capability_id:str
    operation:str
    command_text:str
    timestamp_unix_s:float
    experiment_id:str|None=None

class InstrumentDriver:
    driver_id="ABSTRACT"
    matcher=IdentityMatcher()
    def supports(self,identity):return self.matcher.matches(identity)
    def read(self,*a,**k):raise NotImplementedError
    def write(self,*a,**k):raise NotImplementedError

class SCPIDriver(InstrumentDriver):
    def __init__(self,driver_id,matcher,capabilities,mappings,client,identity,calibration_state=CalibrationState.UNKNOWN):
        if not driver_id:raise ValueError("driver_id required")
        self.driver_id=driver_id;self.matcher=matcher;self.client=client;self.identity=identity;self.calibration_state=calibration_state
        if not self.supports(identity):raise ValueError("driver identity mismatch")
        self.capabilities={c.capability_id:c for c in capabilities}
        self.mappings={x.capability_id:x for x in mappings}
        if set(self.mappings)-set(self.capabilities):raise ValueError("mapping without capability")
        self.command_history=[]
    def _capmap(self,cid):
        if cid not in self.capabilities:raise KeyError(cid)
        if cid not in self.mappings:raise TransportProtocolError("no command mapping")
        return self.capabilities[cid],self.mappings[cid]
    def read(self,capability_id,experiment_id=None,timestamp_unix_s=None):
        cap,mp=self._capmap(capability_id)
        if mp.read_query is None:raise TransportProtocolError("capability is not readable")
        raw=self.client.query(mp.read_query)
        try:value=float(raw)
        except ValueError as e:raise TransportProtocolError(f"non-numeric response: {raw}") from e
        if cap.minimum is not None and value<cap.minimum:raise TransportProtocolError("measurement below declared capability range")
        if cap.maximum is not None and value>cap.maximum:raise TransportProtocolError("measurement above declared capability range")
        ts=time.time() if timestamp_unix_s is None else timestamp_unix_s
        self.command_history.append(CommandProvenance(self.identity.device_id,capability_id,"READ",mp.read_query,ts,experiment_id))
        prov=make_provenance(SourceState.HARDWARE,capability_id,self.identity.device_id,self.calibration_state,experiment_id,timestamp_unix_s=ts)
        return Measurement(value,mp.response_unit or cap.unit,prov)
    def write(self,capability_id,value,unit=None,experiment_id=None,timestamp_unix_s=None):
        cap,mp=self._capmap(capability_id)
        if not cap.writable:raise PermissionError("capability is read-only")
        if mp.write_command_template is None:raise TransportProtocolError("no write command mapping")
        if unit is not None and unit!=cap.unit:raise ValueError(f"unit mismatch: expected {cap.unit}")
        value=float(value)
        if cap.minimum is not None and value<cap.minimum:raise ValueError("value below capability range")
        if cap.maximum is not None and value>cap.maximum:raise ValueError("value above capability range")
        cmd=mp.write_command_template.format(value=format(value,".12g"))
        self.client.command(cmd)
        ts=time.time() if timestamp_unix_s is None else timestamp_unix_s
        rec=CommandProvenance(self.identity.device_id,capability_id,"WRITE",cmd,ts,experiment_id)
        self.command_history.append(rec);return rec

class DriverRegistry:
    def __init__(self):self._drivers={}
    def register(self,driver_id,matcher,factory):
        if not driver_id or driver_id in self._drivers:raise ValueError("invalid or duplicate driver_id")
        self._drivers[driver_id]=(matcher,factory)
    def candidates(self,identity):
        return tuple((did,factory) for did,(matcher,factory) in self._drivers.items() if matcher.matches(identity))
    def select(self,identity):
        matches=self.candidates(identity)
        if not matches:raise LookupError("no matching driver")
        if len(matches)>1:raise LookupError("ambiguous driver match")
        return matches[0]
