from pathlib import Path
import json,sys
from core.integration import CoreHealthCheck
ROOT=Path(__file__).resolve().parent
r=CoreHealthCheck(ROOT)
report=r.run()
print(json.dumps({"passed":report.passed,"checks":list(report.checks)},indent=2))
raise SystemExit(0 if report.passed else 2)
