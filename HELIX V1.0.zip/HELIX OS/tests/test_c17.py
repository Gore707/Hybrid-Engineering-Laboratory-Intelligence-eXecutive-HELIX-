import tempfile,unittest
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.guardian.adaptive import *
from core.compute.models import ComputeDevice
ROOT=Path(__file__).resolve().parents[1]
class C17Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C17")
 def test_memory(self):
  with tempfile.TemporaryDirectory() as td:
   m=AdaptiveMemory(Path(td)/"a.db");m.observe("numeric","temp",10);m.remember("M1","pattern","stable",.8,"test")
   self.assertEqual(m.observation_count(),1);self.assertEqual(m.memory_count(),1);m.close()
 def test_pattern_anomaly(self):
  with tempfile.TemporaryDirectory() as td:
   m=AdaptiveMemory(Path(td)/"a.db");p=PatternLearner(m,5,3)
   for v in [10,10.1,9.9,10.05,9.95]:p.evaluate("x",v)
   self.assertTrue(p.evaluate("x",100).anomaly);m.close()
 def test_proposal_approval_required(self):
  with tempfile.TemporaryDirectory() as td:
   p=ProposalManager(Path(td));q=p.create("MODEL","Candidate","Improve solver",["E1"],["regression"],["tests"],"restore previous",.7)
   with self.assertRaises(ValueError):p.mark_deployed(q.proposal_id)
   q=p.decide(q.proposal_id,True);self.assertEqual(q.status,ProposalStatus.APPROVED)
   self.assertEqual(p.mark_deployed(q.proposal_id).status,ProposalStatus.DEPLOYED)
 def test_denied_fingerprint(self):
  with tempfile.TemporaryDirectory() as td:
   p=ProposalManager(Path(td));q=p.create("UI","A","B",[],[],[],"rollback",.5);p.decide(q.proposal_id,False)
   with self.assertRaises(ValueError):p.create("UI","A","B",[],[],[],"rollback",.5)
 def test_runtime_selection(self):
  d=ComputeDevice("AMD-0","GPU","AMD","GPU",16*1024**3,"rocm")
  r=RuntimeSelector().recommend({},[d]);self.assertEqual(r.parameter_range_billions,(7,14))
 def test_runtime_fallback(self):
  r=RuntimeSelector().recommend({},[]);self.assertEqual(r.class_name,"extractive-local");self.assertFalse(r.requires_installation)
 def test_metrics_not_iq(self):
  m=IntelligenceMetrics(100,5,20,8,2,9,1);d=m.dict()
  self.assertAlmostEqual(d["grounding_rate"],.8);self.assertNotIn("iq",d)
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
