from __future__ import annotations
from dataclasses import dataclass
import re
@dataclass(frozen=True)
class RuntimeResult:
 text:str;used_item_ids:tuple[str,...];confidence:float
class ExtractiveLocalRuntime:
 name="extractive-local"
 def answer(self,question,ranked_items):
  if not ranked_items:
   return RuntimeResult("I do not have grounded HELIX knowledge for that question yet.",(),0.0)
  q=set(re.findall(r"[A-Za-z0-9_]+",question.lower()))
  candidates=[]
  for score,item in ranked_items:
   sentences=re.split(r"(?<=[.!?])\s+",item.text.strip())
   best=max(sentences,key=lambda s:len(q & set(re.findall(r"[A-Za-z0-9_]+",s.lower()))),default=item.text)
   candidates.append((score,item,best))
  selected=candidates[:3]
  body=" ".join(x[2] for x in selected if x[2])
  conf=min(.95,max(.05,sum(x[0] for x in selected)/len(selected)))
  return RuntimeResult(body,tuple(x[1].item_id for x in selected),conf)
