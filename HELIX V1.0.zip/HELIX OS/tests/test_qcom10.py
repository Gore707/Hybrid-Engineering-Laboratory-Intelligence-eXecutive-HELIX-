import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QCOM"
sp=importlib.util.spec_from_file_location("skl_qcom",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qcom"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_zero_r(self):self.assertEqual(q.squeezed_quadrature_variance(0),1)
 def test_squeeze(self):self.assertLess(q.squeezed_quadrature_variance(1),1)
 def test_antisqueeze(self):self.assertGreater(q.antisqueezed_quadrature_variance(1),1)
 def test_db_roundtrip(self):
  for db in (0,3,10):self.assertAlmostEqual(q.squeezing_db_from_variance(q.variance_from_squeezing_db(db)),db)
 def test_loss_none(self):self.assertEqual(q.loss_degraded_variance(.5,1),.5)
 def test_loss_total(self):self.assertEqual(q.loss_degraded_variance(.5,0),1)
 def test_loss_hurts(self):self.assertLess(q.loss_degraded_squeezing_db(10,.5),10)
 def test_snr(self):self.assertAlmostEqual(q.ideal_snr_improvement_factor(.25),2)
 def test_snr_db(self):self.assertAlmostEqual(q.ideal_snr_improvement_db(.1),10)
 def test_phase_zero(self):self.assertAlmostEqual(q.phase_mismatch_variance(1,0),math.exp(-2))
 def test_phase_pi2(self):self.assertAlmostEqual(q.phase_mismatch_variance(1,math.pi/2),math.exp(2))
 def test_detected_loss(self):self.assertGreater(q.detected_variance(1,.5,.5),math.exp(-2))
 def test_receiver(self):
  x=q.SqueezedReceiver(1,.8,.9,.01)
  self.assertTrue(0<x.detected_noise_variance<1);self.assertGreater(x.detected_squeezing_db,0);self.assertGreater(x.ideal_sensitivity_improvement,1)
 def test_causality(self):self.assertFalse(q.causality_or_capacity_bypass_available())
 def test_no_signalling_preserved(self):self.assertEqual(q.no_signalling_remote_probability("squeezed"),(.5,.5))
 def test_interplanetary_preserved(self):self.assertEqual(q.one_way_light_time_s(q.C_M_S),1)
 def test_free_space_preserved(self):self.assertEqual(q.link_loss_db(.1),10)
 def test_registry(self):self.assertTrue({"QCOM-SQ-V","QCOM-SQ-ANTI","QCOM-SQ-LOSS","QCOM-SQ-PHASE","QCOM-SQ-SNR"}<={x.model_id for x in q.QuantumCommRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QCOM-10")
 def test_pho_dependency(self):self.assertIn("SKL-PHO",json.loads((M/"module.json").read_text())["dependencies"])
 def test_opt_dependency(self):self.assertIn("SKL-OPT",json.loads((M/"module.json").read_text())["dependencies"])
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
