import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-RF"
sp=importlib.util.spec_from_file_location("skl_rf",M/"__init__.py",submodule_search_locations=[str(M)])
r=importlib.util.module_from_spec(sp);sys.modules["skl_rf"]=r;sp.loader.exec_module(r)
class T(unittest.TestCase):
 def test_aperture(self):self.assertAlmostEqual(r.effective_aperture_m2(4*math.pi,r.C),1)
 def test_beam(self):self.assertAlmostEqual(r.dish_half_power_beamwidth_rad(1,r.C),1.02)
 def test_eirp(self):self.assertEqual(r.eirp_w(10,20,.5),100)
 def test_pol_aligned(self):self.assertAlmostEqual(r.polarization_mismatch_factor(0),1)
 def test_pol_orthogonal(self):self.assertAlmostEqual(r.polarization_mismatch_factor(math.pi/2),0,places=12)
 def test_pointing_zero(self):self.assertEqual(r.pointing_loss_gaussian_linear(0,.1),1)
 def test_pointing_hpbw(self):self.assertAlmostEqual(r.pointing_loss_gaussian_linear(.1,.1),1/16)
 def test_phase_broadside(self):self.assertAlmostEqual(r.progressive_phase_shift_rad(.5,r.C,0),0)
 def test_array_peak(self):self.assertAlmostEqual(r.uniform_linear_array_factor(8,.5,r.C,.2,.2),1)
 def test_array_off_peak(self):self.assertLess(r.uniform_linear_array_factor(8,.5,r.C,.5,0),1)
 def test_no_grating_half_lambda(self):self.assertFalse(r.has_visible_grating_lobe(.5,r.C,0))
 def test_grating_lambda(self):self.assertTrue(r.has_visible_grating_lobe(1.0,r.C,0))
 def test_array_gain(self):
  a=r.PhasedArray(16,.5,r.C,2,10,.8);self.assertAlmostEqual(a.coherent_peak_gain_linear,25.6)
 def test_array_power(self):self.assertEqual(r.PhasedArray(16,.5,r.C,2,10,.8).total_rf_power_w,160)
 def test_array_eirp(self):self.assertGreater(r.PhasedArray(16,.5,r.C,2,10,.8).peak_eirp_w,160)
 def test_array_peak_method(self):
  a=r.PhasedArray(8,.5,r.C);self.assertAlmostEqual(a.array_factor(.3,.3),1)
 def test_array_grating_method(self):self.assertFalse(r.PhasedArray(8,.5,r.C).grating_lobe_risk())
 def test_invalid_array(self):
  with self.assertRaises(ValueError):r.PhasedArray(0,.5,r.C)
 def test_foundation_preserved(self):self.assertAlmostEqual(r.wavelength_m(r.C),1)
 def test_friis_preserved(self):self.assertGreater(r.friis_received_power_w(1,1,1,1,r.C),0)
 def test_registry(self):self.assertTrue({"RF-APERTURE","RF-BEAM-HPBW","RF-EIRP","RF-ARRAY-PHASE","RF-ARRAY-FACTOR"}<={x.model_id for x in r.RFRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-RF-02")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-HQIC"])
 def test_hqic_complete(self):self.assertEqual(json.loads((R/"HQIC_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
