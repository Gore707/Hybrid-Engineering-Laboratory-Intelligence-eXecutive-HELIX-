from __future__ import annotations
from .models import *
import time
class SimulatedDevice:
 def __init__(self,descriptor,channels):
  if descriptor.source!=HALSource.SIMULATION:raise ValueError("source mismatch")
  self.descriptor=descriptor;self.channels=dict(channels);self.state=DeviceState.DISCONNECTED
 def connect(self):self.state=DeviceState.CONNECTED
 def disconnect(self):self.state=DeviceState.DISCONNECTED
 def read(self,channel):
  if self.state==DeviceState.DISCONNECTED:raise RuntimeError("device disconnected")
  if channel not in self.channels:raise KeyError(channel)
  value,unit=self.channels[channel]
  return Measurement(self.descriptor.device_id,channel,float(value),unit,time.time(),HALSource.SIMULATION,
   provenance_id="HAL:"+self.descriptor.device_id)
 def write(self,channel,value):self.channels[channel]=(float(value),self.channels[channel][1])
class ImportedDevice:
 def __init__(self,descriptor,records):
  if descriptor.source!=HALSource.IMPORTED:raise ValueError("source mismatch")
  self.descriptor=descriptor;self.records={r.channel:r for r in records};self.state=DeviceState.DISCONNECTED
 def connect(self):self.state=DeviceState.CONNECTED
 def disconnect(self):self.state=DeviceState.DISCONNECTED
 def read(self,channel):
  if self.state==DeviceState.DISCONNECTED:raise RuntimeError("device disconnected")
  return self.records[channel]
