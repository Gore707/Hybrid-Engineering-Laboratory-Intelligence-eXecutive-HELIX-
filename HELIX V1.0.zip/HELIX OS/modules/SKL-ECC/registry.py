from dataclasses import dataclass
@dataclass(frozen=True)
class ExtremeCarrierModel:
    model_id:str;name:str;equation:str;inputs:tuple;outputs:tuple
class ExtremeCarrierRegistry:
    def __init__(self):
        self._models=(
          ExtremeCarrierModel("ECC-EQ-PHOTON","Photon quantum energy","E=h nu=hc/lambda",("frequency_or_wavelength",),("energy",)),
          ExtremeCarrierModel("ECC-FLUX-ISO","Isotropic carrier flux","Phi=Ndot/(4*pi*r^2)",("emission_rate","distance"),("flux",)),
          ExtremeCarrierModel("ECC-FLUX-BEAM","Directed carrier flux","Phi=Ndot/Abeam",("emission_rate","beam_area"),("flux",)),
          ExtremeCarrierModel("ECC-INTERACT","Thin-target interaction probability","P=1-exp(-sigma*Ncol)",("cross_section","column_density"),("interaction_probability",)),
          ExtremeCarrierModel("ECC-DETECT","Expected detected event rate","R=Phi*A*Pint*eta",("flux","area","interaction_probability","efficiency"),("event_rate",)),
          ExtremeCarrierModel("ECC-SNR","Poisson event SNR","SNR=S/sqrt(S+B)",("signal_events","background_events"),("snr",)),
          ExtremeCarrierModel("ECC-RATE","Ideal event-limited bit rate","Rb=Rdet/Nevent_per_bit",("event_rate","events_per_bit"),("bit_rate",)),
          ExtremeCarrierModel("ECC-EBIT","Transmitter energy per bit","Ebit=Eq*Nqbit/eta",("carrier_energy","quanta_per_bit","efficiency"),("energy_per_bit",)),
          ExtremeCarrierModel("ECC-LATENCY","Causal propagation time","t=d/v; v<=c",("distance","speed"),("time",)),
          ExtremeCarrierModel("ECC-NU-XSEC","Approximate neutrino CC cross section","sigma≈k E_GeV",("energy_gev","particle_type"),("cross_section",)),
          ExtremeCarrierModel("ECC-NU-OSC","Two-flavor survival probability","P=1-sin^2(2theta)sin^2(1.267*dm2*L/E)",("theta","delta_m2","baseline","energy"),("survival_probability",)),
          ExtremeCarrierModel("ECC-NU-BEAM","Neutrino beam footprint","A=pi(r0+L*theta)^2",("baseline","divergence","source_radius"),("beam_area",)),
          ExtremeCarrierModel("ECC-NU-EVENT","Neutrino detector event rate","R=Phi*sigma*Ntarget*eta",("flux","cross_section","detector_mass","efficiency"),("event_rate",)),
          ExtremeCarrierModel("ECC-NU-POWER","Ideal carrier wall-power lower-bound model","Pwall=Ndot*Enu/eta_source",("production_rate","energy","source_efficiency"),("wall_power",)),
          ExtremeCarrierModel("ECC-HEP-E","High-energy photon energy/wavelength","E=hc/lambda",("wavelength_or_energy",),("energy_or_wavelength",)),
          ExtremeCarrierModel("ECC-HEP-DIFF","Ideal diffraction half-angle","theta=1.22*lambda/D",("wavelength","aperture"),("divergence",)),
          ExtremeCarrierModel("ECC-HEP-ATTEN","Beer-Lambert transmission","T=exp(-mu*x)",("attenuation_coefficient","path_length"),("transmission",)),
          ExtremeCarrierModel("ECC-HEP-RX","Detected high-energy photon rate","R=Ndot*min(1,Arx/Abeam)*T*eta",("source_rate","beam_area","receiver_area","transmission","efficiency"),("detected_rate",)),
          ExtremeCarrierModel("ECC-HEP-SNR","Photon-counting SNR","SNR=S/sqrt(S+B)",("signal_rate","background_rate","integration_time"),("snr",)),
          ExtremeCarrierModel("ECC-HEP-DOSE","Absorbed dose","D=Eabs/m",("absorbed_energy","mass"),("dose_gy",)),
          ExtremeCarrierModel("ECC-PB-GAMMA","Particle Lorentz factor","gamma=1+K/(mc^2)",("kinetic_energy","rest_mass"),("gamma",)),
          ExtremeCarrierModel("ECC-PB-BETA","Relativistic particle speed","beta=sqrt(1-gamma^-2)",("gamma",),("beta",)),
          ExtremeCarrierModel("ECC-PB-GYRO","Magnetic gyroradius","rL=p/(|q|B)",("momentum","charge","magnetic_field"),("gyroradius",)),
          ExtremeCarrierModel("ECC-PB-SURV","Particle survival probability","P=exp(-L/lambda_mfp)",("path_length","mean_free_path"),("survival",)),
          ExtremeCarrierModel("ECC-PB-RX","Detected particle rate","R=Ndot*min(1,Arx/Abeam)*Psurv*eta",("source_rate","beam_area","detector_area","survival","efficiency"),("detected_rate",)),
          ExtremeCarrierModel("ECC-PB-PERVEANCE","Generalized perveance proxy","K=2I/(I0 beta^3 gamma^3)",("current","beta","gamma","characteristic_current"),("perveance",)),
          ExtremeCarrierModel("ECC-GW-FLUX","Sinusoidal GW energy flux","F=c^3/(32*pi*G)*(omega*h0)^2",("strain","frequency"),("flux",)),
          ExtremeCarrierModel("ECC-GW-STRAIN","Strain from GW energy flux","h0=sqrt(32*pi*G*F/c^3)/omega",("flux","frequency"),("strain",)),
          ExtremeCarrierModel("ECC-GW-QUAD","Far-field quadrupole strain scaling","h~2G*Qdd/(c^4*r)",("quadrupole_second_derivative","distance"),("strain",)),
          ExtremeCarrierModel("ECC-GW-DISP","Detector displacement","dx=h*L",("strain","arm_length"),("displacement",)),
          ExtremeCarrierModel("ECC-GW-SNR","Ideal monochromatic coherent SNR","rho~h*sqrt(T)/ASD",("strain","integration_time","noise_asd"),("snr",)),
          ExtremeCarrierModel("ECC-GW-POWER","Isotropic-equivalent GW power","Piso=4*pi*r^2*F",("flux","distance"),("power",)),
          ExtremeCarrierModel("ECC-CMP-EBIT","Architecture energy per bit","Ebit=Ptotal/Rb",("total_power","information_rate"),("joules_per_bit",)),
          ExtremeCarrierModel("ECC-CMP-PARETO","Physical Pareto comparison","nondominated{latency,power,mass,rate,transmission}",("scenarios",),("pareto_front",)),
          ExtremeCarrierModel("ECC-CMP-SWEEP","Carrier parameter sweep","evaluate scenario builder over explicit parameter vector",("parameter_values","scenario_builder"),("scenario_series",)),
          ExtremeCarrierModel("ECC-CMP-MC","Rate uncertainty Monte Carlo","R~truncated Normal(R0,sigma_R)",("base_rate","relative_sigma","trials","seed"),("rate_distribution",)),
          ExtremeCarrierModel("ECC-LAB-RECORD","Reproducible ECC experiment record","scenario+parameters+outputs+provenance+checksum",("scenario","provenance","parameters","outputs"),("experiment_record",)),
          ExtremeCarrierModel("ECC-LAB-VIZ","Visualization-ready experiment projection","record -> typed physical metric row",("experiment_records",),("visualization_rows",)),
          ExtremeCarrierModel("ECC-LAB-GUARDIAN","Guardian-readable scientific summary","record -> evidence/source/model/metric summary",("experiment_record",),("guardian_summary",)),
          ExtremeCarrierModel("ECC-VAL-SENS","Normalized local sensitivity","S=(dy/dx)(x/y)",("model","parameter","step"),("normalized_sensitivity",)),
          ExtremeCarrierModel("ECC-VAL-GATES","Carrier-specific engineering failure gates","evaluate physical and causal constraints",("carrier_link","thresholds"),("gate_findings",)),
          ExtremeCarrierModel("ECC-VAL-XENG","ECC cross-engine validation","validate ECC-01..07 physical invariants and dependencies",("installed_root",),("validation_checks",)),
        )
    def get(self,model_id):
        return next((m for m in self._models if m.model_id==model_id),None)
    def all(self):return self._models
