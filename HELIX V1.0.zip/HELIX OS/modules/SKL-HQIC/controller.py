from __future__ import annotations
from dataclasses import dataclass,field
from enum import Enum
import time

class DeviceState(str,Enum):
    DISCONNECTED="DISCONNECTED"; IDLE="IDLE"; ARMED="ARMED"; BUSY="BUSY"; FAULT="FAULT"

class CommandKind(str,Enum):
    DISCOVER="DISCOVER"; READ_CLASSICAL="READ_CLASSICAL"; WRITE_CLASSICAL="WRITE_CLASSICAL"
    PREPARE_QUANTUM="PREPARE_QUANTUM"; STORE_QUANTUM="STORE_QUANTUM"; RETRIEVE_QUANTUM="RETRIEVE_QUANTUM"
    RESET_QUANTUM="RESET_QUANTUM"; ABORT="ABORT"

@dataclass(frozen=True)
class DeviceCapabilities:
    classical_read:bool=True
    classical_write:bool=False
    quantum_prepare:bool=False
    quantum_store:bool=False
    quantum_retrieve:bool=False
    quantum_reset:bool=False
    max_classical_address:int=0
    quantum_slots:int=0
    def __post_init__(self):
        if self.max_classical_address<0 or self.quantum_slots<0: raise ValueError("negative capacity")

@dataclass(frozen=True)
class DeviceAddress:
    classical_address:int|None=None
    quantum_slot:int|None=None
    def __post_init__(self):
        if self.classical_address is None and self.quantum_slot is None: raise ValueError("address required")
        if self.classical_address is not None and self.classical_address<0: raise ValueError("negative address")
        if self.quantum_slot is not None and self.quantum_slot<0: raise ValueError("negative slot")

@dataclass(frozen=True)
class HQICCommand:
    command_id:str
    kind:CommandKind
    address:DeviceAddress|None=None
    payload_ref:str|None=None
    confirmation_token:str|None=None
    def __post_init__(self):
        if not self.command_id.strip(): raise ValueError("command id required")

@dataclass(frozen=True)
class TelemetryFrame:
    timestamp_s:float
    state:DeviceState
    temperature_k:float|None=None
    optical_power_w:float|None=None
    controller_load:float|None=None
    fault_code:str|None=None
    source:str="HARDWARE"
    def __post_init__(self):
        if self.timestamp_s<0: raise ValueError("invalid timestamp")
        if self.temperature_k is not None and self.temperature_k<0: raise ValueError("invalid temperature")
        if self.optical_power_w is not None and self.optical_power_w<0: raise ValueError("invalid power")
        if self.controller_load is not None and not 0<=self.controller_load<=1: raise ValueError("load must be 0..1")

def validate_command(command,caps,state):
    if state==DeviceState.FAULT and command.kind!=CommandKind.ABORT:return False,"device_fault"
    if command.kind==CommandKind.DISCOVER:return True,"ok"
    if command.kind==CommandKind.ABORT:return True,"ok"
    needs_addr=command.kind not in (CommandKind.DISCOVER,CommandKind.ABORT)
    if needs_addr and command.address is None:return False,"address_required"
    if command.kind==CommandKind.READ_CLASSICAL:
        if not caps.classical_read:return False,"unsupported"
        if command.address.classical_address is None or command.address.classical_address>caps.max_classical_address:return False,"address_out_of_range"
    elif command.kind==CommandKind.WRITE_CLASSICAL:
        if not caps.classical_write:return False,"unsupported"
        if command.address.classical_address is None or command.address.classical_address>caps.max_classical_address:return False,"address_out_of_range"
    elif command.kind in (CommandKind.PREPARE_QUANTUM,CommandKind.STORE_QUANTUM,CommandKind.RETRIEVE_QUANTUM,CommandKind.RESET_QUANTUM):
        flag={CommandKind.PREPARE_QUANTUM:caps.quantum_prepare,CommandKind.STORE_QUANTUM:caps.quantum_store,
              CommandKind.RETRIEVE_QUANTUM:caps.quantum_retrieve,CommandKind.RESET_QUANTUM:caps.quantum_reset}[command.kind]
        if not flag:return False,"unsupported"
        if command.address.quantum_slot is None or command.address.quantum_slot>=caps.quantum_slots:return False,"slot_out_of_range"
        if command.kind in (CommandKind.PREPARE_QUANTUM,CommandKind.STORE_QUANTUM) and not command.confirmation_token:
            return False,"confirmation_required"
    return True,"ok"

@dataclass
class DeterministicHQICController:
    capabilities:DeviceCapabilities
    state:DeviceState=DeviceState.IDLE
    audit:list[dict]=field(default_factory=list)
    def execute(self,command):
        ok,reason=validate_command(command,self.capabilities,self.state)
        self.audit.append({"command_id":command.command_id,"kind":command.kind.value,"accepted":ok,"reason":reason})
        if not ok:return {"accepted":False,"reason":reason}
        if command.kind==CommandKind.ABORT:self.state=DeviceState.IDLE
        elif command.kind not in (CommandKind.DISCOVER,): self.state=DeviceState.BUSY
        return {"accepted":True,"reason":"ok","state":self.state.value}
    def complete_operation(self): 
        if self.state==DeviceState.BUSY:self.state=DeviceState.IDLE
    def fault(self,code="FAULT"): self.state=DeviceState.FAULT; return code
    def telemetry(self,**kwargs): return TelemetryFrame(time.time(),self.state,**kwargs)
