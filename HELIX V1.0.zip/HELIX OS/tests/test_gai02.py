import unittest,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];L=(R/"core/guardian/local_llm.py").read_text();C=(R/"core/guardian/console.py").read_text();Q=(R/"core/guardian/reasoning.py").read_text()
class T(unittest.TestCase):
 def test_runtime(self):self.assertIn("class LocalLLMRuntime",L);self.assertIn("from llama_cpp import Llama",L)
 def test_gguf_config(self):self.assertIn("model_path",L);self.assertTrue((R/"core/resources/guardian/local_model.example.json").exists())
 def test_no_model_bundled(self):self.assertFalse(list(R.rglob("*.gguf")))
 def test_no_download(self):self.assertNotIn("requests.get",L);self.assertNotIn("urlretrieve",L)
 def test_reasoner(self):self.assertIn("class GuardianReasoner",Q);self.assertIn("Never fabricate telemetry",Q)
 def test_authority(self):self.assertIn("deterministic CommandService",Q);self.assertNotIn("command_service.execute",Q)
 def test_console_fallback(self):self.assertIn("reasoner=None",C);self.assertIn("self.reasoner.answer",C)
 def test_deterministic_first(self):self.assertLess(C.index('if upper.startswith("RUN ")'),C.index("self.reasoner.answer"))
 def test_marker(self):
  d=json.loads((R/"GAI_02_COMPLETE.json").read_text());self.assertEqual(d["sequence"],"2/8");self.assertFalse(d["model_bundled"])
 def test_gai01(self):self.assertTrue((R/"GAI_01_COMPLETE.json").exists())
 def test_windows_fix(self):self.assertIn('quick = QGroupBox("QUICK START")',(R/"core/ui/main_window.py").read_text())
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
