from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import C

H=6.62607015e-34

def photon_energy_j(frequency_hz):
    if frequency_hz<=0: raise ValueError("frequency must be positive")
    return H*frequency_hz

def resonator_quality_factor(frequency_hz,linewidth_hz):
    if frequency_hz<=0 or linewidth_hz<=0: raise ValueError("positive frequency/linewidth required")
    return frequency_hz/linewidth_hz

def resonator_linewidth_hz(frequency_hz,q_factor):
    if frequency_hz<=0 or q_factor<=0: raise ValueError("positive frequency/Q required")
    return frequency_hz/q_factor

def coherence_time_s(linewidth_hz):
    if linewidth_hz<=0: raise ValueError("linewidth must be positive")
    return 1/(math.pi*linewidth_hz)

def cavity_energy_decay_time_s(q_factor,frequency_hz):
    if q_factor<=0 or frequency_hz<=0: raise ValueError("positive Q/frequency required")
    return q_factor/(2*math.pi*frequency_hz)

def population_inversion_fraction(upper_population,lower_population):
    total=upper_population+lower_population
    if upper_population<0 or lower_population<0 or total<=0: raise ValueError("invalid populations")
    return (upper_population-lower_population)/total

def small_signal_power_gain_linear(gain_coefficient_per_m,length_m):
    if length_m<0: raise ValueError("length nonnegative")
    return math.exp(gain_coefficient_per_m*length_m)

def phase_coherence_factor(phase_errors_rad):
    xs=tuple(phase_errors_rad)
    if not xs: raise ValueError("phase errors required")
    z=sum(complex(math.cos(x),math.sin(x)) for x in xs)
    return abs(z)/len(xs)

def coherent_combined_power_w(per_source_power_w,phase_errors_rad):
    xs=tuple(phase_errors_rad)
    if per_source_power_w<0 or not xs: raise ValueError("invalid source power/phases")
    # Far-field peak in a common normalized combining mode: N*P times coherence factor^2.
    n=len(xs); c=phase_coherence_factor(xs)
    return n*per_source_power_w*c*c

def incoherent_combined_power_w(per_source_power_w,source_count):
    if per_source_power_w<0 or source_count<1 or int(source_count)!=source_count: raise ValueError("invalid sources")
    return per_source_power_w*source_count

def fractional_frequency_stability(frequency_error_hz,carrier_frequency_hz):
    if carrier_frequency_hz<=0: raise ValueError("carrier positive")
    return abs(frequency_error_hz)/carrier_frequency_hz

def phase_drift_rad(frequency_error_hz,elapsed_s):
    if elapsed_s<0: raise ValueError("elapsed time nonnegative")
    return 2*math.pi*frequency_error_hz*elapsed_s

def max_frequency_error_for_phase_budget_hz(max_phase_error_rad,coherent_interval_s):
    if max_phase_error_rad<0 or coherent_interval_s<=0: raise ValueError("invalid phase/time")
    return max_phase_error_rad/(2*math.pi*coherent_interval_s)

@dataclass(frozen=True)
class MaserResonator:
    frequency_hz:float
    q_factor:float
    upper_population:float
    lower_population:float
    gain_coefficient_per_m:float
    active_length_m:float
    def __post_init__(self):
        if self.frequency_hz<=0 or self.q_factor<=0 or min(self.upper_population,self.lower_population,self.active_length_m)<0:
            raise ValueError("invalid maser resonator")
        if self.upper_population+self.lower_population<=0: raise ValueError("population required")
    @property
    def linewidth_hz(self): return resonator_linewidth_hz(self.frequency_hz,self.q_factor)
    @property
    def coherence_time_s(self): return coherence_time_s(self.linewidth_hz)
    @property
    def inversion_fraction(self): return population_inversion_fraction(self.upper_population,self.lower_population)
    @property
    def small_signal_gain_linear(self): return small_signal_power_gain_linear(self.gain_coefficient_per_m,self.active_length_m)
    @property
    def photon_energy_j(self): return photon_energy_j(self.frequency_hz)

@dataclass(frozen=True)
class CoherentMicrowaveArray:
    per_element_power_w:float
    phase_errors_rad:tuple[float,...]
    frequency_hz:float
    def __post_init__(self):
        if self.per_element_power_w<0 or not self.phase_errors_rad or self.frequency_hz<=0: raise ValueError("invalid coherent array")
    @property
    def element_count(self): return len(self.phase_errors_rad)
    @property
    def coherence_factor(self): return phase_coherence_factor(self.phase_errors_rad)
    @property
    def peak_combined_power_w(self): return coherent_combined_power_w(self.per_element_power_w,self.phase_errors_rad)
    @property
    def total_generated_rf_power_w(self): return self.element_count*self.per_element_power_w
