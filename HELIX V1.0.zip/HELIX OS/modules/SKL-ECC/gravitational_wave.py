from __future__ import annotations
from dataclasses import dataclass
import math

G_M3_KG_S2=6.67430e-11
C_M_S=299792458.0
PI=math.pi

def sinusoidal_gw_energy_flux_w_m2(strain_amplitude,frequency_hz):
    """Cycle-averaged plane-wave flux for h(t)=h0 cos(2*pi*f*t), one effective polarization."""
    if strain_amplitude<0 or frequency_hz<=0: raise ValueError("invalid GW inputs")
    omega=2*PI*frequency_hz
    return (C_M_S**3/(32*PI*G_M3_KG_S2))*(omega*strain_amplitude)**2

def strain_from_energy_flux(flux_w_m2,frequency_hz):
    if flux_w_m2<0 or frequency_hz<=0: raise ValueError("invalid GW inputs")
    omega=2*PI*frequency_hz
    return math.sqrt(flux_w_m2*32*PI*G_M3_KG_S2/C_M_S**3)/omega

def far_field_strain_from_quadrupole_second_derivative(qdd_kg_m2_s2,distance_m):
    """Order-of-magnitude transverse-traceless far-field scaling h~(2G/c^4r) Qdd."""
    if qdd_kg_m2_s2<0 or distance_m<=0: raise ValueError("invalid quadrupole inputs")
    return 2*G_M3_KG_S2*qdd_kg_m2_s2/(C_M_S**4*distance_m)

def rotating_quadrupole_strain(mass_kg,separation_m,angular_frequency_rad_s,distance_m,geometry_factor=1.0):
    """Transparent order-of-magnitude rotating quadrupole estimate."""
    if mass_kg<0 or separation_m<0 or angular_frequency_rad_s<0 or distance_m<=0 or geometry_factor<0:
        raise ValueError("invalid source")
    qdd=mass_kg*separation_m**2*angular_frequency_rad_s**2
    return geometry_factor*far_field_strain_from_quadrupole_second_derivative(qdd,distance_m)

def isotropic_equivalent_power_w(flux_w_m2,distance_m):
    if flux_w_m2<0 or distance_m<=0: raise ValueError("invalid power inputs")
    return 4*PI*distance_m**2*flux_w_m2

def detector_displacement_m(strain,arm_length_m):
    if strain<0 or arm_length_m<0: raise ValueError("nonnegative inputs")
    return strain*arm_length_m

def monochromatic_snr(strain_amplitude,amplitude_spectral_density_per_sqrt_hz,integration_s):
    """Ideal coherent single-frequency scaling h*sqrt(T)/ASD."""
    if strain_amplitude<0 or amplitude_spectral_density_per_sqrt_hz<=0 or integration_s<=0:
        raise ValueError("invalid detector inputs")
    return strain_amplitude*math.sqrt(integration_s)/amplitude_spectral_density_per_sqrt_hz

def integration_time_for_snr_s(strain_amplitude,amplitude_spectral_density_per_sqrt_hz,target_snr):
    if strain_amplitude<=0 or amplitude_spectral_density_per_sqrt_hz<=0 or target_snr<=0:
        raise ValueError("positive inputs")
    return (target_snr*amplitude_spectral_density_per_sqrt_hz/strain_amplitude)**2

def ideal_symbol_rate_from_integration_time(integration_s,symbols_per_integration=1.0):
    if integration_s<=0 or symbols_per_integration<=0: raise ValueError("positive inputs")
    return symbols_per_integration/integration_s

def propagation_time_s(distance_m):
    if distance_m<0: raise ValueError("distance nonnegative")
    return distance_m/C_M_S

@dataclass(frozen=True)
class GravitationalWaveLink:
    strain_amplitude:float
    frequency_hz:float
    distance_m:float
    detector_asd_per_sqrt_hz:float
    integration_s:float
    detector_arm_length_m:float=1.0
    def __post_init__(self):
        if self.strain_amplitude<0 or self.frequency_hz<=0 or self.distance_m<=0 or self.detector_asd_per_sqrt_hz<=0 or self.integration_s<=0 or self.detector_arm_length_m<=0:
            raise ValueError("invalid GW link")
    @property
    def energy_flux_w_m2(self): return sinusoidal_gw_energy_flux_w_m2(self.strain_amplitude,self.frequency_hz)
    @property
    def isotropic_equivalent_power_w(self): return isotropic_equivalent_power_w(self.energy_flux_w_m2,self.distance_m)
    @property
    def detector_displacement_m(self): return detector_displacement_m(self.strain_amplitude,self.detector_arm_length_m)
    @property
    def ideal_coherent_snr(self): return monochromatic_snr(self.strain_amplitude,self.detector_asd_per_sqrt_hz,self.integration_s)
    @property
    def propagation_time_s(self): return propagation_time_s(self.distance_m)
