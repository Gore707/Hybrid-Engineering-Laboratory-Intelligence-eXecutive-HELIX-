from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import BoundaryEvidence,C_M_S
from .axion import HBARC_EV_M,sinc

def dark_photon_momentum_mismatch_ev(m_dark_ev,photon_energy_ev,effective_photon_mass_ev=0.0):
    """Relativistic small-mass mismatch q ~= |m_A'^2-m_gamma^2|/(2E)."""
    if m_dark_ev<0 or photon_energy_ev<=0 or effective_photon_mass_ev<0:raise ValueError("invalid dark-photon inputs")
    return abs(m_dark_ev*m_dark_ev-effective_photon_mass_ev*effective_photon_mass_ev)/(2*photon_energy_ev)

def dark_photon_coherence_length_m(m_dark_ev,photon_energy_ev,effective_photon_mass_ev=0.0):
    q=dark_photon_momentum_mismatch_ev(m_dark_ev,photon_energy_ev,effective_photon_mass_ev)
    return math.inf if q==0 else 2*math.pi*HBARC_EV_M/q

def photon_dark_photon_probability(kinetic_mixing,length_m,m_dark_ev,photon_energy_ev,effective_photon_mass_ev=0.0):
    """Vacuum/medium two-state benchmark P ~= 4 eps^2 sinc^2(qL/2) sin^2(qL/2), expressed as 4 eps^2 sin^2(qL/2).
    For q->0 the oscillation phase vanishes in this simple massive-mixing propagation benchmark."""
    if kinetic_mixing<0 or length_m<0 or m_dark_ev<0 or photon_energy_ev<=0 or effective_photon_mass_ev<0:
        raise ValueError("invalid mixing inputs")
    q=dark_photon_momentum_mismatch_ev(m_dark_ev,photon_energy_ev,effective_photon_mass_ev)
    phase=q*(length_m/HBARC_EV_M)/2
    return min(1.0,max(0.0,4*kinetic_mixing*kinetic_mixing*math.sin(phase)**2))

def regeneration_probability(p_conversion,p_reconversion):
    if not 0<=p_conversion<=1 or not 0<=p_reconversion<=1:raise ValueError("probabilities in [0,1]")
    return p_conversion*p_reconversion

def regenerated_event_rate_s(source_photon_rate_s,p_conversion,p_reconversion,detector_efficiency=1.0):
    if source_photon_rate_s<0 or not 0<=detector_efficiency<=1:raise ValueError("invalid event inputs")
    return source_photon_rate_s*regeneration_probability(p_conversion,p_reconversion)*detector_efficiency

def attenuation_transmission(optical_depth):
    if optical_depth<0:raise ValueError("optical depth nonnegative")
    return math.exp(-optical_depth)

def effective_visible_coupling(kinetic_mixing,electric_charge_units=1.0):
    if kinetic_mixing<0 or electric_charge_units<0:raise ValueError("nonnegative coupling")
    return kinetic_mixing*electric_charge_units

def poisson_snr(signal_rate_s,background_rate_s,integration_s):
    if signal_rate_s<0 or background_rate_s<0 or integration_s<=0:raise ValueError("invalid counting")
    s=signal_rate_s*integration_s;b=background_rate_s*integration_s
    return 0.0 if s+b==0 else s/math.sqrt(s+b)

def ideal_bit_rate_bps(event_rate_s,events_per_bit):
    if event_rate_s<0 or events_per_bit<=0:raise ValueError("invalid event budget")
    return event_rate_s/events_per_bit

def dark_photon_information_speed_status(speed_m_s):
    if speed_m_s<0:raise ValueError("speed nonnegative")
    return speed_m_s<=C_M_S

@dataclass(frozen=True)
class DarkPhotonStage:
    kinetic_mixing:float
    length_m:float
    m_dark_ev:float
    photon_energy_ev:float
    effective_photon_mass_ev:float=0.0
    @property
    def probability(self):return photon_dark_photon_probability(self.kinetic_mixing,self.length_m,self.m_dark_ev,self.photon_energy_ev,self.effective_photon_mass_ev)
    @property
    def coherence_length_m(self):return dark_photon_coherence_length_m(self.m_dark_ev,self.photon_energy_ev,self.effective_photon_mass_ev)

@dataclass(frozen=True)
class DarkPhotonCommunicationLink:
    production:DarkPhotonStage
    reconversion:DarkPhotonStage
    source_photon_rate_s:float
    detector_efficiency:float=1.0
    events_per_bit:float=10.0
    background_rate_s:float=0.0
    evidence:BoundaryEvidence=BoundaryEvidence.SPECULATIVE_UNRESOLVED
    def __post_init__(self):
        if self.source_photon_rate_s<0 or not 0<=self.detector_efficiency<=1 or self.events_per_bit<=0 or self.background_rate_s<0:raise ValueError("invalid link")
    @property
    def end_to_end_probability(self):return regeneration_probability(self.production.probability,self.reconversion.probability)
    @property
    def regenerated_rate_s(self):return regenerated_event_rate_s(self.source_photon_rate_s,self.production.probability,self.reconversion.probability,self.detector_efficiency)
    @property
    def ideal_bit_rate_bps(self):return ideal_bit_rate_bps(self.regenerated_rate_s,self.events_per_bit)
