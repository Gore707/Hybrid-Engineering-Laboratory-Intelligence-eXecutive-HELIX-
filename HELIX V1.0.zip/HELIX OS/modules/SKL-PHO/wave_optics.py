from __future__ import annotations
from dataclasses import dataclass
import cmath,math
@dataclass(frozen=True)
class ComplexField:
 amplitude:complex;wavelength_m:float
 def __post_init__(self):
  if self.wavelength_m<=0 or not math.isfinite(self.wavelength_m):raise ValueError("wavelength must be positive finite")
  if not math.isfinite(self.amplitude.real) or not math.isfinite(self.amplitude.imag):raise ValueError("field must be finite")
 @property
 def intensity_arb(self):return abs(self.amplitude)**2
 @property
 def phase_rad(self):return cmath.phase(self.amplitude)
 def propagate(self,distance_m,refractive_index=1.0):
  if refractive_index<=0:raise ValueError("index must be positive")
  k=2*math.pi*refractive_index/self.wavelength_m
  return ComplexField(self.amplitude*cmath.exp(1j*k*distance_m),self.wavelength_m)
def superpose(fields):
 if not fields:raise ValueError("at least one field required")
 wl=fields[0].wavelength_m
 if any(abs(f.wavelength_m-wl)>max(1e-15,wl*1e-12) for f in fields):raise ValueError("simple coherent superposition requires equal wavelength")
 return ComplexField(sum((f.amplitude for f in fields),0j),wl)
def two_beam_intensity(i1,i2,phase_difference_rad,visibility=1.0):
 if i1<0 or i2<0 or not 0<=visibility<=1:raise ValueError("invalid intensity/visibility")
 return i1+i2+2*visibility*math.sqrt(i1*i2)*math.cos(phase_difference_rad)
def fringe_visibility(i_max,i_min):
 if i_max<0 or i_min<0 or i_max<i_min or i_max+i_min==0:raise ValueError("invalid extrema")
 return (i_max-i_min)/(i_max+i_min)
def temporal_coherence_length(coherence_time_s,refractive_index=1.0):
 from .foundation import C0
 if coherence_time_s<0 or refractive_index<=0:raise ValueError("invalid coherence parameters")
 return C0*coherence_time_s/refractive_index
def rectangular_single_slit_intensity(theta_rad,wavelength_m,slit_width_m,i0=1.0):
 if wavelength_m<=0 or slit_width_m<=0 or i0<0:raise ValueError("invalid diffraction parameters")
 beta=math.pi*slit_width_m*math.sin(theta_rad)/wavelength_m
 sinc=1.0 if abs(beta)<1e-15 else math.sin(beta)/beta
 return i0*sinc*sinc
def double_slit_intensity(theta_rad,wavelength_m,slit_separation_m,slit_width_m=None,i0=1.0):
 if wavelength_m<=0 or slit_separation_m<=0 or i0<0:raise ValueError("invalid slit parameters")
 phase=math.pi*slit_separation_m*math.sin(theta_rad)/wavelength_m
 envelope=1.0
 if slit_width_m is not None:
  if slit_width_m<=0:raise ValueError("slit width must be positive")
  beta=math.pi*slit_width_m*math.sin(theta_rad)/wavelength_m
  envelope=(1 if abs(beta)<1e-15 else math.sin(beta)/beta)**2
 return 4*i0*(math.cos(phase)**2)*envelope
def grating_principal_angle(order,wavelength_m,spacing_m,incidence_rad=0.0):
 if spacing_m<=0 or wavelength_m<=0:raise ValueError("positive wavelength/spacing required")
 s=order*wavelength_m/spacing_m-math.sin(incidence_rad)
 return None if abs(s)>1 else math.asin(s)
def airy_intensity(theta_rad,wavelength_m,aperture_diameter_m,i0=1.0):
 if wavelength_m<=0 or aperture_diameter_m<=0 or i0<0:raise ValueError("invalid aperture parameters")
 x=math.pi*aperture_diameter_m*math.sin(theta_rad)/wavelength_m
 if abs(x)<1e-12:return i0
 try:
  from scipy.special import j1
  a=2*j1(x)/x
 except Exception:
  # convergent J1 power series; sufficient deterministic fallback
  term=x/2;s=term
  for k in range(1,80):
   term*=-(x*x/4)/(k*(k+1));s+=term
   if abs(term)<1e-16:break
  a=2*s/x
 return i0*a*a
