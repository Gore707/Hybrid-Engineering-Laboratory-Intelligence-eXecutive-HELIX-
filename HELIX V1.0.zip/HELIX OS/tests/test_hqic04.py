import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HQIC"
sp=importlib.util.spec_from_file_location("skl_hqic",M/"__init__.py",submodule_search_locations=[str(M)])
h=importlib.util.module_from_spec(sp);sys.modules["skl_hqic"]=h;sp.loader.exec_module(h)
class T(unittest.TestCase):
 def caps(self):return h.DeviceCapabilities(True,True,True,True,True,True,99,4)
 def test_caps(self):self.assertEqual(self.caps().quantum_slots,4)
 def test_address_guard(self):
  with self.assertRaises(ValueError):h.DeviceAddress(classical_address=-1)
 def test_read_valid(self):
  ok,r=h.validate_command(h.HQICCommand("1",h.CommandKind.READ_CLASSICAL,h.DeviceAddress(classical_address=5)),self.caps(),h.DeviceState.IDLE);self.assertTrue(ok)
 def test_read_range(self):
  ok,r=h.validate_command(h.HQICCommand("1",h.CommandKind.READ_CLASSICAL,h.DeviceAddress(classical_address=100)),self.caps(),h.DeviceState.IDLE);self.assertEqual(r,"address_out_of_range")
 def test_unsupported_write(self):
  c=h.DeviceCapabilities(True,False,max_classical_address=9);ok,r=h.validate_command(h.HQICCommand("1",h.CommandKind.WRITE_CLASSICAL,h.DeviceAddress(classical_address=1)),c,h.DeviceState.IDLE);self.assertEqual(r,"unsupported")
 def test_quantum_confirmation(self):
  ok,r=h.validate_command(h.HQICCommand("1",h.CommandKind.STORE_QUANTUM,h.DeviceAddress(quantum_slot=1)),self.caps(),h.DeviceState.IDLE);self.assertEqual(r,"confirmation_required")
 def test_quantum_confirmed(self):
  ok,r=h.validate_command(h.HQICCommand("1",h.CommandKind.STORE_QUANTUM,h.DeviceAddress(quantum_slot=1),confirmation_token="YES"),self.caps(),h.DeviceState.IDLE);self.assertTrue(ok)
 def test_quantum_range(self):
  ok,r=h.validate_command(h.HQICCommand("1",h.CommandKind.RETRIEVE_QUANTUM,h.DeviceAddress(quantum_slot=4)),self.caps(),h.DeviceState.IDLE);self.assertEqual(r,"slot_out_of_range")
 def test_fault_blocks(self):
  ok,r=h.validate_command(h.HQICCommand("1",h.CommandKind.READ_CLASSICAL,h.DeviceAddress(classical_address=1)),self.caps(),h.DeviceState.FAULT);self.assertFalse(ok)
 def test_abort_fault(self):
  ok,r=h.validate_command(h.HQICCommand("1",h.CommandKind.ABORT),self.caps(),h.DeviceState.FAULT);self.assertTrue(ok)
 def test_controller_busy(self):
  c=h.DeterministicHQICController(self.caps());x=c.execute(h.HQICCommand("1",h.CommandKind.READ_CLASSICAL,h.DeviceAddress(classical_address=1)));self.assertEqual(c.state,h.DeviceState.BUSY)
 def test_complete(self):
  c=h.DeterministicHQICController(self.caps());c.execute(h.HQICCommand("1",h.CommandKind.READ_CLASSICAL,h.DeviceAddress(classical_address=1)));c.complete_operation();self.assertEqual(c.state,h.DeviceState.IDLE)
 def test_audit(self):
  c=h.DeterministicHQICController(self.caps());c.execute(h.HQICCommand("1",h.CommandKind.DISCOVER));self.assertEqual(c.audit[0]["accepted"],True)
 def test_telemetry(self):
  c=h.DeterministicHQICController(self.caps());t=c.telemetry(temperature_k=4,optical_power_w=.1,controller_load=.2);self.assertEqual(t.source,"HARDWARE")
 def test_bad_telemetry(self):
  with self.assertRaises(ValueError):h.TelemetryFrame(0,h.DeviceState.IDLE,controller_load=2)
 def test_transduction_preserved(self):self.assertAlmostEqual(h.cascaded_efficiency(.8,.5),.4)
 def test_layering_preserved(self):self.assertEqual(h.layer_address_capacity(.01,.01,.001,.001),100)
 def test_registry(self):self.assertTrue({"HQIC-CTL-ADDR","HQIC-CTL-STATE","HQIC-CTL-TELEM"}<={x.model_id for x in h.HQICRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HQIC-04")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO","SKL-QMEM"])
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
