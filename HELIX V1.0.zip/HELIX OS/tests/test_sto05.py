import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-STO";sp=importlib.util.spec_from_file_location("skl_sto",M/"__init__.py",submodule_search_locations=[str(M)]);s=importlib.util.module_from_spec(sp);sys.modules["skl_sto"]=s;sp.loader.exec_module(s)
class T(unittest.TestCase):
 def test_symbol(self):self.assertEqual(s.dna_ideal_bits_per_base(),2);self.assertEqual(s.ideal_bits_per_symbol(4),2)
 def test_sequence(self):self.assertEqual(s.sequence_raw_bits(100),200)
 def test_overhead(self):self.assertAlmostEqual(s.SequenceOverhead(.1,.1,.2,.1).total_fraction,.5)
 def test_plan(self):
  p=s.DNAStoragePlan(100,200,s.SequenceOverhead(.05,.05,.1,.1),1.5);c=p.capacity();self.assertEqual(p.total_bases,20000);self.assertEqual(c.raw_bits,30000);self.assertAlmostEqual(c.usable_bits,21000)
 def test_channel_zero_error(self):self.assertEqual(s.substitution_channel_capacity_bits_per_base(0),2)
 def test_channel_degrades(self):self.assertLess(s.substitution_channel_capacity_bits_per_base(.1),2)
 def test_recovery_copies(self):self.assertEqual(s.copies_for_target_recovery(.9,.999),3)
 def test_mass_capacity(self):self.assertGreater(s.mass_limited_ideal_capacity_bits(1),1e21)
 def test_survival(self):self.assertAlmostEqual(s.exponential_survival_fraction(10,10),math.e**-1)
 def test_invalid_overhead(self):
  with self.assertRaises(ValueError):s.SequenceOverhead(.5,.5,0,0)
 def test_registry(self):self.assertEqual(s.StorageRegistry().get("STO-DNA-IDEAL").evidence_class,"ESTABLISHED_PHYSICS")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-STO-05")
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
