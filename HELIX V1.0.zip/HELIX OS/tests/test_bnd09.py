import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-BND"
sp=importlib.util.spec_from_file_location("skl_bnd",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_bnd"]=q;sp.loader.exec_module(q)
def sc(f=q.BoundaryFamily.ORDINARY_RELATIVISTIC,speed=q.C_M_S,e=q.BoundaryEvidence.ESTABLISHED_PHYSICS,v=1,en=1):
 return q.BoundaryScenario(f,10*q.C_M_S,e,q.C_M_S,speed,v,en)
class T(unittest.TestCase):
 def test_latency(self):self.assertAlmostEqual(sc().latency_s,10)
 def test_effective_ftl(self):self.assertEqual(sc(q.BoundaryFamily.WORMHOLE,10*q.C_M_S,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED).ftl_class,q.FTLClaimClass.APPARENT_OR_EFFECTIVE)
 def test_compare(self):self.assertEqual(len(q.compare_scenarios([sc(),sc(q.BoundaryFamily.QFT_VACUUM)])),2)
 def test_compare_fast_first(self):self.assertEqual(q.compare_scenarios([sc(),sc(q.BoundaryFamily.WARP_METRIC,2*q.C_M_S,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED)])[0]["family"],"WARP_METRIC")
 def test_pareto(self):self.assertTrue(q.pareto_front([sc()]))
 def test_sweep(self):self.assertEqual(len(q.parameter_sweep(lambda v:sc(speed=v),[q.C_M_S,2*q.C_M_S])),2)
 def test_mc_repro(self):self.assertEqual(q.monte_carlo_latency(sc(),.01,100,42),q.monte_carlo_latency(sc(),.01,100,42))
 def test_mc_bounds(self):self.assertLess(q.monte_carlo_latency(sc(),.01,100,1)["p05_s"],q.monte_carlo_latency(sc(),.01,100,1)["p95_s"])
 def test_partition(self):self.assertIn("ESTABLISHED_PHYSICS",q.evidence_partition([sc()]))
 def test_viz(self):self.assertEqual(q.visualization_dataset([sc()])[0]["effective_speed_over_c"],1)
 def test_guardian(self):self.assertIn("Simulation output",q.guardian_summary([sc()])["warning"])
 def test_record_fingerprint(self):
  a=q.BoundaryExperimentRecord("E1",sc(),42);self.assertEqual(a.fingerprint(),a.fingerprint());self.assertEqual(len(a.fingerprint()),64)
 def test_lab(self):
  l=q.BoundaryPhysicsLab();l.add(q.BoundaryExperimentRecord("E1",sc(),1));self.assertEqual(l.get("E1").experiment_id,"E1");self.assertEqual(len(l.compare()),1)
 def test_duplicate(self):
  l=q.BoundaryPhysicsLab();r=q.BoundaryExperimentRecord("E1",sc(),1);l.add(r)
  with self.assertRaises(ValueError):l.add(r)
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/boundary_experiment.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_causality_preserved(self):self.assertFalse(q.demonstrated_ftl_information_gate(q.BoundaryEvidence.SPECULATIVE_UNRESOLVED,False,True))
 def test_warp_preserved(self):self.assertFalse(q.physically_demonstrated_warp_metric_engineering_available())
 def test_wormhole_preserved(self):self.assertFalse(q.physically_demonstrated_traversable_wormhole_available())
 def test_registry(self):self.assertTrue({"BND-LAB-COMP","BND-LAB-MC","BND-LAB-PROV"}<={x.model_id for x in q.default_registry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-BND-09")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
