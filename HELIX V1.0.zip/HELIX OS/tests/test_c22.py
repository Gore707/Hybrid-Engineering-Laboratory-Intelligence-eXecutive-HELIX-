import unittest,math
from core.bootstrap.identity import IDENTITY
from core.engineering.engines import *
from core.engineering.hybrid import HybridInformationCapacity
from core.engineering.assessment import *
from core.design import DesignStudio,Component,Parameter
ROOT=__import__("pathlib").Path(__file__).resolve().parents[1]
class C22Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C22")
 def test_thermal(self):self.assertAlmostEqual(thermal_steady(10,1,2,310,300).conduction_w,50)
 def test_transduction_product(self):self.assertAlmostEqual(transduction_chain(100,[.5,.8]).output_power_w,40)
 def test_decoherence(self):self.assertAlmostEqual(decoherence(2,2).coherence_fraction,math.exp(-1))
 def test_classical_capacity(self):self.assertEqual(classical_capacity(1000,.1).usable_bytes,900)
 def test_hybrid_not_additive(self):
  h=HybridInformationCapacity(classical_capacity(1000,.1),quantum_capacity(100,.8,.99,1))
  with self.assertRaises(TypeError):_ = h+h
 def test_manufacturing(self):self.assertEqual(manufacturing(100,.8,2).throughput_good_per_hour,40)
 def test_power(self):
  r=power_energy(100,.75,10);self.assertEqual(r.waste_heat_w,25);self.assertEqual(r.energy_j,1000)
 def test_mechanical(self):self.assertAlmostEqual(uniaxial(100,1,200e9,250e6).stress_pa,100)
 def test_reliability(self):self.assertLess(exponential_reliability(.01,100).survival_probability,1)
 def test_assessment_is_not_physics_proof(self):
  s=DesignStudio();d=s.new("x","CUSTOM");c=Component("C","c","x",{"p":Parameter("p",1)},["M"],["E"],"ESTABLISHED_PHYSICS",["S"])
  s.add_component(d,c);a=assess_design(s,d);self.assertEqual(a.feasibility,FeasibilityClass.A);self.assertIn("not proof",a.reasons[-1])
 def test_invalid_inputs(self):
  with self.assertRaises(ValueError):transduction_chain(1,[1.2])
  with self.assertRaises(ValueError):uniaxial(1,0,1,1)
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
