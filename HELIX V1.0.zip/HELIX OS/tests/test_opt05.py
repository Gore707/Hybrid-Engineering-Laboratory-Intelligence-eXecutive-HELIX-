import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-OPT"
sp=importlib.util.spec_from_file_location("skl_opt",M/"__init__.py",submodule_search_locations=[str(M)])
o=importlib.util.module_from_spec(sp);sys.modules["skl_opt"]=o;sp.loader.exec_module(o)
class T(unittest.TestCase):
 def test_tau_zero(self):self.assertEqual(o.transmission_from_optical_depth(0),1)
 def test_tau_inverse(self):
  t=.7;self.assertAlmostEqual(o.transmission_from_optical_depth(o.optical_depth_from_transmission(t)),t)
 def test_beer(self):self.assertAlmostEqual(o.beer_lambert_transmission(.1,10),math.exp(-1))
 def test_airmass_zenith(self):self.assertEqual(o.plane_parallel_airmass(0),1)
 def test_airmass_grows(self):self.assertGreater(o.plane_parallel_airmass(math.radians(60)),1)
 def test_slant(self):self.assertAlmostEqual(o.slant_optical_depth(.1,math.radians(60)),.2)
 def test_r0(self):self.assertGreater(o.fried_parameter_m(500e-9,1e-13),0)
 def test_r0_wave_scaling(self):self.assertGreater(o.fried_parameter_m(1e-6,1e-13),o.fried_parameter_m(500e-9,1e-13))
 def test_seeing(self):self.assertAlmostEqual(o.seeing_fwhm_rad(1e-6,.1),9.8e-6)
 def test_coherence(self):self.assertAlmostEqual(o.greenwood_coherence_time_s(.1,10),.00314)
 def test_rytov_zero(self):self.assertEqual(o.rytov_variance_plane_wave(0,1e7,1000),0)
 def test_rytov_positive(self):self.assertGreater(o.rytov_variance_plane_wave(1e-15,1e7,1000),0)
 def test_weak_scint(self):self.assertEqual(o.weak_scintillation_index_from_rytov(.1),.1)
 def test_spread(self):self.assertGreater(o.turbulence_beam_radius_rss_m(1,1e-6,1e6),1)
 def test_loss(self):self.assertAlmostEqual(o.atmospheric_loss_db(.5),3.010299956639812)
 def test_atmosphere(self):
  a=o.GroundSpaceAtmosphere(1e-6,.1,math.radians(30),1e-13,10)
  self.assertTrue(0<a.transmission<1);self.assertGreater(a.r0_m,0);self.assertGreater(a.coherence_time_s,0)
 def test_no_turbulence_optional(self):
  a=o.GroundSpaceAtmosphere(1e-6,.1,0);self.assertIsNone(a.r0_m);self.assertIsNone(a.seeing_fwhm_rad)
 def test_horizon_rejected(self):
  with self.assertRaises(ValueError):o.plane_parallel_airmass(math.pi/2)
 def test_pat_preserved(self):self.assertEqual(o.gaussian_pointing_coupling(0,1e-6),1)
 def test_receiver_preserved(self):self.assertGreater(o.telescope_collection_area_m2(1),0)
 def test_transmitter_preserved(self):self.assertGreater(o.rayleigh_range_m(1e-6,1),0)
 def test_foundation_preserved(self):self.assertAlmostEqual(o.frequency_hz(1),o.C)
 def test_registry(self):self.assertTrue({"OPT-ATM-BEER","OPT-ATM-AIRMASS","OPT-TURB-R0","OPT-TURB-SEEING","OPT-TURB-RYTOV"}<={x.model_id for x in o.OpticalRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-OPT-05")
 def test_rf_complete(self):self.assertEqual(json.loads((R/"RF_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
