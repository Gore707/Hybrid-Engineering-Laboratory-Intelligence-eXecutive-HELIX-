from __future__ import annotations
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget,QVBoxLayout,QHBoxLayout,QPlainTextEdit,QLineEdit,QPushButton,QLabel,
    QTabWidget,QFrame,QTextEdit
)
from core.guardian.voice import recognize_once_windows, speak_windows, VoiceUnavailable

class GuardianConsoleWidget(QWidget):
    """Unified Guardian surface. Console remains the operational command interface;
    additional tabs expose real state only when a backing service exists."""
    TAB_NAMES=("Console","Observations","Intelligence","Memory","Research","Journal","Proposals","Permissions")
    def __init__(self,engine,parent=None,intelligence_service=None):
        super().__init__(parent); self.engine=engine; self.intelligence_service=intelligence_service; self.state_views={}
        self.setObjectName("GuardianSurface")
        outer=QVBoxLayout(self); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)

        header=QFrame(); header.setObjectName("GuardianHeader")
        hl=QHBoxLayout(header);hl.setContentsMargins(10,7,10,7)
        brand=QLabel("GUARDIAN");brand.setObjectName("GuardianBrand")
        self.breadcrumb=QLabel(engine.breadcrumb);self.breadcrumb.setObjectName("GuardianBreadcrumb")
        self.mode=QLabel("C08 · CONTEXTUAL");self.mode.setObjectName("GuardianMode")
        hl.addWidget(brand);hl.addWidget(self.breadcrumb,1);hl.addWidget(self.mode)
        outer.addWidget(header)

        self.tabs=QTabWidget();self.tabs.setObjectName("GuardianTabs")
        outer.addWidget(self.tabs,1)
        self._build_console()
        self._add_state_tab("Observations","No observation stream is active.", "Observation results appear here when produced by registered Guardian/experiment services.")
        self._add_state_tab("Intelligence","Guardian intelligence services are available through the unified command interface.", "Reasoning output remains provenance-aware and subordinate to deterministic controls.")
        self._add_state_tab("Memory","No memory record selected.", "Persistent Guardian knowledge is shown here only when returned by the configured Guardian memory service.")
        self._add_state_tab("Research","No research item selected.", "Open Research Gateway results and cited research artifacts can be surfaced here.")
        self._add_state_tab("Journal","No journal entries in this view.", "Experiment/operator journal entries appear when supplied by the journal service.")
        self._add_state_tab("Proposals","No Guardian proposal selected.", "Guardian self-improvement and workflow proposals require explicit human review before deployment.")
        self._add_state_tab("Permissions","Guardian authority: ADVISORY", "Deterministic safety, hardware interlocks, command permissions and human approval boundaries remain authoritative.")

    def _build_console(self):
        page=QWidget();layout=QVBoxLayout(page);layout.setContentsMargins(9,8,9,8);layout.setSpacing(7)
        self.output=QPlainTextEdit();self.output.setObjectName("GuardianTranscript");self.output.setReadOnly(True)
        self.input=QLineEdit();self.input.setObjectName("GuardianInput")
        self.input.setPlaceholderText("Ask Guardian, choose a menu item, or enter an Expert RUN command…")
        self.send=QPushButton("Execute");self.send.setObjectName("GuardianExecute")
        self.voice=QPushButton("Push to Talk");self.voice.setObjectName("GuardianVoice")
        self.speak=QPushButton("Speak Last");self.speak.setObjectName("GuardianSpeak")
        row=QHBoxLayout();row.addWidget(self.input,1);row.addWidget(self.voice);row.addWidget(self.speak);row.addWidget(self.send)
        layout.addWidget(self.output,1);layout.addLayout(row)
        self.tabs.addTab(page,"Console")
        self.send.clicked.connect(self.execute);self.input.returnPressed.connect(self.execute)
        self.voice.clicked.connect(self.capture_voice);self.speak.clicked.connect(self.speak_last)
        self.append("GUARDIAN",self.engine.render_menu())

    def _add_state_tab(self,name,state,detail):
        page=QWidget();v=QVBoxLayout(page);v.setContentsMargins(14,14,14,14)
        title=QLabel(name.upper());title.setObjectName("GuardianTabTitle")
        status=QLabel(state);status.setObjectName("GuardianState");status.setWordWrap(True)
        note=QLabel(detail);note.setObjectName("GuardianDetail");note.setWordWrap(True)
        view=QPlainTextEdit();view.setReadOnly(True);view.setObjectName("GuardianStateView");view.setVisible(False)
        v.addWidget(title);v.addWidget(status);v.addWidget(note);v.addWidget(view,1);v.addStretch(1)
        self.state_views[name]=(status,note,view)
        self.tabs.addTab(page,name)

    def refresh_intelligence_views(self):
        if self.intelligence_service is None:return
        snap=self.intelligence_service.snapshot()
        import json
        mapping={"Observations":"observations","Memory":"memory","Journal":"journal","Proposals":"proposals"}
        for tab,key in mapping.items():
            status,note,view=self.state_views[tab]
            rows=snap.get(key,[])
            status.setText(f"{len(rows)} record(s) available.")
            view.setPlainText(json.dumps(rows,indent=2,ensure_ascii=False))
            view.setVisible(bool(rows))

    def append(self,source,text):
        self.output.appendPlainText(f"{source.upper()}  ›\n{text}\n")
        bar=self.output.verticalScrollBar();bar.setValue(bar.maximum())

    def execute(self):
        text=self.input.text().strip()
        if not text:return
        self.append("OPERATOR",text);self.input.clear()
        reply=self.engine.handle(text)
        self.breadcrumb.setText(self.engine.breadcrumb)
        self.append("GUARDIAN",reply.text);self.last_guardian_reply=reply.text

    def speak_last(self):
        text=getattr(self,"last_guardian_reply","")
        if not text:return
        try:speak_windows(text)
        except VoiceUnavailable as exc:self.append("VOICE",str(exc))

    def capture_voice(self):
        try:text=recognize_once_windows()
        except VoiceUnavailable as exc:
            self.append("VOICE",str(exc));return
        self.input.setText(text)
        self.append("VOICE",f"Recognized: {text}")
