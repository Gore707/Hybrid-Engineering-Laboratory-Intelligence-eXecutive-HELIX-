from pathlib import Path
from .database import MaterialsDatabase
from .models import *
class MaterialsService:
 def __init__(self,path:Path):self.db=MaterialsDatabase(path)
 def add_material(self,material):self.db.upsert(material);return material.material_id
 def material(self,material_id):return self.db.get(material_id)
 def find(self,query="",phase=None,tag=None):return self.db.search(query,phase,tag)
 def compare_property(self,material_ids,property_id):
  result=[]
  for mid in material_ids:
   for p in self.db.property_series(mid,property_id):
    result.append({"material_id":mid,"property_id":property_id,"value":p.value,"unit":p.unit,
     "condition":p.condition.__dict__,"uncertainty":p.uncertainty,"evidence_class":p.evidence_class,"source_ids":p.source_ids})
  return result

def _set_composition(self,profile):
 self.db.save_composition(profile);return profile.material_id
def _composition(self,material_id):return self.db.load_composition(material_id)
MaterialsService.set_composition=_set_composition
MaterialsService.composition=_composition
