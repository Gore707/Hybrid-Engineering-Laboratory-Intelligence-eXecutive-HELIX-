from __future__ import annotations
from dataclasses import dataclass,field,asdict
from enum import Enum
import math
class MaterialPhase(str,Enum):
 SOLID="SOLID";LIQUID="LIQUID";GAS="GAS";PLASMA="PLASMA";UNKNOWN="UNKNOWN"
@dataclass(frozen=True)
class PropertyCondition:
 temperature_k:float|None=None;pressure_pa:float|None=None;frequency_hz:float|None=None;wavelength_m:float|None=None
 def __post_init__(self):
  for x in (self.temperature_k,self.pressure_pa,self.frequency_hz,self.wavelength_m):
   if x is not None and (not math.isfinite(x) or x<0):raise ValueError("condition values must be finite and nonnegative")
@dataclass(frozen=True)
class PropertyValue:
 property_id:str;value:float;unit:str;condition:PropertyCondition=field(default_factory=PropertyCondition)
 uncertainty:float|None=None;evidence_class:str="UNCLASSIFIED";source_ids:tuple[str,...]=()
 def __post_init__(self):
  if not self.property_id.strip() or not self.unit.strip() or not math.isfinite(float(self.value)):raise ValueError("invalid property")
  if self.uncertainty is not None and (not math.isfinite(self.uncertainty) or self.uncertainty<0):raise ValueError("invalid uncertainty")
@dataclass(frozen=True)
class MaterialRecord:
 material_id:str;name:str;formula:str;phase:MaterialPhase;description:str=""
 tags:tuple[str,...]=();properties:tuple[PropertyValue,...]=();source_ids:tuple[str,...]=();schema_version:str="1.0"
 def __post_init__(self):
  if not self.material_id.strip() or not self.name.strip():raise ValueError("material id and name required")
