import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QCOM"
sp=importlib.util.spec_from_file_location("skl_qcom",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qcom"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_basis_match(self):self.assertEqual(q.basis_match_probability(),.5)
 def test_biased_basis(self):self.assertEqual(q.basis_match_probability(1,1),1)
 def test_sift(self):self.assertEqual(q.sifted_key_rate_bps(1000,.5),500)
 def test_qber(self):self.assertEqual(q.qber(10,100),.1)
 def test_qber_zero(self):self.assertEqual(q.qber(0,0),0)
 def test_noise_qber(self):self.assertEqual(q.qber_from_signal_and_background(0,100),.5)
 def test_secret_zero_error(self):self.assertEqual(q.asymptotic_bb84_secret_fraction(0),1)
 def test_secret_high_error(self):self.assertEqual(q.asymptotic_bb84_secret_fraction(.5),0)
 def test_secret_rate(self):self.assertEqual(q.asymptotic_secret_key_rate_bps(1000,0),500)
 def test_intercept_resend(self):self.assertEqual(q.intercept_resend_qber(1),.25)
 def test_half_intercept(self):self.assertEqual(q.intercept_resend_qber(.5),.125)
 def test_wcp_rate(self):self.assertAlmostEqual(q.expected_detected_rate_per_s(1e6,.1,.5,.8),1e6*(1-math.exp(-.04)))
 def test_link(self):
  x=q.BB84Link(1e6,.1,.5,.8,background_rate_per_s=100,intrinsic_signal_error=.01)
  self.assertGreater(x.signal_detection_rate_per_s,0);self.assertGreater(x.sifted_rate_bps,0);self.assertGreaterEqual(x.idealized_secret_rate_bps,0)
 def test_background_hurts(self):
  a=q.BB84Link(1e6,.1,.5,.8,0,.01);b=q.BB84Link(1e6,.1,.5,.8,10000,.01)
  self.assertGreater(b.qber,a.qber);self.assertLessEqual(b.idealized_secret_fraction,a.idealized_secret_fraction)
 def test_entanglement_preserved(self):self.assertAlmostEqual(q.pure_two_qubit_concurrence(q.bell_state_vector(q.BellState.PHI_PLUS)),1)
 def test_no_signalling_preserved(self):self.assertEqual(q.no_signalling_remote_probability("X"),(.5,.5))
 def test_registry(self):self.assertTrue({"QCOM-BB84-SIFT","QCOM-QBER","QCOM-BB84-SECRET","QCOM-IR-QBER","QCOM-WCP-DETECT"}<={x.model_id for x in q.QuantumCommRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QCOM-03")
 def test_opt_complete(self):self.assertEqual(json.loads((R/"OPT_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
