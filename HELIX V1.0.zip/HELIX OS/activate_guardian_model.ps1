param(
 [Parameter(Mandatory=$true)][string]$ModelPath,
 [string]$ModelName = "Guardian Local Model",
 [int]$Context = 4096,
 [int]$GpuLayers = 0
)
$ErrorActionPreference="Stop"
$root=$PSScriptRoot
$python=Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $python)) { throw "HELIX .venv not found. Install HELIX first." }
if (-not (Test-Path $ModelPath)) { throw "GGUF model not found: $ModelPath" }
& $python (Join-Path $root "GUARDIAN_MODEL_SETUP.py") --model $ModelPath --name $ModelName --context $Context --gpu-layers $GpuLayers
if ($LASTEXITCODE -ne 0) { throw "Guardian model configuration failed." }
$flag=Join-Path $root "user\guardian\autoload_model"
New-Item -ItemType Directory -Force -Path (Split-Path $flag) | Out-Null
Set-Content -Path $flag -Value "operator-enabled" -Encoding ASCII
Write-Host "Guardian model configured for startup loading. GACT-03 benchmark/tuning is still required."
