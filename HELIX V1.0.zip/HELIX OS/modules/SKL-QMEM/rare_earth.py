from __future__ import annotations
from dataclasses import dataclass
import math

C=299792458.0

def afc_echo_time_s(tooth_spacing_hz):
    if tooth_spacing_hz<=0: raise ValueError("positive AFC tooth spacing required")
    return 1/tooth_spacing_hz

def afc_finesse(tooth_spacing_hz,tooth_fwhm_hz):
    if tooth_spacing_hz<=0 or tooth_fwhm_hz<=0: raise ValueError("positive AFC widths required")
    return tooth_spacing_hz/tooth_fwhm_hz

def afc_mode_capacity_estimate(comb_bandwidth_hz,tooth_spacing_hz):
    if comb_bandwidth_hz<0 or tooth_spacing_hz<=0: raise ValueError("invalid AFC bandwidth/spacing")
    return int(math.floor(comb_bandwidth_hz/tooth_spacing_hz))

def afc_forward_efficiency_idealized(optical_depth,finesse):
    if optical_depth<0 or finesse<=0: raise ValueError("invalid optical depth/finesse")
    # Standard idealized Gaussian-tooth forward-AFC form; excludes control transfer,
    # background absorption, propagation imperfections and cavity enhancement.
    d_tilde=optical_depth/finesse
    return d_tilde**2*math.exp(-d_tilde)*math.exp(-7/(finesse**2))

def afc_spin_wave_efficiency(forward_afc_efficiency,control_transfer_efficiency,spin_survival):
    vals=(forward_afc_efficiency,control_transfer_efficiency,spin_survival)
    if any(v<0 or v>1 for v in vals): raise ValueError("efficiency factors must be 0..1")
    # Two control pulses: transfer to spin state and back.
    return forward_afc_efficiency*(control_transfer_efficiency**2)*spin_survival

def lorentzian_coherence_time_s(homogeneous_fwhm_hz):
    if homogeneous_fwhm_hz<=0: raise ValueError("positive homogeneous linewidth required")
    return 1/(math.pi*homogeneous_fwhm_hz)

def spectral_hole_quality_factor(center_frequency_hz,hole_fwhm_hz):
    if center_frequency_hz<=0 or hole_fwhm_hz<=0: raise ValueError("positive frequencies required")
    return center_frequency_hz/hole_fwhm_hz

def wavelength_to_frequency_hz(wavelength_m):
    if wavelength_m<=0: raise ValueError("positive wavelength required")
    return C/wavelength_m

def telecom_band_relevance(wavelength_m,lower_m=1260e-9,upper_m=1675e-9):
    if wavelength_m<=0 or lower_m<=0 or upper_m<=lower_m: raise ValueError("invalid wavelength/band")
    return lower_m<=wavelength_m<=upper_m

@dataclass(frozen=True)
class RareEarthTransition:
    ion:str
    host:str
    wavelength_m:float
    homogeneous_fwhm_hz:float
    inhomogeneous_fwhm_hz:float
    def __post_init__(self):
        if not self.ion.strip() or not self.host.strip() or self.wavelength_m<=0 or self.homogeneous_fwhm_hz<=0 or self.inhomogeneous_fwhm_hz<=0:
            raise ValueError("invalid transition parameters")
        if self.inhomogeneous_fwhm_hz<self.homogeneous_fwhm_hz:
            raise ValueError("inhomogeneous linewidth must not be smaller than homogeneous linewidth")
    @property
    def optical_frequency_hz(self): return wavelength_to_frequency_hz(self.wavelength_m)
    @property
    def coherence_time_s(self): return lorentzian_coherence_time_s(self.homogeneous_fwhm_hz)
    @property
    def inhomogeneous_ratio(self): return self.inhomogeneous_fwhm_hz/self.homogeneous_fwhm_hz
    @property
    def is_in_broad_telecom_window(self): return telecom_band_relevance(self.wavelength_m)

@dataclass(frozen=True)
class AFCMemoryEstimate:
    optical_depth:float
    tooth_spacing_hz:float
    tooth_fwhm_hz:float
    comb_bandwidth_hz:float
    def __post_init__(self):
        if self.optical_depth<0 or self.tooth_spacing_hz<=0 or self.tooth_fwhm_hz<=0 or self.comb_bandwidth_hz<0:
            raise ValueError("invalid AFC parameters")
    @property
    def finesse(self): return afc_finesse(self.tooth_spacing_hz,self.tooth_fwhm_hz)
    @property
    def echo_time_s(self): return afc_echo_time_s(self.tooth_spacing_hz)
    @property
    def temporal_mode_estimate(self): return afc_mode_capacity_estimate(self.comb_bandwidth_hz,self.tooth_spacing_hz)
    @property
    def idealized_forward_efficiency(self): return afc_forward_efficiency_idealized(self.optical_depth,self.finesse)
