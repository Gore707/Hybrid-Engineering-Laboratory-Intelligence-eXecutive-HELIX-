from __future__ import annotations
from dataclasses import dataclass
from .analytics import GuardianAnalytics

@dataclass(frozen=True)
class AnalyticsRequest:
    analysis:str
    metric:str
    values:tuple[float,...]
    reference:tuple[float,...]=()
    provenance:str="SOFTWARE"

class GuardianAnalyticsService:
    def __init__(self):self.engine=GuardianAnalytics();self.last=[]
    def analyze(self,r:AnalyticsRequest):
        if r.analysis=="outliers":result=self.engine.robust_outliers(r.metric,r.values,provenance=r.provenance)
        elif r.analysis=="trend":
            one=self.engine.trend(r.metric,r.values,provenance=r.provenance);result=[one] if one else []
        elif r.analysis=="divergence":
            one=self.engine.divergence(r.metric,r.values,r.reference,provenance=r.provenance);result=[one] if one else []
        else:raise ValueError(f"Unsupported Guardian analysis: {r.analysis}")
        self.last=result;return result
