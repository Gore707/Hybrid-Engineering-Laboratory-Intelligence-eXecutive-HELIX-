from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class CheckResult:
    name: str
    passed: bool
    detail: str

def verify_directory(path: Path) -> CheckResult:
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / ".helix-write-test"
        probe.write_text("HELIX", encoding="utf-8")
        probe.unlink()
        return CheckResult(str(path), True, "writable")
    except Exception as exc:
        return CheckResult(str(path), False, f"{type(exc).__name__}: {exc}")

def run_preflight(root: Path, cfg: dict) -> list[CheckResult]:
    results = []
    for key in ("modules", "data", "projects", "user"):
        results.append(verify_directory(root / cfg["paths"][key]))
    return results
