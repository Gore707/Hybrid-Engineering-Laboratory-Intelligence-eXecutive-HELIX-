from __future__ import annotations
import importlib.util
from .models import BackendCapability

def probe_backends(devices):
    ids=lambda vendor:tuple(d.device_id for d in devices if d.vendor==vendor and d.kind=="GPU")
    caps=[BackendCapability("numpy",True,"CPU numerical backend available.",tuple(d.device_id for d in devices if d.kind=="CPU"))]
    cuda_ids=ids("NVIDIA")
    cuda_runtime=importlib.util.find_spec("cupy") is not None
    caps.append(BackendCapability("cuda",bool(cuda_ids and cuda_runtime),
        "CuPy and NVIDIA device detected." if cuda_ids and cuda_runtime else
        "Requires both an NVIDIA GPU and CuPy runtime.",cuda_ids if cuda_runtime else ()))
    amd_ids=ids("AMD")
    torch_available=importlib.util.find_spec("torch") is not None
    rocm_detected=any(d.backend=="rocm" for d in devices if d.vendor=="AMD")
    caps.append(BackendCapability("rocm",bool(amd_ids and rocm_detected and torch_available),
        "AMD ROCm device and PyTorch runtime detected." if amd_ids and rocm_detected and torch_available else
        "Requires an AMD ROCm device and compatible PyTorch runtime.",amd_ids if rocm_detected and torch_available else ()))
    return tuple(caps)
