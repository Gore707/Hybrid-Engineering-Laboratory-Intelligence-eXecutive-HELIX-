import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-STO";sp=importlib.util.spec_from_file_location("skl_sto",M/"__init__.py",submodule_search_locations=[str(M)]);s=importlib.util.module_from_spec(sp);sys.modules["skl_sto"]=s;sp.loader.exec_module(s)
class T(unittest.TestCase):
 def test_barrier(self):self.assertAlmostEqual(s.anisotropy_energy_barrier_j(1e6,1e-24),1e-18,places=30)
 def test_stability(self):self.assertGreater(s.thermal_stability_factor(1e6,1e-24,300),200)
 def test_retention_inverse(self):
  d=s.required_stability_factor(1e9,1e-9);self.assertAlmostEqual(s.neel_arrhenius_retention_s(1e-9,d),1e9,places=3)
 def test_cell_density(self):self.assertAlmostEqual(s.MagneticBitCell(10e-9,20e-9).areal_bit_density_m2/5e15,1.0,places=12)
 def test_array(self):
  a=s.MagneticArray(100e-9,100e-9,2,s.MagneticBitCell(10e-9,10e-9),.1);c=a.capacity();self.assertEqual(a.cell_count,200);self.assertEqual(c.raw_bits,200);self.assertEqual(c.usable_bits,180)
 def test_tmr(self):self.assertEqual(s.tunneling_magnetoresistance_ratio(100,200),1)
 def test_margin(self):self.assertEqual(s.read_margin_ohm(100,180),80)
 def test_topological(self):self.assertEqual(s.TopologicalStateModel(4).ideal_bits_per_site,2)
 def test_invalid_temp(self):
  with self.assertRaises(ValueError):s.thermal_stability_factor(1,1,0)
 def test_registry(self):self.assertEqual(s.StorageRegistry().get("STO-MAG-STABILITY").evidence_class,"ESTABLISHED_PHYSICS")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-STO-06")
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
