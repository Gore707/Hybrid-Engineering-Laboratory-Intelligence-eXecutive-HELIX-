from __future__ import annotations
from dataclasses import dataclass
import math

def transmission_from_optical_depth(optical_depth):
    if optical_depth<0: raise ValueError("optical depth nonnegative")
    return math.exp(-optical_depth)

def optical_depth_from_transmission(transmission):
    if not 0<transmission<=1: raise ValueError("transmission in (0,1]")
    return -math.log(transmission)

def beer_lambert_transmission(extinction_coefficient_per_m,path_m):
    if extinction_coefficient_per_m<0 or path_m<0: raise ValueError("nonnegative extinction/path")
    return math.exp(-extinction_coefficient_per_m*path_m)

def plane_parallel_airmass(zenith_angle_rad):
    if not 0<=zenith_angle_rad<math.pi/2: raise ValueError("zenith angle [0,pi/2)")
    return 1/math.cos(zenith_angle_rad)

def slant_optical_depth(vertical_optical_depth,zenith_angle_rad):
    if vertical_optical_depth<0: raise ValueError("optical depth nonnegative")
    return vertical_optical_depth*plane_parallel_airmass(zenith_angle_rad)

def fried_parameter_m(wavelength_m,integrated_cn2_m13):
    if wavelength_m<=0 or integrated_cn2_m13<=0: raise ValueError("positive wavelength/integrated Cn2 required")
    k=2*math.pi/wavelength_m
    return (0.423*k*k*integrated_cn2_m13)**(-3/5)

def seeing_fwhm_rad(wavelength_m,r0_m):
    if wavelength_m<=0 or r0_m<=0: raise ValueError("positive wavelength/r0")
    return 0.98*wavelength_m/r0_m

def greenwood_coherence_time_s(r0_m,effective_wind_m_s):
    if r0_m<=0 or effective_wind_m_s<=0: raise ValueError("positive r0/wind")
    return 0.314*r0_m/effective_wind_m_s

def rytov_variance_plane_wave(cn2_m_2_3,wavenumber_rad_m,path_m):
    if cn2_m_2_3<0 or wavenumber_rad_m<=0 or path_m<0: raise ValueError("invalid Rytov inputs")
    return 1.23*cn2_m_2_3*wavenumber_rad_m**(7/6)*path_m**(11/6)

def weak_scintillation_index_from_rytov(rytov_variance):
    if rytov_variance<0: raise ValueError("variance nonnegative")
    return rytov_variance

def turbulence_beam_radius_rss_m(diffraction_radius_m,seeing_angle_rad,distance_m):
    if diffraction_radius_m<0 or seeing_angle_rad<0 or distance_m<0: raise ValueError("nonnegative inputs")
    turb=seeing_angle_rad*distance_m
    return math.sqrt(diffraction_radius_m**2+turb**2)

def atmospheric_loss_db(transmission):
    if not 0<transmission<=1: raise ValueError("transmission in (0,1]")
    return -10*math.log10(transmission)

@dataclass(frozen=True)
class GroundSpaceAtmosphere:
    wavelength_m:float
    vertical_optical_depth:float
    zenith_angle_rad:float
    integrated_cn2_m13:float|None=None
    effective_wind_m_s:float|None=None
    def __post_init__(self):
        if self.wavelength_m<=0 or self.vertical_optical_depth<0 or not 0<=self.zenith_angle_rad<math.pi/2:
            raise ValueError("invalid atmosphere")
        if self.integrated_cn2_m13 is not None and self.integrated_cn2_m13<=0: raise ValueError("integrated Cn2 positive")
        if self.effective_wind_m_s is not None and self.effective_wind_m_s<=0: raise ValueError("wind positive")
    @property
    def airmass(self): return plane_parallel_airmass(self.zenith_angle_rad)
    @property
    def slant_optical_depth(self): return slant_optical_depth(self.vertical_optical_depth,self.zenith_angle_rad)
    @property
    def transmission(self): return transmission_from_optical_depth(self.slant_optical_depth)
    @property
    def loss_db(self): return atmospheric_loss_db(self.transmission)
    @property
    def r0_m(self):
        return None if self.integrated_cn2_m13 is None else fried_parameter_m(self.wavelength_m,self.integrated_cn2_m13)
    @property
    def seeing_fwhm_rad(self):
        return None if self.r0_m is None else seeing_fwhm_rad(self.wavelength_m,self.r0_m)
    @property
    def coherence_time_s(self):
        return None if self.r0_m is None or self.effective_wind_m_s is None else greenwood_coherence_time_s(self.r0_m,self.effective_wind_m_s)
