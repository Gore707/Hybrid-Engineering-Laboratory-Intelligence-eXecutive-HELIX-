"""HELIX UI shell — SKL-CORE-C02."""
