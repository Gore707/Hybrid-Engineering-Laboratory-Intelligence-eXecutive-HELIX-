from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
class MemoryClass(str,Enum):
 QUANTUM="QUANTUM";HYBRID="HYBRID"
class StateKind(str,Enum):
 QUBIT="QUBIT";QUDIT="QUDIT";PHOTONIC_MODE="PHOTONIC_MODE";COLLECTIVE_EXCITATION="COLLECTIVE_EXCITATION"
class Operation(str,Enum):
 PREPARE="PREPARE";WRITE="WRITE";STORE="STORE";READ="READ";RETRIEVE="RETRIEVE";RESET="RESET"
@dataclass(frozen=True)
class QuantumStateDescriptor:
 state_id:str;kind:StateKind;dimension:int;evidence_ids:tuple[str,...]=();source_ids:tuple[str,...]=()
 def __post_init__(self):
  if not self.state_id.strip() or self.dimension<2:raise ValueError("valid state id and Hilbert dimension >=2 required")
@dataclass(frozen=True)
class CoherenceRecord:
 t1_s:float|None=None;t2_s:float|None=None;temperature_k:float|None=None
 def __post_init__(self):
  for x in (self.t1_s,self.t2_s,self.temperature_k):
   if x is not None and (x<=0 or not math.isfinite(x)):raise ValueError("coherence/environment values positive finite")
@dataclass(frozen=True)
class MemoryProtocol:
 name:str;operations:tuple[Operation,...]
 def __post_init__(self):
  if not self.name.strip() or not self.operations:raise ValueError("protocol requires name and operations")
 def has_storage_cycle(self):
  o=self.operations
  return Operation.WRITE in o and Operation.RETRIEVE in o and o.index(Operation.WRITE)<o.index(Operation.RETRIEVE)
@dataclass(frozen=True)
class MemoryPerformance:
 write_efficiency:float;retrieval_efficiency:float;fidelity:float
 def __post_init__(self):
  if any(not 0<=x<=1 for x in (self.write_efficiency,self.retrieval_efficiency,self.fidelity)):raise ValueError("performance fractions 0..1")
 @property
 def end_to_end_efficiency(self):return self.write_efficiency*self.retrieval_efficiency
def pure_state_fidelity(overlap_magnitude):
 if not 0<=overlap_magnitude<=1:raise ValueError("overlap magnitude 0..1")
 return overlap_magnitude**2
def exponential_coherence_survival(storage_time_s,coherence_time_s):
 if storage_time_s<0 or coherence_time_s<=0:raise ValueError("invalid times")
 return math.exp(-storage_time_s/coherence_time_s)
def coherence_limited_fidelity(initial_fidelity,storage_time_s,coherence_time_s,floor=0.5):
 if not 0<=floor<=initial_fidelity<=1:raise ValueError("invalid fidelity bounds")
 s=exponential_coherence_survival(storage_time_s,coherence_time_s)
 return floor+(initial_fidelity-floor)*s
def no_cloning_guard(copies_requested,unknown_quantum_state=True):
 if unknown_quantum_state and copies_requested>1:raise ValueError("arbitrary unknown quantum states cannot be perfectly cloned")
 if copies_requested<1:raise ValueError("at least one output required")
 return True
def classical_metadata_record(state):
 return {"state_id":state.state_id,"kind":state.kind.value,"dimension":state.dimension,
         "evidence_ids":list(state.evidence_ids),"source_ids":list(state.source_ids)}
