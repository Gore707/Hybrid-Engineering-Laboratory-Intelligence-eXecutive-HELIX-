from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import binary_entropy_bits

def poisson_photon_probability(mu,n):
    if mu<0 or n<0 or int(n)!=n: raise ValueError("mu>=0 and integer n>=0")
    return math.exp(-mu)*mu**int(n)/math.factorial(int(n))

def poisson_vacuum_probability(mu): return poisson_photon_probability(mu,0)
def poisson_single_photon_probability(mu): return poisson_photon_probability(mu,1)
def multiphoton_probability(mu):
    if mu<0: raise ValueError("mu>=0")
    return max(0.0,1-poisson_photon_probability(mu,0)-poisson_photon_probability(mu,1))

def channel_yield_n(n,eta,y0=0.0):
    if n<0 or int(n)!=n or not 0<=eta<=1 or not 0<=y0<=1: raise ValueError("invalid yield inputs")
    # Independent background plus n-photon transmission model.
    return 1-(1-y0)*(1-eta)**int(n)

def coherent_state_gain(mu,eta,y0=0.0):
    if mu<0 or not 0<=eta<=1 or not 0<=y0<=1: raise ValueError("invalid gain inputs")
    # Sum over Poisson photon number analytically.
    return 1-(1-y0)*math.exp(-eta*mu)

def coherent_state_qber(mu,eta,y0=0.0,intrinsic_error=0.0):
    if mu<0 or not 0<=eta<=1 or not 0<=y0<=1 or not 0<=intrinsic_error<=.5: raise ValueError("invalid inputs")
    q=coherent_state_gain(mu,eta,y0)
    if q==0:return 0.0
    signal_click=1-math.exp(-eta*mu)
    return min(.5,(.5*y0+intrinsic_error*signal_click)/q)

def vacuum_weak_single_photon_yield_lower(mu,nu,q_mu,q_nu,y0):
    """Common asymptotic vacuum+weak decoy lower bound for Y1, with mu>nu>0."""
    if not mu>nu>0 or not all(0<=x<=1 for x in (q_mu,q_nu,y0)): raise ValueError("require mu>nu>0 and gains in [0,1]")
    denom=mu*nu-mu*nu**2/mu
    term=q_nu*math.exp(nu)-q_mu*math.exp(mu)*(nu**2/mu**2)-((mu**2-nu**2)/mu**2)*y0
    return min(1.0,max(0.0,mu/denom*term))

def single_photon_gain_lower(mu,y1_lower):
    if mu<0 or not 0<=y1_lower<=1: raise ValueError("invalid inputs")
    return poisson_single_photon_probability(mu)*y1_lower

def single_photon_error_upper(nu,q_nu,e_nu,y0,y1_lower):
    if nu<=0 or not 0<=q_nu<=1 or not 0<=e_nu<=.5 or not 0<=y0<=1 or not 0<y1_lower<=1: raise ValueError("invalid inputs")
    numerator=e_nu*q_nu*math.exp(nu)-.5*y0
    return min(.5,max(0.0,numerator/(nu*y1_lower)))

def error_correction_leak_bits(sifted_bits,qber_value,f_ec=1.16):
    if sifted_bits<0 or not 0<=qber_value<=.5 or f_ec<1: raise ValueError("invalid EC inputs")
    return sifted_bits*f_ec*binary_entropy_bits(qber_value)

def privacy_amplification_fraction_single_photon(e1_upper):
    if not 0<=e1_upper<=.5: raise ValueError("e1 in [0,.5]")
    return max(0.0,1-binary_entropy_bits(e1_upper))

def asymptotic_decoy_secret_rate_per_pulse(q_signal,e_signal,q1_lower,e1_upper,basis_sift_fraction=.5,f_ec=1.16):
    if not all(0<=x<=1 for x in (q_signal,q1_lower,basis_sift_fraction)) or not 0<=e_signal<=.5 or not 0<=e1_upper<=.5 or f_ec<1:
        raise ValueError("invalid secret-rate inputs")
    # GLLP-style asymptotic lower-bound structure for decoy-state BB84.
    return max(0.0,basis_sift_fraction*(q1_lower*(1-binary_entropy_bits(e1_upper))-q_signal*f_ec*binary_entropy_bits(e_signal)))

@dataclass(frozen=True)
class VacuumWeakDecoyExperiment:
    signal_mu:float
    decoy_nu:float
    channel_efficiency:float
    background_yield:float=0.0
    intrinsic_error:float=0.0
    basis_sift_fraction:float=.5
    error_correction_efficiency:float=1.16
    def __post_init__(self):
        if not self.signal_mu>self.decoy_nu>0:raise ValueError("signal_mu > decoy_nu > 0")
        if not all(0<=x<=1 for x in (self.channel_efficiency,self.background_yield,self.basis_sift_fraction)):raise ValueError("probabilities in [0,1]")
        if not 0<=self.intrinsic_error<=.5 or self.error_correction_efficiency<1:raise ValueError("invalid error model")
    @property
    def q_signal(self):return coherent_state_gain(self.signal_mu,self.channel_efficiency,self.background_yield)
    @property
    def q_decoy(self):return coherent_state_gain(self.decoy_nu,self.channel_efficiency,self.background_yield)
    @property
    def e_signal(self):return coherent_state_qber(self.signal_mu,self.channel_efficiency,self.background_yield,self.intrinsic_error)
    @property
    def e_decoy(self):return coherent_state_qber(self.decoy_nu,self.channel_efficiency,self.background_yield,self.intrinsic_error)
    @property
    def y1_lower(self):return vacuum_weak_single_photon_yield_lower(self.signal_mu,self.decoy_nu,self.q_signal,self.q_decoy,self.background_yield)
    @property
    def q1_lower(self):return single_photon_gain_lower(self.signal_mu,self.y1_lower)
    @property
    def e1_upper(self):return single_photon_error_upper(self.decoy_nu,self.q_decoy,self.e_decoy,self.background_yield,self.y1_lower) if self.y1_lower>0 else .5
    @property
    def secret_bits_per_emitted_signal_pulse(self):
        return asymptotic_decoy_secret_rate_per_pulse(self.q_signal,self.e_signal,self.q1_lower,self.e1_upper,self.basis_sift_fraction,self.error_correction_efficiency)
