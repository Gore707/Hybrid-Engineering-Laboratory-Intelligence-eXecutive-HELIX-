from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

class OpticalModulation(str,Enum):
    OOK="OOK"; PPM="PPM"

def bits_per_ppm_symbol(order):
    if order<2 or order&(order-1): raise ValueError("PPM order must be power of two >=2")
    return int(math.log2(order))

def symbol_rate_baud(bit_rate_bps,bits_per_symbol,code_rate=1.0):
    if bit_rate_bps<0 or bits_per_symbol<=0 or not 0<code_rate<=1: raise ValueError("invalid rate inputs")
    return bit_rate_bps/(bits_per_symbol*code_rate)

def ppm_slot_rate_hz(bit_rate_bps,order,code_rate=1.0):
    return symbol_rate_baud(bit_rate_bps,bits_per_ppm_symbol(order),code_rate)*order

def photons_per_information_bit(signal_photon_rate_per_s,bit_rate_bps):
    if signal_photon_rate_per_s<0 or bit_rate_bps<=0: raise ValueError("invalid photon/bit inputs")
    return signal_photon_rate_per_s/bit_rate_bps

def bits_per_detected_photon(bit_rate_bps,detected_signal_photon_rate_per_s):
    if bit_rate_bps<0 or detected_signal_photon_rate_per_s<=0: raise ValueError("invalid photon efficiency inputs")
    return bit_rate_bps/detected_signal_photon_rate_per_s

def q_function(x):
    return 0.5*math.erfc(x/math.sqrt(2))

def ook_ber_awgn(ebn0_linear):
    if ebn0_linear<0: raise ValueError("Eb/N0 nonnegative")
    return q_function(math.sqrt(ebn0_linear))

def ideal_ppm_symbol_error_poisson(order,mean_signal_photons_per_symbol):
    if order<2 or order&(order-1) or mean_signal_photons_per_symbol<0: raise ValueError("invalid PPM inputs")
    # Idealized zero-background direct detection: error only if no signal photon is detected,
    # then the receiver guesses among M slots.
    return (1-1/order)*math.exp(-mean_signal_photons_per_symbol)

def approximate_ppm_ber_from_ser(order,symbol_error_rate):
    b=bits_per_ppm_symbol(order)
    if not 0<=symbol_error_rate<=1: raise ValueError("SER in [0,1]")
    # Random wrong-slot labels: expected Hamming distance b/2.
    return 0.5*symbol_error_rate if b>0 else 0.0

def coding_gain_adjusted_ebn0(ebn0_linear,coding_gain_db):
    if ebn0_linear<0: raise ValueError("Eb/N0 nonnegative")
    return ebn0_linear*10**(coding_gain_db/10)

def packet_error_rate(bit_error_rate,bits_per_packet):
    if not 0<=bit_error_rate<=1 or bits_per_packet<1 or int(bits_per_packet)!=bits_per_packet: raise ValueError("invalid packet inputs")
    return 1-(1-bit_error_rate)**bits_per_packet

def goodput_bps(raw_information_rate_bps,packet_error_probability):
    if raw_information_rate_bps<0 or not 0<=packet_error_probability<=1: raise ValueError("invalid goodput inputs")
    return raw_information_rate_bps*(1-packet_error_probability)

def minimum_nyquist_bandwidth_hz(symbol_rate):
    if symbol_rate<0: raise ValueError("symbol rate nonnegative")
    return symbol_rate/2

@dataclass(frozen=True)
class PhotonStarvedDigitalLink:
    modulation:OpticalModulation
    bit_rate_bps:float
    detected_signal_photon_rate_per_s:float
    code_rate:float=1.0
    ppm_order:int=2
    coding_gain_db:float=0.0
    bits_per_packet:int=1024
    def __post_init__(self):
        if self.bit_rate_bps<=0 or self.detected_signal_photon_rate_per_s<0 or not 0<self.code_rate<=1 or self.bits_per_packet<1:
            raise ValueError("invalid digital link")
        if self.modulation==OpticalModulation.PPM: bits_per_ppm_symbol(self.ppm_order)
    @property
    def photons_per_bit(self): return photons_per_information_bit(self.detected_signal_photon_rate_per_s,self.bit_rate_bps)
    @property
    def photon_efficiency_bits_per_photon(self):
        return math.inf if self.detected_signal_photon_rate_per_s==0 else bits_per_detected_photon(self.bit_rate_bps,self.detected_signal_photon_rate_per_s)
    @property
    def symbol_rate(self):
        return self.bit_rate_bps/self.code_rate if self.modulation==OpticalModulation.OOK else symbol_rate_baud(self.bit_rate_bps,bits_per_ppm_symbol(self.ppm_order),self.code_rate)
    @property
    def slot_rate(self):
        return self.symbol_rate if self.modulation==OpticalModulation.OOK else self.symbol_rate*self.ppm_order
    @property
    def ideal_ppm_ser(self):
        if self.modulation!=OpticalModulation.PPM:return None
        photons_per_symbol=self.detected_signal_photon_rate_per_s/self.symbol_rate
        return ideal_ppm_symbol_error_poisson(self.ppm_order,photons_per_symbol)
    @property
    def ideal_ppm_ber(self):
        return None if self.ideal_ppm_ser is None else approximate_ppm_ber_from_ser(self.ppm_order,self.ideal_ppm_ser)
    @property
    def packet_error(self):
        if self.ideal_ppm_ber is None:return None
        return packet_error_rate(self.ideal_ppm_ber,self.bits_per_packet)
    @property
    def goodput(self):
        return None if self.packet_error is None else goodput_bps(self.bit_rate_bps,self.packet_error)
