import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HQIC"
sp=importlib.util.spec_from_file_location("skl_hqic",M/"__init__.py",submodule_search_locations=[str(M)])
h=importlib.util.module_from_spec(sp);sys.modules["skl_hqic"]=h;sp.loader.exec_module(h)
class T(unittest.TestCase):
 def layer(self,i,role,t=1e-3,n=None):return h.LayerGeometry(i,role,t,.1,.05,n)
 def stack(self):
  return h.CartridgeStack("GEN-I",[self.layer("glass",h.PhysicalLayerRole.CLASSICAL_5D_ARCHIVE),
   self.layer("q",h.PhysicalLayerRole.QUANTUM_ACTIVE),self.layer("opt",h.PhysicalLayerRole.OPTICAL_COUPLING),
   self.layer("ctl",h.PhysicalLayerRole.CONTROLLER_INTERFACE)])
 def test_volume(self):self.assertAlmostEqual(self.layer("x",h.PhysicalLayerRole.PROTECTIVE).volume_m3,5e-6)
 def test_stack_thickness(self):self.assertAlmostEqual(self.stack().total_thickness_m,4e-3)
 def test_hybrid_valid(self):self.assertEqual(self.stack().validate_hybrid_stack(),(True,()))
 def test_missing_quantum(self):
  s=h.CartridgeStack("x",[self.layer("g",h.PhysicalLayerRole.CLASSICAL_5D_ARCHIVE)]);self.assertFalse(s.validate_hybrid_stack()[0])
 def test_duplicate_layer(self):
  with self.assertRaises(ValueError):h.CartridgeStack("x",[self.layer("a",h.PhysicalLayerRole.PROTECTIVE),self.layer("a",h.PhysicalLayerRole.PROTECTIVE)])
 def test_footprint_guard(self):
  a=self.layer("a",h.PhysicalLayerRole.PROTECTIVE);b=h.LayerGeometry("b",h.PhysicalLayerRole.PROTECTIVE,1e-3,.2,.05)
  with self.assertRaises(ValueError):h.CartridgeStack("x",[a,b])
 def test_fresnel_equal(self):self.assertEqual(h.OpticalInterface("a","b",1.5,1.5).normal_incidence_reflectance,0)
 def test_fresnel_transmission(self):
  x=h.OpticalInterface("a","b",1,1.5);self.assertAlmostEqual(x.normal_incidence_reflectance+x.ideal_transmittance,1)
 def test_spot(self):self.assertAlmostEqual(h.diffraction_limited_spot_radius_m(500e-9,1),305e-9)
 def test_axial(self):self.assertGreater(h.axial_confocal_scale_m(500e-9,1.5,.8),0)
 def test_addressing(self):self.assertEqual(h.layer_address_capacity(.01,.01,.001,.001),100)
 def test_attenuation(self):self.assertAlmostEqual(h.attenuation_transmission(1,1),math.exp(-1))
 def test_isolation_pass(self):self.assertTrue(h.IsolationRequirement("thermal",.01,.005).passes)
 def test_isolation_fail(self):self.assertFalse(h.IsolationRequirement("optical",.01,.02).passes)
 def test_hqic01_capacity_guard(self):
  with self.assertRaises(ValueError):h.aggregate_capacity_same_domain([h.Capacity(1,h.InformationDomain.CLASSICAL,"bit"),h.Capacity(1,h.InformationDomain.QUANTUM,"qubit")])
 def test_registry(self):self.assertTrue({"HQIC-LAYER-VOLUME","HQIC-OPT-FRESNEL","HQIC-OPT-SPOT","HQIC-LAYER-ADDR","HQIC-OPT-ATTEN"}<={x.model_id for x in h.HQICRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HQIC-02")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO","SKL-QMEM"])
 def test_qmem_complete(self):self.assertTrue((R/"QMEM_COMPLETE.json").exists())
 def test_core_manifest_root(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists())
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
