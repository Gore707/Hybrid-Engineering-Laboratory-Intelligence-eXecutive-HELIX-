import tempfile,unittest
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.design import *
from core.design.report import engineering_readiness_report
ROOT=Path(__file__).resolve().parents[1]
def component(cid="C1"):
 return Component(cid,"Laser","OPTICAL_SOURCE",{"power":Parameter("power",10.0,"W","design input")},
  ["MODEL-ARCH-PHOTON-ENERGY-001"],["EQ-ARCH-PHOTON-ENERGY-001"],"ESTABLISHED_PHYSICS",["SRC-1"])
class C18Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C18")
 def test_design_type_validation(self):
  with self.assertRaises(DesignValidationError):DesignStudio().new("x","MAGIC")
 def test_component_and_connection(self):
  s=DesignStudio();d=s.new("Optical Link","COMMUNICATIONS");s.add_component(d,component("A"));s.add_component(d,component("B"))
  s.connect(d,Connection("A","out","B","in","optical"));self.assertEqual(len(d.connections),1)
 def test_missing_connection_endpoint(self):
  s=DesignStudio();d=s.new("x","CUSTOM");s.add_component(d,component())
  with self.assertRaises(DesignValidationError):s.connect(d,Connection("C1","o","NO","i","x"))
 def test_readiness(self):
  s=DesignStudio();d=s.new("x","PHOTONIC");s.add_component(d,component());r=s.analysis_readiness(d)
  self.assertEqual(r["physics_coverage"],1);self.assertEqual(r["evidence_coverage"],1);self.assertEqual(r["provenance_coverage"],1)
 def test_save_load(self):
  with tempfile.TemporaryDirectory() as td:
   s=DesignStudio();d=s.new("Quantum Memory","QUANTUM_MEMORY");d.requirements.append(Requirement("REQ-1","Store optical state"))
   s.add_component(d,component());p=Path(td)/"design.helix.json";s.save(d,p);q=s.load(p)
   self.assertEqual(q.name,"Quantum Memory");self.assertEqual(q.components["C1"].parameters["power"].unit,"W")
 def test_refuse_incomplete_save(self):
  with tempfile.TemporaryDirectory() as td:
   s=DesignStudio();d=s.new("Empty","CUSTOM")
   with self.assertRaises(DesignValidationError):s.save(d,Path(td)/"x.json")
 def test_report(self):
  s=DesignStudio();d=s.new("x","STORAGE");s.add_component(d,component())
  self.assertIn("Structural validation: PASS",engineering_readiness_report(s,d))
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
