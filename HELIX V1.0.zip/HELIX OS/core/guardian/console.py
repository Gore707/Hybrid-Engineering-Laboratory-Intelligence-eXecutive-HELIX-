from __future__ import annotations
import shlex
from dataclasses import dataclass
from typing import Callable

from core.commands import CommandRequest, CommandContext
from .menu import ROOT_MENU, MenuNode, find_child
from .nlu import RuleBasedInterpreter
from .workflow import GuidedWorkflow

@dataclass(frozen=True)
class ConsoleReply:
    ok: bool
    text: str
    kind: str = "INFO"

class GuardianConsoleEngine:
    """Deterministic C07 console.

    Natural-language interpretation is intentionally not claimed here. C07
    provides a complete structured menu and expert-command interface over C06.
    """
    def __init__(self, command_service, context_provider: Callable[[], CommandContext],
                 status_provider: Callable[[], dict], layout_names_provider: Callable[[], list[str]], reasoner=None):
        self.command_service = command_service
        self.context_provider = context_provider
        self.status_provider = status_provider
        self.layout_names_provider = layout_names_provider
        self.stack: list[MenuNode] = [ROOT_MENU]
        self.cancelled = False
        self.interpreter=RuleBasedInterpreter()
        self.workflow=GuidedWorkflow(command_service.registry)
        self.last_interpretation=None
        self.reasoner=reasoner

    @property
    def current(self): return self.stack[-1]

    @property
    def breadcrumb(self):
        return " > ".join(n.title for n in self.stack)

    def render_menu(self) -> str:
        n = self.current
        lines = [self.breadcrumb, "", n.description, ""]
        if n.children:
            lines.extend(f"[{c.key}] {c.title}" for c in n.children)
        else:
            lines.append("No structured actions are registered in this domain.")
        lines += ["", "Navigation: BACK | MAIN | HELP | STATUS | EXPLAIN | LIST | CANCEL",
                  "Expert: RUN <action.id> [key=value ...]"]
        return "\n".join(lines)

    def _run(self, action_id: str, params: dict, confirmed=False):
        req = CommandRequest(
            action_id=action_id, parameters=params,
            context=self.context_provider(), confirmed=confirmed
        )
        r = self.command_service.execute(req)
        detail = ""
        if r.data:
            detail = "\n" + "\n".join(f"{k}: {v}" for k,v in r.data.items())
        return ConsoleReply(r.success, f"{r.status}: {r.message}{detail}",
                            "SUCCESS" if r.success else r.status)

    def _parse_scalar(self, raw: str):
        low=raw.lower()
        if low=="true": return True
        if low=="false": return False
        try: return int(raw)
        except ValueError: pass
        try: return float(raw)
        except ValueError: return raw

    def _expert(self, text: str):
        try: parts=shlex.split(text)
        except ValueError as e: return ConsoleReply(False,f"Parse error: {e}","ERROR")
        if len(parts)<2: return ConsoleReply(False,"Usage: RUN <action.id> [key=value ...]","ERROR")
        aid=parts[1]; params={}; confirmed=False
        for token in parts[2:]:
            if token.upper()=="CONFIRM":
                confirmed=True; continue
            if "=" not in token:
                return ConsoleReply(False,f"Expected key=value, received: {token}","ERROR")
            k,v=token.split("=",1); params[k]=self._parse_scalar(v)
        return self._run(aid,params,confirmed)

    def handle(self, raw: str) -> ConsoleReply:
        text=raw.strip()
        if not text: return ConsoleReply(False,"Enter a command or menu selection.","NOTICE")
        upper=text.upper()

        if self.workflow.state is not None and upper not in {"CANCEL","MAIN","HELP"}:
            try:
                next_prompt=self.workflow.accept(text)
                if next_prompt:
                    return ConsoleReply(True,next_prompt,"WORKFLOW")
                aid,params=self.workflow.consume()
                return self._run(aid,params)
            except Exception as exc:
                return ConsoleReply(False,f"Workflow input rejected: {exc}\n{self.workflow.prompt()}","ERROR")

        if upper=="BACK":
            if len(self.stack)>1: self.stack.pop()
            return ConsoleReply(True,self.render_menu(),"MENU")
        if upper=="MAIN":
            self.stack=[ROOT_MENU]; return ConsoleReply(True,self.render_menu(),"MENU")
        if upper=="HELP":
            return ConsoleReply(True,
                "Select a numbered/lettered menu item, use BACK/MAIN/STATUS/EXPLAIN/LIST/CANCEL, "
                "or execute a registered action with RUN <action.id> key=value.","HELP")
        if upper=="STATUS":
            s=self.status_provider()
            return ConsoleReply(True,"\n".join(f"{k}: {v}" for k,v in s.items()),"STATUS")
        if upper=="EXPLAIN":
            return ConsoleReply(True,f"{self.current.title}: {self.current.description}","INFO")
        if upper=="LIST":
            actions=self.command_service.registry.all()
            return ConsoleReply(True,"\n".join(
                f"{a.action_id} — {a.title}" for a in actions
            ) or "No registered actions.","LIST")
        if upper=="CANCEL":
            self.cancelled=True
            self.workflow.cancel()
            return ConsoleReply(True,"Current console interaction cancelled.","NOTICE")
        if upper.startswith("RUN "):
            return self._expert(text)

        child=find_child(self.current,upper)
        if child:
            # Operational leaf bindings in C07.
            if self.current.key=="12" and child.key=="C":
                return self._run("workspace.reset",{})
            if self.current.key=="15" and child.key=="A":
                return self._run("session.checkpoint",{})
            if self.current.key=="15" and child.key=="B":
                return self.handle("STATUS")
            self.stack.append(child)
            return ConsoleReply(True,self.render_menu(),"MENU")

        interpretation=self.interpreter.interpret(text,self.layout_names_provider())
        self.last_interpretation=interpretation
        if interpretation.matched:
            action=self.command_service.registry.get(interpretation.action_id)
            missing=[
                p.name for p in action.parameters
                if p.required and p.default is None and p.name not in (interpretation.parameters or {})
            ]
            if missing:
                prompt=self.workflow.start(interpretation.action_id)
                return ConsoleReply(True,prompt,"WORKFLOW")
            return self._run(interpretation.action_id,interpretation.parameters or {})

        if self.reasoner is not None and self.reasoner.ready:
            context="\n".join(f"{k}: {v}" for k,v in self.status_provider().items())
            ai=self.reasoner.answer(text,context)
            if ai.ok:return ConsoleReply(True,ai.text,"INTELLIGENCE")
            return ConsoleReply(False,f"Local Guardian inference failed: {ai.error}","ERROR")
        return ConsoleReply(False,
            f"{interpretation.explanation}\nLocal Guardian model is not loaded. Use HELP or LIST.","ERROR")
