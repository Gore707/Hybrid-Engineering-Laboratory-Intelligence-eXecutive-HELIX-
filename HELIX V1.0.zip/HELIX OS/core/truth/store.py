from __future__ import annotations
import json,os
from pathlib import Path
from .models import *
class TruthStore:
    def __init__(self,path:Path,require_source_for_imported=True,contradiction_tolerance=1e-9):
        self.path=path;self.require_source=require_source_for_imported;self.tol=contradiction_tolerance
        self.sources={};self.records={};self.edges=[]
        if path.exists():self._load()
    def add_source(self,s:SourceRecord):
        if s.source_id in self.sources:raise ValueError("duplicate source_id")
        self.sources[s.source_id]=s;self.save();return s
    def add_record(self,r:TruthRecord):
        if r.record_id in self.records:raise ValueError("duplicate record_id")
        if self.require_source and r.source_class==SourceClass.IMPORTED and not r.source_ids:
            raise ValueError("IMPORTED truth records require source_ids.")
        missing=[x for x in r.source_ids if x not in self.sources]
        if missing:raise ValueError("unknown source_ids: "+",".join(missing))
        self.records[r.record_id]=r;self.save();return r
    def add_lineage(self,parent_id,child_id,relation):
        if not relation.strip():raise ValueError("relation required")
        e=LineageEdge(parent_id,child_id,relation);self.edges.append(e);self.save();return e
    def lineage(self,node_id):
        return [e for e in self.edges if e.parent_id==node_id or e.child_id==node_id]
    def contradictions(self):
        out=[];groups={}
        for r in self.records.values():
            if r.status!="ACTIVE":continue
            groups.setdefault(r.subject_id,[]).append(r)
        for subject,rs in groups.items():
            for i,a in enumerate(rs):
                for b in rs[i+1:]:
                    if a.value is not None and b.value is not None and a.unit==b.unit:
                        scale=max(1.0,abs(a.value),abs(b.value))
                        if abs(a.value-b.value)>self.tol*scale:
                            out.append(Contradiction(a.record_id,b.record_id,subject,"Conflicting quantitative values in the same unit."))
                    elif a.claim.strip().lower()!=b.claim.strip().lower() and a.confidence>=.8 and b.confidence>=.8:
                        # This is a review flag, not an assertion that either claim is false.
                        out.append(Contradiction(a.record_id,b.record_id,subject,"High-confidence claims differ; human/scientific review required."))
        return out
    def truth_panel(self,subject_id):
        rs=[r for r in self.records.values() if r.subject_id==subject_id and r.status=="ACTIVE"]
        return {"subject_id":subject_id,"records":[r.dict() for r in rs],
                "evidence_composition":{e.value:sum(r.evidence_class==e for r in rs) for e in EvidenceClass},
                "source_composition":{s.value:sum(r.source_class==s for r in rs) for s in SourceClass},
                "contradictions":[c.__dict__ for c in self.contradictions() if c.subject_id==subject_id]}
    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        data={"format_version":"1.0.0","sources":[s.dict() for s in self.sources.values()],
              "records":[r.dict() for r in self.records.values()],"lineage":[e.__dict__ for e in self.edges]}
        tmp=self.path.with_suffix(".tmp");tmp.write_text(json.dumps(data,indent=2),encoding="utf-8");os.replace(tmp,self.path)
    def _load(self):
        d=json.loads(self.path.read_text(encoding="utf-8"))
        for x in d.get("sources",[]):
            x["source_class"]=SourceClass(x["source_class"]);self.sources[x["source_id"]]=SourceRecord(**x)
        for x in d.get("records",[]):
            x["evidence_class"]=EvidenceClass(x["evidence_class"]);x["source_class"]=SourceClass(x["source_class"])
            for k in ("source_ids","model_ids","dataset_ids","experiment_ids","equation_ids"):x[k]=tuple(x.get(k,()))
            self.records[x["record_id"]]=TruthRecord(**x)
        self.edges=[LineageEdge(**x) for x in d.get("lineage",[])]
