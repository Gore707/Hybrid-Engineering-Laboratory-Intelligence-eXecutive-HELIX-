from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
import json,time

@dataclass(frozen=True)
class LocalModelConfig:
    model_path:str
    model_name:str
    context_size:int=4096
    max_tokens:int=512
    temperature:float=0.2
    gpu_layers:int=0
    threads:int|None=None

@dataclass(frozen=True)
class InferenceResult:
    ok:bool
    text:str
    runtime:str
    model_name:str|None
    elapsed_seconds:float
    tokens_per_second:float|None
    error:str|None=None

class LocalLLMRuntime:
    """Permissionless local inference adapter. It produces text only.
    HELIX actions remain exclusively deterministic through CommandService."""
    def __init__(self,config:LocalModelConfig|None=None):
        self.config=config;self._model=None;self.runtime="unavailable";self.last_result=None

    def available(self):
        try:
            import llama_cpp
            return True
        except ImportError:
            return False

    def load(self):
        if not self.config:raise RuntimeError("No local Guardian model configured.")
        path=Path(self.config.model_path)
        if not path.exists():raise FileNotFoundError(f"Guardian model not found: {path}")
        try: from llama_cpp import Llama
        except ImportError as exc:raise RuntimeError("llama-cpp-python is not installed.") from exc
        self._model=Llama(model_path=str(path),n_ctx=self.config.context_size,
                         n_gpu_layers=self.config.gpu_layers,n_threads=self.config.threads,verbose=False)
        self.runtime="llama_cpp";return True

    def unload(self):self._model=None;self.runtime="unavailable"

    def generate(self,prompt,system=None):
        if self._model is None:
            return InferenceResult(False,"","unavailable",self.config.model_name if self.config else None,0,None,
                                   "Local Guardian model is not loaded.")
        start=time.perf_counter()
        messages=[]
        if system:messages.append({"role":"system","content":system})
        messages.append({"role":"user","content":prompt})
        try:
            out=self._model.create_chat_completion(messages=messages,max_tokens=self.config.max_tokens,
                                                    temperature=self.config.temperature)
            text=out["choices"][0]["message"]["content"].strip()
            elapsed=max(time.perf_counter()-start,1e-9)
            usage=out.get("usage",{});n=usage.get("completion_tokens")
            r=InferenceResult(True,text,self.runtime,self.config.model_name,elapsed,(n/elapsed if n else None))
        except Exception as exc:
            r=InferenceResult(False,"",self.runtime,self.config.model_name,time.perf_counter()-start,None,str(exc))
        self.last_result=r;return r

def load_model_config(path:Path):
    if not path.exists():return None
    d=json.loads(path.read_text(encoding="utf-8"))
    return LocalModelConfig(**d)

def save_model_config(path:Path,config:LocalModelConfig):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp");tmp.write_text(json.dumps(asdict(config),indent=2),encoding="utf-8");tmp.replace(path)
