@echo off
setlocal
cd /d "%~dp0"
py -3 HELIX.py
if errorlevel 1 (
    echo.
    echo HELIX exited with an error. Check data\logs and data\crash.
    pause
)
endlocal
