import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HWI"
sp=importlib.util.spec_from_file_location("skl_hwi",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_hwi"]=q;sp.loader.exec_module(q)
def env():return q.OperatingEnvelope("temperature","K",270,330,250,350,5)
class T(unittest.TestCase):
 def test_allow(self):self.assertEqual(q.evaluate_value("D",300,env(),0).decision,q.SafetyDecision.ALLOW)
 def test_soft_hold(self):self.assertEqual(q.evaluate_value("D",340,env(),0).decision,q.SafetyDecision.HOLD)
 def test_hard_shutdown(self):self.assertEqual(q.evaluate_value("D",360,env(),0).decision,q.SafetyDecision.EMERGENCY_SHUTDOWN)
 def test_rate_allow(self):self.assertEqual(q.evaluate_rate("D",300,0,304,1,env()).decision,q.SafetyDecision.ALLOW)
 def test_rate_abort(self):self.assertEqual(q.evaluate_rate("D",300,0,306,1,env()).decision,q.SafetyDecision.ABORT)
 def test_bad_time(self):
  with self.assertRaises(ValueError):q.evaluate_rate("D",1,1,2,1,env())
 def test_watchdog_fresh(self):self.assertEqual(q.watchdog_event("D","T","K",9,10,q.WatchdogPolicy(2)).decision,q.SafetyDecision.ALLOW)
 def test_watchdog_stale(self):self.assertEqual(q.watchdog_event("D","T","K",0,10,q.WatchdogPolicy(2)).decision,q.SafetyDecision.ABORT)
 def test_watchdog_cannot_allow(self):
  with self.assertRaises(ValueError):q.WatchdogPolicy(1,q.SafetyDecision.ALLOW)
 def test_future_telemetry(self):
  with self.assertRaises(ValueError):q.watchdog_event("D","T","K",11,10,q.WatchdogPolicy(2))
 def test_emergency(self):
  calls=[];e=q.EmergencyController((q.FailSafeAction("off","D","power off",lambda:calls.append("off") or "ok"),))
  r=e.execute(1,"test");self.assertEqual(calls,["off"]);self.assertEqual(r["executing_authority"],"DETERMINISTIC_CONTROLLER")
 def test_emergency_continues_after_failure(self):
  calls=[]
  def bad():raise RuntimeError("x")
  e=q.EmergencyController((q.FailSafeAction("a","D","a",bad),q.FailSafeAction("b","D","b",lambda:calls.append("b"))))
  r=e.execute(1,"test");self.assertFalse(r["results"][0][1]);self.assertEqual(calls,["b"])
 def test_guardian_no_override(self):self.assertFalse(q.guardian_can_override_safety())
 def test_authority(self):self.assertNotEqual(q.SafetyAuthority.GUARDIAN_ADVISORY,q.SafetyAuthority.DETERMINISTIC_CONTROLLER)
 def test_coordination_preserved(self):self.assertTrue(hasattr(q,"CoordinatedExecutor"))
 def test_acquisition_preserved(self):self.assertTrue(hasattr(q,"AcquisitionSession"))
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/safety_event.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HWI-07")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
