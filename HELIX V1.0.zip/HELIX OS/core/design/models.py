from __future__ import annotations
from dataclasses import dataclass,field,asdict
@dataclass
class Parameter:
 name:str;value:float|int|str|bool;unit:str|None=None;source:str|None=None
@dataclass
class Requirement:
 requirement_id:str;text:str;kind:str="FUNCTIONAL";target:float|str|None=None;unit:str|None=None
@dataclass
class Component:
 component_id:str;name:str;component_type:str;parameters:dict[str,Parameter]=field(default_factory=dict)
 model_ids:list[str]=field(default_factory=list);equation_ids:list[str]=field(default_factory=list)
 evidence_class:str|None=None;provenance_ids:list[str]=field(default_factory=list)
@dataclass(frozen=True)
class Connection:
 source_component_id:str;source_port:str;target_component_id:str;target_port:str;medium:str
@dataclass
class Design:
 design_id:str;name:str;design_type:str;requirements:list[Requirement]=field(default_factory=list)
 components:dict[str,Component]=field(default_factory=dict);connections:list[Connection]=field(default_factory=list)
 assumptions:list[str]=field(default_factory=list);notes:str="";format_version:str="1.0.0"
