from __future__ import annotations
from dataclasses import dataclass

@dataclass
class WorkflowState:
    action_id:str
    pending:list[str]
    values:dict

class GuidedWorkflow:
    def __init__(self,registry):
        self.registry=registry
        self.state:WorkflowState|None=None

    def start(self,action_id:str):
        action=self.registry.get(action_id)
        pending=[p.name for p in action.parameters if p.required and p.default is None]
        self.state=WorkflowState(action_id,pending,{})
        return self.prompt()

    def prompt(self):
        if not self.state:return None
        if not self.state.pending:return None
        return f"Enter {self.state.pending[0]}:"

    def accept(self,value:str):
        if not self.state or not self.state.pending:
            raise RuntimeError("No workflow input is pending.")
        action=self.registry.get(self.state.action_id)
        name=self.state.pending.pop(0)
        spec=next(p for p in action.parameters if p.name==name)
        converted=value
        if spec.python_type is int: converted=int(value)
        elif spec.python_type is float: converted=float(value)
        elif spec.python_type is bool:
            if value.lower() not in ("true","false"): raise ValueError("Enter true or false.")
            converted=value.lower()=="true"
        spec.validate(converted)
        self.state.values[name]=converted
        return self.prompt()

    def complete(self):
        return bool(self.state and not self.state.pending)

    def consume(self):
        if not self.complete(): raise RuntimeError("Workflow is incomplete.")
        state=self.state; self.state=None
        return state.action_id,state.values

    def cancel(self): self.state=None
