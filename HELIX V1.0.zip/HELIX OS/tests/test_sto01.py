import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-STO"
sp=importlib.util.spec_from_file_location("skl_sto",M/"__init__.py",submodule_search_locations=[str(M)])
s=importlib.util.module_from_spec(sp);sys.modules["skl_sto"]=s;sp.loader.exec_module(s)
class STO01(unittest.TestCase):
 def test_geometry(self):
  g=s.StorageGeometry(.1,.2,.3);self.assertAlmostEqual(g.volume_m3,.006)
 def test_invalid_geometry(self):
  with self.assertRaises(ValueError):s.StorageGeometry(0,1,1)
 def test_medium(self):
  g=s.StorageGeometry(.01,.01,.001);m=s.StorageMedium("M1","Test",s.MediumFamily.GLASS_5D,s.StorageClass.CLASSICAL,g,s.EvidenceClass.DEMONSTRATED_TECH,("SRC1",));self.assertEqual(m.source_ids,("SRC1",))
 def test_density_capacity(self):
  c=s.capacity_from_bit_density(.001,1e12,.1);self.assertEqual(c.raw_bits,1e9);self.assertEqual(c.usable_bits,9e8)
 def test_sites(self):
  c=s.capacity_from_sites(1000,5,.2);self.assertEqual(c.raw_bits,5000);self.assertEqual(c.usable_bits,4000)
 def test_no_quantum_conflation(self):
  g=s.StorageGeometry(1,1,1);m=s.StorageMedium("Q","Q",s.MediumFamily.OTHER,s.StorageClass.QUANTUM,g,s.EvidenceClass.ESTABLISHED_PHYSICS);self.assertEqual(m.storage_class,s.StorageClass.QUANTUM)
 def test_device(self):
  g=s.StorageGeometry(1,1,1);m=s.StorageMedium("M","M",s.MediumFamily.OTHER,s.StorageClass.CLASSICAL,g,s.EvidenceClass.ESTABLISHED_PHYSICS);d=s.StorageDevice("D","Device",m,"SIMULATION");self.assertEqual(d.interface,"SIMULATION")
 def test_registry(self):self.assertEqual(s.StorageRegistry().get("STO-CAP-DENSITY").equation,"C_raw=rho_b V")
 def test_schema(self):
  x=json.loads((R/"core/resources/schemas/storage-medium.schema.json").read_text());self.assertEqual(x["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-STO-01");self.assertEqual(x["dependencies"],["SKL-MAT","SKL-PHO"])
 def test_core_manifest_root(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
