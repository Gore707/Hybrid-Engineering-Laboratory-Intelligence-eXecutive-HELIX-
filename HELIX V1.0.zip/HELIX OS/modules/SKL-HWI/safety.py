from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

class SafetySeverity(str,Enum):
    INFO="INFO"; NOTICE="NOTICE"; WARNING="WARNING"; ERROR="ERROR"; CRITICAL="CRITICAL"; EMERGENCY="EMERGENCY"

class SafetyDecision(str,Enum):
    ALLOW="ALLOW"; HOLD="HOLD"; ABORT="ABORT"; EMERGENCY_SHUTDOWN="EMERGENCY_SHUTDOWN"

class SafetyAuthority(str,Enum):
    DETERMINISTIC_CONTROLLER="DETERMINISTIC_CONTROLLER"
    HARDWARE_INTERLOCK="HARDWARE_INTERLOCK"
    OPERATOR="OPERATOR"
    GUARDIAN_ADVISORY="GUARDIAN_ADVISORY"

@dataclass(frozen=True)
class OperatingEnvelope:
    quantity:str
    unit:str
    soft_min:float|None=None
    soft_max:float|None=None
    hard_min:float|None=None
    hard_max:float|None=None
    max_abs_rate_per_s:float|None=None
    def __post_init__(self):
        if not self.quantity or not self.unit:raise ValueError("quantity/unit required")
        if self.soft_min is not None and self.soft_max is not None and self.soft_min>self.soft_max:raise ValueError("soft range invalid")
        if self.hard_min is not None and self.hard_max is not None and self.hard_min>self.hard_max:raise ValueError("hard range invalid")
        if self.max_abs_rate_per_s is not None and self.max_abs_rate_per_s<0:raise ValueError("rate limit nonnegative")

@dataclass(frozen=True)
class SafetyEvent:
    timestamp_s:float
    device_id:str
    quantity:str
    value:float|None
    unit:str
    severity:SafetySeverity
    decision:SafetyDecision
    authority:SafetyAuthority
    reason:str
    def __post_init__(self):
        if not self.device_id or not self.quantity or not self.unit or not self.reason:raise ValueError("event identity required")

def evaluate_value(device_id,value,envelope,timestamp_s):
    if envelope.hard_min is not None and value<envelope.hard_min or envelope.hard_max is not None and value>envelope.hard_max:
        return SafetyEvent(timestamp_s,device_id,envelope.quantity,value,envelope.unit,SafetySeverity.CRITICAL,
                           SafetyDecision.EMERGENCY_SHUTDOWN,SafetyAuthority.DETERMINISTIC_CONTROLLER,"hard limit exceeded")
    if envelope.soft_min is not None and value<envelope.soft_min or envelope.soft_max is not None and value>envelope.soft_max:
        return SafetyEvent(timestamp_s,device_id,envelope.quantity,value,envelope.unit,SafetySeverity.WARNING,
                           SafetyDecision.HOLD,SafetyAuthority.DETERMINISTIC_CONTROLLER,"soft operating envelope exceeded")
    return SafetyEvent(timestamp_s,device_id,envelope.quantity,value,envelope.unit,SafetySeverity.INFO,
                       SafetyDecision.ALLOW,SafetyAuthority.DETERMINISTIC_CONTROLLER,"within operating envelope")

def evaluate_rate(device_id,previous_value,previous_timestamp_s,value,timestamp_s,envelope):
    if timestamp_s<=previous_timestamp_s:raise ValueError("timestamp must advance")
    if envelope.max_abs_rate_per_s is None:
        return SafetyEvent(timestamp_s,device_id,envelope.quantity,value,envelope.unit,SafetySeverity.INFO,
                           SafetyDecision.ALLOW,SafetyAuthority.DETERMINISTIC_CONTROLLER,"no rate limit declared")
    rate=abs((value-previous_value)/(timestamp_s-previous_timestamp_s))
    if rate>envelope.max_abs_rate_per_s:
        return SafetyEvent(timestamp_s,device_id,envelope.quantity,value,envelope.unit,SafetySeverity.ERROR,
                           SafetyDecision.ABORT,SafetyAuthority.DETERMINISTIC_CONTROLLER,
                           f"rate limit exceeded: {rate:.12g} {envelope.unit}/s")
    return SafetyEvent(timestamp_s,device_id,envelope.quantity,value,envelope.unit,SafetySeverity.INFO,
                       SafetyDecision.ALLOW,SafetyAuthority.DETERMINISTIC_CONTROLLER,"rate within limit")

@dataclass(frozen=True)
class WatchdogPolicy:
    max_telemetry_age_s:float
    action:SafetyDecision=SafetyDecision.ABORT
    def __post_init__(self):
        if self.max_telemetry_age_s<=0:raise ValueError("watchdog age positive")
        if self.action==SafetyDecision.ALLOW:raise ValueError("watchdog action must fail safe")

def watchdog_event(device_id,quantity,unit,last_telemetry_s,now_s,policy):
    age=now_s-last_telemetry_s
    if age<0:raise ValueError("telemetry timestamp is in the future")
    if age>policy.max_telemetry_age_s:
        severity=SafetySeverity.EMERGENCY if policy.action==SafetyDecision.EMERGENCY_SHUTDOWN else SafetySeverity.ERROR
        return SafetyEvent(now_s,device_id,quantity,None,unit,severity,policy.action,
                           SafetyAuthority.DETERMINISTIC_CONTROLLER,f"stale telemetry: age={age:.12g}s")
    return SafetyEvent(now_s,device_id,quantity,None,unit,SafetySeverity.INFO,SafetyDecision.ALLOW,
                       SafetyAuthority.DETERMINISTIC_CONTROLLER,"telemetry fresh")

@dataclass(frozen=True)
class FailSafeAction:
    action_id:str
    device_id:str
    description:str
    command:callable
    def __post_init__(self):
        if not self.action_id or not self.device_id or not self.description or not callable(self.command):raise ValueError("valid fail-safe action required")

class EmergencyController:
    """Deterministic emergency executor. Guardian may request/escalate, never override this authority."""
    def __init__(self,actions):
        self.actions=tuple(actions);self.audit=[]
    def execute(self,timestamp_s,reason,requesting_authority=SafetyAuthority.DETERMINISTIC_CONTROLLER):
        if not reason:raise ValueError("reason required")
        results=[]
        for a in self.actions:
            try:
                result=a.command()
                results.append((a.action_id,True,result))
            except Exception as e:
                results.append((a.action_id,False,str(e)))
        event={"timestamp_s":float(timestamp_s),"reason":reason,"requesting_authority":requesting_authority.value,
               "executing_authority":SafetyAuthority.DETERMINISTIC_CONTROLLER.value,"results":tuple(results)}
        self.audit.append(event)
        return event

def guardian_can_override_safety():return False
