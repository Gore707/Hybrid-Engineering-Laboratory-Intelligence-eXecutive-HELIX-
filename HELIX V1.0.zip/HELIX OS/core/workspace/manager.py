from __future__ import annotations
from pathlib import Path

try:
    from PySide6.QtCore import QByteArray, Qt
    from PySide6.QtWidgets import (
        QDockWidget, QLabel, QMainWindow, QMessageBox,
        QInputDialog, QWidget, QVBoxLayout
    )
except ImportError as exc:
    raise RuntimeError("PySide6 is required for HELIX workspace management.") from exc

from .layout_store import LayoutStore

class WorkspaceManager:
    def __init__(self, window: QMainWindow, user_root: Path):
        self.window = window
        self.store = LayoutStore(user_root)
        self.docks: dict[str, QDockWidget] = {}

        self.window.setDockNestingEnabled(True)
        self.window.setDockOptions(
            QMainWindow.DockOption.AllowNestedDocks |
            QMainWindow.DockOption.AllowTabbedDocks |
            QMainWindow.DockOption.AnimatedDocks
        )

    def create_dock(self, dock_id: str, title: str, message: str,
                    area=Qt.DockWidgetArea.LeftDockWidgetArea) -> QDockWidget:
        dock = QDockWidget(title, self.window)
        dock.setObjectName(dock_id)
        dock.setAllowedAreas(Qt.DockWidgetArea.AllDockWidgetAreas)
        dock.setFeatures(
            QDockWidget.DockWidgetFeature.DockWidgetClosable |
            QDockWidget.DockWidgetFeature.DockWidgetMovable |
            QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        body = QWidget()
        layout = QVBoxLayout(body)
        label = QLabel(message)
        label.setWordWrap(True)
        layout.addWidget(label)
        layout.addStretch(1)
        dock.setWidget(body)
        self.window.addDockWidget(area, dock)
        self.docks[dock_id] = dock
        return dock

    def tabify(self, first_id: str, second_id: str) -> None:
        if first_id in self.docks and second_id in self.docks:
            self.window.tabifyDockWidget(self.docks[first_id], self.docks[second_id])

    def save_layout(self, name: str) -> None:
        geometry = bytes(self.window.saveGeometry()).hex()
        state = bytes(self.window.saveState(1)).hex()
        self.store.put(name, geometry, state)

    def restore_layout(self, name: str) -> bool:
        item = self.store.get(name)
        if not item:
            return False
        try:
            geometry = QByteArray.fromHex(item["geometry"].encode("ascii"))
            state = QByteArray.fromHex(item["state"].encode("ascii"))
            ok_geo = self.window.restoreGeometry(geometry)
            ok_state = self.window.restoreState(state, 1)
            return bool(ok_geo and ok_state)
        except Exception:
            return False

    def restore_last(self) -> bool:
        data = self.store.load()
        name = data.get("last_layout")
        return self.restore_layout(name) if name else False
