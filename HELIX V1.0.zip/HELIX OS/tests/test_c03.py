import json
import os
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from core.bootstrap.config import load_config
from core.bootstrap.identity import IDENTITY
from core.workspace.layout_store import LayoutStore

ROOT = Path(__file__).resolve().parents[1]

class C03Tests(unittest.TestCase):
    def test_identity_and_config(self):
        cfg = load_config(ROOT / "skl.config")
        self.assertEqual(IDENTITY.patch_id, "SKL-CORE-C03")
        self.assertTrue(cfg["workspace"]["allow_floating_docks"])

    def test_layout_store_round_trip(self):
        with tempfile.TemporaryDirectory() as td:
            s = LayoutStore(Path(td))
            s.put("Lab A", "aa", "bb")
            self.assertEqual(s.get("Lab A")["state"], "bb")
            self.assertIn("Lab A", s.names())
            s.delete("Lab A")
            self.assertIsNone(s.get("Lab A"))

    def test_ui_workspace_if_pyside_available(self):
        try:
            from PySide6.QtWidgets import QApplication, QDockWidget
            from core.ui.main_window import HelixMainWindow
        except ImportError:
            self.skipTest("PySide6 not installed in test environment")
        app = QApplication.instance() or QApplication([])
        w = HelixMainWindow(load_config(ROOT/"skl.config"), ROOT)
        self.assertGreaterEqual(len(w.workspace.docks), 4)
        self.assertTrue(all(isinstance(d, QDockWidget) for d in w.workspace.docks.values()))
        w.workspace.save_layout("test-layout")
        self.assertTrue(w.workspace.restore_layout("test-layout"))

if __name__ == "__main__":
    unittest.main()
