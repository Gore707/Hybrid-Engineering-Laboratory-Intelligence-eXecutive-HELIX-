import os
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from core.bootstrap.config import load_config
from core.bootstrap.identity import IDENTITY
from core.persistence.atomic import read_json
from core.persistence.manager import ProjectManager, SessionManager

ROOT = Path(__file__).resolve().parents[1]

class C04Tests(unittest.TestCase):
    def test_identity_config(self):
        cfg = load_config(ROOT/"skl.config")
        self.assertEqual(IDENTITY.patch_id, "SKL-CORE-C04")
        self.assertTrue(cfg["persistence"]["atomic_writes"])

    def test_project_and_experiment_round_trip(self):
        with tempfile.TemporaryDirectory() as td:
            pm = ProjectManager(Path(td)/"projects")
            folder, project = pm.create_project("Photon Test", "C04 test")
            self.assertTrue((folder/"project.helix.json").exists())
            exp = pm.create_experiment(folder, project, "Run One")
            self.assertIn(exp.experiment_id, project.experiments)
            loaded = pm.load_project(folder)
            self.assertEqual(loaded.project_id, project.project_id)
            self.assertIn(exp.experiment_id, loaded.experiments)

    def test_session_and_checkpoint(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            sm = SessionManager(base/"user", base/"recovery")
            session = sm.new_session()
            session.project_path = "X"
            session.dirty = True
            sm.save(session)
            loaded = sm.load_or_create()
            self.assertEqual(loaded.session_id, session.session_id)
            self.assertTrue(loaded.dirty)
            checkpoint = sm.checkpoint(loaded)
            self.assertTrue(checkpoint.exists())
            self.assertEqual(read_json(checkpoint)["resource_type"], "helix_recovery_session")

    def test_ui_construct_if_pyside_available(self):
        try:
            from PySide6.QtWidgets import QApplication
            from core.ui.main_window import HelixMainWindow
        except ImportError:
            self.skipTest("PySide6 not installed in test environment")
        app = QApplication.instance() or QApplication([])
        w = HelixMainWindow(load_config(ROOT/"skl.config"), ROOT)
        self.assertIsNotNone(w.session_manager)
        self.assertTrue(w.autosave_timer.isActive())

if __name__ == "__main__":
    unittest.main()
