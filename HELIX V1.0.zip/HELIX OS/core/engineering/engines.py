from __future__ import annotations
from dataclasses import dataclass
import math
@dataclass(frozen=True)
class ThermalResult:
 conduction_w:float;radiation_w:float;total_heat_w:float
def thermal_steady(k,area,length,t_hot,t_cold,emissivity=0.0,radiating_area=0.0,t_environment=0.0):
 if k<0 or area<0 or length<=0 or not 0<=emissivity<=1:raise ValueError("invalid thermal parameters")
 conduction=k*area*(t_hot-t_cold)/length
 sigma=5.670374419e-8
 radiation=emissivity*sigma*radiating_area*(t_hot**4-t_environment**4)
 return ThermalResult(conduction,radiation,conduction+radiation)
@dataclass(frozen=True)
class TransductionResult:
 total_efficiency:float;output_power_w:float;added_noise_quanta:float
def transduction_chain(input_power_w,efficiencies,added_noise_quanta=0.0):
 if input_power_w<0 or added_noise_quanta<0 or any(x<0 or x>1 for x in efficiencies):raise ValueError("invalid transduction")
 eta=math.prod(efficiencies) if efficiencies else 1.0
 return TransductionResult(eta,input_power_w*eta,added_noise_quanta)
@dataclass(frozen=True)
class DecoherenceResult:
 coherence_fraction:float;survival_probability:float
def decoherence(t,t2,loss_rate=0.0):
 if t<0 or t2<=0 or loss_rate<0:raise ValueError("invalid decoherence")
 return DecoherenceResult(math.exp(-t/t2),math.exp(-loss_rate*t))
@dataclass(frozen=True)
class ClassicalCapacity:
 raw_bytes:float;ecc_overhead_fraction:float;usable_bytes:float
def classical_capacity(raw_bytes,ecc_overhead_fraction):
 if raw_bytes<0 or not 0<=ecc_overhead_fraction<1:raise ValueError("invalid capacity")
 return ClassicalCapacity(raw_bytes,ecc_overhead_fraction,raw_bytes*(1-ecc_overhead_fraction))
@dataclass(frozen=True)
class QuantumCapacity:
 physical_modes:int;interface_efficiency:float;fidelity:float;coherence_seconds:float
def quantum_capacity(physical_modes,interface_efficiency,fidelity,coherence_seconds):
 if physical_modes<0 or not 0<=interface_efficiency<=1 or not 0<=fidelity<=1 or coherence_seconds<0:raise ValueError("invalid quantum capacity")
 return QuantumCapacity(int(physical_modes),interface_efficiency,fidelity,coherence_seconds)
@dataclass(frozen=True)
class ManufacturingResult:
 attempted:int;yield_fraction:float;good_units:float;throughput_good_per_hour:float
def manufacturing(attempted,yield_fraction,hours):
 if attempted<0 or not 0<=yield_fraction<=1 or hours<=0:raise ValueError("invalid manufacturing")
 good=attempted*yield_fraction
 return ManufacturingResult(attempted,yield_fraction,good,good/hours)
@dataclass(frozen=True)
class PowerResult:
 input_w:float;useful_w:float;waste_heat_w:float;energy_j:float
def power_energy(input_w,efficiency,duration_s):
 if input_w<0 or not 0<=efficiency<=1 or duration_s<0:raise ValueError("invalid power")
 useful=input_w*efficiency
 return PowerResult(input_w,useful,input_w-useful,input_w*duration_s)
@dataclass(frozen=True)
class MechanicalResult:
 stress_pa:float;strain:float;safety_factor:float
def uniaxial(load_n,area_m2,youngs_modulus_pa,yield_strength_pa):
 if area_m2<=0 or youngs_modulus_pa<=0 or yield_strength_pa<=0:raise ValueError("invalid mechanical")
 stress=load_n/area_m2
 return MechanicalResult(stress,stress/youngs_modulus_pa,yield_strength_pa/abs(stress) if stress else math.inf)
@dataclass(frozen=True)
class ReliabilityResult:
 survival_probability:float;mtbf_hours:float
def exponential_reliability(failure_rate_per_hour,hours):
 if failure_rate_per_hour<0 or hours<0:raise ValueError("invalid reliability")
 return ReliabilityResult(math.exp(-failure_rate_per_hour*hours),math.inf if failure_rate_per_hour==0 else 1/failure_rate_per_hour)
