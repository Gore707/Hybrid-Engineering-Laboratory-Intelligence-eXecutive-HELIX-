from __future__ import annotations
from dataclasses import dataclass
import re,math
from .atomic import *
_TOKEN=re.compile(r"([A-Z][a-z]?)(\d*(?:\.\d+)?)")
def parse_formula(formula):
 pos=0;counts={}
 for m in _TOKEN.finditer(formula):
  if m.start()!=pos:raise ValueError("unsupported or invalid formula syntax")
  sym,num=m.groups();counts[sym]=counts.get(sym,0.0)+(float(num) if num else 1.0);pos=m.end()
 if pos!=len(formula) or not counts:raise ValueError("invalid formula")
 total=sum(counts.values())
 return tuple(CompositionEntry(k,v/total) for k,v in sorted(counts.items()))
def stoichiometric_counts(formula):
 pos=0;counts={}
 for m in _TOKEN.finditer(formula):
  if m.start()!=pos:raise ValueError("unsupported or invalid formula syntax")
  sym,num=m.groups();counts[sym]=counts.get(sym,0.0)+(float(num) if num else 1.0);pos=m.end()
 if pos!=len(formula) or not counts:raise ValueError("invalid formula")
 return counts
@dataclass(frozen=True)
class CompositionProfile:
 material_id:str;entries:tuple[CompositionEntry,...];dopants:tuple[DopantRecord,...]=();defects:tuple[DefectRecord,...]=()
 def __post_init__(self):
  if not math.isclose(sum(x.atomic_fraction for x in self.entries),1.0,abs_tol=1e-9):raise ValueError("host composition must sum to 1")
  if sum(x.fraction for x in self.dopants)>=1:raise ValueError("total dopant fraction must be < 1")
 def effective_atomic_fractions(self):
  dop=sum(x.fraction for x in self.dopants);host_scale=1-dop
  out={x.element_symbol:x.atomic_fraction*host_scale for x in self.entries}
  for d in self.dopants:out[d.species]=out.get(d.species,0)+d.fraction
  return out
