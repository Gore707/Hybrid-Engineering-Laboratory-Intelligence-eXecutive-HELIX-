import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-OPT"
sp=importlib.util.spec_from_file_location("skl_opt",M/"__init__.py",submodule_search_locations=[str(M)])
o=importlib.util.module_from_spec(sp);sys.modules["skl_opt"]=o;sp.loader.exec_module(o)
class T(unittest.TestCase):
 def test_displacement_zero(self):self.assertEqual(o.angular_to_lateral_displacement_m(0,1e9),0)
 def test_small_angle(self):self.assertAlmostEqual(o.angular_to_lateral_displacement_m(1e-6,1e6),o.small_angle_displacement_m(1e-6,1e6),places=9)
 def test_coupling_zero(self):self.assertEqual(o.gaussian_pointing_coupling(0,1e-6),1)
 def test_coupling_falls(self):self.assertLess(o.gaussian_pointing_coupling(1e-6,1e-6),1)
 def test_loss_zero(self):self.assertEqual(o.gaussian_pointing_loss_db(0,1e-6),0)
 def test_rss(self):self.assertEqual(o.rss_pointing_error_rad(3,4),5)
 def test_rss_empty(self):self.assertEqual(o.rss_pointing_error_rad(),0)
 def test_bias_rms(self):self.assertEqual(o.total_bias_plus_rms_rad(3,4),5)
 def test_ratio(self):self.assertEqual(o.diffraction_to_pointing_ratio(1e-6,2e-6),.5)
 def test_grid_zero_for(self):self.assertEqual(o.acquisition_grid_points(0,1e-6),1)
 def test_grid(self):self.assertEqual(o.acquisition_grid_points(2e-6,1e-6),25)
 def test_scan(self):self.assertAlmostEqual(o.acquisition_scan_time_s(25,.1,.02),3)
 def test_requirement_perfect(self):self.assertEqual(o.max_rms_pointing_for_min_coupling_rad(1,1e-6),0)
 def test_requirement(self):
  x=o.max_rms_pointing_for_min_coupling_rad(.5,1e-6);self.assertAlmostEqual(o.gaussian_pointing_coupling(x,1e-6),.5)
 def test_budget_rss(self):
  b=o.PATBudget(10e-6,3e-6,4e-6);self.assertEqual(b.random_rms_rad,5e-6)
 def test_budget_bias(self):
  b=o.PATBudget(10e-6,3e-6,4e-6,0,12e-6);self.assertAlmostEqual(b.effective_error_rad,13e-6)
 def test_budget_coupling(self):self.assertTrue(0<o.PATBudget(10e-6,1e-6).nominal_coupling<=1)
 def test_budget_loss(self):self.assertGreater(o.PATBudget(10e-6,1e-6).nominal_loss_db,0)
 def test_meets(self):self.assertTrue(o.PATBudget(10e-6,0).meets_coupling(.99))
 def test_invalid(self):
  with self.assertRaises(ValueError):o.gaussian_pointing_coupling(0,0)
 def test_receiver_preserved(self):self.assertGreater(o.telescope_collection_area_m2(1),0)
 def test_transmitter_preserved(self):self.assertGreater(o.rayleigh_range_m(1e-6,1),0)
 def test_foundation_preserved(self):self.assertAlmostEqual(o.frequency_hz(1),o.C)
 def test_registry(self):self.assertTrue({"OPT-PAT-DISPLACE","OPT-PAT-COUPLING","OPT-PAT-RSS","OPT-PAT-GRID","OPT-PAT-REQ"}<={x.model_id for x in o.OpticalRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-OPT-04")
 def test_rf_complete(self):self.assertEqual(json.loads((R/"RF_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
