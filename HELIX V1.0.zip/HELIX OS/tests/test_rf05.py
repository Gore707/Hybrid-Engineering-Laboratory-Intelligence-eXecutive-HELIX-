import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-RF"
sp=importlib.util.spec_from_file_location("skl_rf",M/"__init__.py",submodule_search_locations=[str(M)])
r=importlib.util.module_from_spec(sp);sys.modules["skl_rf"]=r;sp.loader.exec_module(r)
class T(unittest.TestCase):
 def test_photon(self):self.assertAlmostEqual(r.photon_energy_j(1e9),r.H*1e9)
 def test_q(self):self.assertEqual(r.resonator_quality_factor(1e9,1e3),1e6)
 def test_linewidth_inverse(self):self.assertEqual(r.resonator_linewidth_hz(1e9,1e6),1e3)
 def test_coherence(self):self.assertAlmostEqual(r.coherence_time_s(1),1/math.pi)
 def test_decay(self):self.assertAlmostEqual(r.cavity_energy_decay_time_s(2*math.pi,1),1)
 def test_inversion_positive(self):self.assertAlmostEqual(r.population_inversion_fraction(3,1),.5)
 def test_inversion_negative(self):self.assertAlmostEqual(r.population_inversion_fraction(1,3),-.5)
 def test_gain_zero(self):self.assertEqual(r.small_signal_power_gain_linear(0,10),1)
 def test_gain(self):self.assertAlmostEqual(r.small_signal_power_gain_linear(1,1),math.e)
 def test_phase_coherent(self):self.assertAlmostEqual(r.phase_coherence_factor((0,0,0,0)),1)
 def test_phase_cancel(self):self.assertAlmostEqual(r.phase_coherence_factor((0,math.pi)),0,places=12)
 def test_combining_perfect(self):self.assertEqual(r.coherent_combined_power_w(10,(0,0,0,0)),40)
 def test_combining_cancel(self):self.assertAlmostEqual(r.coherent_combined_power_w(10,(0,math.pi)),0,places=12)
 def test_incoherent(self):self.assertEqual(r.incoherent_combined_power_w(10,4),40)
 def test_stability(self):self.assertEqual(r.fractional_frequency_stability(1,1e9),1e-9)
 def test_phase_drift(self):self.assertAlmostEqual(r.phase_drift_rad(1,.5),math.pi)
 def test_frequency_budget(self):self.assertAlmostEqual(r.max_frequency_error_for_phase_budget_hz(math.pi,1),.5)
 def test_maser(self):
  m=r.MaserResonator(10e9,1e7,3,1,.5,2);self.assertEqual(m.linewidth_hz,1000);self.assertAlmostEqual(m.inversion_fraction,.5);self.assertGreater(m.small_signal_gain_linear,1)
 def test_array(self):
  a=r.CoherentMicrowaveArray(100,(0,0,0,0),10e9);self.assertEqual(a.element_count,4);self.assertEqual(a.total_generated_rf_power_w,400);self.assertEqual(a.peak_combined_power_w,400)
 def test_no_energy_creation_claim(self):
  a=r.CoherentMicrowaveArray(100,(0,0,0,0),10e9);self.assertEqual(a.peak_combined_power_w,a.total_generated_rf_power_w)
 def test_invalid_q(self):
  with self.assertRaises(ValueError):r.resonator_quality_factor(1,0)
 def test_frontend_preserved(self):self.assertEqual(r.dc_power_for_rf_output_w(100,.5),200)
 def test_propagation_preserved(self):self.assertAlmostEqual(r.propagation_delay_s(r.C),1)
 def test_registry(self):self.assertTrue({"RF-MASER-PHOTON","RF-RESONATOR-Q","RF-COHERENCE-T","RF-MASER-GAIN","RF-PHASE-COHERENCE","RF-COHERENT-COMBINE"}<={x.model_id for x in r.RFRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-RF-05")
 def test_hqic_complete(self):self.assertEqual(json.loads((R/"HQIC_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
