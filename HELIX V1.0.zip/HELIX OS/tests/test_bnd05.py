import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-BND"
sp=importlib.util.spec_from_file_location("skl_bnd",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_bnd"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_rs_sun(self):self.assertTrue(2900<q.schwarzschild_radius_m(1.98847e30)<3000)
 def test_lapse(self):self.assertTrue(0<q.schwarzschild_lapse(1.98847e30,6.957e8)<1)
 def test_proper_less_coordinate(self):self.assertLess(q.proper_time_static_s(1,1.98847e30,6.957e8),1)
 def test_freq_same_radius(self):self.assertAlmostEqual(q.gravitational_frequency_ratio_static(1e30,1e9,1e9),1)
 def test_redshift_deep_to_far(self):self.assertGreater(q.gravitational_redshift_z(1.98847e30,6.957e8,1.496e11),0)
 def test_shapiro_positive(self):self.assertGreater(q.weak_field_shapiro_delay_s(1.98847e30,1.496e11,1.496e11,6.957e8),0)
 def test_light_time(self):self.assertEqual(q.flat_light_time_s(q.C_M_S),1)
 def test_curved_longer(self):self.assertGreater(q.curved_link_coordinate_time_s(q.C_M_S,1),1)
 def test_horizon(self):
  rs=q.schwarzschild_radius_m(1e30);self.assertTrue(q.outside_schwarzschild_horizon(1e30,rs*2));self.assertFalse(q.outside_schwarzschild_horizon(1e30,rs))
 def test_escape_guard(self):
  rs=q.schwarzschild_radius_m(1e30);self.assertFalse(q.static_escape_signal_possible(1e30,rs*.9))
 def test_no_ftl(self):self.assertFalse(q.curved_spacetime_ftl_information_available())
 def test_link(self):
  l=q.SchwarzschildCommunicationLink(1.98847e30,1.496e11,2.0e11,1e9,6.957e8);self.assertGreaterEqual(l.coordinate_latency_s,l.flat_latency_s);self.assertFalse(l.ftl_information_available)
 def test_invalid_static(self):
  rs=q.schwarzschild_radius_m(1e30)
  with self.assertRaises(ValueError):q.schwarzschild_lapse(1e30,rs)
 def test_qft_preserved(self):self.assertFalse(q.spacelike_vacuum_correlation_implies_controllable_signal())
 def test_dp_preserved(self):self.assertGreaterEqual(q.photon_dark_photon_probability(1e-3,10,1e-3,1),0)
 def test_axion_preserved(self):self.assertGreaterEqual(q.photon_axion_conversion_probability(1e-10,10,10),0)
 def test_registry(self):self.assertTrue({"BND-GR-RS","BND-GR-LAPSE","BND-GR-REDSHIFT","BND-GR-SHAPIRO"}<={x.model_id for x in q.default_registry().all()})
 def test_foundation_guard(self):self.assertFalse(q.established_physics_causality_bypass_available())
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-BND-05")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
