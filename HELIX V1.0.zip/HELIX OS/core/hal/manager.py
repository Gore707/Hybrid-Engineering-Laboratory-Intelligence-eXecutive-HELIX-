from __future__ import annotations
from pathlib import Path
import json,time,os
from .models import *
class HALError(RuntimeError):pass
class HardwareAbstractionLayer:
 def __init__(self,audit_path:Path):
  self.devices={};self.armed=set();self.audit_path=audit_path
 def register(self,device):
  did=device.descriptor.device_id
  if did in self.devices:raise HALError("duplicate device_id")
  self.devices[did]=device;self._audit("REGISTER",did,{"source":device.descriptor.source.value})
 def connect(self,did):
  d=self._get(did);d.connect();self._audit("CONNECT",did,{})
 def disconnect(self,did):
  d=self._get(did);self.armed.discard(did);d.disconnect();self._audit("DISCONNECT",did,{})
 def arm(self,did,confirmation=False):
  d=self._get(did)
  if d.descriptor.source!=HALSource.HARDWARE:raise HALError("arming is reserved for real hardware")
  if not d.descriptor.writable:raise HALError("device is read-only")
  if not confirmation:raise HALError("explicit confirmation required")
  if d.state!=DeviceState.CONNECTED:raise HALError("device must be connected")
  self.armed.add(did);self._audit("ARM",did,{})
 def disarm(self,did):
  self.armed.discard(did);self._audit("DISARM",did,{})
 def read(self,did,channel):
  d=self._get(did)
  try:m=d.read(channel)
  except Exception as e:self._audit("READ_FAIL",did,{"channel":channel,"error":str(e)});raise HALError(str(e)) from e
  if m.source!=d.descriptor.source:raise HALError("measurement source does not match registered device source")
  self._audit("READ",did,{"channel":channel,"source":m.source.value});return m
 def write(self,did,channel,value):
  d=self._get(did)
  if not d.descriptor.writable:raise HALError("device is read-only")
  if d.descriptor.source==HALSource.IMPORTED:raise HALError("imported datasets are immutable through HAL")
  if d.descriptor.source==HALSource.HARDWARE and did not in self.armed:raise HALError("real hardware write requires armed state")
  if not hasattr(d,"write"):raise HALError("device has no write operation")
  try:d.write(channel,value)
  except Exception as e:self._audit("WRITE_FAIL",did,{"channel":channel,"error":str(e)});raise HALError(str(e)) from e
  self._audit("WRITE",did,{"channel":channel,"value":value,"source":d.descriptor.source.value})
 def inventory(self):
  return [{"device_id":d.descriptor.device_id,"name":d.descriptor.name,"source":d.descriptor.source.value,
   "state":d.state.value,"writable":d.descriptor.writable,"armed":d.descriptor.device_id in self.armed}
   for d in self.devices.values()]
 def _get(self,did):
  if did not in self.devices:raise HALError("unknown device")
  return self.devices[did]
 def _audit(self,event,did,detail):
  self.audit_path.parent.mkdir(parents=True,exist_ok=True)
  record={"timestamp_unix":time.time(),"event":event,"device_id":did,"detail":detail}
  with self.audit_path.open("a",encoding="utf-8") as f:f.write(json.dumps(record,separators=(",",":"))+"\n")
