from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import EV_J, directed_flux_per_m2, expected_detected_events_per_s, ideal_event_limited_bit_rate_bps

GEV_EV=1e9
NUCLEON_MASS_KG=1.674e-27

def neutrino_energy_j(energy_gev):
    if energy_gev<=0:raise ValueError("energy positive")
    return energy_gev*GEV_EV*EV_J

def approximate_cc_cross_section_m2(energy_gev,antineutrino=False):
    """Transparent GeV-scale linear deep-inelastic approximation; not for precision work."""
    if energy_gev<=0:raise ValueError("energy positive")
    coefficient_cm2=0.34e-38 if antineutrino else 0.67e-38
    return coefficient_cm2*energy_gev*1e-4

def target_nucleons(detector_mass_kg):
    if detector_mass_kg<0:raise ValueError("mass nonnegative")
    return detector_mass_kg/NUCLEON_MASS_KG

def thin_detector_interaction_probability(cross_section_m2,areal_mass_kg_m2):
    if cross_section_m2<0 or areal_mass_kg_m2<0:raise ValueError("nonnegative inputs")
    column=areal_mass_kg_m2/NUCLEON_MASS_KG
    return 1-math.exp(-cross_section_m2*column)

def oscillation_phase(delta_m2_ev2,baseline_km,energy_gev):
    if baseline_km<0 or energy_gev<=0:raise ValueError("invalid oscillation inputs")
    return 1.267*delta_m2_ev2*baseline_km/energy_gev

def two_flavor_survival_probability(theta_rad,delta_m2_ev2,baseline_km,energy_gev):
    ph=oscillation_phase(delta_m2_ev2,baseline_km,energy_gev)
    return 1-(math.sin(2*theta_rad)**2)*(math.sin(ph)**2)

def beam_radius_m(baseline_m,divergence_rad,source_radius_m=0):
    if baseline_m<0 or divergence_rad<0 or source_radius_m<0:raise ValueError("nonnegative geometry")
    return source_radius_m+baseline_m*divergence_rad

def beam_area_m2(baseline_m,divergence_rad,source_radius_m=0):
    r=beam_radius_m(baseline_m,divergence_rad,source_radius_m)
    return math.pi*r*r

def neutrino_flux_per_m2(production_rate_s,baseline_m,divergence_rad,source_radius_m=0):
    area=beam_area_m2(baseline_m,divergence_rad,source_radius_m)
    if area<=0:raise ValueError("beam area positive")
    return directed_flux_per_m2(production_rate_s,area)

def event_rate_from_detector_mass(flux_m2_s,cross_section_m2,detector_mass_kg,detector_efficiency=1.0):
    if flux_m2_s<0 or cross_section_m2<0 or detector_mass_kg<0 or not 0<=detector_efficiency<=1:
        raise ValueError("invalid detector inputs")
    return flux_m2_s*cross_section_m2*target_nucleons(detector_mass_kg)*detector_efficiency

def on_off_keying_ideal_rate_bps(signal_events_s,background_events_s,required_sigma=5,window_s=1):
    if signal_events_s<0 or background_events_s<0 or required_sigma<=0 or window_s<=0:raise ValueError("invalid modulation")
    s=signal_events_s*window_s;b=background_events_s*window_s
    snr=0 if s+b==0 else s/math.sqrt(s+b)
    return (1/window_s) if snr>=required_sigma else 0.0

def wall_power_w(production_rate_s,energy_gev,source_efficiency):
    if production_rate_s<0 or not 0<source_efficiency<=1:raise ValueError("invalid source")
    return production_rate_s*neutrino_energy_j(energy_gev)/source_efficiency

@dataclass(frozen=True)
class NeutrinoLink:
    energy_gev:float
    production_rate_s:float
    baseline_m:float
    divergence_rad:float
    detector_mass_kg:float
    detector_efficiency:float=1.0
    events_per_bit:float=10.0
    antineutrino:bool=False
    source_radius_m:float=0.0
    def __post_init__(self):
        if self.energy_gev<=0 or self.production_rate_s<0 or self.baseline_m<=0 or self.divergence_rad<=0 or self.detector_mass_kg<0:
            raise ValueError("invalid link")
        if not 0<=self.detector_efficiency<=1 or self.events_per_bit<=0:raise ValueError("invalid efficiency/rate")
    @property
    def cross_section_m2(self):return approximate_cc_cross_section_m2(self.energy_gev,self.antineutrino)
    @property
    def beam_area_m2(self):return beam_area_m2(self.baseline_m,self.divergence_rad,self.source_radius_m)
    @property
    def flux_per_m2_s(self):return neutrino_flux_per_m2(self.production_rate_s,self.baseline_m,self.divergence_rad,self.source_radius_m)
    @property
    def detected_events_s(self):return event_rate_from_detector_mass(self.flux_per_m2_s,self.cross_section_m2,self.detector_mass_kg,self.detector_efficiency)
    @property
    def ideal_bit_rate_bps(self):return ideal_event_limited_bit_rate_bps(self.detected_events_s,self.events_per_bit)
