import unittest,importlib.util,sys,json,math,numpy as np
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM"
sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_entanglement_identity(self):
  rho=np.eye(2)/2;self.assertAlmostEqual(q.entanglement_fidelity_from_kraus(rho,[np.eye(2)]),1)
 def test_average_gate(self):self.assertEqual(q.average_gate_fidelity_from_entanglement_fidelity(1,2),1)
 def test_rep_d3(self):self.assertAlmostEqual(q.majority_vote_logical_error_probability(.1,3),.028)
 def test_rep_d5_improves(self):self.assertLess(q.majority_vote_logical_error_probability(.1,5),.1)
 def test_even_distance_rejected(self):
  with self.assertRaises(ValueError):q.majority_vote_logical_error_probability(.1,4)
 def test_syndrome(self):self.assertEqual(q.repetition_syndrome((0,1,0)),(1,1))
 def test_decode_zero(self):self.assertEqual(q.repetition_decode((0,1,0)),0)
 def test_decode_one(self):self.assertEqual(q.repetition_decode((1,0,1)),1)
 def test_overhead(self):self.assertEqual(q.qec_overhead_ratio(9,1),9)
 def test_gain(self):self.assertGreater(q.break_even_improvement(.1,.01),1)
 def test_assessment(self):
  a=q.QECMemoryAssessment(.1,3,3);self.assertTrue(a.improves_error_rate);self.assertAlmostEqual(a.logical_error_probability,.028)
 def test_bad_density(self):
  with self.assertRaises(ValueError):q.entanglement_fidelity_from_kraus([[1,1],[0,0]],[np.eye(2)])
 def test_noise_preserved(self):self.assertEqual(q.combine_independent_rates_s_inv(1,2),3)
 def test_bec_preserved(self):self.assertEqual(q.ideal_condensate_fraction(0,1),1)
 def test_fidelity_preserved(self):self.assertAlmostEqual(q.state_fidelity(np.eye(2)/2,np.eye(2)/2),1)
 def test_no_cloning_preserved(self):
  with self.assertRaises(ValueError):q.no_cloning_guard(2,True)
 def test_registry(self):
  ids={x.model_id for x in q.QuantumMemoryRegistry().all()}
  self.assertTrue({"QMEM-QEC-FE","QMEM-QEC-FAVG","QMEM-QEC-REP","QMEM-QEC-OVERHEAD","QMEM-QEC-GAIN"}<=ids)
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QMEM-11")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO"])
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
