from __future__ import annotations
from pathlib import Path
from dataclasses import asdict
import json,os,re,uuid
from .models import *
class DesignValidationError(ValueError):pass
class DesignStudio:
 DESIGN_TYPES={"STORAGE","HYBRID_STORAGE","QUANTUM_MEMORY","PHOTONIC","COMMUNICATIONS","QUANTUM_COMMS",
 "DEEP_SPACE_INTERSTELLAR","NETWORK_RELAY","DETECTOR_SENSOR","TRANSDUCER_INTERFACE","MATERIAL_MEDIUM",
 "APPARATUS","BOUNDARY_PHYSICS","CUSTOM"}
 def new(self,name,design_type):
  if design_type not in self.DESIGN_TYPES:raise DesignValidationError("unsupported design type")
  if not name.strip():raise DesignValidationError("name required")
  return Design("DSN-"+uuid.uuid4().hex[:16].upper(),name.strip(),design_type)
 def add_component(self,design,component):
  if component.component_id in design.components:raise DesignValidationError("duplicate component")
  design.components[component.component_id]=component
 def connect(self,design,connection):
  if connection.source_component_id not in design.components or connection.target_component_id not in design.components:
   raise DesignValidationError("connections require existing components")
  if connection.source_component_id==connection.target_component_id and connection.source_port==connection.target_port:
   raise DesignValidationError("self-loop to identical port is invalid")
  design.connections.append(connection)
 def validate(self,design):
  issues=[]
  if not design.components:issues.append("Design contains no components.")
  for cid,c in design.components.items():
   for n,p in c.parameters.items():
    if n!=p.name:issues.append(f"{cid}: parameter dictionary key does not match parameter name.")
    if isinstance(p.value,float) and (p.value!=p.value or abs(p.value)==float("inf")):issues.append(f"{cid}.{n}: non-finite value.")
   if not c.model_ids and not c.equation_ids:issues.append(f"{cid}: no physics model/equation attached.")
  for x in design.connections:
   if x.source_component_id not in design.components or x.target_component_id not in design.components:
    issues.append("Connection references missing component.")
  return issues
 def analysis_readiness(self,design):
  total=len(design.components)
  physics=sum(bool(c.model_ids or c.equation_ids) for c in design.components.values())
  evidence=sum(bool(c.evidence_class) for c in design.components.values())
  provenance=sum(bool(c.provenance_ids) for c in design.components.values())
  return {"components":total,"physics_coverage":physics/total if total else 0.0,
   "evidence_coverage":evidence/total if total else 0.0,"provenance_coverage":provenance/total if total else 0.0,
   "validation_issues":self.validate(design)}
 def save(self,design,path:Path):
  issues=self.validate(design)
  if issues:raise DesignValidationError("; ".join(issues))
  path.parent.mkdir(parents=True,exist_ok=True);payload=self._serialize(design)
  tmp=path.with_suffix(".tmp");tmp.write_text(json.dumps(payload,indent=2),encoding="utf-8");os.replace(tmp,path);return path
 def load(self,path:Path):
  x=json.loads(path.read_text(encoding="utf-8"))
  d=Design(x["design_id"],x["name"],x["design_type"],assumptions=x.get("assumptions",[]),notes=x.get("notes",""),format_version=x.get("format_version","1.0.0"))
  d.requirements=[Requirement(**r) for r in x.get("requirements",[])]
  for cid,c in x.get("components",{}).items():
   params={k:Parameter(**v) for k,v in c.get("parameters",{}).items()}
   d.components[cid]=Component(c["component_id"],c["name"],c["component_type"],params,c.get("model_ids",[]),c.get("equation_ids",[]),c.get("evidence_class"),c.get("provenance_ids",[]))
  d.connections=[Connection(**v) for v in x.get("connections",[])]
  return d
 def _serialize(self,d):return asdict(d)
