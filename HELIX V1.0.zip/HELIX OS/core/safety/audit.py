from pathlib import Path
import json,time,hashlib
class AppendOnlyAudit:
 def __init__(self,path:Path):self.path=path
 def append(self,event,actor,detail):
  self.path.parent.mkdir(parents=True,exist_ok=True)
  previous=self.last_hash()
  record={"timestamp_unix":time.time(),"event":event,"actor":actor,"detail":detail,"previous_hash":previous}
  canonical=json.dumps(record,sort_keys=True,separators=(",",":")).encode()
  record["record_hash"]=hashlib.sha256(canonical).hexdigest()
  with self.path.open("a",encoding="utf-8") as f:f.write(json.dumps(record,separators=(",",":"))+"\n")
  return record
 def last_hash(self):
  if not self.path.exists():return None
  lines=self.path.read_text(encoding="utf-8").splitlines()
  return json.loads(lines[-1])["record_hash"] if lines else None
 def verify(self):
  if not self.path.exists():return True
  prev=None
  for line in self.path.read_text(encoding="utf-8").splitlines():
   r=json.loads(line);got=r.pop("record_hash")
   if r.get("previous_hash")!=prev:return False
   expected=hashlib.sha256(json.dumps(r,sort_keys=True,separators=(",",":")).encode()).hexdigest()
   if got!=expected:return False
   prev=got
  return True
