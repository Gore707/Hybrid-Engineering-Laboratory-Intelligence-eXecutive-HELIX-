from pathlib import Path
import json,os,hashlib,time
class CheckpointManager:
 def __init__(self,path:Path):self.path=path;path.mkdir(parents=True,exist_ok=True)
 def create(self,name,state):
  payload={"name":name,"timestamp_unix":time.time(),"state":state}
  raw=json.dumps(payload,sort_keys=True,separators=(",",":")).encode();payload["checksum_sha256"]=hashlib.sha256(raw).hexdigest()
  p=self.path/(name+".checkpoint.json");tmp=p.with_suffix(".tmp");tmp.write_text(json.dumps(payload,indent=2),encoding="utf-8");os.replace(tmp,p);return p
 def load(self,name):
  p=self.path/(name+".checkpoint.json");d=json.loads(p.read_text(encoding="utf-8"));checksum=d.pop("checksum_sha256")
  raw=json.dumps(d,sort_keys=True,separators=(",",":")).encode()
  if hashlib.sha256(raw).hexdigest()!=checksum:raise ValueError("checkpoint checksum mismatch")
  d["checksum_sha256"]=checksum;return d
 def latest(self):
  files=list(self.path.glob("*.checkpoint.json"))
  return max(files,key=lambda p:p.stat().st_mtime) if files else None
