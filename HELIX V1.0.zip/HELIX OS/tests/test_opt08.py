import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-OPT"
sp=importlib.util.spec_from_file_location("skl_opt",M/"__init__.py",submodule_search_locations=[str(M)])
o=importlib.util.module_from_spec(sp);sys.modules["skl_opt"]=o;sp.loader.exec_module(o)
class T(unittest.TestCase):
 def test_light_time(self):self.assertAlmostEqual(o.one_way_light_time_s(o.AU_M),o.AU_M/o.C)
 def test_roundtrip(self):self.assertEqual(o.round_trip_light_time_s(o.C),2)
 def test_data_bits(self):self.assertEqual(o.data_volume_bits(1000,10,.5),5000)
 def test_data_bytes(self):self.assertEqual(o.data_volume_bytes(8000,1),1000)
 def test_power_scale(self):self.assertEqual(o.inverse_square_power_scale(10,1,2),40)
 def test_aperture_scale(self):self.assertEqual(o.aperture_diameter_for_equal_link(1,1,2),2)
 def test_aperture_product(self):self.assertEqual(o.combined_aperture_product_for_range(1,2,1,3),6)
 def test_contact_fraction(self):self.assertEqual(o.contact_fraction(2,10),.2)
 def test_contacts(self):self.assertEqual(o.contacts_required_for_volume(10000,1000,2),5)
 def test_zero_target(self):self.assertEqual(o.contacts_required_for_volume(0,0,0),0)
 def test_impossible_contacts(self):self.assertTrue(math.isinf(o.contacts_required_for_volume(1,0,10)))
 def test_relay_latency(self):self.assertAlmostEqual(o.store_and_forward_latency_s([o.C,o.C],[1]),3)
 def test_terminal(self):
  t=o.OpticalTerminal("DSOC",o.TerminalRole.SPACECRAFT,.2,4,1);self.assertEqual(t.aperture_diameter_m,.2)
 def test_contact(self):
  a=o.OpticalTerminal("A",o.TerminalRole.SPACECRAFT,.2,1);b=o.OpticalTerminal("B",o.TerminalRole.GROUND,5)
  c=o.MissionContact(a,b,o.C,100,1000,.5);self.assertAlmostEqual(c.one_way_light_time_s,1);self.assertEqual(c.expected_data_bits,50000)
 def test_relay_path(self):
  p=o.RelayPath((o.C,o.C),(2,));self.assertEqual(p.total_distance_m,2*o.C);self.assertAlmostEqual(p.latency_s,4)
 def test_bad_relay_delays(self):
  with self.assertRaises(ValueError):o.RelayPath((1,2,3),(1,))
 def test_integrated_link_preserved(self):
  s=o.IntegratedOpticalScenario(1550e-9,1e9,.2,1,10);self.assertGreater(o.simulate(s).received_power_w,0)
 def test_digital_preserved(self):self.assertEqual(o.bits_per_ppm_symbol(16),4)
 def test_atmosphere_preserved(self):self.assertEqual(o.transmission_from_optical_depth(0),1)
 def test_pat_preserved(self):self.assertEqual(o.gaussian_pointing_coupling(0,1e-6),1)
 def test_receiver_preserved(self):self.assertGreater(o.telescope_collection_area_m2(1),0)
 def test_transmitter_preserved(self):self.assertGreater(o.rayleigh_range_m(1e-6,1),0)
 def test_registry(self):self.assertTrue({"OPT-MISSION-LIGHTTIME","OPT-MISSION-DATA","OPT-MISSION-PWR-SCALE","OPT-MISSION-APERTURE","OPT-MISSION-CONTACTS","OPT-MISSION-RELAY"}<={x.model_id for x in o.OpticalRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-OPT-08")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
