import tempfile,unittest,json
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.safety import *
from core.safety.integrity import atomic_write_bytes,verify_bytes
ROOT=Path(__file__).resolve().parents[1]
class C21Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C21")
 def test_preflight_hard_domain_blocks(self):
  p=PreflightEngine().run({"power":11},[RangeRule("power",0,10,0,8)],("power",))
  self.assertFalse(p.passed);self.assertEqual(p.highest_level,AlertLevel.CRITICAL)
 def test_extrapolation_warns_not_blocks(self):
  p=PreflightEngine().run({"power":9},[RangeRule("power",0,10,0,8)])
  self.assertTrue(p.passed);self.assertEqual(p.highest_level,AlertLevel.WARNING)
 def test_safety_hold(self):
  with tempfile.TemporaryDirectory() as td:
   c=SafetyController(AppendOnlyAudit(Path(td)/"a"));c.alert(AlertLevel.CRITICAL,"TEMP","too hot","telemetry")
   self.assertTrue(c.hold)
   with self.assertRaises(SafetyViolation):c.clear_hold(False)
   c.clear_hold(True);self.assertFalse(c.hold)
 def test_guardian_not_authority(self):
  with tempfile.TemporaryDirectory() as td:
   c=SafetyController(AppendOnlyAudit(Path(td)/"a"));x=c.guardian_recommendation("abort")
   self.assertFalse(c.hold);self.assertFalse(x["authoritative"])
 def test_start_requires_preflight_and_no_hold(self):
  with tempfile.TemporaryDirectory() as td:
   c=SafetyController(AppendOnlyAudit(Path(td)/"a"));p=PreflightEngine().run({},[],())
   self.assertTrue(c.authorize_experiment_start(p))
   c.alert(AlertLevel.CRITICAL,"X","x","test")
   with self.assertRaises(SafetyViolation):c.authorize_experiment_start(p)
 def test_checkpoint_integrity(self):
  with tempfile.TemporaryDirectory() as td:
   m=CheckpointManager(Path(td));m.create("last_valid",{"experiment":"E1","value":3});self.assertEqual(m.load("last_valid")["state"]["value"],3)
 def test_audit_chain_detects_tamper(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/"a";a=AppendOnlyAudit(p);a.append("A","x",{});a.append("B","x",{});self.assertTrue(a.verify())
   lines=p.read_text().splitlines();d=json.loads(lines[0]);d["event"]="TAMPER";lines[0]=json.dumps(d);p.write_text("\n".join(lines)+"\n")
   self.assertFalse(a.verify())
 def test_atomic_integrity(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/"x";h=atomic_write_bytes(p,b"abc");self.assertTrue(verify_bytes(p,h))
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
