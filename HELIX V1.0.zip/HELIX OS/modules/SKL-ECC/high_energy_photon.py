from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .foundation import H_J_S,C_M_S,EV_J,photon_energy_j_from_wavelength

class HighEnergyBand(str,Enum):
    XRAY="XRAY"
    GAMMA="GAMMA"

def photon_energy_kev_from_wavelength(wavelength_m):
    if wavelength_m<=0:raise ValueError("wavelength positive")
    return photon_energy_j_from_wavelength(wavelength_m)/EV_J/1e3

def wavelength_m_from_photon_energy_kev(energy_kev):
    if energy_kev<=0:raise ValueError("energy positive")
    return H_J_S*C_M_S/(energy_kev*1e3*EV_J)

def diffraction_half_angle_rad(wavelength_m,aperture_m,factor=1.22):
    if wavelength_m<=0 or aperture_m<=0 or factor<=0:raise ValueError("positive inputs")
    return factor*wavelength_m/aperture_m

def beam_radius_m(distance_m,divergence_rad,source_radius_m=0.0):
    if distance_m<0 or divergence_rad<0 or source_radius_m<0:raise ValueError("nonnegative geometry")
    return source_radius_m+distance_m*divergence_rad

def beam_area_m2(distance_m,divergence_rad,source_radius_m=0.0):
    r=beam_radius_m(distance_m,divergence_rad,source_radius_m)
    return math.pi*r*r

def beer_lambert_transmission(linear_attenuation_per_m,path_length_m):
    if linear_attenuation_per_m<0 or path_length_m<0:raise ValueError("nonnegative attenuation")
    return math.exp(-linear_attenuation_per_m*path_length_m)

def optical_depth_transmission(optical_depth):
    if optical_depth<0:raise ValueError("optical depth nonnegative")
    return math.exp(-optical_depth)

def received_photon_rate_s(source_photon_rate_s,beam_area_m2,receiver_area_m2,transmission=1.0,detector_efficiency=1.0):
    if source_photon_rate_s<0 or beam_area_m2<=0 or receiver_area_m2<0 or not 0<=transmission<=1 or not 0<=detector_efficiency<=1:
        raise ValueError("invalid link inputs")
    capture=min(1.0,receiver_area_m2/beam_area_m2)
    return source_photon_rate_s*capture*transmission*detector_efficiency

def photon_counting_snr(signal_rate_s,background_rate_s,integration_s):
    if signal_rate_s<0 or background_rate_s<0 or integration_s<=0:raise ValueError("invalid counting")
    s=signal_rate_s*integration_s;b=background_rate_s*integration_s
    return 0.0 if s+b==0 else s/math.sqrt(s+b)

def ideal_photon_bit_rate_bps(detected_photon_rate_s,photons_per_bit):
    if detected_photon_rate_s<0 or photons_per_bit<=0:raise ValueError("invalid photon budget")
    return detected_photon_rate_s/photons_per_bit

def source_wall_power_w(photon_rate_s,photon_energy_j,wall_to_photon_efficiency):
    if photon_rate_s<0 or photon_energy_j<0 or not 0<wall_to_photon_efficiency<=1:raise ValueError("invalid source")
    return photon_rate_s*photon_energy_j/wall_to_photon_efficiency

def absorbed_dose_gy(absorbed_energy_j,mass_kg):
    if absorbed_energy_j<0 or mass_kg<=0:raise ValueError("invalid dose")
    return absorbed_energy_j/mass_kg

@dataclass(frozen=True)
class HighEnergyPhotonLink:
    energy_kev:float
    source_photon_rate_s:float
    distance_m:float
    divergence_rad:float
    receiver_diameter_m:float
    transmission:float=1.0
    detector_efficiency:float=1.0
    photons_per_bit:float=10.0
    background_rate_s:float=0.0
    source_radius_m:float=0.0
    def __post_init__(self):
        if self.energy_kev<=0 or self.source_photon_rate_s<0 or self.distance_m<=0 or self.divergence_rad<=0 or self.receiver_diameter_m<=0:
            raise ValueError("invalid link")
        if not 0<=self.transmission<=1 or not 0<=self.detector_efficiency<=1 or self.photons_per_bit<=0 or self.background_rate_s<0:
            raise ValueError("invalid efficiencies")
    @property
    def wavelength_m(self):return wavelength_m_from_photon_energy_kev(self.energy_kev)
    @property
    def band(self):return HighEnergyBand.XRAY if self.energy_kev<100 else HighEnergyBand.GAMMA
    @property
    def beam_area_m2(self):return beam_area_m2(self.distance_m,self.divergence_rad,self.source_radius_m)
    @property
    def receiver_area_m2(self):return math.pi*(self.receiver_diameter_m/2)**2
    @property
    def detected_photon_rate_s(self):
        return received_photon_rate_s(self.source_photon_rate_s,self.beam_area_m2,self.receiver_area_m2,self.transmission,self.detector_efficiency)
    @property
    def ideal_bit_rate_bps(self):return ideal_photon_bit_rate_bps(self.detected_photon_rate_s,self.photons_per_bit)
