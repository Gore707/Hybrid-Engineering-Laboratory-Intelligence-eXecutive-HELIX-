import unittest,importlib.util,sys,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-PHO";MAT=ROOT/"modules/SKL-MAT"
spec=importlib.util.spec_from_file_location("skl_pho",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
p=importlib.util.module_from_spec(spec);sys.modules["skl_pho"]=p;spec.loader.exec_module(p)
ms=importlib.util.spec_from_file_location("skl_mat",MAT/"__init__.py",submodule_search_locations=[str(MAT)])
m=importlib.util.module_from_spec(ms);sys.modules["skl_mat"]=m;ms.loader.exec_module(m)
class PHO06(unittest.TestCase):
 def test_sellmeier_constant_limit(self):
  s=p.SellmeierModel((1.0,),(0.0,));self.assertAlmostEqual(s.refractive_index(1e-6),math.sqrt(2))
 def test_cauchy(self):self.assertAlmostEqual(p.CauchyModel(1.5,.01).refractive_index(1e-6),1.51)
 def test_extinction_absorption(self):self.assertAlmostEqual(p.extinction_to_absorption(.01,1e-6),4*math.pi*.01/1e-6)
 def test_beer(self):self.assertAlmostEqual(p.beer_lambert_transmission(2,.5),math.exp(-1))
 def test_complex_epsilon(self):self.assertEqual(p.complex_relative_permittivity(2+0j),4+0j)
 def test_thermo_optic(self):self.assertAlmostEqual(p.thermo_optic_index(1.5,1e-5,310,300),1.5001)
 def test_birefringence(self):
  n=p.PrincipalRefractiveIndices(1.5,1.6,1.55);self.assertAlmostEqual(n.max_birefringence,.1)
 def test_waveplate(self):self.assertAlmostEqual(p.waveplate_thickness(500e-9,.1,math.pi),2.5e-6)
 def test_group_index_constant(self):self.assertAlmostEqual(p.group_index(1e-6,lambda x:1.5),1.5)
 def test_material_bridge(self):
  mat=m.MaterialRecord("M","Synthetic","X",m.MaterialPhase.SOLID,properties=(
   m.PropertyValue("refractive_index",1.5,"1",m.PropertyCondition(wavelength_m=500e-9),None,"ESTABLISHED_PHYSICS",("S",)),
   m.PropertyValue("refractive_index",1.6,"1",m.PropertyCondition(wavelength_m=600e-9),None,"ESTABLISHED_PHYSICS",("S",))),source_ids=("S",))
  self.assertAlmostEqual(p.interpolate_material_optical_property(mat,"refractive_index",550e-9),1.55)
  with self.assertRaises(ValueError):p.interpolate_material_optical_property(mat,"refractive_index",700e-9)
 def test_registry_manifest(self):
  self.assertEqual(p.PhotonicsRegistry().get("PHO-SELLMEIER").evidence_class,"ESTABLISHED_PHYSICS")
  self.assertEqual(json.loads((MOD/"module.json").read_text())["patch_id"],"SKL-PHO-06")
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
