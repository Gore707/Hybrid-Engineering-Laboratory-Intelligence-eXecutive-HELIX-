from __future__ import annotations
import json
from pathlib import Path
from typing import Any

class ConfigError(RuntimeError):
    pass

REQUIRED_TOP_LEVEL = {
    "schema_version", "resource_version", "application",
    "core", "paths", "logging", "startup"
}

def load_config(path: Path) -> dict[str, Any]:
    try:
        cfg = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ConfigError(f"Configuration file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ConfigError(
            f"Invalid JSON in {path} at line {exc.lineno}, column {exc.colno}: {exc.msg}"
        ) from exc
    missing = REQUIRED_TOP_LEVEL - set(cfg)
    if missing:
        raise ConfigError("Missing required configuration keys: " + ", ".join(sorted(missing)))
    core = cfg.get("core", {})
    if not str(core.get("patch", "")).startswith("SKL-CORE-C"):
        raise ConfigError("Invalid HELIX Core patch identity.")
    return cfg
