from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Iterable

C_M_S=299792458.0

class BoundaryEvidence(str,Enum):
    ESTABLISHED_PHYSICS="ESTABLISHED_PHYSICS"
    DEMONSTRATED_TECHNOLOGY="DEMONSTRATED_TECHNOLOGY"
    EXTRAPOLATED_ENGINEERING="EXTRAPOLATED_ENGINEERING"
    SPECULATIVE_UNRESOLVED="SPECULATIVE_UNRESOLVED"
    NEW_PHYSICS_REQUIRED="NEW_PHYSICS_REQUIRED"

class ClaimType(str,Enum):
    MEASUREMENT="MEASUREMENT"
    DERIVATION="DERIVATION"
    MODEL="MODEL"
    ENGINEERING_PROJECTION="ENGINEERING_PROJECTION"
    HYPOTHESIS="HYPOTHESIS"

class CausalityStatus(str,Enum):
    CAUSAL="CAUSAL"
    APPARENT_SUPERLUMINAL="APPARENT_SUPERLUMINAL"
    FTL_INFORMATION_CLAIM="FTL_INFORMATION_CLAIM"
    UNRESOLVED="UNRESOLVED"

@dataclass(frozen=True)
class BoundaryAssumption:
    assumption_id:str
    statement:str
    evidence:BoundaryEvidence
    testable:bool
    source_refs:tuple[str,...]=()
    def __post_init__(self):
        if not self.assumption_id or not self.statement:raise ValueError("assumption id and statement required")

@dataclass(frozen=True)
class BoundaryClaim:
    claim_id:str
    statement:str
    claim_type:ClaimType
    evidence:BoundaryEvidence
    causality:CausalityStatus
    assumptions:tuple[str,...]=()
    falsification_test:str|None=None
    source_refs:tuple[str,...]=()
    confidence:float|None=None
    def __post_init__(self):
        if not self.claim_id or not self.statement:raise ValueError("claim id and statement required")
        if self.confidence is not None and not 0<=self.confidence<=1:raise ValueError("confidence in [0,1]")
    @property
    def requires_explicit_boundary_warning(self):
        return self.evidence in (BoundaryEvidence.SPECULATIVE_UNRESOLVED,BoundaryEvidence.NEW_PHYSICS_REQUIRED) or self.causality in (CausalityStatus.FTL_INFORMATION_CLAIM,CausalityStatus.UNRESOLVED)

@dataclass(frozen=True)
class BoundaryModel:
    model_id:str
    name:str
    equation:str
    evidence:BoundaryEvidence
    assumptions:tuple[str,...]
    outputs:tuple[str,...]
    allows_ftl_information:bool=False
    def __post_init__(self):
        if not self.model_id or not self.name or not self.equation:raise ValueError("model identity/equation required")
        if self.allows_ftl_information and self.evidence in (BoundaryEvidence.ESTABLISHED_PHYSICS,BoundaryEvidence.DEMONSTRATED_TECHNOLOGY):
            raise ValueError("established/demonstrated model cannot assert FTL information")

def signal_velocity_status(speed_m_s):
    if speed_m_s<0:raise ValueError("speed nonnegative")
    if speed_m_s<=C_M_S:return CausalityStatus.CAUSAL
    return CausalityStatus.FTL_INFORMATION_CLAIM

def no_signalling_entanglement_allows_message_without_classical_channel():
    return False

def established_physics_causality_bypass_available():
    return False

def classify_boundary_candidate(observed:bool,engineering_demonstrated:bool,established_theory:bool,new_physics_required:bool):
    if engineering_demonstrated:return BoundaryEvidence.DEMONSTRATED_TECHNOLOGY
    if observed and established_theory:return BoundaryEvidence.ESTABLISHED_PHYSICS
    if new_physics_required:return BoundaryEvidence.NEW_PHYSICS_REQUIRED
    if established_theory:return BoundaryEvidence.EXTRAPOLATED_ENGINEERING
    return BoundaryEvidence.SPECULATIVE_UNRESOLVED

def falsifiability_ready(claim:BoundaryClaim):
    return bool(claim.falsification_test and claim.falsification_test.strip())

class BoundaryRegistry:
    def __init__(self,models:Iterable[BoundaryModel]=()):
        self._models={}
        for m in models:self.register(m)
    def register(self,model):
        if model.model_id in self._models:raise ValueError("duplicate model id")
        self._models[model.model_id]=model;return model
    def get(self,model_id):return self._models.get(model_id)
    def all(self):return tuple(self._models.values())
