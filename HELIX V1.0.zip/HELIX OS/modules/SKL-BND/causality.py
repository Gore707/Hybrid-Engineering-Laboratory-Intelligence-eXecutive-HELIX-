from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .foundation import BoundaryEvidence,C_M_S
from .qft_vacuum import minkowski_interval_m2

class PropagationClass(str,Enum):
    TIMELIKE="TIMELIKE"
    NULL="NULL"
    SPACELIKE="SPACELIKE"

class FTLClaimClass(str,Enum):
    NONE="NONE"
    APPARENT_OR_EFFECTIVE="APPARENT_OR_EFFECTIVE"
    LOCAL_SUPERLUMINAL="LOCAL_SUPERLUMINAL"
    CLOSED_CAUSAL_RISK="CLOSED_CAUSAL_RISK"

def propagation_class(dt_s,dx_m,dy_m=0.0,dz_m=0.0,tol_m2=1e-9):
    s2=minkowski_interval_m2(dt_s,dx_m,dy_m,dz_m)
    scale=max((C_M_S*dt_s)**2,dx_m**2+dy_m**2+dz_m**2,1.0)
    eps=tol_m2*scale
    if abs(s2)<=eps:return PropagationClass.NULL
    return PropagationClass.TIMELIKE if s2>0 else PropagationClass.SPACELIKE

def lorentz_gamma(beta):
    if abs(beta)>=1:raise ValueError("|beta|<1 required")
    return 1/math.sqrt(1-beta*beta)

def lorentz_transform_event_1d(dt_s,dx_m,frame_beta):
    """Delta t' = gamma(dt-beta dx/c), Delta x'=gamma(dx-beta c dt)."""
    g=lorentz_gamma(frame_beta)
    return g*(dt_s-frame_beta*dx_m/C_M_S), g*(dx_m-frame_beta*C_M_S*dt_s)

def ordering_reversal_possible(dt_s,dx_m):
    """A spacelike-separated event pair admits inertial frames with reversed time order."""
    return propagation_class(dt_s,dx_m)==PropagationClass.SPACELIKE

def reversal_frame_beta_threshold(dt_s,dx_m):
    """beta at which dt'=0; reversal is available when |beta|<1 for a spacelike pair."""
    if dx_m==0:raise ValueError("dx nonzero")
    return C_M_S*dt_s/dx_m

def local_vs_effective_ftl(local_signal_speed_m_s,effective_endpoint_speed_m_s):
    if local_signal_speed_m_s<0 or effective_endpoint_speed_m_s<0:raise ValueError("speeds nonnegative")
    local=local_signal_speed_m_s>C_M_S
    effective=effective_endpoint_speed_m_s>C_M_S
    if local:return FTLClaimClass.LOCAL_SUPERLUMINAL
    if effective:return FTLClaimClass.APPARENT_OR_EFFECTIVE
    return FTLClaimClass.NONE

def tachyonic_antitelephone_risk(superluminal_speed_m_s,relative_frame_speed_m_s):
    """Sufficient two-frame antitelephone risk benchmark: u*v > c^2 for u>c and 0<v<c.
    Flags causal-loop construction risk; it is not evidence that tachyons exist."""
    if superluminal_speed_m_s<=C_M_S:return False
    if not 0<=relative_frame_speed_m_s<C_M_S:raise ValueError("relative inertial speed must satisfy 0<=v<c")
    return superluminal_speed_m_s*relative_frame_speed_m_s>C_M_S**2

def closed_arrival_loop_risk(total_clock_offset_s):
    return total_clock_offset_s<0

def chronology_protection_status(has_closed_causal_risk,quantum_backreaction_resolved=False):
    if not has_closed_causal_risk:return "NO_CLOSED_CAUSAL_RISK_IDENTIFIED"
    if quantum_backreaction_resolved:return "MODEL_SPECIFIC_RESOLUTION_REQUIRED"
    return "UNRESOLVED_CHRONOLOGY_PROTECTION"

def demonstrated_ftl_information_gate(evidence,local_ftl_claim=False,effective_ftl_claim=False):
    """No current BND result may be promoted to demonstrated FTL information.
    A future evidence system would require independent empirical support beyond simulation/model output."""
    if local_ftl_claim or effective_ftl_claim:return False
    return evidence==BoundaryEvidence.DEMONSTRATED_TECHNOLOGY

@dataclass(frozen=True)
class CausalityAssessment:
    dt_s:float
    dx_m:float
    local_signal_speed_m_s:float
    effective_endpoint_speed_m_s:float
    evidence:BoundaryEvidence
    relative_frame_speed_m_s:float=0.0
    closed_clock_offset_s:float=0.0
    def __post_init__(self):
        if self.local_signal_speed_m_s<0 or self.effective_endpoint_speed_m_s<0:raise ValueError("speeds nonnegative")
        if not 0<=self.relative_frame_speed_m_s<C_M_S:raise ValueError("frame speed in [0,c)")
    @property
    def interval_class(self):return propagation_class(self.dt_s,self.dx_m)
    @property
    def ordering_reversal_possible(self):return ordering_reversal_possible(self.dt_s,self.dx_m)
    @property
    def ftl_class(self):return local_vs_effective_ftl(self.local_signal_speed_m_s,self.effective_endpoint_speed_m_s)
    @property
    def antitelephone_risk(self):
        u=max(self.local_signal_speed_m_s,self.effective_endpoint_speed_m_s)
        return tachyonic_antitelephone_risk(u,self.relative_frame_speed_m_s) if u>C_M_S else False
    @property
    def closed_loop_risk(self):return closed_arrival_loop_risk(self.closed_clock_offset_s)
    @property
    def chronology_status(self):return chronology_protection_status(self.antitelephone_risk or self.closed_loop_risk)
    @property
    def demonstrated_ftl_information(self):
        return demonstrated_ftl_information_gate(self.evidence,self.ftl_class==FTLClaimClass.LOCAL_SUPERLUMINAL,self.ftl_class==FTLClaimClass.APPARENT_OR_EFFECTIVE)
