from __future__ import annotations
import os,platform,subprocess,re,shutil
from .models import ComputeDevice

def cpu_device():
    name=platform.processor() or os.environ.get("PROCESSOR_IDENTIFIER") or "Generic CPU"
    return ComputeDevice("CPU-0","CPU",platform.machine() or "UNKNOWN",name,None,"numpy",True,
        {"logical_cores":os.cpu_count() or 1,"architecture":platform.machine(),"platform":platform.platform()})

def _run(args):
    try:
        p=subprocess.run(args,capture_output=True,text=True,timeout=4,check=False)
        return p.stdout.strip() if p.returncode==0 else ""
    except (OSError,subprocess.SubprocessError):
        return ""

def detect_nvidia():
    exe=shutil.which("nvidia-smi")
    if not exe:return []
    out=_run([exe,"--query-gpu=index,name,memory.total,driver_version","--format=csv,noheader,nounits"])
    devices=[]
    for line in out.splitlines():
        parts=[x.strip() for x in line.split(",")]
        if len(parts)<4:continue
        try: idx=int(parts[0]); mem=int(float(parts[2]))*1024*1024
        except ValueError:continue
        devices.append(ComputeDevice(f"NVIDIA-{idx}","GPU","NVIDIA",parts[1],mem,"cuda",True,
            {"driver_version":parts[3],"ordinal":idx}))
    return devices

def detect_amd():
    devices=[]
    # ROCm path (Linux or Windows ROCm environments where rocminfo exists).
    exe=shutil.which("rocminfo")
    if exe:
        out=_run([exe]); names=[]
        for line in out.splitlines():
            m=re.match(r"\s*Name:\s+(.+)",line)
            if m and "gfx" not in m.group(1).lower():
                names.append(m.group(1).strip())
        for i,name in enumerate(dict.fromkeys(names)):
            devices.append(ComputeDevice(f"AMD-{i}","GPU","AMD",name,None,"rocm",True,{"ordinal":i}))
        if devices:return devices
    # Windows PowerShell/CIM fallback detects physical AMD adapters even without ROCm.
    if platform.system()=="Windows":
        ps=shutil.which("powershell") or shutil.which("pwsh")
        if ps:
            cmd="$g=Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM,DriverVersion,PNPDeviceID; $g | ConvertTo-Json -Compress"
            out=_run([ps,"-NoProfile","-Command",cmd])
            if out:
                import json
                try:data=json.loads(out)
                except json.JSONDecodeError:data=[]
                if isinstance(data,dict):data=[data]
                for item in data:
                    name=str(item.get("Name",""))
                    if "AMD" in name.upper() or "RADEON" in name.upper():
                        mem=item.get("AdapterRAM")
                        try:mem=int(mem) if mem is not None else None
                        except (ValueError,TypeError):mem=None
                        i=len(devices)
                        devices.append(ComputeDevice(f"AMD-{i}","GPU","AMD",name,mem,"detected-only",True,
                            {"driver_version":item.get("DriverVersion"),"ordinal":i}))
    return devices
