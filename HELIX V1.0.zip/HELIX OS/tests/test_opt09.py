import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-OPT"
sp=importlib.util.spec_from_file_location("skl_opt",M/"__init__.py",submodule_search_locations=[str(M)])
o=importlib.util.module_from_spec(sp);sys.modules["skl_opt"]=o;sp.loader.exec_module(o)
class T(unittest.TestCase):
 def s(self,**kw):
  d=dict(wavelength_m=1550e-9,distance_m=1e9,transmit_aperture_m=.2,receive_aperture_m=1,transmitted_optical_power_w=10,bit_rate_bps=1000,required_snr=5)
  d.update(kw);return o.IntegratedOpticalScenario(**d)
 def test_sweep(self):
  x=o.sweep_parameter(self.s(),"distance_m",[1e9,2e9]);self.assertGreater(x[0][1].received_power_w,x[1][1].received_power_w)
 def test_bad_parameter(self):
  with self.assertRaises(ValueError):o.sweep_parameter(self.s(),"banana",[1])
 def test_sensitivity(self):
  x=o.local_sensitivity(self.s(),"transmitted_optical_power_w");self.assertEqual(x.parameter,"transmitted_optical_power_w")
 def test_sensitivity_bad_zero(self):
  with self.assertRaises(ValueError):o.local_sensitivity(self.s(pointing_error_rad=0),"pointing_error_rad")
 def test_failure_tuple(self):self.assertIsInstance(o.analyze_failures(self.s()),tuple)
 def test_pointing_failure(self):
  f=o.analyze_failures(self.s(pointing_error_rad=20e-6,beam_half_angle_rad=10e-6));self.assertIn("POINTING_LOSS",{x.code for x in f})
 def test_atmos_failure(self):
  f=o.analyze_failures(self.s(atmospheric_transmission=.1));self.assertIn("ATMOSPHERIC_LOSS",{x.code for x in f})
 def test_compare(self):
  x=o.compare_scenarios([("near",self.s()),("far",self.s(distance_m=2e9))]);self.assertEqual([z[0] for z in x],["near","far"])
 def test_mc_counts(self):
  m=o.monte_carlo(self.s(),100,seed=7);self.assertAlmostEqual(m.pass_fraction+m.marginal_fraction+m.fail_fraction,1)
 def test_mc_repeatable(self):
  a=o.monte_carlo(self.s(),50,seed=3);b=o.monte_carlo(self.s(),50,seed=3);self.assertEqual(a,b)
 def test_mc_stats(self):
  m=o.monte_carlo(self.s(),100,seed=2);self.assertLessEqual(m.p05_margin_db,m.p50_margin_db);self.assertLessEqual(m.p50_margin_db,m.p95_margin_db)
 def test_mc_zero_uncertainty(self):
  m=o.monte_carlo(self.s(),10,seed=1,power_sigma_fraction=0,atmosphere_sigma_fraction=0);self.assertAlmostEqual(m.std_margin_db,0)
 def test_mc_pointing_jitter(self):
  a=o.monte_carlo(self.s(),100,seed=1,power_sigma_fraction=0,atmosphere_sigma_fraction=0,pointing_sigma_rad=0)
  b=o.monte_carlo(self.s(),100,seed=1,power_sigma_fraction=0,atmosphere_sigma_fraction=0,pointing_sigma_rad=10e-6)
  self.assertLess(b.mean_margin_db,a.mean_margin_db)
 def test_mission_preserved(self):self.assertEqual(o.data_volume_bits(100,10),1000)
 def test_integrated_preserved(self):self.assertGreater(o.simulate(self.s()).received_power_w,0)
 def test_digital_preserved(self):self.assertEqual(o.bits_per_ppm_symbol(16),4)
 def test_atmosphere_preserved(self):self.assertEqual(o.transmission_from_optical_depth(0),1)
 def test_pat_preserved(self):self.assertEqual(o.gaussian_pointing_coupling(0,1e-6),1)
 def test_receiver_preserved(self):self.assertGreater(o.telescope_collection_area_m2(1),0)
 def test_transmitter_preserved(self):self.assertGreater(o.rayleigh_range_m(1e-6,1),0)
 def test_registry(self):self.assertTrue({"OPT-SYS-SWEEP","OPT-SYS-SENS","OPT-SYS-MC","OPT-SYS-FAIL"}<={x.model_id for x in o.OpticalRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-OPT-09")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
