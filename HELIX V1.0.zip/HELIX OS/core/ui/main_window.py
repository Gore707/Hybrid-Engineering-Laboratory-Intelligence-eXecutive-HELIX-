from __future__ import annotations
from pathlib import Path

try:
    from PySide6.QtCore import Qt, QTimer, QSize
    from PySide6.QtGui import QKeySequence
    from PySide6.QtWidgets import (
        QFileDialog, QFrame, QLabel, QMainWindow, QInputDialog,
        QMessageBox, QStatusBar, QVBoxLayout, QToolBar, QWidget, QHBoxLayout, QToolButton, QSizePolicy, QGridLayout, QPushButton, QTreeWidget, QTreeWidgetItem, QGroupBox, QDialog, QScrollArea
    )
except ImportError as exc:
    raise RuntimeError("PySide6 is required for HELIX.") from exc

from core.bootstrap.identity import IDENTITY
from core.workspace.manager import WorkspaceManager
from core.persistence.manager import ProjectManager, SessionManager
from core.bus.factory import create_core_bus
from core.bus.messages import Provenance, ExperimentStateEvent
from core.commands import ActionRegistry, CommandService, CommandRequest, CommandContext
from core.commands.core_actions import register_core_actions
from core.guardian.console import GuardianConsoleEngine
from core.ui.guardian_console import GuardianConsoleWidget
from core.ui.scientific_widgets import ProvenanceBadge
from core.guardian.integration import GuardianAIServices

TOP_MENUS = ["File","Project","Labs","Research","Data","Models",
             "Experiment","View","Hardware","Guardian","Settings"]

class HelixMainWindow(QMainWindow):
    def __init__(self, config: dict, root: Path):
        super().__init__()
        self.config, self.root = config, root
        self.setWindowTitle(f"HELIX — {IDENTITY.program}")
        self.resize(1440, 900)
        self.setMinimumSize(1000, 650)

        self.bus = create_core_bus(config.get("bus", {}).get("history_per_topic", 256))
        self.project_manager = ProjectManager(root / config["paths"]["projects"])
        self.session_manager = SessionManager(root / config["paths"]["user"], root/"data"/"recovery")
        self.session = self.session_manager.load_or_create()
        self.current_project_path = None
        self.current_project = None
        self.current_experiment = None

        self._build_menu()
        self._build_toolbar()
        self._build_central_workspace()
        self.workspace = WorkspaceManager(self, root / config["paths"]["user"])
        self._build_status_bar()

        self.action_registry = ActionRegistry()
        register_core_actions(self.action_registry, self)
        self.command_service = CommandService(
            self.action_registry,
            config.get("command_service", {}).get("history_limit", 1000)
        )
        self.guardian_ai = GuardianAIServices(
            self.root,self.command_service,lambda:self.command_context("GUARDIAN_AI")
        ).initialize(auto_load_model=False)
        self.guardian_engine = GuardianConsoleEngine(
            self.command_service,
            lambda: self.command_context("GUARDIAN_CONSOLE"),
            self.system_status,
            lambda: self.workspace.store.names(),
            reasoner=self.guardian_ai.reasoner
        )
        self._build_operational_docks()

        self._wire_project_menu()
        self._wire_labs_menu()
        self._wire_view_menu()
        self._start_autosave()

        if config.get("workspace", {}).get("restore_last_layout", True):
            self.workspace.restore_last()
        self._restore_session_project()

    def command_context(self, source="GUI"):
        return CommandContext(
            source=source, actor="local-user",
            project_id=self.current_project.project_id if self.current_project else None,
            experiment_id=self.current_experiment.experiment_id if self.current_experiment else None
        )

    def execute_action(self, action_id, parameters=None, confirmed=False, source="GUI"):
        req = CommandRequest(
            action_id=action_id, parameters=parameters or {},
            context=self.command_context(source), confirmed=confirmed
        )
        result = self.command_service.execute(req)
        self.statusBar().showMessage(result.message, 4000)
        self._refresh_output()
        return result

    def _build_menu(self):
        mb = self.menuBar()
        self.menus = {name: mb.addMenu(name) for name in TOP_MENUS}
        # Unimplemented domains remain empty; C07 adds only the operational Guardian console entry.
        guardian_action = self.menus["Guardian"].addAction("Open Guardian Console")
        guardian_action.triggered.connect(self._show_guardian_console)

    def _build_toolbar(self):
        bar=QToolBar("HELIX Command Bar",self);bar.setObjectName("CommandBar")
        bar.setMovable(False);bar.setFloatable(False);bar.setIconSize(QSize(16,16))
        self.addToolBar(Qt.ToolBarArea.TopToolBarArea,bar)

        new=bar.addAction("New");new.setObjectName("ToolbarNew");new.setShortcut(QKeySequence.StandardKey.New);new.triggered.connect(self._new_project)
        opn=bar.addAction("Open");opn.setObjectName("ToolbarOpen");opn.setShortcut(QKeySequence.StandardKey.Open);opn.triggered.connect(self._open_project)
        save=bar.addAction("Save");save.setObjectName("ToolbarSave");save.setShortcut(QKeySequence.StandardKey.Save)
        save.triggered.connect(lambda:self.execute_action("project.save"))
        bar.addSeparator()

        self.toolbar_run=bar.addAction("Run");self.toolbar_run.setObjectName("ToolbarRun");self.toolbar_run.setEnabled(False)
        self.toolbar_run.setToolTip("Available when a registered experiment run action is active.")
        self.toolbar_hold=bar.addAction("Hold");self.toolbar_hold.setObjectName("ToolbarHold");self.toolbar_hold.setEnabled(False)
        self.toolbar_hold.setToolTip("Available when a registered experiment hold action is active.")
        self.toolbar_abort=bar.addAction("ABORT");self.toolbar_abort.setObjectName("ToolbarAbort");self.toolbar_abort.setEnabled(False)
        self.toolbar_abort.setToolTip("Enabled only when an active deterministic abort action is registered.")
        bar.addSeparator()

        for label in ("Plot","Equation","Data"):
            action=bar.addAction(label);action.setObjectName(f"Toolbar{label}");action.setEnabled(False)
            action.setToolTip(f"{label} becomes available from an active scientific workspace.")
        bar.addSeparator()
        labs=bar.addAction("Labs");labs.setObjectName("ToolbarLabs");labs.triggered.connect(self._show_lab_launcher)
        guardian=bar.addAction("Guardian");guardian.setObjectName("ToolbarGuardian");guardian.triggered.connect(self._show_guardian_console)

    def _build_central_workspace(self):
        central = QFrame()
        central.setObjectName("Workspace")
        layout = QVBoxLayout(central)
        layout.setContentsMargins(20, 18, 20, 20)
        layout.setSpacing(10)

        eyebrow = QLabel("SIERRA KILO LABS  /  THE ARCHIMEDES PROJECT")
        eyebrow.setObjectName("Eyebrow")
        title = QLabel("HELIX COMMAND CENTER")
        title.setObjectName("Brand")
        info = QLabel("Scientific research operating environment · deterministic services ready")
        info.setObjectName("Subtitle")
        layout.addWidget(eyebrow); layout.addWidget(title); layout.addWidget(info)

        rule = QFrame(); rule.setObjectName("WorkspaceRule"); rule.setFrameShape(QFrame.Shape.HLine)
        layout.addWidget(rule)

        grid = QGridLayout()
        grid.setHorizontalSpacing(10); grid.setVerticalSpacing(10)
        self.home_project = self._home_card("PROJECT", "No project open", "Create or open a HELIX project")
        self.home_compute = self._home_card("COMPUTE", "Core ready", "Adaptive compute status available in System / Compute")
        self.home_hardware = self._home_card("HARDWARE", "No active hardware session", "Open Hardware for instruments and acquisition")
        self.home_guardian = self._home_card("GUARDIAN", "Console ready", "Unified command and scientific intelligence interface")
        grid.addWidget(self.home_project,0,0); grid.addWidget(self.home_compute,0,1)
        grid.addWidget(self.home_hardware,1,0); grid.addWidget(self.home_guardian,1,1)
        layout.addLayout(grid)

        quick = QGroupBox("QUICK START")
        quick.setObjectName("QuickStart")
        ql = QHBoxLayout(quick)
        bnew=QPushButton("New Project"); bnew.clicked.connect(self._new_project)
        bopen=QPushButton("Open Project"); bopen.clicked.connect(self._open_project)
        bexp=QPushButton("New Experiment"); bexp.clicked.connect(self._new_experiment)
        bguard=QPushButton("Open Guardian"); bguard.clicked.connect(self._show_guardian_console)
        for b in (bnew,bopen,bexp,bguard): ql.addWidget(b)
        ql.addStretch(1)
        layout.addWidget(quick)
        layout.addStretch(1)
        self.setCentralWidget(central)

    def _home_card(self, heading, value, detail):
        card=QFrame(); card.setObjectName("HomeCard")
        v=QVBoxLayout(card); v.setContentsMargins(14,12,14,12); v.setSpacing(4)
        h=QLabel(heading); h.setObjectName("CardHeading")
        val=QLabel(value); val.setObjectName("CardValue"); val.setWordWrap(True)
        det=QLabel(detail); det.setObjectName("CardDetail"); det.setWordWrap(True)
        v.addWidget(h); v.addWidget(val); v.addWidget(det); v.addStretch(1)
        return card

    def _build_operational_docks(self):
        project_dock = self.workspace.create_dock(
            "helix.project_explorer", "Project Explorer",
            "", Qt.DockWidgetArea.LeftDockWidgetArea
        )
        self.project_tree = QTreeWidget()
        self.project_tree.setObjectName("ProjectTree")
        self.project_tree.setHeaderHidden(True)
        self.project_tree.setIndentation(16)
        project_dock.setWidget(self.project_tree)
        self._refresh_project_panel()
        self.workspace.create_dock(
            "helix.output", "Command History",
            "No commands executed.", Qt.DockWidgetArea.BottomDockWidgetArea
        )
        guardian_dock = self.workspace.create_dock(
            "helix.guardian", "Guardian Console",
            "", Qt.DockWidgetArea.BottomDockWidgetArea
        )
        guardian_dock.setWidget(GuardianConsoleWidget(self.guardian_engine, guardian_dock, self.guardian_ai.intelligence))
        self.workspace.tabify("helix.output","helix.guardian")
        self.workspace.docks["helix.guardian"].raise_()

    def system_status(self):
        return {
            "HELIX Core": IDENTITY.core_version,
            "Patch": IDENTITY.patch_id,
            "Project": self.current_project.name if self.current_project else "NONE",
            "Project ID": self.current_project.project_id if self.current_project else "NONE",
            "Experiment": self.current_experiment.name if self.current_experiment else "NONE",
            "Experiment ID": self.current_experiment.experiment_id if self.current_experiment else "NONE",
            "Registered Actions": len(self.action_registry.all()),
            "Bus Topics": len(self.bus.registered_topics()),
            "Session": self.session.session_id,
            "Guardian AI": "LOCAL MODEL LOADED" if self.guardian_ai.reasoner.ready else "DETERMINISTIC / MODEL NOT LOADED",
            "Guardian Knowledge": len(self.guardian_ai.knowledge.chunks)
        }

    def _show_guardian_console(self):
        dock=self.workspace.docks.get("helix.guardian")
        if dock:
            dock.show()
            dock.raise_()
            dock.widget().input.setFocus()

    def _wire_project_menu(self):
        m = self.menus["Project"]
        a = m.addAction("New Project…"); a.triggered.connect(self._new_project)
        a = m.addAction("Open Project…"); a.triggered.connect(self._open_project)
        m.addSeparator()
        a = m.addAction("New Experiment…"); a.triggered.connect(self._new_experiment)
        m.addSeparator()
        a = m.addAction("Save Project")
        a.triggered.connect(lambda: self.execute_action("project.save"))

    def _installed_labs(self):
        labs=[]
        modules_root=self.root/"modules"
        if not modules_root.exists(): return labs
        for folder in sorted(modules_root.iterdir()):
            manifest=folder/"module.json"
            if not manifest.exists(): continue
            try:
                import json
                d=json.loads(manifest.read_text(encoding="utf-8"))
            except Exception:
                continue
            name=d.get("name",folder.name)
            if "Laboratory" not in name and folder.name!="SKL-HWI": continue
            labs.append({
                "id":folder.name,
                "name":name.replace("HELIX ","").replace(" Laboratory",""),
                "full_name":name,
                "status":d.get("status","Installed"),
                "version":d.get("version",""),
                "folder":folder,
            })
        return labs

    def _wire_labs_menu(self):
        m=self.menus["Labs"]
        launcher=m.addAction("Open Lab Launcher…")
        launcher.triggered.connect(self._show_lab_launcher)
        m.addSeparator()
        for lab in self._installed_labs():
            a=m.addAction(lab["name"])
            a.triggered.connect(lambda checked=False, lab_id=lab["id"]: self._open_lab(lab_id))

    def _show_lab_launcher(self):
        dlg=QDialog(self); dlg.setObjectName("LabLauncher"); dlg.setWindowTitle("HELIX Laboratories")
        dlg.resize(760,560)
        outer=QVBoxLayout(dlg)
        title=QLabel("HELIX LABORATORIES"); title.setObjectName("Brand")
        subtitle=QLabel("Installed scientific modules · select a laboratory workspace")
        subtitle.setObjectName("Subtitle")
        outer.addWidget(title);outer.addWidget(subtitle)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QFrame.Shape.NoFrame)
        body=QWidget();grid=QGridLayout(body);grid.setSpacing(10)
        for i,lab in enumerate(self._installed_labs()):
            card=QFrame();card.setObjectName("LabCard")
            v=QVBoxLayout(card);v.setContentsMargins(12,11,12,11)
            h=QLabel(lab["name"].upper());h.setObjectName("CardHeading")
            st=QLabel(lab["status"]);st.setObjectName("CardValue");st.setWordWrap(True)
            ver=QLabel(lab["version"]);ver.setObjectName("CardDetail")
            b=QPushButton("Open Laboratory")
            b.clicked.connect(lambda checked=False, lid=lab["id"], d=dlg:(self._open_lab(lid),d.accept()))
            v.addWidget(h);v.addWidget(st);v.addWidget(ver);v.addStretch(1);v.addWidget(b)
            grid.addWidget(card,i//3,i%3)
        scroll.setWidget(body);outer.addWidget(scroll)
        dlg.exec()

    def _open_lab(self, lab_id):
        lab=next((x for x in self._installed_labs() if x["id"]==lab_id),None)
        if not lab:
            QMessageBox.warning(self,"HELIX Laboratory","Installed laboratory manifest not found.")
            return
        dock_id=f"helix.lab.{lab_id.lower()}"
        if dock_id in self.workspace.docks:
            dock=self.workspace.docks[dock_id];dock.show();dock.raise_();return
        dock=self.workspace.create_dock(dock_id,lab["name"],"",Qt.DockWidgetArea.RightDockWidgetArea)
        body=QWidget();body.setObjectName("LabWorkspace")
        v=QVBoxLayout(body);v.setContentsMargins(14,12,14,12);v.setSpacing(7)
        eyebrow=QLabel("HELIX SCIENTIFIC LABORATORY");eyebrow.setObjectName("Eyebrow")
        title=QLabel(lab["name"].upper());title.setObjectName("LabTitle")
        state=QLabel(f'{lab["status"]}  ·  {lab["version"]}');state.setObjectName("Subtitle")
        notice=QLabel("Module installed. Scientific tools are exposed only through registered module/core actions; this workspace does not fabricate controls.")
        notice.setObjectName("LabNotice");notice.setWordWrap(True)
        v.addWidget(eyebrow);v.addWidget(title);v.addWidget(state);v.addWidget(notice);v.addStretch(1)
        dock.setWidget(body);dock.show();dock.raise_()

    def _wire_view_menu(self):
        m = self.menus["View"]
        panels = m.addMenu("Panels")
        for dock in self.workspace.docks.values():
            panels.addAction(dock.toggleViewAction())
        m.addSeparator()
        a = m.addAction("Save Workspace Layout…"); a.triggered.connect(self._save_layout_dialog)
        restore = m.addMenu("Restore Workspace Layout")
        restore.aboutToShow.connect(lambda: self._populate_restore_menu(restore))
        a = m.addAction("Reset to Scientific Default")
        a.triggered.connect(lambda: self.execute_action("workspace.reset"))

    def _new_project(self):
        name, ok = QInputDialog.getText(self, "New HELIX Project", "Project name:")
        name = name.strip()
        if not ok or not name: return
        path, project = self.project_manager.create_project(name)
        self.current_project_path, self.current_project = path, project
        self.current_experiment = None
        self.session.project_path = str(path)
        self.session.active_experiment_id = None
        self.session.dirty = False
        self.session_manager.save(self.session)
        self._refresh_project_panel()
        if hasattr(self,'status_experiment'): self._refresh_status_bar()

    def _open_project(self):
        folder = QFileDialog.getExistingDirectory(
            self, "Open HELIX Project", str(self.root/self.config["paths"]["projects"])
        )
        if folder: self._load_project_path(Path(folder), show_error=True)

    def _load_project_path(self, path: Path, show_error=False):
        try:
            project = self.project_manager.load_project(path)
        except Exception as exc:
            if show_error: QMessageBox.critical(self, "HELIX Project Error", str(exc))
            return False
        self.current_project_path, self.current_project = path, project
        self.current_experiment = None
        self.session.project_path = str(path)
        self.session.dirty = False
        self.session_manager.save(self.session)
        self._refresh_project_panel()
        if hasattr(self,'status_experiment'): self._refresh_status_bar()
        return True

    def _restore_session_project(self):
        if self.session.project_path:
            self._load_project_path(Path(self.session.project_path), show_error=False)

    def _new_experiment(self):
        if not self.current_project or not self.current_project_path:
            QMessageBox.information(self, "HELIX", "Create or open a project first.")
            return
        name, ok = QInputDialog.getText(self, "New Experiment", "Experiment name:")
        name = name.strip()
        if not ok or not name: return
        exp = self.project_manager.create_experiment(
            self.current_project_path, self.current_project, name
        )
        self.current_experiment = exp
        self.bus.publish(ExperimentStateEvent(
            topic="experiment.state",
            provenance=Provenance("SOFTWARE", "HELIX.C04.ProjectManager"),
            experiment_id=exp.experiment_id, state="DRAFT", detail="Experiment created"
        ))
        self.session.active_experiment_id = exp.experiment_id
        self.session_manager.save(self.session)
        self._refresh_project_panel()
        if hasattr(self,'status_experiment'): self._refresh_status_bar()

    def _save_layout_dialog(self):
        name, ok = QInputDialog.getText(self, "Save Workspace Layout", "Layout name:")
        if ok and name.strip():
            self.execute_action("workspace.save", {"name": name.strip()})

    def _populate_restore_menu(self, menu):
        menu.clear()
        for name in self.workspace.store.names():
            a = menu.addAction(name)
            a.triggered.connect(
                lambda checked=False, n=name:
                    self.execute_action("workspace.restore", {"name": n})
            )

    def reset_default_workspace(self):
        for dock in self.workspace.docks.values():
            dock.setFloating(False); dock.show()
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea,
                           self.workspace.docks["helix.project_explorer"])
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea,
                           self.workspace.docks["helix.output"])

    def _refresh_project_panel(self):
        if not hasattr(self, "project_tree"): return
        self.project_tree.clear()
        if not self.current_project:
            item=QTreeWidgetItem(["NO PROJECT OPEN"])
            item.setData(0,Qt.ItemDataRole.UserRole,"empty")
            self.project_tree.addTopLevelItem(item)
            if hasattr(self,"home_project"):
                labels=self.home_project.findChildren(QLabel)
                if len(labels)>=3: labels[1].setText("No project open"); labels[2].setText("Create or open a HELIX project")
            return

        root_item=QTreeWidgetItem([self.current_project.name.upper()])
        root_item.setData(0,Qt.ItemDataRole.UserRole,"project")
        self.project_tree.addTopLevelItem(root_item)
        categories=("Experiments","Models","Equations","Simulations","Datasets","Materials",
                    "Devices","Hardware","Figures","Research","Reports")
        nodes={}
        for name in categories:
            node=QTreeWidgetItem([name]); node.setData(0,Qt.ItemDataRole.UserRole,name.lower())
            root_item.addChild(node); nodes[name]=node
        for exp_id in self.current_project.experiments:
            label=exp_id
            if self.current_experiment and exp_id==self.current_experiment.experiment_id:
                label=f"{self.current_experiment.name}  [ACTIVE]"
            child=QTreeWidgetItem([label]); child.setData(0,Qt.ItemDataRole.UserRole,exp_id)
            nodes["Experiments"].addChild(child)
        root_item.setExpanded(True); nodes["Experiments"].setExpanded(True)
        if hasattr(self,"home_project"):
            labels=self.home_project.findChildren(QLabel)
            if len(labels)>=3:
                labels[1].setText(self.current_project.name)
                labels[2].setText(f"{len(self.current_project.experiments)} experiment(s) · " +
                                  (f"Active: {self.current_experiment.name}" if self.current_experiment else "No active experiment"))

    def _refresh_output(self):
        label = self.workspace.docks["helix.output"].widget().findChild(QLabel)
        hist = self.command_service.history()[-12:]
        label.setText("\n".join(
            f"{r.status:>21}  {r.action_id} — {r.message}" for r in hist
        ) or "No commands executed.")

    def _start_autosave(self):
        self.autosave_timer = QTimer(self)
        seconds = int(self.config.get("persistence", {}).get("autosave_seconds", 120))
        self.autosave_timer.setInterval(max(10, seconds)*1000)
        self.autosave_timer.timeout.connect(self._autosave)
        self.autosave_timer.start()

    def _autosave(self):
        if self.current_project and self.current_project_path and self.session.dirty:
            self.project_manager.save_project(self.current_project_path, self.current_project)
            self.session.dirty = False
        self.session_manager.save(self.session)
        self.session_manager.checkpoint(self.session)

    def _build_status_bar(self):
        status=QStatusBar();status.setObjectName("HelixStatusBar");status.setSizeGripEnabled(False);self.setStatusBar(status)
        self.status_experiment=QLabel("EXPERIMENT  ·  READY  ·  No active run");self.status_experiment.setObjectName("StatusExperiment")
        self.status_system=QLabel(f"SYSTEM  ·  CORE {IDENTITY.core_version}");self.status_system.setObjectName("StatusSystem")
        self.status_environment=QLabel("ENVIRONMENT  ·  Guardian READY");self.status_environment.setObjectName("StatusEnvironment")
        status.addWidget(self.status_experiment,1);status.addPermanentWidget(self.status_system);status.addPermanentWidget(self.status_environment)
        self.status_timer=QTimer(self);self.status_timer.setInterval(1500);self.status_timer.timeout.connect(self._refresh_status_bar);self.status_timer.start()
        self._refresh_status_bar()

    def _refresh_status_bar(self):
        exp=self.current_experiment.name if self.current_experiment else "No active run"
        self.status_experiment.setText(f"EXPERIMENT  ·  {'DRAFT' if self.current_experiment else 'READY'}  ·  {exp}")
        self.status_system.setText(f"SYSTEM  ·  CORE {IDENTITY.core_version}  ·  BUS {len(self.bus.registered_topics())} topics")
        self.status_environment.setText("ENVIRONMENT  ·  Guardian READY")

    def closeEvent(self, event):
        self.workspace.save_layout("__last_session__")
        self.session_manager.save(self.session)
        self.session_manager.checkpoint(self.session)
        super().closeEvent(event)
