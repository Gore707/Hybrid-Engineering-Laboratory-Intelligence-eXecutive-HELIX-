from __future__ import annotations
import math
def shannon_capacity(B,S,N):
    if B<0 or S<0 or N<=0: raise ValueError("Require B≥0, S≥0, N>0")
    return {"C":B*math.log2(1.0+S/N)}
def free_space_path_loss(d,lambda_):
    if d<0 or lambda_<=0: raise ValueError("Require d≥0 and wavelength>0")
    return {"L_FS":(4.0*math.pi*d/lambda_)**2}
def photon_energy(lambda_,h,c):
    if lambda_<=0: raise ValueError("Wavelength must be >0")
    return {"E_gamma":h*c/lambda_}
def coherence_decay(C0,t,T2):
    if T2<=0 or t<0: raise ValueError("Require T2>0 and t≥0")
    return {"C":C0*math.exp(-t/T2)}
