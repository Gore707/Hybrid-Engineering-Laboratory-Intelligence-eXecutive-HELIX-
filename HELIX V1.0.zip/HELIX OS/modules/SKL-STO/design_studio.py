from __future__ import annotations
from dataclasses import dataclass,field
from enum import Enum
from typing import Mapping
class StorageTechnology(str,Enum):
 GLASS_5D="GLASS_5D";HOLOGRAPHIC="HOLOGRAPHIC";SPECTRAL="SPECTRAL";MOLECULAR_DNA="MOLECULAR_DNA";MAGNETIC_SPINTRONIC="MAGNETIC_SPINTRONIC"
class Readiness(str,Enum):
 INCOMPLETE="INCOMPLETE";ANALYZABLE="ANALYZABLE";ENGINEERING_CANDIDATE="ENGINEERING_CANDIDATE"
@dataclass(frozen=True)
class StorageDesign:
 name:str;technology:StorageTechnology;parameters:Mapping[str,float];evidence_ids:tuple[str,...]=();source_ids:tuple[str,...]=()
 def __post_init__(self):
  if not self.name.strip():raise ValueError("name required")
  if any(not isinstance(v,(int,float)) for v in self.parameters.values()):raise TypeError("numeric parameters required")
@dataclass(frozen=True)
class DesignRequirement:
 key:str;minimum:float|None=None;maximum:float|None=None
 def __post_init__(self):
  if self.minimum is None and self.maximum is None:raise ValueError("bound required")
  if self.minimum is not None and self.maximum is not None and self.minimum>self.maximum:raise ValueError("invalid bounds")
 def evaluate(self,metrics):
  if self.key not in metrics:return None
  v=metrics[self.key]
  return (self.minimum is None or v>=self.minimum) and (self.maximum is None or v<=self.maximum)
@dataclass(frozen=True)
class DesignAssessment:
 technology:StorageTechnology;metrics:Mapping[str,float];requirement_results:Mapping[str,bool|None];readiness:Readiness;warnings:tuple[str,...]
 @property
 def passes_known_requirements(self):return all(v is not False for v in self.requirement_results.values())
def assess_design(design,metrics,requirements=()):
 if any(not isinstance(v,(int,float)) for v in metrics.values()):raise TypeError("numeric metrics required")
 results={r.key:r.evaluate(metrics) for r in requirements}
 warnings=[]
 if any(v is None for v in results.values()):warnings.append("One or more required metrics are unavailable.")
 if not design.evidence_ids:warnings.append("No evidence identifiers attached.")
 if not design.source_ids:warnings.append("No source identifiers attached.")
 if any(v is False for v in results.values()):readiness=Readiness.INCOMPLETE
 elif warnings:readiness=Readiness.ANALYZABLE
 else:readiness=Readiness.ENGINEERING_CANDIDATE
 return DesignAssessment(design.technology,dict(metrics),results,readiness,tuple(warnings))
def compare_designs(assessments,metric):
 vals=[]
 for a in assessments:
  if metric in a.metrics:vals.append((a.technology,a.metrics[metric]))
 return tuple(sorted(vals,key=lambda x:x[1],reverse=True))
def technology_model_ids(technology):
 return {
 StorageTechnology.GLASS_5D:("STO-5D-VOXELS","STO-5D-BITS","STO-5D-RETARDANCE"),
 StorageTechnology.HOLOGRAPHIC:("STO-HOLO-FRINGE","STO-HOLO-BRAGG","STO-HOLO-PAGE"),
 StorageTechnology.SPECTRAL:("STO-SPEC-COHERENCE","STO-SPEC-CHANNELS","STO-AFC-ECHO"),
 StorageTechnology.MOLECULAR_DNA:("STO-DNA-IDEAL","STO-DNA-CAP","STO-DNA-SURVIVAL"),
 StorageTechnology.MAGNETIC_SPINTRONIC:("STO-MAG-BARRIER","STO-MAG-STABILITY","STO-MAG-NEEL","STO-MRAM-TMR"),
 }[technology]
def analysis_chain(technology):
 return ("physics_models","capacity_density","read_write_error","engineering_requirements","evidence_provenance","comparison")
