from __future__ import annotations
from dataclasses import dataclass
import random,statistics,math
from .spec import *
class SimulationError(ValueError):pass
@dataclass(frozen=True)
class SimulationResult:
 mode:str;model_id:str;records:tuple;metadata:dict
class SimulationEngine:
 def __init__(self,physics_registry,max_sweep_points=100000,max_monte_carlo_samples=100000):
  self.physics=physics_registry;self.max_sweep=max_sweep_points;self.max_mc=max_monte_carlo_samples
 def _eval(self,spec,inputs):
  try:return self.physics.evaluate(spec.model_id,**inputs)
  except Exception as e:raise SimulationError(str(e)) from e
 def run(self,spec):
  dispatch={SimulationMode.POINT:self._point,SimulationMode.TIME_DOMAIN:self._time,
   SimulationMode.SWEEP:self._sweep,SimulationMode.MONTE_CARLO:self._mc,
   SimulationMode.SENSITIVITY:self._sensitivity,SimulationMode.OPTIMIZATION:self._optimization,
   SimulationMode.FAILURE:self._failure}
  if spec.mode==SimulationMode.SUITE:raise SimulationError("Use run_suite for SUITE mode.")
  return dispatch[spec.mode](spec)
 def _result(self,spec,records,**meta):
  return SimulationResult(spec.mode.value,spec.model_id,tuple(records),{"record_count":len(records),**meta})
 def _point(self,spec):
  out=self._eval(spec,dict(spec.inputs));return self._result(spec,[{"inputs":dict(spec.inputs),"outputs":out}])
 def _time(self,spec):
  if not spec.time_parameter or not spec.time_values:raise SimulationError("time_parameter and time_values required")
  if len(spec.time_values)>self.max_sweep:raise SimulationError("time-domain point limit exceeded")
  rec=[]
  for t in spec.time_values:
   x=dict(spec.inputs);x[spec.time_parameter]=float(t);rec.append({"time":float(t),"outputs":self._eval(spec,x)})
  return self._result(spec,rec,time_parameter=spec.time_parameter)
 def _sweep(self,spec):
  if not spec.sweep_parameter or not spec.sweep_values:raise SimulationError("sweep_parameter and sweep_values required")
  if len(spec.sweep_values)>self.max_sweep:raise SimulationError("sweep point limit exceeded")
  rec=[]
  for v in spec.sweep_values:
   x=dict(spec.inputs);x[spec.sweep_parameter]=float(v);rec.append({"parameter":float(v),"outputs":self._eval(spec,x)})
  return self._result(spec,rec,sweep_parameter=spec.sweep_parameter)
 def _sample(self,rng,definition):
  kind=definition["kind"]
  if kind=="uniform":return rng.uniform(float(definition["low"]),float(definition["high"]))
  if kind=="normal":return rng.gauss(float(definition["mean"]),float(definition["stdev"]))
  raise SimulationError("unsupported distribution: "+kind)
 def _mc(self,spec):
  if spec.samples<1 or spec.samples>self.max_mc:raise SimulationError("invalid Monte Carlo sample count")
  if spec.seed is None:raise SimulationError("Monte Carlo seed required for reproducibility")
  rng=random.Random(spec.seed);rec=[]
  for i in range(spec.samples):
   x=dict(spec.inputs)
   for k,v in spec.distributions.items():x[k]=self._sample(rng,v)
   rec.append({"sample":i,"inputs":x,"outputs":self._eval(spec,x)})
  return self._result(spec,rec,seed=spec.seed)
 def _sensitivity(self,spec):
  if not spec.output_key:raise SimulationError("output_key required")
  base=self._eval(spec,dict(spec.inputs));y0=float(base[spec.output_key]);rec=[]
  for k,v in spec.inputs.items():
   if not isinstance(v,(int,float)) or v==0:continue
   delta=abs(float(v))*.01;x=dict(spec.inputs);x[k]=float(v)+delta
   y1=float(self._eval(spec,x)[spec.output_key])
   elasticity=((y1-y0)/y0)/((x[k]-v)/v) if y0!=0 else None
   rec.append({"parameter":k,"base":float(v),"delta":delta,"elasticity":elasticity})
  return self._result(spec,rec,perturbation_fraction=.01)
 def _optimization(self,spec):
  if not spec.output_key or not spec.sweep_parameter or not spec.sweep_values:raise SimulationError("optimization requires output_key and sweep")
  sweep=self._sweep(spec);key=spec.output_key
  valid=[r for r in sweep.records if key in r["outputs"]]
  if not valid:raise SimulationError("objective output absent")
  fn=max if spec.objective=="max" else min if spec.objective=="min" else None
  if fn is None:raise SimulationError("objective must be max or min")
  best=fn(valid,key=lambda r:float(r["outputs"][key]))
  return self._result(spec,[best],objective=spec.objective,sweep_parameter=spec.sweep_parameter)
 def _failure(self,spec):
  out=self._eval(spec,dict(spec.inputs));fail=[]
  for key,rule in spec.failure_rules.items():
   if key not in out:continue
   v=float(out[key]);op=rule["op"];limit=float(rule["value"])
   hit={"gt":v>limit,"ge":v>=limit,"lt":v<limit,"le":v<=limit}.get(op)
   if hit is None:raise SimulationError("unsupported failure operator")
   if hit:fail.append({"output":key,"value":v,"op":op,"limit":limit})
  return self._result(spec,[{"outputs":out,"failures":fail,"failed":bool(fail)}])
 def run_suite(self,specs):
  results=[]
  for x in specs:
   if x.mode==SimulationMode.SUITE:raise SimulationError("nested suites unsupported")
   results.append(self.run(x))
  return tuple(results)
