from dataclasses import dataclass
@dataclass(frozen=True)
class PhotonicsModel:
 model_id:str;name:str;equation:str;inputs:tuple[str,...];outputs:tuple[str,...];evidence_class:str="ESTABLISHED_PHYSICS"
class PhotonicsRegistry:
 def __init__(self):
  self.models={}
  for m in (
   PhotonicsModel("PHO-PHOTON-ENERGY","Photon energy","E = h c / lambda",("wavelength_m",),("energy_j",)),
   PhotonicsModel("PHO-SNELL","Snell refraction","n1 sin(theta1) = n2 sin(theta2)",("n1","n2","theta1_rad"),("theta2_rad",)),
   PhotonicsModel("PHO-OPL","Optical path length","OPL = n L",("length_m","refractive_index"),("opl_m",)),
   PhotonicsModel("PHO-PHASE","Propagation phase","phi = 2 pi n L / lambda",("length_m","wavelength_m","refractive_index"),("phase_rad",)),
   PhotonicsModel("PHO-ABCD-FREE","Paraxial free-space propagation","[y2,theta2]^T = [[1,L],[0,1]][y1,theta1]^T",("height_m","angle_rad","distance_m"),("height_out_m","angle_out_rad",)),
   PhotonicsModel("PHO-ABCD-LENS","Paraxial thin lens","[y2,theta2]^T = [[1,0],[-1/f,1]][y1,theta1]^T",("height_m","angle_rad","focal_length_m"),("height_out_m","angle_out_rad",)),
   PhotonicsModel("PHO-LENSMAKER","Thin lensmaker","1/f=(n_l/n_m-1)(1/R1-1/R2)",("n_lens","n_medium","r1_m","r2_m"),("focal_length_m",)),
   PhotonicsModel("PHO-INTERFERENCE-2","Two-beam interference","I=I1+I2+2 V sqrt(I1 I2) cos(delta)",("i1","i2","phase_difference_rad","visibility"),("intensity",)),
   PhotonicsModel("PHO-SINGLE-SLIT","Fraunhofer single slit","I=I0 sinc^2(pi a sin(theta)/lambda)",("theta_rad","wavelength_m","slit_width_m"),("intensity",)),
   PhotonicsModel("PHO-GRATING","Diffraction grating","m lambda=d(sin(theta_m)+sin(theta_i))",("order","wavelength_m","spacing_m","incidence_rad"),("theta_rad",)),
   PhotonicsModel("PHO-GAUSS-ZR","Gaussian Rayleigh range","z_R=pi w0^2/lambda_medium",("waist_m","wavelength_m","refractive_index"),("rayleigh_range_m",)),
   PhotonicsModel("PHO-GAUSS-W","Gaussian beam radius","w(z)=w0 sqrt(1+(z/z_R)^2)",("waist_m","z_m","rayleigh_range_m"),("radius_m",)),
   PhotonicsModel("PHO-GAUSS-Q","Gaussian ABCD law","q2=(A q1+B)/(C q1+D)",("q_in","ABCD"),("q_out",)),
   PhotonicsModel("PHO-MALUS","Malus law","I=I0 cos^2(theta)",("input_intensity","angle_rad"),("intensity",)),
   PhotonicsModel("PHO-STOKES","Jones-to-Stokes","S0=|Ex|^2+|Ey|^2; S1=|Ex|^2-|Ey|^2",("Ex","Ey"),("S0","S1","S2","S3",)),
   PhotonicsModel("PHO-RETARDER","Linear retarder","J=R(-theta) diag(1,exp(i delta)) R(theta)",("theta","retardance_rad"),("JonesMatrix",)),
   PhotonicsModel("PHO-SELLMEIER","Sellmeier dispersion","n^2=1+sum(B_i lambda^2/(lambda^2-C_i))",("wavelength_m","B","C"),("refractive_index",)),
   PhotonicsModel("PHO-BEER","Beer-Lambert transmission","T=exp(-alpha L)",("absorption_m_inv","length_m"),("transmission",)),
   PhotonicsModel("PHO-GROUP-INDEX","Group index","n_g=n-lambda dn/dlambda",("wavelength_m","n(lambda)"),("group_index",)),
   PhotonicsModel("PHO-LASER-FSR","Linear cavity FSR","Delta nu=c/(2 n L)",("length_m","n"),("fsr_hz",)),
   PhotonicsModel("PHO-LASER-THRESHOLD","Laser threshold gain","g_th=alpha+(1/(2L)) ln(1/(R1 R2))",("r1","r2","length_m","loss"),("gain_per_m",)),
   PhotonicsModel("PHO-PULSE-ENERGY","Pulse energy","E_p=P_avg/f_rep",("average_power_w","repetition_rate_hz"),("pulse_energy_j",)),
   PhotonicsModel("PHO-DETECT-RESP","Photodiode responsivity","R=eta q lambda/(h c)",("qe","wavelength_m"),("responsivity_a_w",)),
   PhotonicsModel("PHO-DETECT-SHOT","Shot noise","i_n=sqrt(2 q I B)",("current_a","bandwidth_hz"),("noise_a_rms",)),
   PhotonicsModel("PHO-DETECT-NEP","Noise equivalent power","NEP=i_n/R",("noise_density","responsivity"),("nep",))):
   self.models[m.model_id]=m
 def get(self,model_id):return self.models[model_id]
