from __future__ import annotations
from dataclasses import dataclass,asdict
from math import sqrt
from statistics import mean,median
from typing import Iterable
import time

@dataclass(frozen=True)
class AnalyticsFinding:
    kind:str
    severity:str
    metric:str
    message:str
    score:float|None
    confidence:float
    evidence:dict
    provenance:str
    timestamp:float

def _clean(values):
    return [float(x) for x in values if x is not None]

def _mad(xs):
    if not xs:return 0.0
    m=median(xs);return median([abs(x-m) for x in xs])

class GuardianAnalytics:
    """Small, local statistical/ML-style analytics layer.
    It flags evidence; it never becomes a safety authority or fabricates missing samples."""
    def robust_outliers(self,metric,values,threshold=3.5,provenance="SOFTWARE"):
        xs=_clean(values)
        if len(xs)<5:return []
        med=median(xs);mad=_mad(xs)
        if mad==0:return []
        out=[]
        for i,x in enumerate(xs):
            z=0.67448975*(x-med)/mad
            if abs(z)>=threshold:
                out.append(AnalyticsFinding("OUTLIER","WARNING",metric,
                    f"Robust outlier at sample {i}.",abs(z),min(.99,.55+.05*len(xs)),
                    {"index":i,"value":x,"median":med,"mad":mad,"threshold":threshold},
                    provenance,time.time()))
        return out

    def trend(self,metric,values,min_abs_slope=0.0,provenance="SOFTWARE"):
        xs=_clean(values);n=len(xs)
        if n<4:return None
        mx=(n-1)/2;my=mean(xs)
        den=sum((i-mx)**2 for i in range(n))
        slope=sum((i-mx)*(y-my) for i,y in enumerate(xs))/den if den else 0.0
        if abs(slope)<=min_abs_slope:return None
        direction="increasing" if slope>0 else "decreasing"
        return AnalyticsFinding("TREND","NOTICE",metric,f"{metric} is {direction}.",abs(slope),
            min(.95,.5+.04*n),{"slope_per_sample":slope,"samples":n},provenance,time.time())

    def divergence(self,metric,observed,reference,relative_warn=.10,provenance="SOFTWARE"):
        a=_clean(observed);b=_clean(reference);n=min(len(a),len(b))
        if n<2:return None
        a=a[:n];b=b[:n]
        rmse=sqrt(sum((x-y)**2 for x,y in zip(a,b))/n)
        scale=max(sqrt(sum(y*y for y in b)/n),1e-12)
        rel=rmse/scale
        sev="WARNING" if rel>=relative_warn else "INFO"
        return AnalyticsFinding("DIVERGENCE",sev,metric,
            f"Observed/reference normalized RMSE is {rel:.4g}.",rel,
            min(.99,.55+.04*n),{"rmse":rmse,"normalized_rmse":rel,"samples":n,"warning_threshold":relative_warn},
            provenance,time.time())

    def consistency(self,metric,values,lower=None,upper=None,provenance="SOFTWARE"):
        xs=_clean(values);findings=[]
        for i,x in enumerate(xs):
            bad=(lower is not None and x<lower) or (upper is not None and x>upper)
            if bad:
                findings.append(AnalyticsFinding("CONSISTENCY","WARNING",metric,
                    f"Sample {i} is outside the declared analytical range.",None,.99,
                    {"index":i,"value":x,"lower":lower,"upper":upper},provenance,time.time()))
        return findings

    def summarize(self,findings):
        fs=list(findings)
        return {"count":len(fs),"warnings":sum(f.severity=="WARNING" for f in fs),
                "findings":[asdict(f) for f in fs]}
