from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import heapq,math

class QuantumLinkKind(str,Enum):
    FIBER="FIBER"; FREE_SPACE="FREE_SPACE"; SATELLITE="SATELLITE"; INTERPLANETARY="INTERPLANETARY"; REPEATER="REPEATER"

@dataclass(frozen=True)
class QuantumNetworkNode:
    node_id:str
    memory_efficiency:float=1.0
    memory_coherence_time_s:float=1.0
    processing_delay_s:float=0.0
    def __post_init__(self):
        if not self.node_id or not 0<=self.memory_efficiency<=1 or self.memory_coherence_time_s<=0 or self.processing_delay_s<0:
            raise ValueError("invalid node")

@dataclass(frozen=True)
class QuantumNetworkLink:
    source:str
    target:str
    kind:QuantumLinkKind
    entanglement_rate_per_s:float
    fidelity:float
    success_probability:float
    classical_latency_s:float
    key_rate_bps:float=0.0
    def __post_init__(self):
        if not self.source or not self.target or self.source==self.target or self.entanglement_rate_per_s<0 or self.key_rate_bps<0 or self.classical_latency_s<0:
            raise ValueError("invalid link")
        if not 0<=self.fidelity<=1 or not 0<=self.success_probability<=1:raise ValueError("probabilities/fidelity in [0,1]")

def path_bottleneck_rate_per_s(links):
    if not links:return 0.0
    return min(x.entanglement_rate_per_s for x in links)

def path_bottleneck_key_rate_bps(links):
    if not links:return 0.0
    return min(x.key_rate_bps for x in links)

def path_classical_latency_s(links,node_processing_delay_s=0.0):
    if node_processing_delay_s<0:raise ValueError("delay nonnegative")
    return sum(x.classical_latency_s for x in links)+max(0,len(links)-1)*node_processing_delay_s

def path_success_probability(links,swap_success_probability=1.0):
    if not 0<=swap_success_probability<=1:raise ValueError("swap probability in [0,1]")
    if not links:return 0.0
    p=1.0
    for x in links:p*=x.success_probability
    if len(links)>1:p*=swap_success_probability**(len(links)-1)
    return p

def path_werner_visibility(links,swap_quality=1.0):
    if not 0<=swap_quality<=1:raise ValueError("swap quality in [0,1]")
    if not links:return 0.0
    v=1.0
    for x in links:
        # F=(1+3V)/4 => V=(4F-1)/3, clipped for the Werner approximation.
        v*=max(0.0,min(1.0,(4*x.fidelity-1)/3))
    if len(links)>1:v*=swap_quality**(len(links)-1)
    return v

def path_fidelity(links,swap_quality=1.0):
    if not links:return 0.0
    return (1+3*path_werner_visibility(links,swap_quality))/4

def effective_entanglement_throughput_per_s(links,swap_success_probability=1.0):
    return path_bottleneck_rate_per_s(links)*path_success_probability(links,swap_success_probability)

class QuantumNetwork:
    def __init__(self):
        self.nodes={};self.links=[]
    def add_node(self,node:QuantumNetworkNode):
        if node.node_id in self.nodes:raise ValueError("duplicate node")
        self.nodes[node.node_id]=node
    def add_link(self,link:QuantumNetworkLink):
        if link.source not in self.nodes or link.target not in self.nodes:raise ValueError("link endpoints must exist")
        self.links.append(link)
    def _adj(self):
        a={k:[] for k in self.nodes}
        for x in self.links:
            a[x.source].append((x.target,x));a[x.target].append((x.source,x))
        return a
    def shortest_latency_path(self,start,end):
        if start not in self.nodes or end not in self.nodes:raise ValueError("unknown endpoint")
        if start==end:return []
        adj=self._adj();dist={start:0.0};prev={};q=[(0.0,start)]
        while q:
            d,u=heapq.heappop(q)
            if d!=dist.get(u):continue
            if u==end:break
            for v,link in adj[u]:
                nd=d+link.classical_latency_s+self.nodes[v].processing_delay_s
                if nd<dist.get(v,float("inf")):
                    dist[v]=nd;prev[v]=(u,link);heapq.heappush(q,(nd,v))
        if end not in prev:return []
        out=[];cur=end
        while cur!=start:
            u,link=prev[cur];out.append(link);cur=u
        return list(reversed(out))
    def widest_entanglement_path(self,start,end):
        if start not in self.nodes or end not in self.nodes:raise ValueError("unknown endpoint")
        if start==end:return []
        adj=self._adj();best={start:float("inf")};prev={};q=[(-float("inf"),start)]
        while q:
            neg,u=heapq.heappop(q);cap=-neg
            if u==end:break
            for v,link in adj[u]:
                nc=min(cap,link.entanglement_rate_per_s)
                if nc>best.get(v,-1):
                    best[v]=nc;prev[v]=(u,link);heapq.heappush(q,(-nc,v))
        if end not in prev:return []
        out=[];cur=end
        while cur!=start:
            u,link=prev[cur];out.append(link);cur=u
        return list(reversed(out))

@dataclass(frozen=True)
class NetworkPathAssessment:
    hop_count:int
    bottleneck_entanglement_rate_per_s:float
    effective_entanglement_throughput_per_s:float
    bottleneck_key_rate_bps:float
    end_to_end_fidelity:float
    success_probability:float
    classical_latency_s:float

def assess_path(links,swap_success_probability=1.0,swap_quality=1.0,node_processing_delay_s=0.0):
    if not links:return NetworkPathAssessment(0,0,0,0,0,0,0)
    return NetworkPathAssessment(len(links),path_bottleneck_rate_per_s(links),
      effective_entanglement_throughput_per_s(links,swap_success_probability),
      path_bottleneck_key_rate_bps(links),path_fidelity(links,swap_quality),
      path_success_probability(links,swap_success_probability),
      path_classical_latency_s(links,node_processing_delay_s))
