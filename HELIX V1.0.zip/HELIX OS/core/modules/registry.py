from dataclasses import dataclass,asdict
from pathlib import Path
import json,os
class ModuleError(RuntimeError):pass
@dataclass(frozen=True)
class ModuleManifest:
 module_id:str;name:str;version:str;api_version:str;dependencies:tuple[str,...]=();capabilities:tuple[str,...]=()
class ModuleRegistry:
 def __init__(self,path:Path,api_version="1.0"):
  self.path=path;self.api_version=api_version;self.modules={}
  if path.exists():
   for x in json.loads(path.read_text()).get("modules",[]):self.modules[x["module_id"]]=ModuleManifest(**{**x,"dependencies":tuple(x.get("dependencies",[])),"capabilities":tuple(x.get("capabilities",[]))})
 def register(self,manifest):
  if manifest.api_version!=self.api_version:raise ModuleError("module API incompatibility")
  missing=[x for x in manifest.dependencies if x not in self.modules]
  if missing:raise ModuleError("missing dependencies: "+", ".join(missing))
  self.modules[manifest.module_id]=manifest;self._save()
 def unregister(self,module_id):
  dependents=[x.module_id for x in self.modules.values() if module_id in x.dependencies]
  if dependents:raise ModuleError("module required by: "+", ".join(dependents))
  self.modules.pop(module_id,None);self._save()
 def _save(self):
  self.path.parent.mkdir(parents=True,exist_ok=True);tmp=self.path.with_suffix(".tmp")
  data={"api_version":self.api_version,"modules":[]}
  for x in sorted(self.modules.values(),key=lambda z:z.module_id):
   d=asdict(x);d["dependencies"]=list(x.dependencies);d["capabilities"]=list(x.capabilities);data["modules"].append(d)
  tmp.write_text(json.dumps(data,indent=2),encoding="utf-8");os.replace(tmp,self.path)
