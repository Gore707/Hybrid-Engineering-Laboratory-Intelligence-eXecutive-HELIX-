import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import unittest
from pathlib import Path

from core.bootstrap.config import load_config
from core.bootstrap.identity import IDENTITY

ROOT = Path(__file__).resolve().parents[1]

class C02CoreTests(unittest.TestCase):
    def test_identity(self):
        self.assertEqual(IDENTITY.patch_id, "SKL-CORE-C02")
        self.assertEqual(IDENTITY.product, "HELIX")

    def test_config(self):
        cfg = load_config(ROOT / "skl.config")
        self.assertEqual(cfg["core"]["patch"], "SKL-CORE-C02")
        self.assertTrue(cfg["ui"]["top_bar"])
        self.assertTrue(cfg["ui"]["bottom_status_bar"])

    def test_ui_import_and_construct_if_pyside_available(self):
        try:
            from PySide6.QtWidgets import QApplication
            from core.ui.main_window import HelixMainWindow, TOP_MENUS
        except ImportError:
            self.skipTest("PySide6 not installed in test environment")
        app = QApplication.instance() or QApplication([])
        w = HelixMainWindow(load_config(ROOT / "skl.config"))
        self.assertEqual(len(TOP_MENUS), 11)
        self.assertIn("Guardian", TOP_MENUS)
        self.assertIsNotNone(w.centralWidget())
        self.assertIsNotNone(w.statusBar())

if __name__ == "__main__":
    unittest.main()
