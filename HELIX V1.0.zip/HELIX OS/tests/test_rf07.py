import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-RF"
sp=importlib.util.spec_from_file_location("skl_rf",M/"__init__.py",submodule_search_locations=[str(M)])
r=importlib.util.module_from_spec(sp);sys.modules["skl_rf"]=r;sp.loader.exec_module(r)
def scenario(power=100,distance=1000,required=-10):
 p=r.PropagationLossBudget(distance,1e9)
 return r.IntegratedRFScenario(power,100,100,p,1.5,290,1e6,r.Modulation.QPSK,.8,.2,required,2,1024,.9)
class T(unittest.TestCase):
 def test_sim(self):
  x=r.simulate_rf_link(scenario());self.assertGreater(x.received_power_w,0);self.assertGreater(x.bandwidth_hz,0)
 def test_evidence(self):self.assertEqual(r.simulate_rf_link(scenario()).evidence,"SIMULATION")
 def test_margin_identity(self):
  s=scenario();x=r.simulate_rf_link(s);self.assertAlmostEqual(x.link_margin_db,x.ebn0_db+s.coding_gain_db-s.required_ebn0_db)
 def test_status_pass(self):self.assertEqual(r.simulate_rf_link(scenario(required=-50)).status,r.LinkStatus.PASS)
 def test_status_fail(self):self.assertEqual(r.simulate_rf_link(scenario(power=1e-12,required=20)).status,r.LinkStatus.FAIL)
 def test_power_improves_margin(self):
  self.assertGreater(r.simulate_rf_link(scenario(1000)).link_margin_db,r.simulate_rf_link(scenario(10)).link_margin_db)
 def test_distance_hurts_margin(self):
  self.assertLess(r.simulate_rf_link(scenario(distance=10000)).link_margin_db,r.simulate_rf_link(scenario(distance=1000)).link_margin_db)
 def test_sweep_distance(self):
  xs=r.sweep_distance(scenario(),[1000,2000,4000]);self.assertEqual(len(xs),3);self.assertGreater(xs[0][1].link_margin_db,xs[-1][1].link_margin_db)
 def test_sweep_power(self):
  xs=r.sweep_transmit_power(scenario(),[1,10,100]);self.assertGreater(xs[-1][1].link_margin_db,xs[0][1].link_margin_db)
 def test_min_power(self):
  s=scenario();p=r.minimum_transmit_power_for_margin_w(s,3);x=r.simulate_rf_link(r.IntegratedRFScenario(p,s.tx_gain_linear,s.rx_gain_linear,s.propagation,s.receiver_noise_factor,s.receiver_temperature_k,s.bit_rate_bps,s.modulation,s.code_rate,s.rolloff,s.required_ebn0_db,s.coding_gain_db,s.packet_bits,s.protocol_efficiency,s.tx_misc_loss_db,s.rx_misc_loss_db,s.marginal_threshold_db));self.assertAlmostEqual(x.link_margin_db,3,places=8)
 def test_per_bounds(self):
  x=r.simulate_rf_link(scenario());self.assertTrue(0<=x.packet_error_rate<=1)
 def test_goodput_bounds(self):
  s=scenario();x=r.simulate_rf_link(s);self.assertTrue(0<=x.goodput_bps<=s.bit_rate_bps)
 def test_misc_loss_hurts(self):
  s=scenario();a=r.simulate_rf_link(s);b=r.simulate_rf_link(r.IntegratedRFScenario(s.transmit_power_w,s.tx_gain_linear,s.rx_gain_linear,s.propagation,s.receiver_noise_factor,s.receiver_temperature_k,s.bit_rate_bps,s.modulation,s.code_rate,s.rolloff,s.required_ebn0_db,s.coding_gain_db,s.packet_bits,s.protocol_efficiency,10,0,s.marginal_threshold_db));self.assertAlmostEqual(a.link_margin_db-b.link_margin_db,10)
 def test_coding_gain_improves(self):
  s=scenario();b=r.IntegratedRFScenario(s.transmit_power_w,s.tx_gain_linear,s.rx_gain_linear,s.propagation,s.receiver_noise_factor,s.receiver_temperature_k,s.bit_rate_bps,s.modulation,s.code_rate,s.rolloff,s.required_ebn0_db,5,s.packet_bits,s.protocol_efficiency);self.assertGreater(r.simulate_rf_link(b).link_margin_db,r.simulate_rf_link(s).link_margin_db)
 def test_invalid(self):
  with self.assertRaises(ValueError):scenario(power=-1)
 def test_digital_preserved(self):self.assertEqual(r.bits_per_symbol(r.Modulation.QPSK),2)
 def test_coherent_preserved(self):self.assertAlmostEqual(r.phase_coherence_factor((0,0)),1)
 def test_propagation_preserved(self):self.assertAlmostEqual(r.propagation_delay_s(r.C),1)
 def test_registry(self):self.assertTrue({"RF-LINK-END2END","RF-LINK-MARGIN","RF-LINK-MIN-PT"}<={x.model_id for x in r.RFRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-RF-07")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-HQIC"])
 def test_hqic_complete(self):self.assertEqual(json.loads((R/"HQIC_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
