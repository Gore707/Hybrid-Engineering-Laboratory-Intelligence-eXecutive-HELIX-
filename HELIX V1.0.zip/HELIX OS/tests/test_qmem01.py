import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM";sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)]);q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_state(self):self.assertEqual(q.QuantumStateDescriptor("q1",q.StateKind.QUBIT,2).dimension,2)
 def test_bad_dimension(self):
  with self.assertRaises(ValueError):q.QuantumStateDescriptor("q",q.StateKind.QUBIT,1)
 def test_protocol(self):self.assertTrue(q.MemoryProtocol("cycle",(q.Operation.WRITE,q.Operation.STORE,q.Operation.RETRIEVE)).has_storage_cycle())
 def test_efficiency(self):self.assertAlmostEqual(q.MemoryPerformance(.8,.75,.9).end_to_end_efficiency,.6)
 def test_fidelity(self):self.assertEqual(q.pure_state_fidelity(.5),.25)
 def test_survival(self):self.assertAlmostEqual(q.exponential_coherence_survival(1,1),math.exp(-1))
 def test_coherence_fidelity(self):self.assertAlmostEqual(q.coherence_limited_fidelity(1,0,1),1)
 def test_no_cloning(self):
  with self.assertRaises(ValueError):q.no_cloning_guard(2,True)
 def test_metadata(self):self.assertEqual(q.classical_metadata_record(q.QuantumStateDescriptor("q",q.StateKind.QUDIT,3))["dimension"],3)
 def test_coherence_record(self):self.assertEqual(q.CoherenceRecord(t1_s=1,t2_s=.5).t2_s,.5)
 def test_registry(self):self.assertEqual(len(q.QuantumMemoryRegistry().all()),4)
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QMEM-01")
 def test_schema(self):self.assertEqual(json.loads((R/"core/resources/schemas/quantum-memory-state.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_sto_complete(self):self.assertEqual(json.loads((R/"STO_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
