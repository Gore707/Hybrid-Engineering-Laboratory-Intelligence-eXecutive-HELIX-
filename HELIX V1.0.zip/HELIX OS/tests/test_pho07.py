import unittest,importlib.util,sys,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-PHO"
sp=importlib.util.spec_from_file_location("skl_pho",MOD/"__init__.py",submodule_search_locations=[str(MOD)]);p=importlib.util.module_from_spec(sp);sys.modules["skl_pho"]=p;sp.loader.exec_module(p)
class T(unittest.TestCase):
 def test_source_frequency(self):self.assertAlmostEqual(p.LaserSource(1e-6,1).frequency_hz,p.C0/1e-6)
 def test_flux(self):self.assertAlmostEqual(p.LaserSource(1e-6,1).photon_flux_s*p.LaserSource(1e-6,1).photon_energy_j,1)
 def test_coherence(self):self.assertAlmostEqual(p.LaserSource(1e-6,1,1e6).coherence_time_s,1/(math.pi*1e6))
 def test_fsr(self):self.assertAlmostEqual(p.LinearResonator(.5).free_spectral_range_hz,p.C0)
 def test_mode(self):self.assertAlmostEqual(p.LinearResonator(.5).longitudinal_mode_frequency_hz(2),2*p.C0)
 def test_finesse_linewidth(self):
  F=p.resonator_finesse_from_reflectivity(.9);self.assertAlmostEqual(p.resonator_linewidth_hz(1e9,F),1e9/F)
 def test_threshold(self):self.assertAlmostEqual(p.threshold_gain_per_m(1,1,1),0)
 def test_pulse(self):
  x=p.PulseTrain(10,1e6,1e-9);self.assertAlmostEqual(x.pulse_energy_j,1e-5);self.assertAlmostEqual(x.peak_power_rectangular_w,1e4);self.assertAlmostEqual(x.duty_cycle,1e-3)
 def test_transform_limit(self):self.assertAlmostEqual(p.transform_limited_gaussian_bandwidth_hz(1e-12),.441e12)
 def test_saturation(self):self.assertEqual(p.saturation_parameter(10,5),2)
 def test_registry_manifest(self):
  self.assertEqual(p.PhotonicsRegistry().get("PHO-LASER-FSR").evidence_class,"ESTABLISHED_PHYSICS");self.assertEqual(json.loads((MOD/"module.json").read_text())["patch_id"],"SKL-PHO-07")
 def test_no_acceptance(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
