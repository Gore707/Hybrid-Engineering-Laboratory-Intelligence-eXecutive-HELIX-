from __future__ import annotations
from dataclasses import dataclass
import math

G=6.67430e-11
C=299792458.0
M_SUN_KG=1.98847e30
R_SUN_M=6.957e8
AU_M=149597870700.0

def schwarzschild_radius_m(mass_kg=M_SUN_KG):
    if mass_kg<=0:raise ValueError("mass positive")
    return 2*G*mass_kg/C**2

def minimum_solar_focal_distance_m(solar_radius_m=R_SUN_M,mass_kg=M_SUN_KG):
    if solar_radius_m<=0 or mass_kg<=0:raise ValueError("positive inputs")
    rs=schwarzschild_radius_m(mass_kg)
    return solar_radius_m**2/(2*rs)

def minimum_solar_focal_distance_au():
    return minimum_solar_focal_distance_m()/AU_M

def impact_parameter_for_focal_distance_m(focal_distance_m,mass_kg=M_SUN_KG):
    if focal_distance_m<=0:raise ValueError("distance positive")
    return math.sqrt(2*schwarzschild_radius_m(mass_kg)*focal_distance_m)

def weak_field_deflection_rad(impact_parameter_m,mass_kg=M_SUN_KG):
    if impact_parameter_m<=0 or mass_kg<=0:raise ValueError("positive inputs")
    return 4*G*mass_kg/(C**2*impact_parameter_m)

def sgl_on_axis_wave_optics_gain(wavelength_m,mass_kg=M_SUN_KG):
    if wavelength_m<=0 or mass_kg<=0:raise ValueError("positive inputs")
    # Leading on-axis amplification for the ideal monopole wave-optics SGL.
    return 4*math.pi**2*G*mass_kg/(C**2*wavelength_m)

def sgl_gain_db(wavelength_m,mass_kg=M_SUN_KG):
    return 10*math.log10(sgl_on_axis_wave_optics_gain(wavelength_m,mass_kg))

def einstein_ring_angular_radius_rad(focal_distance_m,impact_parameter_m=None,mass_kg=M_SUN_KG):
    if focal_distance_m<=0:raise ValueError("distance positive")
    b=impact_parameter_m if impact_parameter_m is not None else impact_parameter_for_focal_distance_m(focal_distance_m,mass_kg)
    if b<=0:raise ValueError("impact parameter positive")
    return b/focal_distance_m

def image_plane_scale_m_per_rad(focal_distance_m):
    if focal_distance_m<=0:raise ValueError("distance positive")
    return focal_distance_m

def transverse_offset_for_angle_m(focal_distance_m,angle_rad):
    if focal_distance_m<=0:raise ValueError("distance positive")
    return focal_distance_m*angle_rad

def required_angular_pointing_rad(transverse_tolerance_m,focal_distance_m):
    if transverse_tolerance_m<0 or focal_distance_m<=0:raise ValueError("invalid tolerance")
    return transverse_tolerance_m/focal_distance_m

def corona_noise_penalty(signal_power_w,corona_background_power_w):
    if signal_power_w<0 or corona_background_power_w<0:raise ValueError("powers nonnegative")
    if signal_power_w==0:return math.inf if corona_background_power_w>0 else 0.0
    return corona_background_power_w/signal_power_w

def signal_to_corona_ratio(signal_power_w,corona_background_power_w):
    if signal_power_w<0 or corona_background_power_w<0:raise ValueError("powers nonnegative")
    return math.inf if corona_background_power_w==0 else signal_power_w/corona_background_power_w

def cruise_time_years(distance_au,speed_km_s):
    if distance_au<0 or speed_km_s<=0:raise ValueError("invalid cruise")
    seconds=distance_au*AU_M/(speed_km_s*1000)
    return seconds/(365.25*86400)

@dataclass(frozen=True)
class SolarGravitationalLensTerminal:
    focal_distance_au:float
    wavelength_m:float
    transverse_position_tolerance_m:float
    signal_power_w:float=0.0
    corona_background_power_w:float=0.0
    def __post_init__(self):
        if self.focal_distance_au<=0 or self.wavelength_m<=0 or self.transverse_position_tolerance_m<0 or self.signal_power_w<0 or self.corona_background_power_w<0:
            raise ValueError("invalid terminal")
    @property
    def focal_distance_m(self):return self.focal_distance_au*AU_M
    @property
    def above_minimum_focal_distance(self):return self.focal_distance_m>=minimum_solar_focal_distance_m()
    @property
    def impact_parameter_m(self):return impact_parameter_for_focal_distance_m(self.focal_distance_m)
    @property
    def ring_angle_rad(self):return einstein_ring_angular_radius_rad(self.focal_distance_m,self.impact_parameter_m)
    @property
    def ideal_on_axis_gain(self):return sgl_on_axis_wave_optics_gain(self.wavelength_m)
    @property
    def ideal_gain_db(self):return sgl_gain_db(self.wavelength_m)
    @property
    def pointing_tolerance_rad(self):return required_angular_pointing_rad(self.transverse_position_tolerance_m,self.focal_distance_m)
    @property
    def signal_to_corona(self):return signal_to_corona_ratio(self.signal_power_w,self.corona_background_power_w)
