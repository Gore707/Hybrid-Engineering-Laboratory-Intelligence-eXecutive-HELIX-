from __future__ import annotations
from dataclasses import dataclass
@dataclass(frozen=True)
class GuardianAnswer:
 text:str;confidence:float;grounded:bool;knowledge_ids:tuple[str,...];sources:tuple[str,...]
 evidence_classes:tuple[str,...];runtime:str
class GuardianIntelligenceService:
 def __init__(self,index,runtime,max_context_items=8,minimum_grounding_score=.05):
  self.index=index;self.runtime=runtime;self.max_items=max_context_items;self.min_score=minimum_grounding_score
 def ask(self,question):
  if not question.strip():raise ValueError("question required")
  ranked=self.index.search(question,self.max_items)
  ranked=[x for x in ranked if x[0]>=self.min_score]
  result=self.runtime.answer(question,ranked)
  byid={item.item_id:item for _,item in ranked}
  used=[byid[x] for x in result.used_item_ids if x in byid]
  sources=tuple(dict.fromkeys(x.source_id for x in used if x.source_id))
  evidence=tuple(dict.fromkeys(x.evidence_class for x in used if x.evidence_class))
  return GuardianAnswer(result.text,result.confidence,bool(used),result.used_item_ids,sources,evidence,self.runtime.name)
