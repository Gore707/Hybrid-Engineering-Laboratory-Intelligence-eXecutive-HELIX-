from __future__ import annotations
from dataclasses import dataclass,asdict
from enum import Enum
from pathlib import Path
import json,hashlib,os,time
class ProposalStatus(str,Enum):
 PROPOSED="PROPOSED";APPROVED="APPROVED";DENIED="DENIED";DEPLOYED="DEPLOYED"
@dataclass(frozen=True)
class Proposal:
 proposal_id:str;category:str;title:str;rationale:str;evidence:tuple[str,...];risks:tuple[str,...]
 validation:tuple[str,...];rollback:str;confidence:float;fingerprint:str;status:ProposalStatus;created_unix:float
 def dict(self):
  d=asdict(self);d["status"]=self.status.value
  for k in ("evidence","risks","validation"):d[k]=list(d[k])
  return d
class ProposalManager:
 ALLOWED={"GUARDIAN","ALGORITHM","MODEL","DATA","WORKFLOW","UI","COMPUTE","MODULE","CORE","SECURITY"}
 def __init__(self,path:Path):
  self.path=path;path.mkdir(parents=True,exist_ok=True)
 def _fingerprint(self,category,title,rationale):
  return hashlib.sha256((category+"\0"+title+"\0"+rationale).encode()).hexdigest()
 def create(self,category,title,rationale,evidence,risks,validation,rollback,confidence):
  if category not in self.ALLOWED:raise ValueError("invalid proposal category")
  if not 0<=confidence<=1:raise ValueError("confidence")
  fp=self._fingerprint(category,title,rationale)
  for p in self.path.glob("*.json"):
   d=json.loads(p.read_text())
   if d.get("fingerprint")==fp and d.get("status")=="DENIED":
    raise ValueError("Previously denied proposal requires materially new rationale/evidence.")
  pid="PROP-"+fp[:16].upper()
  q=Proposal(pid,category,title,rationale,tuple(evidence),tuple(risks),tuple(validation),rollback,confidence,fp,ProposalStatus.PROPOSED,time.time())
  self._write(q);return q
 def decide(self,proposal_id,approve):
  q=self.get(proposal_id)
  if q.status!=ProposalStatus.PROPOSED:raise ValueError("proposal is not pending")
  d=q.dict();d["status"]=(ProposalStatus.APPROVED if approve else ProposalStatus.DENIED).value
  self._atomic(proposal_id,d);return self.get(proposal_id)
 def mark_deployed(self,proposal_id):
  q=self.get(proposal_id)
  if q.status!=ProposalStatus.APPROVED:raise ValueError("only approved proposals may be deployed")
  d=q.dict();d["status"]=ProposalStatus.DEPLOYED.value;self._atomic(proposal_id,d);return self.get(proposal_id)
 def get(self,pid):
  d=json.loads((self.path/(pid+".json")).read_text());d["status"]=ProposalStatus(d["status"])
  for k in ("evidence","risks","validation"):d[k]=tuple(d[k])
  return Proposal(**d)
 def _write(self,q):self._atomic(q.proposal_id,q.dict())
 def _atomic(self,pid,d):
  p=self.path/(pid+".json");t=p.with_suffix(".tmp");t.write_text(json.dumps(d,indent=2),encoding="utf-8");os.replace(t,p)
