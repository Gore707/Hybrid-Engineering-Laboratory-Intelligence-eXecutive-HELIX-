from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
from datetime import datetime,timezone
import json,os,uuid

def _utc():return datetime.now(timezone.utc).isoformat()

@dataclass(frozen=True)
class MemoryRecord:
    record_id:str;kind:str;title:str;text:str;provenance:str;created_utc:str
    project_id:str|None=None;experiment_id:str|None=None;source_ids:tuple[str,...]=()
    confidence:float|None=None;metadata:dict|None=None

class GuardianMemoryStore:
    """Append-oriented scientific/operator memory. It records supplied facts;
    it does not infer truth or silently promote AI output to canonical evidence."""
    def __init__(self,path:Path):self.path=path;self.records=self._load()
    def _load(self):
        if not self.path.exists():return []
        try:return [MemoryRecord(**x) for x in json.loads(self.path.read_text(encoding="utf-8"))]
        except (OSError,json.JSONDecodeError,TypeError):return []
    def _save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True);tmp=self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps([asdict(x) for x in self.records],indent=2),encoding="utf-8");os.replace(tmp,self.path)
    def add(self,kind,title,text,provenance,project_id=None,experiment_id=None,source_ids=(),confidence=None,metadata=None):
        r=MemoryRecord("MEM-"+uuid.uuid4().hex[:16].upper(),kind,title,text,provenance,_utc(),
                       project_id,experiment_id,tuple(source_ids),confidence,metadata or {})
        self.records.append(r);self._save();return r
    def query(self,text="",project_id=None,experiment_id=None,kind=None,limit=50):
        terms=set(text.lower().split());out=[]
        for r in reversed(self.records):
            if project_id is not None and r.project_id!=project_id:continue
            if experiment_id is not None and r.experiment_id!=experiment_id:continue
            if kind is not None and r.kind!=kind:continue
            hay=(r.title+" "+r.text+" "+" ".join(r.source_ids)).lower()
            if terms and not terms.issubset(set(hay.split())) and not all(t in hay for t in terms):continue
            out.append(r)
            if len(out)>=limit:break
        return out
