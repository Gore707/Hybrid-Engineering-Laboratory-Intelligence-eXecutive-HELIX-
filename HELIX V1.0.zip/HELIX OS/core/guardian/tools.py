from __future__ import annotations
from dataclasses import dataclass,asdict
from typing import Any
from core.commands import CommandRequest,CommandContext,ConfirmationLevel
from .permissions import GuardianPermissionPolicy

@dataclass(frozen=True)
class ToolProposal:
    action_id:str
    parameters:dict[str,Any]
    rationale:str
    requires_confirmation:bool
    confirmation_level:str
    valid:bool
    errors:tuple[str,...]=()

class GuardianToolBridge:
    """Permission boundary between AI reasoning and HELIX CommandService.
    AI may inspect schemas and propose actions. Execution always re-enters deterministic CommandService."""
    def __init__(self,command_service,context_provider,permission_policy=None):
        self.command_service=command_service;self.context_provider=context_provider;self.permission_policy=permission_policy or GuardianPermissionPolicy()

    def catalog(self):
        out=[]
        for a in self.command_service.registry.all():
            out.append({"action_id":a.action_id,"title":a.title,"description":a.description,
                        "category":a.category,"confirmation":a.confirmation.value,
                        "parameters":[{"name":p.name,"type":p.python_type.__name__,"required":p.required,
                                       "default":p.default,"choices":p.choices,"minimum":p.minimum,"maximum":p.maximum}
                                      for p in a.parameters]})
        return out

    def propose(self,action_id,parameters=None,rationale=""):
        parameters=dict(parameters or {});errors=[]
        try:
            action=self.command_service.registry.get(action_id)
            known={p.name for p in action.parameters}
            unknown=set(parameters)-known
            if unknown:errors.append("Unknown parameter(s): "+", ".join(sorted(unknown)))
            for p in action.parameters:
                try:p.validate(parameters.get(p.name,None))
                except (ValueError,TypeError) as exc:errors.append(str(exc))
            level=action.confirmation
        except Exception as exc:
            return ToolProposal(action_id,parameters,rationale,True,"UNKNOWN",False,(str(exc),))
        return ToolProposal(action_id,parameters,rationale,level!=ConfirmationLevel.NONE,level.value,not errors,tuple(errors))

    def execute(self,proposal:ToolProposal,confirmed=False,confirmation_source="OPERATOR"):
        if not proposal.valid:raise ValueError("Invalid Guardian tool proposal: "+"; ".join(proposal.errors))
        action=self.command_service.registry.get(proposal.action_id)
        decision=self.permission_policy.evaluate(action,proposal.valid)
        if not decision.allowed:raise PermissionError(decision.reason)
        if confirmed and confirmation_source!="OPERATOR":
            raise PermissionError("Guardian/AI cannot self-confirm protected HELIX actions.")
        # Only explicit operator confirmation can cross a protected confirmation boundary.
        if proposal.requires_confirmation and not confirmed:
            return self.command_service.execute(CommandRequest(proposal.action_id,proposal.parameters,
                self.context_provider(),confirmed=False))
        return self.command_service.execute(CommandRequest(proposal.action_id,proposal.parameters,
            self.context_provider(),confirmed=bool(confirmed)))
