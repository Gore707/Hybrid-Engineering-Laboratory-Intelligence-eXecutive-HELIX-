from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math, random, statistics
from .foundation import one_way_latency_years_from_ly, causality_bypass_available
from .optical_links import InterstellarOpticalLink, airy_divergence_rad
from .sgl import minimum_solar_focal_distance_au, SolarGravitationalLensTerminal
from .pulsar_timing import minimum_pulsars_for_3d_position_and_clock
from .relays import hop_delivery_capacity_bps
from .galactic_network import GalacticNetwork, GalacticEdge
from .simulation import simulate_route

class FailureSeverity(str,Enum):
    INFO="INFO";NOTICE="NOTICE";WARNING="WARNING";ERROR="ERROR";CRITICAL="CRITICAL"

@dataclass(frozen=True)
class FailureFinding:
    gate_id:str
    severity:FailureSeverity
    passed:bool
    message:str

@dataclass(frozen=True)
class SensitivityPoint:
    parameter:str
    normalized_sensitivity:float

@dataclass(frozen=True)
class MonteCarloSummary:
    trials:int
    success_fraction:float
    mean_rate_bps:float
    p05_rate_bps:float
    p50_rate_bps:float
    p95_rate_bps:float

def percentile(values,p):
    if not values or not 0<=p<=1: raise ValueError("invalid percentile")
    x=sorted(values); k=(len(x)-1)*p; lo=math.floor(k); hi=math.ceil(k)
    if lo==hi:return x[lo]
    return x[lo]*(hi-k)+x[hi]*(k-lo)

def normalized_local_sensitivity(fn,x,relative_step=1e-4):
    if x==0 or relative_step<=0:raise ValueError("nonzero x and positive step required")
    h=abs(x)*relative_step
    yp=fn(x+h);ym=fn(x-h);y0=fn(x)
    if y0==0:return math.inf
    return ((yp-ym)/(2*h))*(x/y0)

def monte_carlo_optical_rate(base:InterstellarOpticalLink,trials=1000,seed=1,
                             power_sigma_fraction=.05,pointing_sigma_rad=0.0):
    if trials<1 or power_sigma_fraction<0 or pointing_sigma_rad<0:raise ValueError("invalid Monte Carlo inputs")
    rng=random.Random(seed);rates=[]
    for _ in range(trials):
        p=max(0,rng.gauss(base.transmit_power_w,base.transmit_power_w*power_sigma_fraction))
        pe=abs(rng.gauss(base.pointing_error_rad,pointing_sigma_rad))
        x=InterstellarOpticalLink(base.distance_ly,base.wavelength_m,p,base.transmitter_diameter_m,
          base.receiver_diameter_m,pe,base.tx_efficiency,base.rx_efficiency,base.detector_efficiency,
          base.background_power_w,base.photons_per_bit)
        rates.append(x.ideal_bit_rate_bps)
    success=sum(r>0 for r in rates)/trials
    return MonteCarloSummary(trials,success,statistics.mean(rates),percentile(rates,.05),
                             percentile(rates,.50),percentile(rates,.95))

def interstellar_failure_gates(link:InterstellarOpticalLink=None,network_result=None,
                               require_sgl=False,sgl_terminal=None,min_rate_bps=1.0,
                               min_route_availability=.5):
    out=[]
    out.append(FailureFinding("ISN-GATE-CAUSALITY",FailureSeverity.CRITICAL,
      not causality_bypass_available(),"Established-physics solver must not expose a causality bypass."))
    if link is not None:
        out.append(FailureFinding("ISN-GATE-RATE",FailureSeverity.ERROR,
          link.ideal_bit_rate_bps>=min_rate_bps,f"Ideal photon-budget rate must be >= {min_rate_bps:g} bit/s."))
        out.append(FailureFinding("ISN-GATE-POINTING",FailureSeverity.ERROR,
          link.pointing_efficiency>0.01,"Pointing efficiency must remain above 1%."))
    if network_result is not None:
        out.append(FailureFinding("ISN-GATE-ROUTE",FailureSeverity.CRITICAL,
          network_result.route_found,"A causal source-to-destination route must exist."))
        out.append(FailureFinding("ISN-GATE-AVAIL",FailureSeverity.WARNING,
          network_result.route_availability>=min_route_availability,
          f"Route availability must be >= {min_route_availability:.3f}."))
    if require_sgl:
        ok=sgl_terminal is not None and sgl_terminal.above_minimum_focal_distance
        out.append(FailureFinding("ISN-GATE-SGL-FOCAL",FailureSeverity.CRITICAL,ok,
          "SGL terminal must lie on or beyond the solar minimum focal line."))
    return tuple(out)

def all_critical_gates_pass(findings):
    return all(f.passed for f in findings if f.severity==FailureSeverity.CRITICAL)

def run_cross_engine_validation(root_path=None):
    checks={}
    checks["causality_no_bypass"]=not causality_bypass_available()
    checks["one_light_year_one_year"]=abs(one_way_latency_years_from_ly(1)-1)<1e-12
    checks["diffraction_inverse_aperture"]=airy_divergence_rad(1e-6,2)<airy_divergence_rad(1e-6,1)
    a=InterstellarOpticalLink(1,1e-6,1e9,100,30)
    b=InterstellarOpticalLink(2,1e-6,1e9,100,30)
    checks["optical_distance_loss"]=b.received_power_w<a.received_power_w
    checks["relay_bottleneck"]=hop_delivery_capacity_bps([100,20,50])==20
    checks["sgl_focal_range"]=540<minimum_solar_focal_distance_au()<560
    checks["pulsar_3d_clock_sources"]=minimum_pulsars_for_3d_position_and_clock()==4
    n=GalacticNetwork(["A","B","C"])
    n.add_edge(GalacticEdge("A","B",1,100,.99));n.add_edge(GalacticEdge("B","C",1,50,.99))
    rr=simulate_route(n,"A","C")
    checks["integrated_route"]=rr.route_found and rr.hops==2 and rr.bottleneck_capacity_bps==50
    if root_path is not None:
        from pathlib import Path
        r=Path(root_path)
        checks["pho_complete"]=(r/"PHO_COMPLETE.json").exists()
        checks["opt_complete"]=(r/"OPT_COMPLETE.json").exists()
        checks["qcom_complete"]=(r/"QCOM_COMPLETE.json").exists()
    return checks
