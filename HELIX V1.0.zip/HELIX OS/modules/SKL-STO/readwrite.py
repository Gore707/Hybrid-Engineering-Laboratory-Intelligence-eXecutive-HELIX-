from __future__ import annotations
from dataclasses import dataclass
import math,hashlib
def expected_bit_errors(bit_count,ber):
 if bit_count<0 or not 0<=ber<=1:raise ValueError("invalid BER inputs")
 return bit_count*ber
def block_uncorrectable_probability(bit_count,ber,correctable_errors):
 if bit_count<0 or int(bit_count)!=bit_count or not 0<=ber<=1 or correctable_errors<0 or int(correctable_errors)!=correctable_errors:raise ValueError("invalid ECC inputs")
 n=int(bit_count);t=int(correctable_errors)
 if t>=n:return 0.0
 return sum(math.comb(n,k)*ber**k*(1-ber)**(n-k) for k in range(t+1,n+1))
def code_rate(data_bits,codeword_bits):
 if data_bits<=0 or codeword_bits<data_bits:raise ValueError("invalid code")
 return data_bits/codeword_bits
def effective_throughput_bps(raw_rate_bps,code_rate_fraction,retry_probability=0.0):
 if raw_rate_bps<0 or not 0<code_rate_fraction<=1 or not 0<=retry_probability<1:raise ValueError("invalid throughput inputs")
 return raw_rate_bps*code_rate_fraction*(1-retry_probability)
def transfer_latency_s(payload_bits,throughput_bps,fixed_latency_s=0.0):
 if payload_bits<0 or throughput_bps<=0 or fixed_latency_s<0:raise ValueError("invalid latency inputs")
 return fixed_latency_s+payload_bits/throughput_bps
@dataclass(frozen=True)
class EnduranceModel:
 rated_cycles:int;completed_cycles:int=0
 def __post_init__(self):
  if self.rated_cycles<1 or self.completed_cycles<0:raise ValueError("invalid endurance")
 @property
 def consumed_fraction(self):return self.completed_cycles/self.rated_cycles
 @property
 def remaining_cycles(self):return max(0,self.rated_cycles-self.completed_cycles)
 @property
 def beyond_rating(self):return self.completed_cycles>self.rated_cycles
@dataclass(frozen=True)
class DefectMap:
 total_sites:int;defective_sites:frozenset[int]
 def __post_init__(self):
  if self.total_sites<1 or any(i<0 or i>=self.total_sites for i in self.defective_sites):raise ValueError("invalid defect map")
 @property
 def yield_fraction(self):return (self.total_sites-len(self.defective_sites))/self.total_sites
def combined_independent_ber(*probabilities):
 if not probabilities:return 0.0
 if any(not 0<=p<=1 for p in probabilities):raise ValueError("probabilities 0..1")
 return 1-math.prod(1-p for p in probabilities)
def sha256_bytes(data):
 if not isinstance(data,(bytes,bytearray)):raise TypeError("bytes required")
 return hashlib.sha256(data).hexdigest()
def verify_sha256(data,expected_hex):
 return sha256_bytes(data).lower()==str(expected_hex).lower()
