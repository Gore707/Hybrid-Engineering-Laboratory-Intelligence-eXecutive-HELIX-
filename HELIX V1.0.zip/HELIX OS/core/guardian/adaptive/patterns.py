from __future__ import annotations
from dataclasses import dataclass
import statistics
@dataclass(frozen=True)
class AnomalyResult:
 anomaly:bool;z_score:float|None;mean:float|None;stdev:float|None;reason:str
class PatternLearner:
 def __init__(self,memory,min_samples=5,z_threshold=3.0):
  self.memory=memory;self.min_samples=min_samples;self.threshold=z_threshold
 def evaluate(self,key,value):
  history=self.memory.values(key,500)
  if len(history)<self.min_samples:
   self.memory.observe("numeric",key,value=value,provenance="Guardian statistical baseline")
   return AnomalyResult(False,None,None,None,"Insufficient baseline samples.")
  mean=statistics.fmean(history);sd=statistics.stdev(history)
  z=0.0 if sd==0 and value==mean else (float("inf") if sd==0 else abs(value-mean)/sd)
  anomaly=z>=self.threshold
  self.memory.observe("numeric",key,value=value,provenance="Guardian statistical baseline")
  return AnomalyResult(anomaly,z,mean,sd,"Statistical deviation exceeds threshold." if anomaly else "Within learned baseline.")
