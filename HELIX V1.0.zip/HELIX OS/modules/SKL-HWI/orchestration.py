from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import time
from .foundation import ConnectionState,CalibrationState
from .coordination import coordinated_preflight,ExperimentTimeline,CoordinatedExecutor,SynchronizationGroup,Interlock
from .safety import SafetyDecision,evaluate_value,OperatingEnvelope

class ExperimentRunState(str,Enum):
    CREATED="CREATED"; PREFLIGHTED="PREFLIGHTED"; RUNNING="RUNNING"; COMPLETED="COMPLETED"; ABORTED="ABORTED"; FAILED="FAILED"

@dataclass(frozen=True)
class InstrumentBinding:
    role:str
    device_id:str
    required:bool=True
    def __post_init__(self):
        if not self.role or not self.device_id:raise ValueError("binding identity required")

@dataclass(frozen=True)
class HardwarePreflightResult:
    ready:bool
    reasons:tuple[str,...]
    checked_device_ids:tuple[str,...]
    timestamp_s:float

@dataclass(frozen=True)
class HardwareExperimentRecord:
    experiment_id:str
    run_id:str
    state:ExperimentRunState
    started_at_s:float|None
    stopped_at_s:float|None
    device_ids:tuple[str,...]
    timeline_history:tuple
    acquisition_manifest_refs:tuple[str,...]
    provenance_sources:tuple[str,...]
    failure_reason:str|None=None

class HardwareExperimentOrchestrator:
    """Unifies hardware state, deterministic safety/preflight, timing and acquisition metadata.
    It delegates physical actions to registered handlers and never bypasses HAL/device safety."""
    def __init__(self,experiment_id,run_id,bindings,instrument_registry,interlocks=(),
                 sync_group=None,envelopes=None):
        if not experiment_id or not run_id:raise ValueError("experiment/run required")
        self.experiment_id=experiment_id;self.run_id=run_id;self.bindings=tuple(bindings)
        self.registry=instrument_registry;self.interlocks=tuple(interlocks);self.sync_group=sync_group
        self.envelopes=dict(envelopes or {})
        self.state=ExperimentRunState.CREATED;self.started_at_s=None;self.stopped_at_s=None
        self.preflight_result=None;self.timeline_history=[];self.acquisition_manifest_refs=[];self.failure_reason=None
    def preflight(self,timestamp_s,timestamps_by_channel=None,current_values=None):
        reasons=[];checked=[]
        for b in self.bindings:
            try:i=self.registry.get(b.device_id)
            except Exception:
                if b.required:reasons.append(f"required device unavailable: {b.device_id}")
                continue
            checked.append(b.device_id)
            if b.required and getattr(i,"connection_state",None)!=ConnectionState.CONNECTED:
                reasons.append(f"required device not connected: {b.device_id}")
            cs=getattr(i,"calibration_state",CalibrationState.UNKNOWN)
            if b.required and cs in (CalibrationState.EXPIRED,CalibrationState.INVALID):
                reasons.append(f"required device calibration not valid: {b.device_id}")
        cp=coordinated_preflight(self.interlocks,self.sync_group,timestamps_by_channel)
        reasons.extend(cp.blocked_reasons)
        for key,val in (current_values or {}).items():
            if key in self.envelopes:
                dev,quantity=key
                ev=evaluate_value(dev,float(val),self.envelopes[key],timestamp_s)
                if ev.decision!=SafetyDecision.ALLOW:reasons.append(f"{dev}/{quantity}: {ev.reason}")
        self.preflight_result=HardwarePreflightResult(not reasons,tuple(reasons),tuple(sorted(checked)),float(timestamp_s))
        self.state=ExperimentRunState.PREFLIGHTED
        return self.preflight_result
    def start(self,timestamp_s):
        if self.state!=ExperimentRunState.PREFLIGHTED or not self.preflight_result or not self.preflight_result.ready:
            raise PermissionError("successful preflight required")
        self.started_at_s=float(timestamp_s);self.state=ExperimentRunState.RUNNING
    def execute_timeline(self,timeline,t0_s,handlers,confirmed_step_ids=()):
        if self.state!=ExperimentRunState.RUNNING:raise RuntimeError("experiment not running")
        # preflight already validated deterministic interlocks/synchronization; executor still requires a ready result.
        cp=coordinated_preflight(self.interlocks)
        if not cp.interlocks_ok:raise PermissionError("interlock changed from SAFE")
        ex=CoordinatedExecutor(handlers)
        hist=ex.execute(timeline,t0_s,cp,confirmed_step_ids)
        self.timeline_history.extend(hist);return hist
    def attach_acquisition_manifest(self,reference):
        if not reference:raise ValueError("manifest reference required")
        self.acquisition_manifest_refs.append(reference)
    def complete(self,timestamp_s):
        if self.state!=ExperimentRunState.RUNNING:raise RuntimeError("experiment not running")
        self.stopped_at_s=float(timestamp_s);self.state=ExperimentRunState.COMPLETED
    def abort(self,timestamp_s,reason):
        if self.state in (ExperimentRunState.COMPLETED,ExperimentRunState.ABORTED):raise RuntimeError("run already terminal")
        if not reason:raise ValueError("abort reason required")
        self.stopped_at_s=float(timestamp_s);self.failure_reason=reason;self.state=ExperimentRunState.ABORTED
    def record(self):
        sources=("HARDWARE",) if self.bindings else ()
        return HardwareExperimentRecord(self.experiment_id,self.run_id,self.state,self.started_at_s,self.stopped_at_s,
            tuple(b.device_id for b in self.bindings),tuple(self.timeline_history),tuple(self.acquisition_manifest_refs),
            sources,self.failure_reason)
