from __future__ import annotations
class ProposalController:
    def __init__(self,intelligence_service,tool_bridge):
        self.intelligence=intelligence_service;self.tools=tool_bridge
    def approve_and_execute(self,proposal_id,operator_confirmed=False):
        p=next((x for x in self.intelligence.proposals if x.proposal_id==proposal_id),None)
        if p is None:raise KeyError(proposal_id)
        if not p.action_id:raise ValueError("Proposal has no HELIX action.")
        tp=self.tools.propose(p.action_id,p.parameters,p.rationale)
        if not tp.valid:raise ValueError("Proposal no longer validates: "+"; ".join(tp.errors))
        if tp.requires_confirmation and not operator_confirmed:
            return self.tools.execute(tp,False,"OPERATOR")
        self.intelligence.set_proposal_status(proposal_id,"APPROVED")
        result=self.tools.execute(tp,operator_confirmed,"OPERATOR")
        if result.success:self.intelligence.set_proposal_status(proposal_id,"INSTALLED")
        return result
    def deny(self,proposal_id):return self.intelligence.set_proposal_status(proposal_id,"DENIED")
