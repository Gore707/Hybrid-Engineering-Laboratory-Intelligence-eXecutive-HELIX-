import unittest,tempfile
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.physics.registry import PhysicsRegistry
from core.simulation import *
from core.simulation.integration import sweep_xy,figure_spec_for_result
ROOT=Path(__file__).resolve().parents[1]
def engine():
 r=PhysicsRegistry(ROOT/"core/resources/constants/physical_constants.json",ROOT/"core/resources/equations",ROOT/"core/resources/models")
 return SimulationEngine(r)
class C19Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C19")
 def test_point(self):
  s=SimulationSpec("MODEL-ARCH-SHANNON-001",SimulationMode.POINT,{"B":1e6,"S":10,"N":1})
  self.assertGreater(engine().run(s).records[0]["outputs"]["C"],3e6)
 def test_time_domain(self):
  s=SimulationSpec("MODEL-ARCH-COHERENCE-001",SimulationMode.TIME_DOMAIN,{"C0":1,"T2":2},time_parameter="t",time_values=(0,1,2))
  r=engine().run(s);self.assertEqual(len(r.records),3);self.assertGreater(r.records[0]["outputs"]["C"],r.records[-1]["outputs"]["C"])
 def test_sweep_and_plot_bridge(self):
  s=SimulationSpec("MODEL-ARCH-PHOTON-001",SimulationMode.SWEEP,{},sweep_parameter="lambda",sweep_values=(1e-6,2e-6))
  r=engine().run(s);x,y=sweep_xy(r,"E_gamma");self.assertEqual(x,[1e-6,2e-6]);self.assertLess(y[1],y[0])
  self.assertEqual(figure_spec_for_result(r,"Photon").provenance["source_type"],"SIMULATION")
 def test_monte_carlo_reproducible(self):
  s=SimulationSpec("MODEL-ARCH-SHANNON-001",SimulationMode.MONTE_CARLO,{"B":1e6,"N":1},distributions={"S":{"kind":"uniform","low":1,"high":10}},samples=5,seed=42)
  a=engine().run(s);b=engine().run(s);self.assertEqual(a.records,b.records)
 def test_mc_requires_seed(self):
  s=SimulationSpec("MODEL-ARCH-SHANNON-001",SimulationMode.MONTE_CARLO,{"B":1e6,"N":1},distributions={"S":{"kind":"uniform","low":1,"high":2}},samples=2)
  with self.assertRaises(SimulationError):engine().run(s)
 def test_sensitivity(self):
  s=SimulationSpec("MODEL-ARCH-SHANNON-001",SimulationMode.SENSITIVITY,{"B":1e6,"S":10,"N":1},output_key="C")
  self.assertTrue(engine().run(s).records)
 def test_optimization(self):
  s=SimulationSpec("MODEL-ARCH-SHANNON-001",SimulationMode.OPTIMIZATION,{"B":1e6,"N":1},output_key="C",sweep_parameter="S",sweep_values=(1,2,10),objective="max")
  self.assertEqual(engine().run(s).records[0]["parameter"],10)
 def test_failure(self):
  s=SimulationSpec("MODEL-ARCH-SHANNON-001",SimulationMode.FAILURE,{"B":1e6,"S":10,"N":1},failure_rules={"C":{"op":"lt","value":4e6}})
  self.assertTrue(engine().run(s).records[0]["failed"])
 def test_suite(self):
  a=SimulationSpec("MODEL-ARCH-PHOTON-001",SimulationMode.POINT,{"lambda":1e-6})
  b=SimulationSpec("MODEL-ARCH-PHOTON-001",SimulationMode.POINT,{"lambda":2e-6})
  self.assertEqual(len(engine().run_suite([a,b])),2)
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
