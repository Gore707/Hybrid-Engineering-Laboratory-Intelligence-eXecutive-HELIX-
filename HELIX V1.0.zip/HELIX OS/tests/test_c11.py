import tempfile,unittest,json
from pathlib import Path
from unittest.mock import patch
from core.bootstrap.identity import IDENTITY
from core.compute.models import ComputeDevice,BackendCapability
from core.compute.manager import ComputeBackendManager
from core.compute.detect import cpu_device
ROOT=Path(__file__).resolve().parents[1]

class C11Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C11")
 def test_cpu_always_real(self):
  d=cpu_device();self.assertEqual(d.kind,"CPU");self.assertEqual(d.backend,"numpy");self.assertTrue(d.available)
 def test_cpu_fallback(self):
  m=ComputeBackendManager();m.devices=[cpu_device()]
  m.capabilities=(BackendCapability("numpy",True,"ok",("CPU-0",)),BackendCapability("cuda",False,"no"),BackendCapability("rocm",False,"no"))
  self.assertEqual(m.choose_backend(),"numpy")
 def test_nvidia_priority_when_available(self):
  m=ComputeBackendManager();m.capabilities=(BackendCapability("numpy",True,"ok"),BackendCapability("cuda",True,"ok"),BackendCapability("rocm",True,"ok"))
  self.assertEqual(m.choose_backend(),"cuda")
 def test_rocm_before_cpu(self):
  m=ComputeBackendManager();m.capabilities=(BackendCapability("numpy",True,"ok"),BackendCapability("cuda",False,"no"),BackendCapability("rocm",True,"ok"))
  self.assertEqual(m.choose_backend(),"rocm")
 def test_preferred_falls_back(self):
  m=ComputeBackendManager();m.capabilities=(BackendCapability("numpy",True,"ok"),BackendCapability("cuda",False,"no"))
  self.assertEqual(m.choose_backend("cuda"),"numpy")
 def test_multi_gpu_summary(self):
  m=ComputeBackendManager();m.devices=[
   cpu_device(),ComputeDevice("AMD-0","GPU","AMD","Radeon A",8,"rocm"),
   ComputeDevice("AMD-1","GPU","AMD","Radeon B",16,"rocm"),
   ComputeDevice("NVIDIA-0","GPU","NVIDIA","RTX",12,"cuda")]
  s=m.summary();self.assertEqual(s["gpu_count"],3);self.assertEqual(s["amd_gpu_count"],2);self.assertEqual(s["nvidia_gpu_count"],1)
 def test_profile_atomic_write(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/"profile.json";m=ComputeBackendManager(p)
   m.devices=[cpu_device()];m.capabilities=(BackendCapability("numpy",True,"ok",("CPU-0",)),);m.selected_backend="numpy"
   m.save_profile();d=json.loads(p.read_text());self.assertEqual(d["selected_backend"],"numpy")
 def test_live_detection_has_cpu(self):
  with tempfile.TemporaryDirectory() as td:
   m=ComputeBackendManager(Path(td)/"p.json");d=m.detect()
   self.assertTrue(any(x.kind=="CPU" for x in d));self.assertIn(m.selected_backend,("numpy","cuda","rocm"))
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
