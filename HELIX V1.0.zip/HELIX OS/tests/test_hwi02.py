import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HWI"
sp=importlib.util.spec_from_file_location("skl_hwi",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_hwi"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_timeout(self):self.assertEqual(q.TimeoutPolicy().io_timeout_s,2)
 def test_bad_timeout(self):
  with self.assertRaises(ValueError):q.TimeoutPolicy(0,1)
 def test_reconnect_delay(self):self.assertEqual(q.ReconnectPolicy(3,.25,2,5).delay_for_attempt(2),1)
 def test_descriptor(self):self.assertEqual(q.TransportDescriptor(q.TransportKind.TCP,"host:1").kind,q.TransportKind.TCP)
 def test_tcp_validation(self):
  with self.assertRaises(ValueError):q.TCPTransport("",1)
 def test_usb_validation(self):
  with self.assertRaises(ValueError):q.USBTransport(70000,1)
 def test_serial_validation(self):
  with self.assertRaises(ValueError):q.SerialTransport("",9600)
 def test_visa_validation(self):
  with self.assertRaises(ValueError):q.VISATransport("")
 def test_scpi_query(self):
  writes=[];c=q.SCPIClient(writes.append,lambda:"SKL,METER,1,1.0\n")
  self.assertEqual(c.identify(),"SKL,METER,1,1.0");self.assertEqual(writes,["*IDN?\n"])
 def test_scpi_command(self):
  writes=[];c=q.SCPIClient(writes.append,lambda:"")
  c.command("OUTP ON");self.assertEqual(writes[-1],"OUTP ON\n")
 def test_scpi_bad_command(self):
  with self.assertRaises(ValueError):q.SCPIClient(lambda x:None,lambda:"").command("*IDN?")
 def test_idn_validation(self):self.assertTrue(q.validate_scpi_identity("SKL,METER,1,1.0"));self.assertFalse(q.validate_scpi_identity("junk"))
 def test_reconnect_success(self):
  n=[0]
  def op():
   n[0]+=1
   if n[0]<2:raise q.TransportError("x")
   return 7
  self.assertEqual(q.reconnect(op,q.ReconnectPolicy(2,0,1,0),lambda x:None),7)
 def test_reconnect_exhausted(self):
  with self.assertRaises(q.TransportUnavailable):q.reconnect(lambda:(_ for _ in ()).throw(q.TransportError("x")),q.ReconnectPolicy(2,0,1,0),lambda x:None)
 def test_discovery_types(self):
  self.assertIsInstance(q.discover_serial(),tuple);self.assertIsInstance(q.discover_visa(),tuple);self.assertIsInstance(q.discover_usb(),tuple)
 def test_foundation_preserved(self):self.assertEqual(q.SourceState.HARDWARE.value,"HARDWARE")
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/transport.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HWI-02")
 def test_bnd_complete_preserved(self):self.assertEqual(json.loads((R/"BND_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
