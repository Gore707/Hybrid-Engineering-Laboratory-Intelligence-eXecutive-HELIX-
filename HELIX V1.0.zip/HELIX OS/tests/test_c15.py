import io,tempfile,unittest
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.research import OpenResearchGateway,GatewayPolicyError,OpenSourceRegistry
from core.research.provenance import artifact_to_source
ROOT=Path(__file__).resolve().parents[1]
class Headers(dict):
 def get(self,k,d=None):return super().get(k,d)
class Response:
 def __init__(self,data,ctype="application/pdf"):self.bio=io.BytesIO(data);self.headers=Headers({"Content-Type":ctype,"Content-Length":str(len(data))})
 def read(self,n=-1):return self.bio.read(n)
 def __enter__(self):return self
 def __exit__(self,*a):pass
def opener_factory(data):
 return lambda req,timeout=None: Response(data,"text/plain" if str(getattr(req,"full_url","")).endswith("robots.txt") else "application/pdf")
class C15Tests(unittest.TestCase):
 def gateway(self,td,data=b"abc"):
  return OpenResearchGateway(Path(td)/"cache",Path(td)/"index.json",respect_robots=False,opener=opener_factory(data))
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C15")
 def test_https_only(self):
  with tempfile.TemporaryDirectory() as td:
   with self.assertRaises(GatewayPolicyError):self.gateway(td).validate_url("http://example.org/a")
 def test_credentials_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   with self.assertRaises(GatewayPolicyError):self.gateway(td).validate_url("https://u:p@example.org/a")
 def test_fetch_cache_checksum_index(self):
  with tempfile.TemporaryDirectory() as td:
   g=self.gateway(td,b"paper");a=g.fetch("https://example.org/paper.pdf",license="CC-BY")
   self.assertEqual(a.size_bytes,5);self.assertTrue(Path(a.cache_file).exists());self.assertEqual(g.cached(a.artifact_id).license,"CC-BY")
 def test_size_limit(self):
  with tempfile.TemporaryDirectory() as td:
   g=self.gateway(td,b"12345");g.max_bytes=4
   with self.assertRaises(GatewayPolicyError):g.fetch("https://example.org/x.pdf")
 def test_provenance_bridge(self):
  with tempfile.TemporaryDirectory() as td:
   a=self.gateway(td).fetch("https://example.org/x.pdf");s=artifact_to_source(a)
   self.assertEqual(s.checksum_sha256,a.checksum_sha256);self.assertEqual(s.source_class.value,"IMPORTED")
 def test_source_registry(self):
  r=OpenSourceRegistry();names={x.source_id for x in r.all()}
  self.assertTrue({"arxiv","nist","nasa_open","zenodo","doaj"}.issubset(names))
 def test_robots_fail_closed(self):
  def bad(req,timeout=None):raise OSError("offline")
  with tempfile.TemporaryDirectory() as td:
   g=OpenResearchGateway(Path(td)/"c",Path(td)/"i.json",respect_robots=True,opener=bad)
   self.assertFalse(g.robots_allowed("https://example.org/a"))
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
