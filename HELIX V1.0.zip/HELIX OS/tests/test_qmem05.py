import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM"
sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_thermal_velocity(self):self.assertGreater(q.one_dimensional_thermal_velocity_std_m_s(300,87*q.AMU),0)
 def test_doppler(self):self.assertGreater(q.doppler_fwhm_hz(q.wavelength_to_frequency_hz(780e-9),300,87*q.AMU),0)
 def test_wavevector(self):self.assertAlmostEqual(q.wavevector_rad_m(1),2*math.pi)
 def test_spinwave_coprop(self):self.assertEqual(q.spin_wave_wavevector_rad_m(1,1,True),0)
 def test_spinwave_counter(self):self.assertAlmostEqual(q.spin_wave_wavevector_rad_m(1,1,False),4*math.pi)
 def test_ballistic_infinite(self):self.assertTrue(math.isinf(q.ballistic_spin_wave_coherence_s(0,100)))
 def test_diffusion_rate(self):self.assertEqual(q.diffusion_spin_wave_decay_rate_s_inv(2,3),18)
 def test_combined_t2(self):self.assertAlmostEqual(q.combined_ground_coherence_time_s(1,1,1),.5)
 def test_beer_lambert(self):self.assertAlmostEqual(q.beer_lambert_transmission(1),math.exp(-1))
 def test_od(self):self.assertEqual(q.resonant_optical_depth(10,2,.5),10)
 def test_survival(self):self.assertAlmostEqual(q.spin_wave_survival(1,1),math.exp(-1))
 def test_cell(self):self.assertEqual(q.VaporCell(300,.1,1e15,87*q.AMU,1e-13).optical_depth,10)
 def test_memory_effective_t2(self):self.assertLess(q.VaporMemoryEstimate(10,1,1,1).effective_t2_s,1)
 def test_memory_eff_bound(self):self.assertGreater(q.VaporMemoryEstimate(100,1).idealized_od_efficiency_bound,q.VaporMemoryEstimate(1,1).idealized_od_efficiency_bound)
 def test_rydberg_preserved(self):self.assertAlmostEqual(q.eit_dark_state_rydberg_fraction(1,1),.5)
 def test_decoherence_preserved(self):self.assertTrue(q.CoherenceBudget(1,10).satisfies_markovian_bound)
 def test_registry(self):
  ids={x.model_id for x in q.QuantumMemoryRegistry().all()}
  self.assertTrue({"QMEM-VAP-DOPPLER","QMEM-SPIN-K","QMEM-SPIN-DIFF","QMEM-VAP-OD","QMEM-SPIN-SURV"}<=ids)
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QMEM-05")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO"])
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
