param(
 [string]$InstallDir = $PSScriptRoot,
 [switch]$SkipDependencies
)
$ErrorActionPreference = "Stop"
$SourceDir = $PSScriptRoot
$InstallDir = [System.IO.Path]::GetFullPath($InstallDir)

Write-Host "Sierra Kilo Labs HELIX installer"
Write-Host "HELIX directory: $InstallDir"

if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
    throw "Python launcher 'py' not found. Install Python 3.11+ first."
}
$ver = & py -3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
if ($LASTEXITCODE -ne 0) { throw "Unable to run Python 3." }
$parts=$ver.Trim().Split('.')
if ([int]$parts[0] -lt 3 -or ([int]$parts[0] -eq 3 -and [int]$parts[1] -lt 11)) {
    throw "Python 3.11+ required."
}

# If a different target was explicitly requested, copy application files there.
if ($InstallDir -ne [System.IO.Path]::GetFullPath($SourceDir)) {
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    Get-ChildItem $SourceDir -Force | Where-Object { $_.Name -ne ".venv" } |
        Copy-Item -Destination $InstallDir -Recurse -Force
}

Push-Location $InstallDir
try {
    if (-not (Test-Path ".\.venv\Scripts\python.exe")) {
        Write-Host "Creating HELIX virtual environment..."
        & py -3 -m venv .venv
        if ($LASTEXITCODE -ne 0) { throw "Failed to create HELIX virtual environment." }
    }

    $python = Join-Path $InstallDir ".venv\Scripts\python.exe"

    if (-not $SkipDependencies) {
        Write-Host "Updating pip..."
        & $python -m pip install --upgrade pip
        if ($LASTEXITCODE -ne 0) { throw "pip upgrade failed." }

        # requirements.txt remains the ONE canonical manifest. The local-LLM binding is
        # installed separately because Windows may otherwise try to compile it from source.
        Write-Host "Installing HELIX dependencies from canonical requirements.txt..."
        $req = Join-Path $InstallDir "requirements.txt"
        if (-not (Test-Path $req)) { throw "requirements.txt not found." }

        $coreReq = Join-Path $env:TEMP "helix-requirements-$PID.txt"
        Get-Content $req |
            Where-Object { $_ -notmatch '^\s*llama-cpp-python(?:\s*[<>=!~].*)?\s*$' } |
            Set-Content -Encoding ASCII $coreReq
        try {
            & $python -m pip install -r $coreReq
            if ($LASTEXITCODE -ne 0) { throw "HELIX dependency installation failed." }
        } finally {
            Remove-Item $coreReq -Force -ErrorAction SilentlyContinue
        }
    }

    Write-Host "Running HELIX self-test..."
    & $python (Join-Path $InstallDir "HELIX_SELFTEST.py")
    if ($LASTEXITCODE -ne 0) { throw "HELIX Core self-test failed." }

    Write-Host ""
    Write-Host "HELIX installed and self-tested successfully."
    Write-Host "Virtual environment: $InstallDir\.venv"
    Write-Host "Next: run .\install_guardian_ai.ps1"
} finally {
    Pop-Location
}
