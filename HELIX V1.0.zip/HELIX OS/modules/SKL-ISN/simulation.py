from __future__ import annotations
from dataclasses import dataclass
import random,statistics,math
from .galactic_network import GalacticNetwork,GalacticEdge,path_distance_ly,path_capacity_bps,path_availability
from .foundation import one_way_latency_years_from_ly
from .optical_links import InterstellarOpticalLink
from .sgl import SolarGravitationalLensTerminal

@dataclass(frozen=True)
class NetworkScenarioResult:
    route_found:bool
    hops:int
    distance_ly:float
    propagation_latency_years:float
    bottleneck_capacity_bps:float
    route_availability:float
    message_serialization_s:float
    total_processing_s:float

def simulate_route(network,start,end,message_bits=0,failed_nodes=(),failed_edges=(),
                   latency_weight=1.0,capacity_weight=0.0,reliability_weight=0.0):
    if message_bits<0:raise ValueError("message bits nonnegative")
    route_pairs=network.route(start,end,latency_weight,capacity_weight,reliability_weight,failed_nodes,failed_edges)
    edges=[e for e,_ in route_pairs]
    if start!=end and not edges:return NetworkScenarioResult(False,0,0,0,0,0,0,0)
    if start==end:return NetworkScenarioResult(True,0,0,0,math.inf,1,0,0)
    d=path_distance_ly(edges);cap=path_capacity_bps(edges);av=path_availability(edges)
    return NetworkScenarioResult(True,len(edges),d,one_way_latency_years_from_ly(d),cap,av,
                                 message_bits/cap if cap>0 else math.inf,
                                 sum(e.processing_delay_s for e in edges[:-1]))

def sweep_failed_edges(network,start,end):
    baseline=simulate_route(network,start,end)
    out=[]
    for i in range(len(network.edges)):
        r=simulate_route(network,start,end,failed_edges=(i,))
        out.append((i,r))
    return baseline,tuple(out)

@dataclass(frozen=True)
class MonteCarloNetworkSummary:
    trials:int
    connected_fraction:float
    mean_distance_ly:float
    mean_capacity_bps:float
    mean_availability:float

def monte_carlo_network_failures(network,start,end,trials=1000,seed=1):
    if trials<1:raise ValueError("trials positive")
    rng=random.Random(seed);results=[]
    for _ in range(trials):
        failed=[]
        for i,e in enumerate(network.edges):
            if rng.random()>e.availability:failed.append(i)
        r=simulate_route(network,start,end,failed_edges=failed)
        if r.route_found:results.append(r)
    frac=len(results)/trials
    if not results:return MonteCarloNetworkSummary(trials,0,0,0,0)
    return MonteCarloNetworkSummary(trials,frac,statistics.mean(x.distance_ly for x in results),
      statistics.mean(x.bottleneck_capacity_bps for x in results),statistics.mean(x.route_availability for x in results))

def optical_distance_sweep(distance_ly_values,**link_kwargs):
    return tuple((d,InterstellarOpticalLink(distance_ly=d,**link_kwargs).ideal_bit_rate_bps) for d in distance_ly_values)

def sgl_distance_sweep(focal_distance_au_values,wavelength_m,transverse_position_tolerance_m):
    return tuple((z,SolarGravitationalLensTerminal(z,wavelength_m,transverse_position_tolerance_m).ideal_gain_db,
                  SolarGravitationalLensTerminal(z,wavelength_m,transverse_position_tolerance_m).pointing_tolerance_rad)
                 for z in focal_distance_au_values)

def compare_architectures(results):
    if not results:raise ValueError("results required")
    valid=[(name,r) for name,r in results if r.route_found]
    if not valid:return {"lowest_latency":None,"highest_capacity":None,"highest_availability":None}
    return {
      "lowest_latency":min(valid,key=lambda x:x[1].propagation_latency_years)[0],
      "highest_capacity":max(valid,key=lambda x:x[1].bottleneck_capacity_bps)[0],
      "highest_availability":max(valid,key=lambda x:x[1].route_availability)[0],
    }
