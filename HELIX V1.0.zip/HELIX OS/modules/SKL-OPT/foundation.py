from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

C=299792458.0
H=6.62607015e-34
K_B=1.380649e-23

class EvidenceState(str,Enum):
    HARDWARE="HARDWARE"; IMPORTED="IMPORTED"; SIMULATION="SIMULATION"
    EXTRAPOLATED="EXTRAPOLATED"; SPECULATIVE="SPECULATIVE"

def frequency_hz(wavelength_m):
    if wavelength_m<=0: raise ValueError("wavelength must be positive")
    return C/wavelength_m

def wavelength_m(frequency_hz):
    if frequency_hz<=0: raise ValueError("frequency must be positive")
    return C/frequency_hz

def photon_energy_j_from_frequency(frequency_hz_value):
    if frequency_hz_value<=0: raise ValueError("frequency must be positive")
    return H*frequency_hz_value

def photon_energy_j_from_wavelength(wavelength_m_value):
    if wavelength_m_value<=0: raise ValueError("wavelength must be positive")
    return H*C/wavelength_m_value

def photon_flux_per_s(optical_power_w,wavelength_m_value):
    if optical_power_w<0 or wavelength_m_value<=0: raise ValueError("invalid power/wavelength")
    return optical_power_w/photon_energy_j_from_wavelength(wavelength_m_value)

def airy_first_zero_angle_rad(wavelength_m_value,aperture_diameter_m):
    if wavelength_m_value<=0 or aperture_diameter_m<=0: raise ValueError("positive wavelength/aperture required")
    return 1.22*wavelength_m_value/aperture_diameter_m

def gaussian_diffraction_half_angle_rad(wavelength_m_value,beam_waist_m,m2=1.0):
    if wavelength_m_value<=0 or beam_waist_m<=0 or m2<1: raise ValueError("invalid beam inputs")
    return m2*wavelength_m_value/(math.pi*beam_waist_m)

def circular_aperture_gain_linear(aperture_diameter_m,wavelength_m_value,efficiency=1.0):
    if aperture_diameter_m<=0 or wavelength_m_value<=0 or not 0<efficiency<=1: raise ValueError("invalid aperture inputs")
    return efficiency*(math.pi*aperture_diameter_m/wavelength_m_value)**2

def free_space_path_loss_linear(distance_m,wavelength_m_value):
    if distance_m<=0 or wavelength_m_value<=0: raise ValueError("positive distance/wavelength required")
    return (4*math.pi*distance_m/wavelength_m_value)**2

def free_space_path_loss_db(distance_m,wavelength_m_value):
    return 10*math.log10(free_space_path_loss_linear(distance_m,wavelength_m_value))

def received_power_friis_w(transmit_power_w,tx_gain_linear,rx_gain_linear,distance_m,wavelength_m_value,system_efficiency=1.0):
    if transmit_power_w<0 or tx_gain_linear<0 or rx_gain_linear<0 or not 0<=system_efficiency<=1: raise ValueError("invalid link inputs")
    return transmit_power_w*tx_gain_linear*rx_gain_linear*system_efficiency/free_space_path_loss_linear(distance_m,wavelength_m_value)

def detected_photon_rate_per_s(received_power_w,wavelength_m_value,quantum_efficiency=1.0):
    if received_power_w<0 or wavelength_m_value<=0 or not 0<=quantum_efficiency<=1: raise ValueError("invalid detector inputs")
    return photon_flux_per_s(received_power_w,wavelength_m_value)*quantum_efficiency

def poisson_shot_noise_snr(expected_detected_photons):
    if expected_detected_photons<0: raise ValueError("photon count nonnegative")
    return math.sqrt(expected_detected_photons)

@dataclass(frozen=True)
class OpticalLink:
    wavelength_m:float
    distance_m:float
    transmit_power_w:float
    tx_aperture_m:float
    rx_aperture_m:float
    tx_aperture_efficiency:float=1.0
    rx_aperture_efficiency:float=1.0
    system_efficiency:float=1.0
    detector_quantum_efficiency:float=1.0
    evidence:EvidenceState=EvidenceState.SIMULATION
    def __post_init__(self):
        if min(self.wavelength_m,self.distance_m,self.tx_aperture_m,self.rx_aperture_m)<=0 or self.transmit_power_w<0:
            raise ValueError("invalid optical link")
        for x in (self.tx_aperture_efficiency,self.rx_aperture_efficiency,self.system_efficiency,self.detector_quantum_efficiency):
            if not 0<=x<=1: raise ValueError("efficiencies must be [0,1]")
    @property
    def frequency_hz(self): return frequency_hz(self.wavelength_m)
    @property
    def photon_energy_j(self): return photon_energy_j_from_wavelength(self.wavelength_m)
    @property
    def tx_gain_linear(self): return circular_aperture_gain_linear(self.tx_aperture_m,self.wavelength_m,self.tx_aperture_efficiency)
    @property
    def rx_gain_linear(self): return circular_aperture_gain_linear(self.rx_aperture_m,self.wavelength_m,self.rx_aperture_efficiency)
    @property
    def fspl_db(self): return free_space_path_loss_db(self.distance_m,self.wavelength_m)
    @property
    def received_power_w(self): return received_power_friis_w(self.transmit_power_w,self.tx_gain_linear,self.rx_gain_linear,self.distance_m,self.wavelength_m,self.system_efficiency)
    @property
    def detected_photon_rate_per_s(self): return detected_photon_rate_per_s(self.received_power_w,self.wavelength_m,self.detector_quantum_efficiency)
    def report(self):
        return {"evidence":self.evidence.value,"wavelength_m":self.wavelength_m,"frequency_hz":self.frequency_hz,
                "photon_energy_j":self.photon_energy_j,"distance_m":self.distance_m,"fspl_db":self.fspl_db,
                "tx_gain_linear":self.tx_gain_linear,"rx_gain_linear":self.rx_gain_linear,
                "received_power_w":self.received_power_w,"detected_photon_rate_per_s":self.detected_photon_rate_per_s}
