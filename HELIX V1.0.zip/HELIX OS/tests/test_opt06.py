import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-OPT"
sp=importlib.util.spec_from_file_location("skl_opt",M/"__init__.py",submodule_search_locations=[str(M)])
o=importlib.util.module_from_spec(sp);sys.modules["skl_opt"]=o;sp.loader.exec_module(o)
class T(unittest.TestCase):
 def test_ppm_bits(self):self.assertEqual(o.bits_per_ppm_symbol(16),4)
 def test_ppm_bad(self):
  with self.assertRaises(ValueError):o.bits_per_ppm_symbol(3)
 def test_symbol_rate(self):self.assertEqual(o.symbol_rate_baud(1000,2,.5),1000)
 def test_slot_rate(self):self.assertEqual(o.ppm_slot_rate_hz(1000,16,1),4000)
 def test_photons_bit(self):self.assertEqual(o.photons_per_information_bit(1000,100),10)
 def test_bits_photon(self):self.assertEqual(o.bits_per_detected_photon(100,1000),.1)
 def test_q0(self):self.assertEqual(o.q_function(0),.5)
 def test_ook_ber_falls(self):self.assertLess(o.ook_ber_awgn(10),o.ook_ber_awgn(1))
 def test_ppm_zero_photons(self):self.assertEqual(o.ideal_ppm_symbol_error_poisson(4,0),.75)
 def test_ppm_ser_falls(self):self.assertLess(o.ideal_ppm_symbol_error_poisson(4,10),o.ideal_ppm_symbol_error_poisson(4,1))
 def test_ppm_ber(self):self.assertEqual(o.approximate_ppm_ber_from_ser(4,.2),.1)
 def test_coding_gain(self):self.assertAlmostEqual(o.coding_gain_adjusted_ebn0(1,3),10**.3)
 def test_packet_zero(self):self.assertEqual(o.packet_error_rate(0,100),0)
 def test_packet_grows(self):self.assertGreater(o.packet_error_rate(.01,100),.01)
 def test_goodput(self):self.assertEqual(o.goodput_bps(1000,.1),900)
 def test_bandwidth(self):self.assertEqual(o.minimum_nyquist_bandwidth_hz(1000),500)
 def test_ppm_link(self):
  l=o.PhotonStarvedDigitalLink(o.OpticalModulation.PPM,1000,10000,1,16,0,100)
  self.assertEqual(l.symbol_rate,250);self.assertEqual(l.slot_rate,4000);self.assertTrue(0<=l.ideal_ppm_ber<=1)
 def test_link_goodput(self):
  l=o.PhotonStarvedDigitalLink(o.OpticalModulation.PPM,1000,100000,1,4,0,100)
  self.assertTrue(0<=l.goodput<=1000)
 def test_ook_link(self):
  l=o.PhotonStarvedDigitalLink(o.OpticalModulation.OOK,1000,10000,.5)
  self.assertEqual(l.symbol_rate,2000);self.assertIsNone(l.ideal_ppm_ser)
 def test_zero_photon_eff(self):
  l=o.PhotonStarvedDigitalLink(o.OpticalModulation.OOK,1000,0);self.assertTrue(math.isinf(l.photon_efficiency_bits_per_photon))
 def test_atmosphere_preserved(self):self.assertEqual(o.transmission_from_optical_depth(0),1)
 def test_pat_preserved(self):self.assertEqual(o.gaussian_pointing_coupling(0,1e-6),1)
 def test_receiver_preserved(self):self.assertGreater(o.telescope_collection_area_m2(1),0)
 def test_transmitter_preserved(self):self.assertGreater(o.rayleigh_range_m(1e-6,1),0)
 def test_registry(self):self.assertTrue({"OPT-PPM-BITS","OPT-PPM-SLOT","OPT-PHOTONS-BIT","OPT-BITS-PHOTON","OPT-PPM-SER","OPT-PACKET","OPT-GOODPUT"}<={x.model_id for x in o.OpticalRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-OPT-06")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
