import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HQIC"
sp=importlib.util.spec_from_file_location("skl_hqic",M/"__init__.py",submodule_search_locations=[str(M)])
h=importlib.util.module_from_spec(sp);sys.modules["skl_hqic"]=h;sp.loader.exec_module(h)
class T(unittest.TestCase):
 def test_hash(self):self.assertTrue(h.verify_sha256(b"abc",h.sha256_digest(b"abc")))
 def test_hash_fail(self):self.assertFalse(h.verify_sha256(b"abc","0"*64))
 def test_parity(self):self.assertEqual(h.parity_bit([1,0,1]),0)
 def test_parity_check(self):self.assertTrue(h.parity_check([1,1,1],1))
 def test_rate(self):self.assertEqual(h.code_rate(8,10),.8)
 def test_redundancy(self):self.assertAlmostEqual(h.redundancy_fraction(8,10),.2)
 def test_rep_error(self):self.assertAlmostEqual(h.repetition_logical_error_probability(.1,3),.028)
 def test_distance(self):self.assertEqual(h.qec_correctable_errors_from_distance(5),2)
 def test_cycle_survival(self):self.assertAlmostEqual(h.independent_cycle_survival(.01,10),.99**10)
 def test_no_cloning(self):
  with self.assertRaises(ValueError):h.no_cloning_integrity_guard(True,2)
 def test_known_copy_allowed(self):self.assertTrue(h.no_cloning_integrity_guard(False,2))
 def test_classical_plan(self):
  p=h.ClassicalIntegrityPlan(8,10,.1,3);self.assertAlmostEqual(p.modeled_logical_ber,.028)
 def test_quantum_plan(self):
  p=h.QuantumIntegrityPlan(3,1,3,.1,5);self.assertEqual(p.overhead,3);self.assertLess(p.modeled_logical_error,.1)
 def test_hybrid_report_separate(self):
  a=h.HybridIntegrityAssessment(h.ClassicalIntegrityPlan(8,10,.1),h.QuantumIntegrityPlan(3,1,3,.1),True)
  self.assertFalse(a.report()["domains_combined_into_single_integrity_score"])
 def test_controller_preserved(self):
  c=h.DeviceCapabilities(True,True,max_classical_address=10);ok,_=h.validate_command(h.HQICCommand("x",h.CommandKind.READ_CLASSICAL,h.DeviceAddress(classical_address=1)),c,h.DeviceState.IDLE);self.assertTrue(ok)
 def test_transduction_preserved(self):self.assertAlmostEqual(h.cascaded_efficiency(.8,.5),.4)
 def test_capacity_boundary_preserved(self):
  with self.assertRaises(ValueError):h.aggregate_capacity_same_domain([h.Capacity(1,h.InformationDomain.CLASSICAL,"bit"),h.Capacity(1,h.InformationDomain.QUANTUM,"qubit")])
 def test_registry(self):self.assertTrue({"HQIC-ECC-RATE","HQIC-ECC-REP","HQIC-QEC-DIST","HQIC-QEC-CYCLE","HQIC-INTEGRITY-HASH"}<={x.model_id for x in h.HQICRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HQIC-05")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO","SKL-QMEM"])
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
