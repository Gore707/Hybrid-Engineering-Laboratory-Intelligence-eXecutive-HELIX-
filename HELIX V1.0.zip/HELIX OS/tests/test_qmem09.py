import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM"
sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_debroglie(self):self.assertGreater(q.thermal_de_broglie_wavelength_m(1e-6,87*q.AMU),0)
 def test_tc_density(self):
  a=q.ideal_gas_bec_critical_temperature_k(1e20,87*q.AMU);b=q.ideal_gas_bec_critical_temperature_k(8e20,87*q.AMU);self.assertAlmostEqual(b/a,4)
 def test_condensate_zero_at_tc(self):self.assertEqual(q.ideal_condensate_fraction(1,1),0)
 def test_condensate_zero_temp(self):self.assertEqual(q.ideal_condensate_fraction(0,1),1)
 def test_interaction(self):self.assertGreater(q.s_wave_interaction_strength_j_m3(5e-9,87*q.AMU),0)
 def test_chemical(self):self.assertGreater(q.mean_field_chemical_potential_j(1e20,5e-9,87*q.AMU),0)
 def test_healing(self):self.assertGreater(q.healing_length_m(1e20,5e-9),0)
 def test_polariton_half(self):self.assertAlmostEqual(q.polariton_photonic_fraction(1,1),.5)
 def test_atomic_complement(self):self.assertAlmostEqual(q.polariton_atomic_fraction(2,1)+q.polariton_photonic_fraction(2,1),1)
 def test_slow_light(self):self.assertLess(q.slow_light_group_velocity_m_s(10,1),q.C)
 def test_survival(self):self.assertAlmostEqual(q.matter_wave_coherence_survival(1,1),math.exp(-1))
 def test_ensemble(self):
  e=q.BECEnsemble(100000,1e-15,87*q.AMU,1e-9,5e-9);self.assertEqual(e.number_density_m3,1e20);self.assertGreaterEqual(e.condensate_fraction,0)
 def test_memory_zero_storage(self):
  m=q.BECMemoryEstimate(10,1,1,.8,.9);self.assertAlmostEqual(m.total_efficiency(0),.72)
 def test_memory_decay(self):
  m=q.BECMemoryEstimate(10,1,1,1,1);self.assertAlmostEqual(m.total_efficiency(1),math.exp(-1))
 def test_diamond_preserved(self):self.assertAlmostEqual(q.initialization_readout_success(.9,.8),.72)
 def test_rare_earth_preserved(self):self.assertEqual(q.afc_echo_time_s(1e6),1e-6)
 def test_registry(self):
  ids={x.model_id for x in q.QuantumMemoryRegistry().all()}
  self.assertTrue({"QMEM-BEC-TC","QMEM-BEC-FRAC","QMEM-BEC-HEAL","QMEM-BEC-VG","QMEM-BEC-SURV"}<=ids)
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QMEM-09")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO"])
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
