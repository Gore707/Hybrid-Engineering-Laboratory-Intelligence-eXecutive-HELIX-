import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-BND"
sp=importlib.util.spec_from_file_location("skl_bnd",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_bnd"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_classes(self):
  self.assertEqual(q.propagation_class(1,0),q.PropagationClass.TIMELIKE)
  self.assertEqual(q.propagation_class(1,q.C_M_S),q.PropagationClass.NULL)
  self.assertEqual(q.propagation_class(0,1),q.PropagationClass.SPACELIKE)
 def test_gamma(self):self.assertAlmostEqual(q.lorentz_gamma(0),1)
 def test_lorentz_identity(self):self.assertEqual(q.lorentz_transform_event_1d(1,2,0),(1,2))
 def test_reversal(self):self.assertTrue(q.ordering_reversal_possible(0,1))
 def test_threshold(self):self.assertAlmostEqual(q.reversal_frame_beta_threshold(1,2*q.C_M_S),.5)
 def test_effective_ftl(self):self.assertEqual(q.local_vs_effective_ftl(.5*q.C_M_S,2*q.C_M_S),q.FTLClaimClass.APPARENT_OR_EFFECTIVE)
 def test_local_ftl(self):self.assertEqual(q.local_vs_effective_ftl(2*q.C_M_S,2*q.C_M_S),q.FTLClaimClass.LOCAL_SUPERLUMINAL)
 def test_antitelephone(self):self.assertTrue(q.tachyonic_antitelephone_risk(2*q.C_M_S,.6*q.C_M_S))
 def test_no_antitelephone_slow_frame(self):self.assertFalse(q.tachyonic_antitelephone_risk(2*q.C_M_S,.4*q.C_M_S))
 def test_closed_loop(self):self.assertTrue(q.closed_arrival_loop_risk(-1))
 def test_chronology(self):self.assertEqual(q.chronology_protection_status(True),"UNRESOLVED_CHRONOLOGY_PROTECTION")
 def test_ftl_gate(self):self.assertFalse(q.demonstrated_ftl_information_gate(q.BoundaryEvidence.SPECULATIVE_UNRESOLVED,False,True))
 def test_assessment(self):
  a=q.CausalityAssessment(.5,2*q.C_M_S,.5*q.C_M_S,4*q.C_M_S,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED,.5*q.C_M_S,-1)
  self.assertEqual(a.interval_class,q.PropagationClass.SPACELIKE);self.assertTrue(a.ordering_reversal_possible);self.assertTrue(a.antitelephone_risk);self.assertTrue(a.closed_loop_risk);self.assertFalse(a.demonstrated_ftl_information)
 def test_warp_preserved(self):self.assertFalse(q.physically_demonstrated_warp_metric_engineering_available())
 def test_wormhole_preserved(self):self.assertFalse(q.physically_demonstrated_traversable_wormhole_available())
 def test_qft_preserved(self):self.assertFalse(q.spacelike_vacuum_correlation_implies_controllable_signal())
 def test_registry(self):self.assertTrue({"BND-CAUS-LT","BND-CAUS-ORDER","BND-CAUS-ANTI","BND-CAUS-GATE"}<={x.model_id for x in q.default_registry().all()})
 def test_foundation_guard(self):self.assertFalse(q.established_physics_causality_bypass_available())
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-BND-08")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
