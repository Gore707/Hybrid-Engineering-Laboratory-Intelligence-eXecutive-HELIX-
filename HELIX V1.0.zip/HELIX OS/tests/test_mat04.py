import unittest,tempfile,importlib.util,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-MAT"
spec=importlib.util.spec_from_file_location("skl_mat",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
pkg=importlib.util.module_from_spec(spec);sys.modules["skl_mat"]=pkg;spec.loader.exec_module(pkg)
from core.visualization.engine import FigureSpec
class MAT04(unittest.TestCase):
 def ds(self,id="D1",mat="MAT-A",unit="W/(m K)"):
  return pkg.PropertyDataset(id,mat,"thermal_conductivity","temperature_k","K",unit,(300.,400.),(1.4,1.5),("SRC-1",),"DEMONSTRATED_TECH",(0.02,0.02))
 def test_store_source_dataset(self):
  with tempfile.TemporaryDirectory() as td:
   s=pkg.MaterialResearchStore(Path(td)/"r.json");s.add_source(pkg.MaterialSource("SRC-1","Paper"))
   s.add_dataset(self.ds());self.assertEqual(s.dataset("D1").source_ids,("SRC-1",))
 def test_unknown_source_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   s=pkg.MaterialResearchStore(Path(td)/"r.json")
   with self.assertRaises(ValueError):s.add_dataset(self.ds())
 def test_dataset_validation(self):
  with self.assertRaises(ValueError):pkg.PropertyDataset("D","M","p","T","K","x",(1,),(1,2),("S",),"E")
 def test_figure_spec_provenance(self):
  f=pkg.dataset_figure_spec(self.ds(),FigureSpec);self.assertEqual(f.provenance["source_type"],"IMPORTED");self.assertIn("SRC-1",f.caption)
 def test_compare_compatible(self):
  r=pkg.compare_datasets([self.ds(),self.ds("D2","MAT-B")]);self.assertTrue(r["compatible"]);self.assertEqual(len(r["series"]),2)
 def test_compare_incompatible(self):
  r=pkg.compare_datasets([self.ds(),self.ds("D2","MAT-B","Pa")]);self.assertFalse(r["compatible"])
 def test_manifest(self):
  m=json.loads((MOD/"module.json").read_text());self.assertEqual(m["patch_id"],"SKL-MAT-04");self.assertIn("materials.visualization",m["capabilities"])
 def test_core_manifest_stays_root(self):
  self.assertTrue((ROOT/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((MOD/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
