import unittest,importlib.util,sys,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-PHO"
spec=importlib.util.spec_from_file_location("skl_pho",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
p=importlib.util.module_from_spec(spec);sys.modules["skl_pho"]=p;spec.loader.exec_module(p)
class PHO04(unittest.TestCase):
 def beam(self):return p.GaussianBeam(1e-6,1e-3,power_w=2)
 def test_rayleigh(self):self.assertAlmostEqual(self.beam().rayleigh_range_m,math.pi)
 def test_radius_at_zr(self):
  b=self.beam();self.assertAlmostEqual(b.radius_m(b.rayleigh_range_m),b.waist_m*math.sqrt(2))
 def test_divergence(self):
  b=self.beam();self.assertAlmostEqual(b.divergence_half_angle_rad,1e-6/(math.pi*1e-3))
 def test_curvature_waist(self):self.assertTrue(math.isinf(self.beam().curvature_radius_m(0)))
 def test_gouy(self):
  b=self.beam();self.assertAlmostEqual(b.gouy_phase_rad(b.rayleigh_range_m),math.pi/4)
 def test_intensity_center(self):
  b=self.beam();self.assertAlmostEqual(b.on_axis_intensity_w_m2(0),4/(math.pi*1e-6))
 def test_radial_intensity(self):
  b=self.beam();self.assertAlmostEqual(b.intensity_w_m2(b.waist_m,0)/b.on_axis_intensity_w_m2(0),math.exp(-2))
 def test_q_free_space(self):
  b=self.beam();q=p.q_propagate(b.q(),p.free_space(2));self.assertAlmostEqual(q.real,2);self.assertAlmostEqual(q.imag,b.rayleigh_range_m)
 def test_q_lens(self):
  b=self.beam();q=p.q_propagate(b.q(),p.thin_lens(.5));self.assertGreater(q.imag,0)
 def test_beam_from_q(self):
  b=self.beam();r=p.beam_from_q(b.q(),b.wavelength_m);self.assertAlmostEqual(r["radius_m"],b.waist_m)
 def test_focus_waist(self):self.assertAlmostEqual(p.focus_waist_collimated(1e-3,.1,1e-6),1e-7/(math.pi*1e-3))
 def test_m2(self):
  ideal=p.m2_divergence_half_angle(1e-6,1e-3);self.assertAlmostEqual(p.m2_divergence_half_angle(1e-6,1e-3,2),2*ideal)
 def test_registry_manifest(self):
  self.assertEqual(p.PhotonicsRegistry().get("PHO-GAUSS-Q").evidence_class,"ESTABLISHED_PHYSICS")
  self.assertEqual(json.loads((MOD/"module.json").read_text())["patch_id"],"SKL-PHO-04")
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
