import unittest,importlib.util,sys,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-MAT"
spec=importlib.util.spec_from_file_location("skl_mat",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
pkg=importlib.util.module_from_spec(spec);sys.modules["skl_mat"]=pkg;spec.loader.exec_module(pkg)
from core.engineering.engines import thermal_steady,uniaxial
class MAT03(unittest.TestCase):
 def test_interpolation(self):
  c=pkg.PropertyCurve([pkg.Sample(300,1),pkg.Sample(400,3)],"temperature_k","W/(m K)")
  self.assertEqual(c.evaluate(350),2)
 def test_extrapolation_blocked_by_default(self):
  c=pkg.PropertyCurve([pkg.Sample(300,1),pkg.Sample(400,3)],"temperature_k","x")
  with self.assertRaises(ValueError):c.evaluate(500)
  self.assertEqual(c.evaluate(500,True),5)
 def test_thermal(self):
  p=pkg.ThermalProperties(2,1000,2000);self.assertAlmostEqual(p.diffusivity_m2_s(),1e-6);self.assertEqual(p.volumetric_heat_capacity(),2e6)
 def test_optical(self):
  p=pkg.OpticalProperties(1.5,0);self.assertAlmostEqual(p.reflectance_normal(),.04);self.assertEqual(p.absorption_coefficient_per_m(1e-6),0)
 def test_electrical(self):
  p=pkg.ElectricalProperties(2);self.assertEqual(p.conductivity_s_m(),.5)
 def test_mechanical(self):
  p=pkg.MechanicalProperties(200e9,.25,250e6);self.assertAlmostEqual(p.shear_modulus_pa(),80e9)
 def test_core_thermal_integration(self):
  p=pkg.ThermalProperties(10,500,1000);r=pkg.thermal_to_core_engine(thermal_steady,p,1,2,310,300)
  self.assertEqual(r.conduction_w,50)
 def test_core_mechanical_integration(self):
  p=pkg.MechanicalProperties(200e9,.3,250e6);r=pkg.mechanical_to_core_engine(uniaxial,p,100,1)
  self.assertEqual(r.stress_pa,100)
 def test_manifest(self):
  m=json.loads((MOD/"module.json").read_text());self.assertEqual(m["patch_id"],"SKL-MAT-03");self.assertIn("materials.optical",m["capabilities"])
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
