from __future__ import annotations
from dataclasses import dataclass
import math,heapq

def hop_delivery_capacity_bps(link_rates_bps):
    if not link_rates_bps or any(x<0 for x in link_rates_bps):raise ValueError("invalid rates")
    return min(link_rates_bps)

def store_forward_serial_message_time_s(message_bits,link_rates_bps,propagation_delays_s,processing_delay_s=0.0):
    if message_bits<0 or not link_rates_bps or len(link_rates_bps)!=len(propagation_delays_s) or any(r<=0 for r in link_rates_bps) or any(t<0 for t in propagation_delays_s) or processing_delay_s<0:
        raise ValueError("invalid route")
    return sum(message_bits/r for r in link_rates_bps)+sum(propagation_delays_s)+max(0,len(link_rates_bps)-1)*processing_delay_s

def pipelined_steady_state_capacity_bps(link_rates_bps):
    return hop_delivery_capacity_bps(link_rates_bps)

def series_route_availability(node_availabilities,link_availabilities):
    vals=list(node_availabilities)+list(link_availabilities)
    if not vals or any(not 0<=x<=1 for x in vals):raise ValueError("availability in [0,1]")
    p=1.0
    for x in vals:p*=x
    return p

def parallel_independent_route_availability(route_availabilities):
    if not route_availabilities or any(not 0<=x<=1 for x in route_availabilities):raise ValueError("availability in [0,1]")
    fail=1.0
    for x in route_availabilities:fail*=1-x
    return 1-fail

def expected_retransmissions(success_probability):
    if not 0<success_probability<=1:raise ValueError("probability in (0,1]")
    return 1/success_probability

def effective_goodput_bps(raw_bps,success_probability,protocol_efficiency=1.0):
    if raw_bps<0 or not 0<=success_probability<=1 or not 0<=protocol_efficiency<=1:raise ValueError("invalid goodput inputs")
    return raw_bps*success_probability*protocol_efficiency

def equal_spacing_relay_positions_ly(total_distance_ly,relay_count):
    if total_distance_ly<0 or relay_count<0 or int(relay_count)!=relay_count:raise ValueError("invalid route")
    n=int(relay_count);step=total_distance_ly/(n+1)
    return tuple(step*i for i in range(1,n+1))

def direct_vs_relay_power_ratio_inverse_square(total_distance,relay_count):
    if total_distance<=0 or relay_count<0 or int(relay_count)!=relay_count:raise ValueError("invalid inputs")
    # Required isotropic power per equal segment relative to one direct hop for equal received flux.
    return 1/(int(relay_count)+1)**2

@dataclass(frozen=True)
class RelayEdge:
    source:str
    target:str
    rate_bps:float
    latency_s:float
    availability:float=1.0
    enabled:bool=True
    def __post_init__(self):
        if not self.source or not self.target or self.source==self.target or self.rate_bps<=0 or self.latency_s<0 or not 0<=self.availability<=1:
            raise ValueError("invalid edge")

class RelayNetwork:
    def __init__(self,nodes):
        self.nodes=set(nodes);self.edges=[]
        if not self.nodes:raise ValueError("nodes required")
    def add_edge(self,e:RelayEdge):
        if e.source not in self.nodes or e.target not in self.nodes:raise ValueError("unknown endpoint")
        self.edges.append(e)
    def _adj(self,failed_nodes=()):
        failed=set(failed_nodes);a={n:[] for n in self.nodes if n not in failed}
        for e in self.edges:
            if e.enabled and e.source not in failed and e.target not in failed:
                a[e.source].append((e.target,e));a[e.target].append((e.source,e))
        return a
    def shortest_latency_route(self,start,end,failed_nodes=()):
        if start==end:return []
        a=self._adj(failed_nodes)
        if start not in a or end not in a:return []
        d={start:0.0};prev={};q=[(0.0,start)]
        while q:
            cost,u=heapq.heappop(q)
            if cost!=d.get(u):continue
            if u==end:break
            for v,e in a[u]:
                nc=cost+e.latency_s
                if nc<d.get(v,float("inf")):d[v]=nc;prev[v]=(u,e);heapq.heappush(q,(nc,v))
        if end not in prev:return []
        out=[];cur=end
        while cur!=start:
            u,e=prev[cur];out.append(e);cur=u
        return list(reversed(out))
    def widest_rate_route(self,start,end,failed_nodes=()):
        if start==end:return []
        a=self._adj(failed_nodes)
        if start not in a or end not in a:return []
        best={start:float("inf")};prev={};q=[(-float("inf"),start)]
        while q:
            neg,u=heapq.heappop(q);cap=-neg
            if u==end:break
            for v,e in a[u]:
                nc=min(cap,e.rate_bps)
                if nc>best.get(v,-1):best[v]=nc;prev[v]=(u,e);heapq.heappush(q,(-nc,v))
        if end not in prev:return []
        out=[];cur=end
        while cur!=start:
            u,e=prev[cur];out.append(e);cur=u
        return list(reversed(out))

@dataclass(frozen=True)
class RelayRouteAssessment:
    hop_count:int
    bottleneck_rate_bps:float
    propagation_latency_s:float
    route_availability:float
    effective_goodput_bps:float

def assess_relay_route(edges,protocol_efficiency=1.0):
    if not edges:return RelayRouteAssessment(0,0,0,0,0)
    rate=hop_delivery_capacity_bps([e.rate_bps for e in edges])
    av=series_route_availability([], [e.availability for e in edges])
    return RelayRouteAssessment(len(edges),rate,sum(e.latency_s for e in edges),av,effective_goodput_bps(rate,av,protocol_efficiency))
