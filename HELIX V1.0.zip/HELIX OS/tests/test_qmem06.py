import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM"
sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_two_photon_detuning(self):self.assertEqual(q.two_photon_raman_detuning_rad_s(10,7,3),0)
 def test_effective_rabi(self):self.assertEqual(q.effective_raman_rabi_rad_s(2,4,2),2)
 def test_zero_detuning_rejected(self):
  with self.assertRaises(ValueError):q.effective_raman_rabi_rad_s(1,1,0)
 def test_stark(self):self.assertEqual(q.ac_stark_shift_rad_s(4,2),2)
 def test_scattering_inverse_square(self):
  a=q.spontaneous_scattering_rate_s_inv(2,10,1);b=q.spontaneous_scattering_rate_s_inv(2,20,1);self.assertAlmostEqual(a/b,4)
 def test_scattering_survival(self):self.assertAlmostEqual(q.scattering_survival(1,1),math.exp(-1))
 def test_bandwidth_positive(self):self.assertGreater(q.idealized_raman_bandwidth_rad_s(10,100,1e6),0)
 def test_tbp(self):self.assertEqual(q.time_bandwidth_product(.01,1e6),1e4)
 def test_retrieval_product(self):self.assertAlmostEqual(q.retrieval_efficiency(.8,.9,.5,.5),.18)
 def test_control(self):
  c=q.RamanControl(10,100,1e6,1e-6);self.assertGreater(c.scattering_rate_s_inv,0);self.assertLessEqual(c.scattering_survival,1)
 def test_memory_zero_storage(self):
  c=q.RamanControl(10,100,1e3,0);m=q.RamanMemoryEstimate(.8,.9,1,c);self.assertAlmostEqual(m.total_efficiency(0),.72)
 def test_memory_decay(self):
  c=q.RamanControl(10,100,0,0);m=q.RamanMemoryEstimate(1,1,1,c);self.assertAlmostEqual(m.total_efficiency(1),math.exp(-1))
 def test_vapor_preserved(self):self.assertAlmostEqual(q.beer_lambert_transmission(1),math.exp(-1))
 def test_rydberg_preserved(self):self.assertAlmostEqual(q.eit_dark_state_rydberg_fraction(1,1),.5)
 def test_state_preserved(self):self.assertAlmostEqual(q.purity([[.5,0],[0,.5]]),.5)
 def test_registry(self):
  ids={x.model_id for x in q.QuantumMemoryRegistry().all()}
  self.assertTrue({"QMEM-RAMAN-OMEGA","QMEM-RAMAN-STARK","QMEM-RAMAN-SCAT","QMEM-RAMAN-TBP","QMEM-RAMAN-ETA"}<=ids)
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QMEM-06")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO"])
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists())
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
