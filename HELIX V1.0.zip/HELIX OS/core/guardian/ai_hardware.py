from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
import importlib.util,json,os,platform,shutil,subprocess,time

@dataclass(frozen=True)
class AIRuntimeCapability:
    runtime:str
    installed:bool
    acceleration:str
    detail:str

@dataclass(frozen=True)
class GuardianAIBudget:
    logical_cores:int
    ram_total_bytes:int|None
    gpu_vendor:str|None
    gpu_name:str|None
    vram_bytes:int|None
    preferred_acceleration:str
    max_context_class:str
    recommended_model_class:str
    note:str

def _has(module): return importlib.util.find_spec(module) is not None

def probe_ai_runtimes(devices=()):
    amd=any(getattr(d,"vendor","")=="AMD" and getattr(d,"kind","")=="GPU" for d in devices)
    nvidia=any(getattr(d,"vendor","")=="NVIDIA" and getattr(d,"kind","")=="GPU" for d in devices)
    caps=[]
    caps.append(AIRuntimeCapability("llama_cpp",_has("llama_cpp"),"CPU / backend-dependent",
        "llama-cpp-python detected." if _has("llama_cpp") else "Not installed."))
    caps.append(AIRuntimeCapability("torch",_has("torch"),
        "CUDA/ROCm/CPU depending on installed build",
        "PyTorch detected." if _has("torch") else "Not installed."))
    caps.append(AIRuntimeCapability("onnxruntime",_has("onnxruntime"),"CPU / provider-dependent",
        "ONNX Runtime detected." if _has("onnxruntime") else "Not installed."))
    caps.append(AIRuntimeCapability("onnxruntime_directml",_has("onnxruntime_directml"),
        "DirectML (Windows AMD/NVIDIA/Intel)",
        "DirectML runtime detected." if _has("onnxruntime_directml") else "Not installed."))
    # This is a capability inventory, not a claim that a GPU backend is usable.
    if amd: caps.append(AIRuntimeCapability("amd_gpu_present",True,"AMD GPU","Physical AMD GPU detected; runtime compatibility must be validated."))
    if nvidia: caps.append(AIRuntimeCapability("nvidia_gpu_present",True,"NVIDIA GPU","Physical NVIDIA GPU detected; runtime compatibility must be validated."))
    return tuple(caps)

def _ram_total():
    try:
        import psutil
        return int(psutil.virtual_memory().total)
    except ImportError:
        return None

def derive_budget(devices=(),ram_total_bytes=None):
    ram=ram_total_bytes if ram_total_bytes is not None else _ram_total()
    gpus=[d for d in devices if getattr(d,"kind","")=="GPU"]
    gpu=max(gpus,key=lambda d:(getattr(d,"memory_bytes",None) or 0),default=None)
    vendor=getattr(gpu,"vendor",None); name=getattr(gpu,"name",None)
    vram=getattr(gpu,"memory_bytes",None)
    accel="CPU"
    if vendor=="NVIDIA":accel="NVIDIA GPU candidate"
    elif vendor=="AMD":accel="AMD GPU candidate"
    # Conservative planning class only. GAI-02 benchmarks actual inference before selecting a model.
    gib=(vram or 0)/(1024**3)
    if gib>=16: model="7B–14B quantized candidate"; ctx="medium/large"
    elif gib>=8: model="7B–8B quantized candidate"; ctx="medium"
    elif gib>=6: model="small 3B–7B quantized candidate"; ctx="small/medium"
    else: model="small local model / CPU fallback candidate"; ctx="small"
    return GuardianAIBudget(os.cpu_count() or 1,ram,vendor,name,vram,accel,ctx,model,
        "Planning estimate only; on-host activation must validate the installed runtime and benchmark the selected model.")

def build_ai_profile(compute_manager,path:Path):
    if not compute_manager.devices:compute_manager.detect()
    runtimes=probe_ai_runtimes(compute_manager.devices)
    budget=derive_budget(compute_manager.devices)
    payload={
        "profile_version":"GAI-01",
        "created_unix":time.time(),
        "host":{"platform":platform.platform(),"machine":platform.machine()},
        "compute":compute_manager.summary(),
        "devices":[d.to_dict() for d in compute_manager.devices],
        "ai_runtimes":[asdict(x) for x in runtimes],
        "guardian_budget":asdict(budget),
        "model_selection":{"locked_model":None,"policy":"hardware-adaptive; select after on-host Guardian diagnostic and benchmark"},
    }
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp");tmp.write_text(json.dumps(payload,indent=2),encoding="utf-8");os.replace(tmp,path)
    return payload
