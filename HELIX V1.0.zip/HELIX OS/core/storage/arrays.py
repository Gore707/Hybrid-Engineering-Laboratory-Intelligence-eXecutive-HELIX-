from __future__ import annotations
import hashlib, json
from pathlib import Path

class ScientificArrayStore:
    """Persistent numerical-array store.

    Uses HDF5 when h5py is installed. Otherwise uses NumPy .npy files. Both are
    binary scientific storage; JSON is metadata only.
    """
    def __init__(self,root:Path):
        self.root=root; root.mkdir(parents=True,exist_ok=True)
    def write(self,dataset_id:str,array,units:str|None=None):
        import numpy as np
        a=np.asarray(array)
        try:
            import h5py
        except ImportError:
            path=self.root/f"{dataset_id}.npy"
            np.save(path,a,allow_pickle=False)
            media="application/x-npy"; uri=f"npy://{path.name}"
        else:
            path=self.root/f"{dataset_id}.h5"
            with h5py.File(path,"w") as f:
                d=f.create_dataset("data",data=a)
                if units is not None:d.attrs["units"]=units
            media="application/x-hdf5"; uri=f"hdf5://{path.name}/data"
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        return {"storage_uri":uri,"media_type":media,"shape":list(a.shape),
                "dtype":str(a.dtype),"units":units,"checksum_sha256":digest}
    def read(self,uri:str):
        import numpy as np
        if uri.startswith("npy://"):
            return np.load(self.root/uri[6:],allow_pickle=False)
        if uri.startswith("hdf5://"):
            spec=uri[7:]; fn,key=spec.split("/",1)
            import h5py
            with h5py.File(self.root/fn,"r") as f:return f[key][:]
        raise ValueError(f"Unsupported scientific-data URI: {uri}")
