from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import hashlib,math

class IntegrityDomain(str,Enum):
    CLASSICAL="CLASSICAL"
    QUANTUM="QUANTUM"

def sha256_digest(data:bytes):
    if not isinstance(data,(bytes,bytearray)): raise TypeError("bytes required")
    return hashlib.sha256(data).hexdigest()

def verify_sha256(data:bytes,expected_hex:str):
    return sha256_digest(data)==expected_hex.lower()

def parity_bit(bits):
    b=tuple(int(x) for x in bits)
    if any(x not in (0,1) for x in b): raise ValueError("binary bits required")
    return sum(b)%2

def parity_check(bits,expected_parity):
    if expected_parity not in (0,1): raise ValueError("binary parity required")
    return parity_bit(bits)==expected_parity

def repetition_logical_error_probability(bit_error_probability,code_distance):
    if not 0<=bit_error_probability<=1 or code_distance<1 or code_distance%2==0:
        raise ValueError("p must be 0..1 and distance odd")
    t=(code_distance+1)//2
    return sum(math.comb(code_distance,k)*bit_error_probability**k*(1-bit_error_probability)**(code_distance-k)
               for k in range(t,code_distance+1))

def code_rate(payload_symbols,total_symbols):
    if payload_symbols<1 or total_symbols<payload_symbols: raise ValueError("invalid code dimensions")
    return payload_symbols/total_symbols

def redundancy_fraction(payload_symbols,total_symbols):
    return 1-code_rate(payload_symbols,total_symbols)

def qec_correctable_errors_from_distance(distance):
    if distance<1: raise ValueError("positive code distance required")
    return (distance-1)//2

def independent_cycle_survival(logical_error_probability,cycles):
    if not 0<=logical_error_probability<=1 or cycles<0 or int(cycles)!=cycles:
        raise ValueError("invalid probability/cycle count")
    return (1-logical_error_probability)**int(cycles)

def no_cloning_integrity_guard(unknown_quantum_state,copies_requested):
    if copies_requested<1: raise ValueError("at least one state instance required")
    if unknown_quantum_state and copies_requested>1:
        raise ValueError("unknown quantum states cannot be perfectly cloned")
    return True

@dataclass(frozen=True)
class ClassicalIntegrityPlan:
    payload_symbols:int
    total_symbols:int
    expected_raw_ber:float
    code_distance:int=3
    def __post_init__(self):
        if self.payload_symbols<1 or self.total_symbols<self.payload_symbols or not 0<=self.expected_raw_ber<=1:
            raise ValueError("invalid classical integrity plan")
        if self.code_distance<1 or self.code_distance%2==0: raise ValueError("odd repetition distance required")
    @property
    def rate(self): return code_rate(self.payload_symbols,self.total_symbols)
    @property
    def redundancy(self): return redundancy_fraction(self.payload_symbols,self.total_symbols)
    @property
    def modeled_logical_ber(self): return repetition_logical_error_probability(self.expected_raw_ber,self.code_distance)

@dataclass(frozen=True)
class QuantumIntegrityPlan:
    physical_qubits:int
    logical_qubits:int
    code_distance:int
    physical_error_probability:float
    cycles:int=1
    def __post_init__(self):
        if self.physical_qubits<1 or self.logical_qubits<1 or self.physical_qubits<self.logical_qubits:
            raise ValueError("invalid qubit counts")
        if self.code_distance<1 or self.code_distance%2==0 or not 0<=self.physical_error_probability<=1 or self.cycles<0:
            raise ValueError("invalid QEC plan")
    @property
    def overhead(self): return self.physical_qubits/self.logical_qubits
    @property
    def correctable_errors(self): return qec_correctable_errors_from_distance(self.code_distance)
    @property
    def modeled_logical_error(self):
        return repetition_logical_error_probability(self.physical_error_probability,self.code_distance)
    @property
    def modeled_cycle_survival(self): return independent_cycle_survival(self.modeled_logical_error,self.cycles)

@dataclass(frozen=True)
class HybridIntegrityAssessment:
    classical:ClassicalIntegrityPlan
    quantum:QuantumIntegrityPlan
    classical_hash_verified:bool
    def report(self):
        return {
          "classical":{"code_rate":self.classical.rate,"redundancy_fraction":self.classical.redundancy,
                       "modeled_logical_ber":self.classical.modeled_logical_ber,"hash_verified":self.classical_hash_verified},
          "quantum":{"overhead":self.quantum.overhead,"code_distance":self.quantum.code_distance,
                     "correctable_errors_ideal_code_distance":self.quantum.correctable_errors,
                     "modeled_logical_error":self.quantum.modeled_logical_error,
                     "modeled_cycle_survival":self.quantum.modeled_cycle_survival},
          "domains_combined_into_single_integrity_score":False
        }
