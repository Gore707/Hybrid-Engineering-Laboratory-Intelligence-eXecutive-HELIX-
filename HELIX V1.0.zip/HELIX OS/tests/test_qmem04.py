import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM"
sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_rabi(self):self.assertAlmostEqual(q.angular_rabi_frequency_rad_s(q.HBAR,2),2)
 def test_rabi_hz(self):self.assertAlmostEqual(q.rabi_frequency_hz(q.HBAR,2*math.pi),1)
 def test_photon_energy(self):self.assertGreater(q.photon_energy_j(780e-9),0)
 def test_detuning(self):self.assertEqual(q.two_photon_detuning_rad_s(10,-10),0)
 def test_dark_state(self):self.assertAlmostEqual(q.eit_dark_state_rydberg_fraction(1,1),.5)
 def test_blockade_inverse_sixth(self):
  a=q.blockade_shift_rad_s(1e-60,1e-6);b=q.blockade_shift_rad_s(1e-60,2e-6);self.assertAlmostEqual(a/b,64)
 def test_blockade_radius(self):
  c6=1e-60;g=1e6;r=q.blockade_radius_m(c6,g);self.assertAlmostEqual(q.blockade_shift_rad_s(c6,r),g,places=5)
 def test_lifetime_scaling(self):self.assertEqual(q.rydberg_lifetime_scaling_s(1,20,10,3),8)
 def test_ensemble_density(self):
  e=q.AtomicEnsemble(1000,.1,.01,1e-12);self.assertEqual(e.number_density_m3,1e6)
 def test_optical_depth(self):
  e=q.AtomicEnsemble(1000,.1,.01,1e-6);self.assertAlmostEqual(e.optical_depth,.1)
 def test_eit_bandwidth(self):
  e=q.EITMemoryEstimate(100,1e7,1e7);self.assertAlmostEqual(e.transparency_bandwidth_rad_s,1e6)
 def test_eit_eff_bound(self):
  self.assertGreater(q.EITMemoryEstimate(100,1,1).idealized_efficiency_bound,q.EITMemoryEstimate(1,1,1).idealized_efficiency_bound)
 def test_survival(self):self.assertAlmostEqual(q.EITMemoryEstimate(1,1,1,2).coherence_survival(.5),math.exp(-1))
 def test_collective(self):self.assertEqual(q.collective_coupling_enhancement(2,100),20)
 def test_prior_decoherence(self):self.assertTrue(q.CoherenceBudget(1,10).satisfies_markovian_bound)
 def test_registry(self):
  ids={x.model_id for x in q.QuantumMemoryRegistry().all()};self.assertTrue({"QMEM-RYD-RABI","QMEM-RYD-BLOCKADE","QMEM-RYD-RB","QMEM-EIT-BW","QMEM-COLL-COUPLING"}<=ids)
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QMEM-04")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO"])
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists())
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
