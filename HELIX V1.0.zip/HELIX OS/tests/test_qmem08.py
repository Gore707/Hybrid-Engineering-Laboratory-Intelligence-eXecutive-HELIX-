import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM"
sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_zeeman_zero(self):self.assertEqual(q.electron_zeeman_shift_hz(2,0),0)
 def test_zeeman_linear(self):self.assertAlmostEqual(q.electron_zeeman_shift_hz(2,.02)/q.electron_zeeman_shift_hz(2,.01),2)
 def test_t2(self):self.assertAlmostEqual(q.lorentzian_t2_from_linewidth_s(1),1/math.pi)
 def test_spin_survival(self):self.assertAlmostEqual(q.exponential_spin_survival(1,1),math.exp(-1))
 def test_init_readout(self):self.assertAlmostEqual(q.initialization_readout_success(.9,.8),.72)
 def test_photon_collection(self):self.assertAlmostEqual(q.photon_collection_probability(.5,.4,.8),.16)
 def test_purcell_positive(self):self.assertGreater(q.cavity_purcell_factor(1e4,1e-18,637e-9,2.4),0)
 def test_beta(self):self.assertAlmostEqual(q.beta_factor_from_purcell(1,1),.5)
 def test_collective(self):self.assertEqual(q.ensemble_collective_coupling_rad_s(2,100),20)
 def test_center(self):
  c=q.ColorCenter("NV",637e-9,.001,.03);self.assertAlmostEqual(c.spin_survival(.001),math.exp(-1))
 def test_bad_center(self):
  with self.assertRaises(ValueError):q.ColorCenter("",637e-9,.001,.03)
 def test_memory_zero_storage(self):
  m=q.DiamondMemoryEstimate(.9,.8,.7,.6,1);self.assertAlmostEqual(m.total_success_probability(0),.3024)
 def test_memory_decay(self):
  m=q.DiamondMemoryEstimate(1,1,1,1,1);self.assertAlmostEqual(m.total_success_probability(1),math.exp(-1))
 def test_rare_earth_preserved(self):self.assertEqual(q.afc_echo_time_s(1e6),1e-6)
 def test_raman_preserved(self):self.assertEqual(q.time_bandwidth_product(.01,1e6),1e4)
 def test_registry(self):
  ids={x.model_id for x in q.QuantumMemoryRegistry().all()}
  self.assertTrue({"QMEM-CC-ZEEMAN","QMEM-CC-T2","QMEM-CC-PHOTON","QMEM-CC-PURCELL","QMEM-CC-COLLECTIVE"}<=ids)
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QMEM-08")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO"])
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists())
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
