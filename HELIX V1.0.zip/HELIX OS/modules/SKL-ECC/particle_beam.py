from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .foundation import C_M_S,EV_J

E_CHARGE_C=1.602176634e-19

class BeamCharge(str,Enum):
    CHARGED="CHARGED"
    NEUTRAL="NEUTRAL"

def lorentz_gamma_from_kinetic_energy_j(kinetic_energy_j,rest_mass_kg):
    if kinetic_energy_j<0 or rest_mass_kg<=0:raise ValueError("invalid inputs")
    return 1+kinetic_energy_j/(rest_mass_kg*C_M_S**2)

def beta_from_gamma(gamma):
    if gamma<1:raise ValueError("gamma >= 1")
    return math.sqrt(max(0.0,1-1/gamma**2))

def speed_from_kinetic_energy_j(kinetic_energy_j,rest_mass_kg):
    return C_M_S*beta_from_gamma(lorentz_gamma_from_kinetic_energy_j(kinetic_energy_j,rest_mass_kg))

def kinetic_energy_j_from_ev(energy_ev):
    if energy_ev<0:raise ValueError("energy nonnegative")
    return energy_ev*EV_J

def particle_latency_s(distance_m,kinetic_energy_j,rest_mass_kg):
    if distance_m<0:raise ValueError("distance nonnegative")
    v=speed_from_kinetic_energy_j(kinetic_energy_j,rest_mass_kg)
    if v<=0:raise ValueError("nonzero particle speed required")
    return distance_m/v

def beam_radius_m(distance_m,divergence_rad,source_radius_m=0.0):
    if distance_m<0 or divergence_rad<0 or source_radius_m<0:raise ValueError("nonnegative geometry")
    return source_radius_m+distance_m*divergence_rad

def beam_area_m2(distance_m,divergence_rad,source_radius_m=0.0):
    r=beam_radius_m(distance_m,divergence_rad,source_radius_m)
    return math.pi*r*r

def magnetic_gyroradius_m(momentum_kg_m_s,charge_c,b_field_t):
    if momentum_kg_m_s<0 or charge_c==0 or b_field_t==0:raise ValueError("charged particle and nonzero field required")
    return momentum_kg_m_s/(abs(charge_c)*abs(b_field_t))

def relativistic_momentum_kg_m_s(rest_mass_kg,kinetic_energy_j):
    if rest_mass_kg<=0 or kinetic_energy_j<0:raise ValueError("invalid inputs")
    g=lorentz_gamma_from_kinetic_energy_j(kinetic_energy_j,rest_mass_kg)
    v=C_M_S*beta_from_gamma(g)
    return g*rest_mass_kg*v

def small_angle_magnetic_deflection_rad(path_length_m,gyroradius_m):
    if path_length_m<0 or gyroradius_m<=0:raise ValueError("invalid geometry")
    return path_length_m/gyroradius_m

def survival_probability(mean_free_path_m,path_length_m):
    if mean_free_path_m<=0 or path_length_m<0:raise ValueError("invalid transport")
    return math.exp(-path_length_m/mean_free_path_m)

def detected_particle_rate_s(source_rate_s,beam_area_m2,detector_area_m2,survival=1.0,efficiency=1.0):
    if source_rate_s<0 or beam_area_m2<=0 or detector_area_m2<0 or not 0<=survival<=1 or not 0<=efficiency<=1:
        raise ValueError("invalid detection inputs")
    return source_rate_s*min(1.0,detector_area_m2/beam_area_m2)*survival*efficiency

def ideal_particle_bit_rate_bps(detected_rate_s,particles_per_bit):
    if detected_rate_s<0 or particles_per_bit<=0:raise ValueError("invalid event budget")
    return detected_rate_s/particles_per_bit

def beam_power_w(source_rate_s,kinetic_energy_j,source_efficiency=1.0):
    if source_rate_s<0 or kinetic_energy_j<0 or not 0<source_efficiency<=1:raise ValueError("invalid source")
    return source_rate_s*kinetic_energy_j/source_efficiency

def generalized_perveance(current_a,beta,gamma,characteristic_current_a):
    """Dimensionless K=2I/(I0 beta^3 gamma^3), a transparent space-charge severity proxy."""
    if current_a<0 or not 0<beta<1 or gamma<1 or characteristic_current_a<=0:raise ValueError("invalid perveance inputs")
    return 2*current_a/(characteristic_current_a*beta**3*gamma**3)

@dataclass(frozen=True)
class ParticleBeamLink:
    rest_mass_kg:float
    kinetic_energy_j:float
    source_rate_s:float
    distance_m:float
    divergence_rad:float
    detector_area_m2:float
    survival:float=1.0
    detector_efficiency:float=1.0
    particles_per_bit:float=10.0
    source_radius_m:float=0.0
    charge_c:float=0.0
    def __post_init__(self):
        if self.rest_mass_kg<=0 or self.kinetic_energy_j<=0 or self.source_rate_s<0 or self.distance_m<=0 or self.divergence_rad<=0 or self.detector_area_m2<0:
            raise ValueError("invalid link")
        if not 0<=self.survival<=1 or not 0<=self.detector_efficiency<=1 or self.particles_per_bit<=0:raise ValueError("invalid efficiency")
    @property
    def gamma(self):return lorentz_gamma_from_kinetic_energy_j(self.kinetic_energy_j,self.rest_mass_kg)
    @property
    def beta(self):return beta_from_gamma(self.gamma)
    @property
    def speed_m_s(self):return self.beta*C_M_S
    @property
    def latency_s(self):return self.distance_m/self.speed_m_s
    @property
    def beam_area_m2(self):return beam_area_m2(self.distance_m,self.divergence_rad,self.source_radius_m)
    @property
    def detected_rate_s(self):return detected_particle_rate_s(self.source_rate_s,self.beam_area_m2,self.detector_area_m2,self.survival,self.detector_efficiency)
    @property
    def ideal_bit_rate_bps(self):return ideal_particle_bit_rate_bps(self.detected_rate_s,self.particles_per_bit)
