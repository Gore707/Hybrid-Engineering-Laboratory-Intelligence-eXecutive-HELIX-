import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QCOM"
sp=importlib.util.spec_from_file_location("skl_qcom",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qcom"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_basis(self):self.assertEqual(q.Qubit(1+0j,0j).probabilities,(1,0))
 def test_bad_norm(self):
  with self.assertRaises(ValueError):q.Qubit(1,1)
 def test_angles(self):
  x=q.qubit_from_angles(math.pi/2,0);self.assertAlmostEqual(sum(x.probabilities),1)
 def test_bloch_zero(self):self.assertEqual(q.bloch_vector(q.Qubit(1+0j,0j)),(0.0,0.0,1.0))
 def test_density_trace(self):self.assertAlmostEqual(q.density_trace(q.pure_density_matrix(q.Qubit(1+0j,0j))),1)
 def test_fidelity_same(self):
  a=q.Qubit(1+0j,0j);self.assertEqual(q.pure_state_fidelity(a,a),1)
 def test_fidelity_orthogonal(self):self.assertEqual(q.pure_state_fidelity(q.Qubit(1+0j,0j),q.Qubit(0j,1+0j)),0)
 def test_trace_distance(self):self.assertEqual(q.pure_state_trace_distance(q.Qubit(1+0j,0j),q.Qubit(0j,1+0j)),1)
 def test_entropy(self):self.assertEqual(q.binary_entropy_bits(.5),1)
 def test_loss(self):self.assertAlmostEqual(q.attenuation_transmissivity(10),.1)
 def test_survival(self):self.assertEqual(q.photon_survival_probability(.5,.8),.4)
 def test_depol(self):self.assertEqual(q.depolarizing_fidelity(.2),.9)
 def test_dephase(self):self.assertEqual(q.dephasing_coherence_factor(.5),0)
 def test_damping(self):self.assertAlmostEqual(q.amplitude_damping_excited_population(.8,.25),.6)
 def test_no_signalling(self):
  self.assertEqual(q.no_signalling_remote_probability("Z"),q.no_signalling_remote_probability("X"))
  self.assertEqual(q.no_signalling_remote_probability("Z"),(.5,.5))
 def test_channel_loss(self):self.assertAlmostEqual(q.QuantumChannel(.1).loss_db,10)
 def test_provenance(self):self.assertEqual(q.QuantumChannel().evidence,q.EvidenceState.SIMULATION)
 def test_registry(self):self.assertTrue({"QCOM-QUBIT","QCOM-FIDELITY","QCOM-LOSS","QCOM-NOSIGNAL"}<={x.model_id for x in q.QuantumCommRegistry().all()})
 def test_schema(self):
  s=json.loads((M/"schemas/quantum_channel.schema.json").read_text());self.assertEqual(s["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QCOM-01")
 def test_opt_complete(self):self.assertEqual(json.loads((R/"OPT_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
