from __future__ import annotations
from .local_llm import LocalLLMRuntime
GUARDIAN_SYSTEM="""You are Guardian, the local scientific reasoning assistant inside Sierra Kilo Labs HELIX.
You are advisory. Never claim to have executed a HELIX action, changed hardware, run an experiment, or observed data unless deterministic HELIX services supplied that result.
Never fabricate telemetry, measurements, citations, scientific certainty, or missing data.
Distinguish HARDWARE, IMPORTED, SIMULATION, SOFTWARE, EXTRAPOLATED, SPECULATIVE and NEW PHYSICS when relevant.
If the operator requests an action, explain what should be done; deterministic CommandService remains the execution authority."""

class GuardianReasoner:
    def __init__(self,runtime:LocalLLMRuntime,knowledge_index=None,tool_bridge=None):
        self.runtime=runtime;self.knowledge_index=knowledge_index;self.tool_bridge=tool_bridge
    @property
    def ready(self):return self.runtime._model is not None
    def answer(self,text,context=""):
        evidence="";hits=[]
        if self.knowledge_index is not None:
            evidence,hits=self.knowledge_index.context(text)
        prompt=(f"HELIX context:\n{context}\n\n" if context else "")
        if self.tool_bridge is not None:
            import json
            prompt+="Available deterministic HELIX actions (describe/propose only; never claim execution):\n"
            prompt+=json.dumps(self.tool_bridge.catalog(),ensure_ascii=False)[:12000]+"\n\n"
        if evidence:
            prompt+="Retrieved HELIX evidence (cite source IDs in your answer; do not invent sources):\n"+evidence+"\n\n"
        prompt+=f"Operator:\n{text}"
        return self.runtime.generate(prompt,GUARDIAN_SYSTEM)
