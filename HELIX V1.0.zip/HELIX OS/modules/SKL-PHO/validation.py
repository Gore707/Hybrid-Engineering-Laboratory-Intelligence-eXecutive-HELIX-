from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import dielectric_interface
from .geometric import Ray,free_space,thin_lens
from .gaussian import GaussianBeam
from .polarization import JonesVector,linear_polarizer
from .detectors import responsivity_from_qe,qe_from_responsivity
from .optical_bench import OpticalBench,BenchComponent,gaussian_bench_state
@dataclass(frozen=True)
class ValidationCheck:
 name:str;passed:bool;value:float|str;tolerance:float|None=None;note:str=""
@dataclass(frozen=True)
class ValidationReport:
 checks:tuple[ValidationCheck,...]
 @property
 def passed(self):return all(c.passed for c in self.checks)
 @property
 def passed_count(self):return sum(c.passed for c in self.checks)
 @property
 def total_count(self):return len(self.checks)
def _close(name,value,target,tol,note=""):
 return ValidationCheck(name,abs(value-target)<=tol,value,tol,note)
def run_photonics_self_validation():
 checks=[]
 # Fresnel lossless normal incidence energy conservation
 x=dielectric_interface(1.0,1.5,0.0,"s");checks.append(_close("fresnel_energy",x.reflectance+x.transmittance,1.0,1e-12))
 # ABCD free space then ideal thin lens ray relation
 ray=thin_lens(1.0).apply(free_space(1.0).apply(Ray(.1,0)));checks.append(_close("abcd_ray_angle",ray.angle_rad,-.1,1e-12))
 # Gaussian beam radius at Rayleigh range
 b=GaussianBeam(1e-6,1e-3);checks.append(_close("gaussian_zr",b.radius_m(b.rayleigh_range_m)/b.waist_m,math.sqrt(2),1e-12))
 # Malus via Jones polarizer
 v=JonesVector(1/math.sqrt(2),1/math.sqrt(2));out=linear_polarizer(0)@v;checks.append(_close("jones_malus",out.intensity,.5,1e-12))
 # detector QE-responsivity inverse consistency
 r=responsivity_from_qe(.73,850e-9);checks.append(_close("detector_qe_roundtrip",qe_from_responsivity(r,850e-9),.73,1e-12))
 # integrated bench energy chain
 state=gaussian_bench_state(GaussianBeam(1e-6,1e-3,power_w=2),polarization=v)
 result=OpticalBench([BenchComponent("A","attenuator",{"power_transmission":.5}),BenchComponent("P","linear_polarizer",{"angle_rad":0}),BenchComponent("D","detector",{"responsivity_a_w":.8})]).run(state)
 checks.append(_close("bench_power_chain",result.final_state.power_w,.5,1e-12))
 checks.append(_close("bench_detector_current",result.detector_readings[0]["signal_current_a"],.4,1e-12))
 return ValidationReport(tuple(checks))
