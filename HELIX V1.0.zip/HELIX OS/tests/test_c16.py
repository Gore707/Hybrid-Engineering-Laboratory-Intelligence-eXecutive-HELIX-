import tempfile,unittest
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.guardian.intelligence import *
from core.guardian.intelligence.ingest import ingest_physics
ROOT=Path(__file__).resolve().parents[1]
class C16Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C16")
 def test_index_search(self):
  with tempfile.TemporaryDirectory() as td:
   i=KnowledgeIndex(Path(td)/"k.db");i.upsert(KnowledgeItem("A","equation","Photon energy","Photon energy equals Planck constant times frequency.","S1","ESTABLISHED_PHYSICS"))
   r=i.search("photon frequency");self.assertEqual(r[0][1].item_id,"A");i.close()
 def test_unknown_is_truthful(self):
  with tempfile.TemporaryDirectory() as td:
   i=KnowledgeIndex(Path(td)/"k.db");s=GuardianIntelligenceService(i,ExtractiveLocalRuntime())
   a=s.ask("unrepresented subject xyz");self.assertFalse(a.grounded);self.assertEqual(a.confidence,0);i.close()
 def test_grounded_answer_has_source(self):
  with tempfile.TemporaryDirectory() as td:
   i=KnowledgeIndex(Path(td)/"k.db");i.upsert(KnowledgeItem("K","truth","Casimir","Casimir forces have been experimentally measured.","SRC","DEMONSTRATED_TECHNOLOGY"))
   a=GuardianIntelligenceService(i,ExtractiveLocalRuntime()).ask("Casimir experimentally measured")
   self.assertTrue(a.grounded);self.assertIn("SRC",a.sources);self.assertIn("DEMONSTRATED_TECHNOLOGY",a.evidence_classes);i.close()
 def test_empty_question(self):
  with tempfile.TemporaryDirectory() as td:
   s=GuardianIntelligenceService(KnowledgeIndex(Path(td)/"k.db"),ExtractiveLocalRuntime())
   with self.assertRaises(ValueError):s.ask(" ")
 def test_ingest_canonical_physics(self):
  with tempfile.TemporaryDirectory() as td:
   i=KnowledgeIndex(Path(td)/"k.db")
   n=ingest_physics(i,ROOT/"core/resources/constants/physical_constants.json",ROOT/"core/resources/equations",ROOT/"core/resources/models")
   self.assertGreaterEqual(n,10);self.assertTrue(i.search("Shannon capacity"));i.close()
 def test_runtime_is_local(self):self.assertEqual(ExtractiveLocalRuntime.name,"extractive-local")
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
