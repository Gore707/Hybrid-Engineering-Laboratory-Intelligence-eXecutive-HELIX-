from __future__ import annotations
from dataclasses import dataclass, field

@dataclass(frozen=True)
class MenuNode:
    key: str
    title: str
    description: str
    children: tuple["MenuNode", ...] = field(default_factory=tuple)

ROOT_MENU = MenuNode("MAIN", "Guardian Main Menu", "HELIX command domains", (
    MenuNode("1", "Research & Evidence", "Research/evidence command domain."),
    MenuNode("2", "Create/Open Project", "Project lifecycle commands."),
    MenuNode("3", "Design Theoretical Device", "Device-design command domain."),
    MenuNode("4", "Physics & Equation Models", "Physics/model command domain."),
    MenuNode("5", "Simulation Laboratory", "Simulation command domain."),
    MenuNode("6", "Parameter Sweeps & Optimization", "Sweep/optimization command domain."),
    MenuNode("7", "Visualization Laboratory", "Visualization command domain."),
    MenuNode("8", "Validation & Published Data", "Validation command domain."),
    MenuNode("9", "Open Research Gateway", "External research command domain."),
    MenuNode("10", "Hardware & Instruments", "Hardware command domain."),
    MenuNode("11", "Data / Results / Experiments", "Experiment/data command domain."),
    MenuNode("12", "Workspaces & UI", "Operational workspace commands.", (
        MenuNode("A", "Save Workspace Layout", "Runs workspace.save."),
        MenuNode("B", "Restore Workspace Layout", "Runs workspace.restore."),
        MenuNode("C", "Reset Workspace", "Runs workspace.reset."),
    )),
    MenuNode("13", "Guardian Intelligence", "Guardian command domain."),
    MenuNode("14", "Automation & Scripts", "Automation command domain."),
    MenuNode("15", "System / Compute / Diagnostics", "Operational system commands.", (
        MenuNode("A", "Create Recovery Checkpoint", "Runs session.checkpoint."),
        MenuNode("B", "System Status", "Shows current HELIX status."),
    )),
    MenuNode("16", "Boundary Physics Laboratory", "Boundary-physics command domain."),
))

def find_child(node: MenuNode, key: str):
    key = key.upper()
    for child in node.children:
        if child.key.upper() == key:
            return child
    return None
