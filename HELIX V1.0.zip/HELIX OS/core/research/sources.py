from dataclasses import dataclass
@dataclass(frozen=True)
class OpenSource:
 source_id:str;name:str;base_url:str;kind:str;notes:str
class OpenSourceRegistry:
 def __init__(self):
  self._items={
   "arxiv":OpenSource("arxiv","arXiv","https://arxiv.org","papers","Open preprints; item licensing varies."),
   "nasa_ads":OpenSource("nasa_ads","NASA ADS","https://ui.adsabs.harvard.edu","bibliography","Metadata/search may expose API/auth requirements."),
   "nist":OpenSource("nist","NIST","https://www.nist.gov","standards-data","Public scientific data and publications."),
   "nasa_open":OpenSource("nasa_open","NASA Open Data","https://data.nasa.gov","datasets","Public NASA datasets."),
   "zenodo":OpenSource("zenodo","Zenodo","https://zenodo.org","papers-data","Open repository; item licensing varies."),
   "doaj":OpenSource("doaj","DOAJ","https://doaj.org","papers","Directory of open-access journals.")
  }
 def get(self,key):return self._items[key]
 def all(self):return tuple(self._items.values())
