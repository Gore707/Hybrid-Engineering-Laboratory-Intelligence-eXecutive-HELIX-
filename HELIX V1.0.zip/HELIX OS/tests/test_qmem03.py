import unittest,importlib.util,sys,json,math
import numpy as np
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM"
sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_identity_kraus(self):self.assertTrue(np.allclose(q.apply_kraus_channel([[1,0],[0,0]],[np.eye(2)]),[[1,0],[0,0]]))
 def test_bad_kraus(self):
  with self.assertRaises(ValueError):q.apply_kraus_channel([[1,0],[0,0]],[.5*np.eye(2)])
 def test_depolarize_full(self):self.assertTrue(np.allclose(q.depolarizing_qubit([[1,0],[0,0]],1),.5*np.eye(2)))
 def test_phase_flip(self):
  o=q.phase_flip_qubit([[.5,.5],[.5,.5]],1);self.assertTrue(np.allclose(o,[[.5,-.5],[-.5,.5]]))
 def test_bit_flip(self):self.assertTrue(np.allclose(q.bit_flip_qubit([[1,0],[0,0]],1),[[0,0],[0,1]]))
 def test_thermal_zero_gap(self):self.assertEqual(q.thermal_excited_population(0,300),.5)
 def test_thermal_large_gap(self):self.assertLess(q.thermal_excited_population(1e-19,1),1e-100)
 def test_gad_trace(self):
  o=q.generalized_amplitude_damping_qubit([[0,0],[0,1]],.2,.9);self.assertAlmostEqual(np.trace(o).real,1)
 def test_budget_relaxation_only(self):self.assertAlmostEqual(q.CoherenceBudget(2).t2_s,4)
 def test_budget_dephasing(self):self.assertAlmostEqual(q.CoherenceBudget(2,4).t2_s,2)
 def test_bound(self):self.assertTrue(q.CoherenceBudget(1,10).satisfies_markovian_bound)
 def test_assessment(self):
  a=q.assess_channel([[1,0],[0,0]],q.depolarizing_qubit([[1,0],[0,0]],.2));self.assertTrue(a.trace_preserved);self.assertLess(a.output_purity,a.input_purity)
 def test_state_engine_preserved(self):self.assertAlmostEqual(q.von_neumann_entropy_bits([[.5,0],[0,.5]]),1)
 def test_no_cloning_preserved(self):
  with self.assertRaises(ValueError):q.no_cloning_guard(2,True)
 def test_registry(self):
  ids={x.model_id for x in q.QuantumMemoryRegistry().all()};self.assertTrue({"QMEM-DEP","QMEM-THERM-POP","QMEM-T2-BUDGET"}<=ids)
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QMEM-03")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO"])
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists())
 def test_completed_modules(self):
  self.assertEqual(json.loads((R/"STO_COMPLETE.json").read_text())["status"],"COMPLETE")
  self.assertEqual(json.loads((R/"PHO_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
