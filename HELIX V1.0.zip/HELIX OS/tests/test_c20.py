import tempfile,unittest,time
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.hal import *
from core.hal.driver_adapter import DriverHardwareDevice
ROOT=Path(__file__).resolve().parents[1]
class Driver:
 def __init__(self):self.v=1;self.connected=False
 def connect(self):self.connected=True
 def disconnect(self):self.connected=False
 def read(self,c):return self.v,"V"
 def write(self,c,v):self.v=v
class C20Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C20")
 def test_simulated_read(self):
  with tempfile.TemporaryDirectory() as td:
   h=HardwareAbstractionLayer(Path(td)/"a.jsonl");d=SimulatedDevice(DeviceDescriptor("S","sim","meter",HALSource.SIMULATION,("read",),True),{"x":(2,"V")})
   h.register(d);h.connect("S");m=h.read("S","x");self.assertEqual(m.source,HALSource.SIMULATION);self.assertEqual(m.value,2)
 def test_imported_immutable(self):
  with tempfile.TemporaryDirectory() as td:
   h=HardwareAbstractionLayer(Path(td)/"a");r=Measurement("I","x",3,"V",time.time(),HALSource.IMPORTED)
   d=ImportedDevice(DeviceDescriptor("I","import","dataset",HALSource.IMPORTED,("read",),True),[r]);h.register(d);h.connect("I")
   with self.assertRaises(HALError):h.write("I","x",4)
 def test_hardware_write_requires_arm(self):
  with tempfile.TemporaryDirectory() as td:
   h=HardwareAbstractionLayer(Path(td)/"a");d=DriverHardwareDevice(DeviceDescriptor("H","meter","instrument",HALSource.HARDWARE,("read","write"),True),Driver())
   h.register(d);h.connect("H")
   with self.assertRaises(HALError):h.write("H","x",5)
   with self.assertRaises(HALError):h.arm("H",False)
   h.arm("H",True);h.write("H","x",5);self.assertEqual(h.read("H","x").value,5)
 def test_source_mismatch_rejected(self):
  class Bad:
   descriptor=DeviceDescriptor("B","bad","x",HALSource.SIMULATION,("read",),False);state=DeviceState.CONNECTED
   def read(self,c):return Measurement("B",c,1,"V",time.time(),HALSource.HARDWARE)
  with tempfile.TemporaryDirectory() as td:
   h=HardwareAbstractionLayer(Path(td)/"a");h.register(Bad())
   with self.assertRaises(HALError):h.read("B","x")
 def test_inventory(self):
  with tempfile.TemporaryDirectory() as td:
   h=HardwareAbstractionLayer(Path(td)/"a");d=SimulatedDevice(DeviceDescriptor("S","sim","x",HALSource.SIMULATION,("read",)),{"x":(1,"V")})
   h.register(d);self.assertEqual(h.inventory()[0]["source"],"SIMULATION")
 def test_audit_written(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/"audit.jsonl";h=HardwareAbstractionLayer(p);h.register(SimulatedDevice(DeviceDescriptor("S","s","x",HALSource.SIMULATION,("read",)),{"x":(1,"V")}))
   self.assertIn('"event":"REGISTER"',p.read_text())
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
