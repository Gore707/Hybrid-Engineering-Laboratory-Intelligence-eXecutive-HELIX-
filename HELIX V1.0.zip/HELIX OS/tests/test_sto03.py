import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-STO";sp=importlib.util.spec_from_file_location("skl_sto",M/"__init__.py",submodule_search_locations=[str(M)]);s=importlib.util.module_from_spec(sp);sys.modules["skl_sto"]=s;sp.loader.exec_module(s)
class T(unittest.TestCase):
 def test_fringe(self):self.assertAlmostEqual(s.fringe_spacing_m(1e-6,1,math.pi),5e-7)
 def test_grating_vector(self):self.assertAlmostEqual(s.grating_vector_magnitude(1e-6),2*math.pi*1e6)
 def test_bragg(self):self.assertAlmostEqual(s.bragg_angle_rad(1e-6,1,1e-6),math.pi/6)
 def test_nonpropagating_bragg(self):self.assertIsNone(s.bragg_angle_rad(3e-6,1,1e-6))
 def test_selectivity(self):self.assertAlmostEqual(s.approximate_angular_selectivity_rad(1e-6,1,1e-3),5e-4)
 def test_page(self):
  p=s.HolographicPage(100,200,2,.1);self.assertEqual(p.raw_bits,40000);self.assertEqual(p.payload_bits,36000)
 def test_multiplex(self):self.assertEqual(s.MultiplexPlan(10,3,2,2).nominal_pages,120)
 def test_volume_capacity(self):
  v=s.HolographicVolume(s.HolographicPage(10,10,1,.1),s.MultiplexPlan(2,2),5,.2);c=v.capacity();self.assertEqual(v.page_count,20);self.assertEqual(c.raw_bits,2000);self.assertAlmostEqual(c.usable_bits,1440)
 def test_diffraction(self):self.assertAlmostEqual(s.diffraction_efficiency_weak_grating(0,1e-3,1e-6),0)
 def test_registry(self):self.assertEqual(s.StorageRegistry().get("STO-HOLO-BRAGG").evidence_class,"ESTABLISHED_PHYSICS")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-STO-03")
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
