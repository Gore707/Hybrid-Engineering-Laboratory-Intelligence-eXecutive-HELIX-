from __future__ import annotations
from dataclasses import dataclass
import math

KB=1.380649e-23
C=299792458.0
AMU=1.66053906660e-27

def one_dimensional_thermal_velocity_std_m_s(temperature_k,atomic_mass_kg):
    if temperature_k<=0 or atomic_mass_kg<=0: raise ValueError("positive temperature and mass required")
    return math.sqrt(KB*temperature_k/atomic_mass_kg)

def doppler_fwhm_hz(center_frequency_hz,temperature_k,atomic_mass_kg):
    if center_frequency_hz<=0: raise ValueError("positive center frequency required")
    sigma_v=one_dimensional_thermal_velocity_std_m_s(temperature_k,atomic_mass_kg)
    sigma_f=center_frequency_hz*sigma_v/C
    return 2*math.sqrt(2*math.log(2))*sigma_f

def wavelength_to_frequency_hz(wavelength_m):
    if wavelength_m<=0: raise ValueError("positive wavelength required")
    return C/wavelength_m

def wavevector_rad_m(wavelength_m):
    if wavelength_m<=0: raise ValueError("positive wavelength required")
    return 2*math.pi/wavelength_m

def spin_wave_wavevector_rad_m(signal_wavelength_m,control_wavelength_m,copropagating=True):
    ks=wavevector_rad_m(signal_wavelength_m); kc=wavevector_rad_m(control_wavelength_m)
    return abs(ks-kc) if copropagating else abs(ks+kc)

def ballistic_spin_wave_coherence_s(delta_k_rad_m,thermal_velocity_std_m_s):
    if delta_k_rad_m<0 or thermal_velocity_std_m_s<0: raise ValueError("nonnegative inputs required")
    if delta_k_rad_m==0 or thermal_velocity_std_m_s==0:return math.inf
    return 1/(delta_k_rad_m*thermal_velocity_std_m_s)

def diffusion_spin_wave_decay_rate_s_inv(diffusion_m2_s,delta_k_rad_m):
    if diffusion_m2_s<0 or delta_k_rad_m<0: raise ValueError("nonnegative inputs required")
    return diffusion_m2_s*delta_k_rad_m**2

def combined_ground_coherence_time_s(intrinsic_t2_s,diffusion_m2_s=0.0,delta_k_rad_m=0.0):
    if intrinsic_t2_s<=0: raise ValueError("positive intrinsic T2 required")
    rate=1/intrinsic_t2_s+diffusion_spin_wave_decay_rate_s_inv(diffusion_m2_s,delta_k_rad_m)
    return 1/rate

def beer_lambert_transmission(optical_depth):
    if optical_depth<0: raise ValueError("optical depth cannot be negative")
    return math.exp(-optical_depth)

def resonant_optical_depth(number_density_m3,length_m,cross_section_m2):
    if number_density_m3<0 or length_m<0 or cross_section_m2<0: raise ValueError("nonnegative inputs required")
    return number_density_m3*length_m*cross_section_m2

def spin_wave_survival(storage_time_s,coherence_time_s):
    if storage_time_s<0 or coherence_time_s<=0: raise ValueError("invalid times")
    return math.exp(-storage_time_s/coherence_time_s)

@dataclass(frozen=True)
class VaporCell:
    temperature_k:float
    length_m:float
    number_density_m3:float
    atomic_mass_kg:float
    resonant_cross_section_m2:float
    def __post_init__(self):
        if self.temperature_k<=0 or self.length_m<=0 or self.number_density_m3<0 or self.atomic_mass_kg<=0 or self.resonant_cross_section_m2<0:
            raise ValueError("invalid vapor-cell parameters")
    @property
    def optical_depth(self):
        return resonant_optical_depth(self.number_density_m3,self.length_m,self.resonant_cross_section_m2)

@dataclass(frozen=True)
class VaporMemoryEstimate:
    optical_depth:float
    intrinsic_ground_t2_s:float
    diffusion_m2_s:float=0.0
    delta_k_rad_m:float=0.0
    def __post_init__(self):
        if self.optical_depth<0 or self.intrinsic_ground_t2_s<=0 or self.diffusion_m2_s<0 or self.delta_k_rad_m<0:
            raise ValueError("invalid vapor-memory parameters")
    @property
    def effective_t2_s(self):
        return combined_ground_coherence_time_s(self.intrinsic_ground_t2_s,self.diffusion_m2_s,self.delta_k_rad_m)
    def survival(self,storage_time_s):
        return spin_wave_survival(storage_time_s,self.effective_t2_s)
    @property
    def idealized_od_efficiency_bound(self):
        od=self.optical_depth
        return (od/(1+od))**2 if od>0 else 0.0
