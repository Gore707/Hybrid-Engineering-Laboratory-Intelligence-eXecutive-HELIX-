from __future__ import annotations
from pathlib import Path
import sqlite3,time,json
class AdaptiveMemory:
 def __init__(self,path:Path):
  path.parent.mkdir(parents=True,exist_ok=True);self.db=sqlite3.connect(path)
  self.db.executescript("""CREATE TABLE IF NOT EXISTS observations(
   id INTEGER PRIMARY KEY AUTOINCREMENT,ts REAL NOT NULL,kind TEXT NOT NULL,key TEXT NOT NULL,
   value REAL,text TEXT,provenance TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS memories(
   memory_id TEXT PRIMARY KEY,ts REAL NOT NULL,kind TEXT NOT NULL,text TEXT NOT NULL,
   confidence REAL NOT NULL,provenance TEXT NOT NULL);
   CREATE INDEX IF NOT EXISTS idx_obs_key ON observations(key,ts);""");self.db.commit()
 def observe(self,kind,key,value=None,text=None,provenance="HELIX"):
  if value is None and not text:raise ValueError("observation requires value or text")
  self.db.execute("INSERT INTO observations(ts,kind,key,value,text,provenance) VALUES(?,?,?,?,?,?)",
   (time.time(),kind,key,value,text,provenance));self.db.commit()
 def values(self,key,limit=100):
  rows=self.db.execute("SELECT value FROM observations WHERE key=? AND value IS NOT NULL ORDER BY id DESC LIMIT ?",(key,limit)).fetchall()
  return [float(r[0]) for r in reversed(rows)]
 def remember(self,memory_id,kind,text,confidence,provenance):
  if not 0<=confidence<=1:raise ValueError("confidence")
  self.db.execute("""INSERT INTO memories VALUES(?,?,?,?,?,?) ON CONFLICT(memory_id) DO UPDATE SET
  ts=excluded.ts,kind=excluded.kind,text=excluded.text,confidence=excluded.confidence,provenance=excluded.provenance""",
  (memory_id,time.time(),kind,text,confidence,provenance));self.db.commit()
 def memory_count(self):return self.db.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
 def observation_count(self):return self.db.execute("SELECT COUNT(*) FROM observations").fetchone()[0]
 def close(self):self.db.close()
