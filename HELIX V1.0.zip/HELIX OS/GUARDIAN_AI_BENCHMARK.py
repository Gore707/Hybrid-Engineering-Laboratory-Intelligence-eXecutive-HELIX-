from __future__ import annotations
from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from core.commands import ActionRegistry,CommandService,CommandContext
from core.guardian.integration import GuardianAIServices
from core.guardian.activation_benchmark import GuardianActivationBenchmark,write_report

def main():
    ap=argparse.ArgumentParser(description="HELIX Guardian AI on-host benchmark")
    ap.add_argument("--no-inference",action="store_true")
    a=ap.parse_args()
    # No duplicate production registry is claimed: this isolated CLI has no GUI action owner and executes nothing.
    svc=GuardianAIServices(ROOT,CommandService(ActionRegistry()),lambda:CommandContext("BENCHMARK","operator"))
    svc.initialize(auto_load_model=False)
    results=GuardianActivationBenchmark(svc).run(run_inference=not a.no_inference)
    report=write_report(ROOT/"user"/"guardian"/"activation_benchmark.json",results,svc)
    print(json.dumps(report,indent=2))
    failed=[r for r in results if r.status=="FAIL"]
    return 1 if failed else 0
if __name__=="__main__":raise SystemExit(main())
