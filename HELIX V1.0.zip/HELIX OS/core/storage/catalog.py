from __future__ import annotations
import json, sqlite3
from pathlib import Path
from datetime import datetime, timezone

def utc_now(): return datetime.now(timezone.utc).isoformat()

class ResourceCatalog:
    def __init__(self,path:Path):
        self.path=path; path.parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(path)
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS resources(
          resource_id TEXT PRIMARY KEY,
          resource_type TEXT NOT NULL,
          name TEXT NOT NULL,
          schema_version TEXT NOT NULL,
          resource_version TEXT NOT NULL,
          json_payload TEXT NOT NULL,
          created_utc TEXT NOT NULL,
          modified_utc TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_resources_type ON resources(resource_type);
        CREATE INDEX IF NOT EXISTS idx_resources_name ON resources(name);
        CREATE TABLE IF NOT EXISTS relations(
          source_id TEXT NOT NULL,
          relation TEXT NOT NULL,
          target_id TEXT NOT NULL,
          PRIMARY KEY(source_id,relation,target_id),
          FOREIGN KEY(source_id) REFERENCES resources(resource_id) ON DELETE CASCADE,
          FOREIGN KEY(target_id) REFERENCES resources(resource_id) ON DELETE CASCADE
        );
        """)
        self.db.commit()
    def upsert(self,resource_type:str,data:dict):
        now=utc_now(); rid=data["resource_id"]
        self.db.execute("""INSERT INTO resources(resource_id,resource_type,name,schema_version,resource_version,json_payload,created_utc,modified_utc)
        VALUES(?,?,?,?,?,?,?,?)
        ON CONFLICT(resource_id) DO UPDATE SET resource_type=excluded.resource_type,name=excluded.name,
        schema_version=excluded.schema_version,resource_version=excluded.resource_version,
        json_payload=excluded.json_payload,modified_utc=excluded.modified_utc""",
        (rid,resource_type,data["name"],data["schema_version"],data["resource_version"],json.dumps(data),now,now))
        self.db.commit(); return rid
    def get(self,rid):
        row=self.db.execute("SELECT resource_type,json_payload FROM resources WHERE resource_id=?",(rid,)).fetchone()
        return None if row is None else (row[0],json.loads(row[1]))
    def search(self,text="",resource_type=None):
        q="SELECT resource_id,resource_type,name,resource_version FROM resources WHERE 1=1"; args=[]
        if text: q+=" AND name LIKE ?"; args.append(f"%{text}%")
        if resource_type: q+=" AND resource_type=?"; args.append(resource_type)
        q+=" ORDER BY name"
        return self.db.execute(q,args).fetchall()
    def relate(self,source_id,relation,target_id):
        self.db.execute("INSERT OR IGNORE INTO relations VALUES(?,?,?)",(source_id,relation,target_id)); self.db.commit()
    def relations(self,source_id):
        return self.db.execute("SELECT relation,target_id FROM relations WHERE source_id=? ORDER BY relation,target_id",(source_id,)).fetchall()
    def close(self): self.db.close()
