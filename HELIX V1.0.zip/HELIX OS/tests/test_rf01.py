import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-RF"
sp=importlib.util.spec_from_file_location("skl_rf",M/"__init__.py",submodule_search_locations=[str(M)])
r=importlib.util.module_from_spec(sp);sys.modules["skl_rf"]=r;sp.loader.exec_module(r)
class T(unittest.TestCase):
 def test_wave(self):self.assertAlmostEqual(r.wavelength_m(r.C),1)
 def test_freq(self):self.assertAlmostEqual(r.frequency_hz(1),r.C)
 def test_db(self):self.assertAlmostEqual(r.linear_to_db(r.db_to_linear(20)),20)
 def test_dbm(self):self.assertAlmostEqual(r.dbm_to_w(30),1)
 def test_w_dbm(self):self.assertAlmostEqual(r.w_to_dbm(1),30)
 def test_fspl_identity(self):self.assertAlmostEqual(r.free_space_path_loss_linear(1,r.C),(4*math.pi)**2)
 def test_fspl_db(self):self.assertAlmostEqual(r.free_space_path_loss_db(1,r.C),r.linear_to_db((4*math.pi)**2))
 def test_gain(self):self.assertAlmostEqual(r.antenna_gain_linear(1,1,r.C),math.pi**2)
 def test_friis(self):
  self.assertAlmostEqual(r.friis_received_power_w(1,1,1,1,r.C),1/(4*math.pi)**2)
 def test_noise(self):self.assertAlmostEqual(r.thermal_noise_power_w(300,1e6),r.K_B*300e6)
 def test_snr(self):self.assertEqual(r.snr_linear(10,2),5)
 def test_shannon(self):self.assertEqual(r.shannon_capacity_bps(1,1),1)
 def test_link_report(self):
  x=r.RFLink(1e9,1000,10,10,10,.8,290,1e6);d=x.report();self.assertEqual(d["evidence"],"SIMULATION");self.assertGreater(d["shannon_capacity_bps"],0)
 def test_invalid_freq(self):
  with self.assertRaises(ValueError):r.wavelength_m(0)
 def test_invalid_link(self):
  with self.assertRaises(ValueError):r.RFLink(1e9,-1,1,1,1,1,290,1)
 def test_registry(self):self.assertEqual(len(r.RFRegistry().all()),7)
 def test_registry_ids(self):self.assertTrue({"RF-FSPL","RF-FRIIS","RF-NOISE-KTB","RF-SHANNON"}<={x.model_id for x in r.RFRegistry().all()})
 def test_schema(self):self.assertEqual(json.loads((R/"core/resources/schemas/rf-link.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-RF-01");self.assertEqual(x["status"],"RF-01 of 8")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-HQIC"])
 def test_hqic_complete(self):self.assertEqual(json.loads((R/"HQIC_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
