import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ISN"
sp=importlib.util.spec_from_file_location("skl_isn",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_isn"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def edge(self,a,b,d,r=100,av=1,p=0):return q.GalacticEdge(a,b,d,r,av,p)
 def test_cost_distance(self):self.assertEqual(q.edge_cost(self.edge("A","B",5)),5)
 def test_cost_reliability(self):self.assertGreater(q.edge_cost(self.edge("A","B",1,100,.5),0,0,1),0)
 def test_path_distance(self):self.assertEqual(q.path_distance_ly([self.edge("A","B",2),self.edge("B","C",3)]),5)
 def test_capacity(self):self.assertEqual(q.path_capacity_bps([self.edge("A","B",2,100),self.edge("B","C",3,20)]),20)
 def test_availability(self):self.assertAlmostEqual(q.path_availability([self.edge("A","B",1,100,.9),self.edge("B","C",1,100,.8)]),.72)
 def test_processing(self):self.assertEqual(q.path_processing_delay_s([self.edge("A","B",1,100,1,2),self.edge("B","C",1,100,1,3)]),2)
 def test_generations(self):self.assertEqual(q.propagation_generations(100,25),4)
 def test_density(self):self.assertEqual(q.infrastructure_linear_density(100,50),2)
 def test_degree(self):self.assertEqual(q.average_node_degree(10,20),4)
 def test_connected(self):
  n=q.GalacticNetwork(["A","B","C"]);n.add_edge(self.edge("A","B",1));n.add_edge(self.edge("B","C",1));self.assertTrue(n.is_connected())
 def test_disconnected(self):
  n=q.GalacticNetwork(["A","B","C"]);n.add_edge(self.edge("A","B",1));self.assertFalse(n.is_connected())
 def test_route_latency(self):
  n=q.GalacticNetwork(["A","B","C"]);n.add_edge(self.edge("A","B",1));n.add_edge(self.edge("B","C",1));n.add_edge(self.edge("A","C",5))
  self.assertEqual(len(n.route("A","C")),2)
 def test_failed_node(self):
  n=q.GalacticNetwork(["A","B","C"]);n.add_edge(self.edge("A","B",1));n.add_edge(self.edge("B","C",1));n.add_edge(self.edge("A","C",5))
  self.assertEqual(len(n.route("A","C",failed_nodes=["B"])),1)
 def test_disjoint(self):
  n=q.GalacticNetwork(["A","B","C","D"]);n.add_edge(self.edge("A","B",1));n.add_edge(self.edge("B","D",1));n.add_edge(self.edge("A","C",2));n.add_edge(self.edge("C","D",2))
  a,b=n.edge_disjoint_alternate("A","D");self.assertEqual(len(a),2);self.assertEqual(len(b),2)
 def test_assessment(self):
  a=q.assess_galactic_path([self.edge("A","B",25,100,.9,1),self.edge("B","C",25,50,.8,2)])
  self.assertEqual(a.hops,2);self.assertEqual(a.distance_ly,50);self.assertEqual(a.capacity_bps,50);self.assertAlmostEqual(a.availability,.72);self.assertEqual(a.generations_at_25y,2)
 def test_pulsar_preserved(self):self.assertEqual(q.minimum_pulsars_for_3d_position_and_clock(),4)
 def test_sgl_preserved(self):self.assertTrue(540<q.minimum_solar_focal_distance_au()<560)
 def test_causality_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ISN-GAL-COST","ISN-GAL-AVAIL","ISN-GAL-DENSITY","ISN-GAL-DEGREE","ISN-GAL-GEN"}<={x.model_id for x in q.InterstellarNetworkRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-ISN-06")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
