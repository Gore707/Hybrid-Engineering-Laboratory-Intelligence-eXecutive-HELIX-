import unittest,importlib.util,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-MAT"
spec=importlib.util.spec_from_file_location("skl_mat",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
pkg=importlib.util.module_from_spec(spec);sys.modules["skl_mat"]=pkg;spec.loader.exec_module(pkg)
class MAT05(unittest.TestCase):
 def ds(self,id,y=(10.,20.),unc=(1.,2.)):
  return pkg.PropertyDataset(id,"M","k","temperature_k","K","W/(m K)",(300.,400.),tuple(y),("SRC",),"DEMONSTRATED_TECH",tuple(unc))
 def test_valid_dataset(self):self.assertTrue(pkg.MaterialValidator().validate_dataset(self.ds("D")).passed)
 def test_unsorted_dataset_fails(self):
  d=pkg.PropertyDataset("D","M","k","temperature_k","K","W/(m K)",(400.,300.),(1.,2.),("SRC",),"DEMONSTRATED_TECH")
  self.assertFalse(pkg.MaterialValidator().validate_dataset(d).passed)
 def test_residuals(self):
  r=pkg.MaterialValidator().compare_reference(self.ds("C",(11,18)),self.ds("R"))
  self.assertEqual(r["residuals"],((300.0,1.0),(400.0,-2.0)));self.assertGreater(r["rmse"],0)
 def test_chi_square(self):
  r=pkg.MaterialValidator().chi_square(self.ds("C",(11,18)),self.ds("R"));self.assertAlmostEqual(r["chi_square"],2.0)
 def test_chi_requires_uncertainty(self):
  with self.assertRaises(ValueError):pkg.MaterialValidator().chi_square(self.ds("C"),self.ds("R",unc=()))
 def test_material_duplicate_detection(self):
  c=pkg.PropertyCondition(temperature_k=300);p=pkg.PropertyValue("k",1,"x",c,source_ids=("S",))
  m=pkg.MaterialRecord("M","M","X",pkg.MaterialPhase.SOLID,properties=(p,p),source_ids=("S",))
  self.assertFalse(pkg.MaterialValidator().validate_material(m).passed)
 def test_curve_integrity(self):
  c=pkg.PropertyCurve([pkg.Sample(300,10),pkg.Sample(400,20)],"temperature_k","W/(m K)")
  r=pkg.check_property_curve_against_dataset(c,self.ds("D"));self.assertTrue(r["passed"]);self.assertEqual(r["comparisons"][0]["residual"],0)
 def test_manifest(self):
  m=json.loads((MOD/"module.json").read_text());self.assertEqual(m["patch_id"],"SKL-MAT-05");self.assertIn("materials.validation",m["capabilities"])
 def test_core_manifest_root(self):self.assertTrue((ROOT/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
