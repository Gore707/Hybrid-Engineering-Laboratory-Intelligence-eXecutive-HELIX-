from __future__ import annotations
from pathlib import Path

from .models import ActionDefinition, ParameterSpec, ConfirmationLevel
from .registry import ActionRegistry

def register_core_actions(registry: ActionRegistry, window) -> None:
    def project_save(params, ctx):
        if not window.current_project or not window.current_project_path:
            raise ValueError("No active project.")
        window.project_manager.save_project(window.current_project_path, window.current_project)
        window.session.dirty = False
        window.session_manager.save(window.session)
        return {
            "project_id": window.current_project.project_id,
            "path": str(window.current_project_path)
        }

    def workspace_save(params, ctx):
        name = params["name"].strip()
        if not name:
            raise ValueError("Layout name cannot be empty.")
        window.workspace.save_layout(name)
        return {"layout": name}

    def workspace_restore(params, ctx):
        name = params["name"]
        if not window.workspace.restore_layout(name):
            raise ValueError(f"Workspace layout not found or invalid: {name}")
        return {"layout": name}

    def workspace_reset(params, ctx):
        window.reset_default_workspace()
        return {"layout": "Scientific Default"}

    def session_checkpoint(params, ctx):
        path = window.session_manager.checkpoint(window.session)
        return {"checkpoint": str(path)}

    registry.register(ActionDefinition(
        "project.save", "Save Project",
        "Persist the active HELIX project and session state.",
        project_save, category="Project"
    ))
    registry.register(ActionDefinition(
        "workspace.save", "Save Workspace Layout",
        "Persist the current dock/window layout.",
        workspace_save,
        parameters=(ParameterSpec("name", str),),
        category="Workspace"
    ))
    registry.register(ActionDefinition(
        "workspace.restore", "Restore Workspace Layout",
        "Restore a named dock/window layout.",
        workspace_restore,
        parameters=(ParameterSpec("name", str),),
        category="Workspace"
    ))
    registry.register(ActionDefinition(
        "workspace.reset", "Reset Workspace",
        "Restore the deterministic Scientific Default workspace.",
        workspace_reset, category="Workspace"
    ))
    registry.register(ActionDefinition(
        "session.checkpoint", "Create Recovery Checkpoint",
        "Write an immediate recovery-session checkpoint.",
        session_checkpoint, category="Session"
    ))
