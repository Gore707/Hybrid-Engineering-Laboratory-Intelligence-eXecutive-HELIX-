from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import K_B,db_to_linear,linear_to_db,dbm_to_w,w_to_dbm

T0_K=290.0

def noise_factor_from_db(noise_figure_db):
    if noise_figure_db<0: raise ValueError("noise figure must be nonnegative")
    return db_to_linear(noise_figure_db)

def noise_figure_db_from_factor(noise_factor):
    if noise_factor<1: raise ValueError("noise factor must be >= 1")
    return linear_to_db(noise_factor)

def equivalent_noise_temperature_k(noise_factor,reference_temperature_k=T0_K):
    if noise_factor<1 or reference_temperature_k<0: raise ValueError("invalid noise inputs")
    return (noise_factor-1)*reference_temperature_k

def cascaded_noise_factor(stages):
    stages=tuple(stages)
    if not stages: raise ValueError("stages required")
    total=stages[0].noise_factor
    gain_product=stages[0].gain_linear
    for s in stages[1:]:
        if gain_product<=0: raise ValueError("preceding gain must be positive")
        total+=(s.noise_factor-1)/gain_product
        gain_product*=s.gain_linear
    return total

def receiver_sensitivity_w(temperature_k,bandwidth_hz,required_snr_linear,noise_factor=1.0):
    if temperature_k<0 or bandwidth_hz<=0 or required_snr_linear<0 or noise_factor<1: raise ValueError("invalid sensitivity inputs")
    return K_B*temperature_k*bandwidth_hz*required_snr_linear*noise_factor

def receiver_sensitivity_dbm(*args,**kwargs): return w_to_dbm(receiver_sensitivity_w(*args,**kwargs))

def spurious_free_dynamic_range_db(iip3_dbm,noise_floor_dbm_hz,bandwidth_hz):
    if bandwidth_hz<=0: raise ValueError("bandwidth must be positive")
    noise_dbm=noise_floor_dbm_hz+10*math.log10(bandwidth_hz)
    return (2/3)*(iip3_dbm-noise_dbm)

def mixer_output_frequency_hz(rf_hz,lo_hz,high_side=False):
    if rf_hz<0 or lo_hz<0: raise ValueError("frequencies nonnegative")
    return rf_hz+lo_hz if high_side else abs(rf_hz-lo_hz)

def ideal_filter_noise_bandwidth_hz(low_hz,high_hz):
    if low_hz<0 or high_hz<=low_hz: raise ValueError("invalid filter edges")
    return high_hz-low_hz

def adc_quantization_snr_db(bits):
    if bits<1 or int(bits)!=bits: raise ValueError("positive integer bits required")
    return 6.02*bits+1.76

def adc_nyquist_rate_hz(signal_bandwidth_hz):
    if signal_bandwidth_hz<0: raise ValueError("bandwidth nonnegative")
    return 2*signal_bandwidth_hz

def oscillator_phase_error_rms_rad(phase_noise_variance_rad2):
    if phase_noise_variance_rad2<0: raise ValueError("variance nonnegative")
    return math.sqrt(phase_noise_variance_rad2)

def dc_power_for_rf_output_w(rf_output_w,drain_efficiency):
    if rf_output_w<0 or not 0<drain_efficiency<=1: raise ValueError("invalid power/efficiency")
    return rf_output_w/drain_efficiency

@dataclass(frozen=True)
class RFStage:
    name:str
    gain_linear:float
    noise_factor:float=1.0
    p1db_output_dbm:float|None=None
    def __post_init__(self):
        if not self.name or self.gain_linear<=0 or self.noise_factor<1: raise ValueError("invalid RF stage")

@dataclass(frozen=True)
class ReceiverChain:
    stages:tuple[RFStage,...]
    temperature_k:float
    bandwidth_hz:float
    required_snr_linear:float
    def __post_init__(self):
        if not self.stages or self.temperature_k<0 or self.bandwidth_hz<=0 or self.required_snr_linear<0: raise ValueError("invalid receiver chain")
    @property
    def total_gain_linear(self):
        return math.prod(s.gain_linear for s in self.stages)
    @property
    def noise_factor(self): return cascaded_noise_factor(self.stages)
    @property
    def noise_figure_db(self): return noise_figure_db_from_factor(self.noise_factor)
    @property
    def sensitivity_w(self): return receiver_sensitivity_w(self.temperature_k,self.bandwidth_hz,self.required_snr_linear,self.noise_factor)
    @property
    def sensitivity_dbm(self): return w_to_dbm(self.sensitivity_w)

@dataclass(frozen=True)
class TransmitterChain:
    requested_rf_output_w:float
    pa_drain_efficiency:float
    feeder_efficiency:float=1.0
    def __post_init__(self):
        if self.requested_rf_output_w<0 or not 0<self.pa_drain_efficiency<=1 or not 0<=self.feeder_efficiency<=1: raise ValueError("invalid transmitter")
    @property
    def dc_input_w(self): return dc_power_for_rf_output_w(self.requested_rf_output_w,self.pa_drain_efficiency)
    @property
    def antenna_input_w(self): return self.requested_rf_output_w*self.feeder_efficiency
    @property
    def waste_heat_w(self): return self.dc_input_w-self.requested_rf_output_w
