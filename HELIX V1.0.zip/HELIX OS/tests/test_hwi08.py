import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HWI"
sp=importlib.util.spec_from_file_location("skl_hwi",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_hwi"]=q;sp.loader.exec_module(q)
class Inst:
 def __init__(self,d,state=None,cal=None):
  self.identity=q.HardwareIdentity(d,"SKL","Test");self.connection_state=state or q.ConnectionState.CONNECTED;self.calibration_state=cal or q.CalibrationState.VALID
class Reg:
 def __init__(self,*xs):self.x={i.identity.device_id:i for i in xs}
 def get(self,d):
  if d not in self.x:raise KeyError(d)
  return self.x[d]
def orch(inst=None,**kw):
 i=inst or Inst("D1");return q.HardwareExperimentOrchestrator("E","R",(q.InstrumentBinding("meter","D1"),),Reg(i),**kw)
class T(unittest.TestCase):
 def test_preflight_ready(self):self.assertTrue(orch().preflight(0).ready)
 def test_missing_device(self):
  o=q.HardwareExperimentOrchestrator("E","R",(q.InstrumentBinding("meter","D1"),),Reg());self.assertFalse(o.preflight(0).ready)
 def test_disconnected(self):self.assertFalse(orch(Inst("D1",q.ConnectionState.DISCONNECTED)).preflight(0).ready)
 def test_expired_cal(self):self.assertFalse(orch(Inst("D1",cal=q.CalibrationState.EXPIRED)).preflight(0).ready)
 def test_interlock(self):
  o=orch(interlocks=(q.Interlock("door","door",q.InterlockState.TRIPPED),));self.assertFalse(o.preflight(0).ready)
 def test_envelope(self):
  e={("D1","T"):q.OperatingEnvelope("T","K",270,330,250,350)}
  self.assertFalse(orch(envelopes=e).preflight(0,current_values={("D1","T"):360}).ready)
 def test_start_requires_preflight(self):
  with self.assertRaises(PermissionError):orch().start(0)
 def test_lifecycle(self):
  o=orch();o.preflight(0);o.start(1);o.complete(2);self.assertEqual(o.record().state,q.ExperimentRunState.COMPLETED)
 def test_timeline(self):
  o=orch();o.preflight(0);o.start(1);t=q.ExperimentTimeline((q.SequenceStep("s",.5,"read","D1"),))
  h=o.execute_timeline(t,1,{"read":lambda s:"ok"});self.assertEqual(h[0][0],1.5)
 def test_changed_interlock_blocks(self):
  i=q.Interlock("door","door");o=orch(interlocks=(i,));o.preflight(0);o.start(1);o.interlocks=(q.Interlock("door","door",q.InterlockState.TRIPPED),)
  with self.assertRaises(PermissionError):o.execute_timeline(q.ExperimentTimeline(()),1,{})
 def test_attach_manifest(self):
  o=orch();o.attach_acquisition_manifest("data/E/R/c1.h5.json");self.assertEqual(o.record().acquisition_manifest_refs,("data/E/R/c1.h5.json",))
 def test_abort(self):
  o=orch();o.abort(2,"operator abort");self.assertEqual(o.record().failure_reason,"operator abort")
 def test_hardware_provenance(self):self.assertEqual(orch().record().provenance_sources,("HARDWARE",))
 def test_safety_preserved(self):self.assertFalse(q.guardian_can_override_safety())
 def test_acquisition_preserved(self):self.assertTrue(hasattr(q,"AcquisitionSession"))
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/hardware_experiment_record.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HWI-08")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
