import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-STO";sp=importlib.util.spec_from_file_location("skl_sto",M/"__init__.py",submodule_search_locations=[str(M)]);s=importlib.util.module_from_spec(sp);sys.modules["skl_sto"]=s;sp.loader.exec_module(s)
class T(unittest.TestCase):
 def layout(self):return s.FiveDLayout(.001,.001,.001,s.VoxelPitch(1e-4,1e-4,2e-4),s.FiveDEncoding(4,4))
 def test_encoding(self):self.assertEqual(s.FiveDEncoding(4,4).bits_per_voxel_ideal,4);self.assertEqual(s.FiveDEncoding(3,3).integer_payload_bits_per_voxel,3)
 def test_counts(self):
  l=self.layout();self.assertEqual((l.nx,l.ny,l.nz),(10,10,5));self.assertEqual(l.voxel_count,500)
 def test_capacity(self):
  c=self.layout().capacity(.1);self.assertEqual(c.raw_bits,2000);self.assertEqual(c.usable_bits,1800)
 def test_address(self):
  l=self.layout();a=s.VoxelAddress(0,0,0,1,2);self.assertTrue(s.validate_address(l,a));self.assertFalse(s.validate_address(l,s.VoxelAddress(99,0,0,0,0)))
 def test_position(self):self.assertAlmostEqual(s.voxel_position(self.layout(),s.VoxelAddress(0,0,0,0,0))[0],5e-5)
 def test_retardance(self):self.assertAlmostEqual(s.retardance_from_birefringence(.01,50e-6,1e-6),math.pi)
 def test_analyzer(self):self.assertAlmostEqual(s.analyzer_intensity_normalized(math.pi,0),1);self.assertAlmostEqual(s.analyzer_intensity_normalized(math.pi,math.pi/4),0,places=12)
 def test_write_energy(self):self.assertAlmostEqual(s.write_energy_j(1e-6,10,100),1e-3)
 def test_registry(self):self.assertEqual(s.StorageRegistry().get("STO-5D-BITS").evidence_class,"ESTABLISHED_PHYSICS")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-STO-02")
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
