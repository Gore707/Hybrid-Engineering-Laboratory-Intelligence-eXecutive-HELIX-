from __future__ import annotations
from dataclasses import dataclass
import math
@dataclass(frozen=True)
class Ray:
 height_m:float;angle_rad:float
 def __post_init__(self):
  if not math.isfinite(self.height_m) or not math.isfinite(self.angle_rad):raise ValueError("ray values must be finite")
@dataclass(frozen=True)
class ABCD:
 A:float;B:float;C:float;D:float
 def apply(self,ray):
  return Ray(self.A*ray.height_m+self.B*ray.angle_rad,self.C*ray.height_m+self.D*ray.angle_rad)
 def __matmul__(self,other):
  return ABCD(self.A*other.A+self.B*other.C,self.A*other.B+self.B*other.D,
              self.C*other.A+self.D*other.C,self.C*other.B+self.D*other.D)
 @property
 def determinant(self):return self.A*self.D-self.B*self.C
def free_space(distance_m):
 if not math.isfinite(distance_m):raise ValueError("distance must be finite")
 return ABCD(1,distance_m,0,1)
def thin_lens(focal_length_m):
 if focal_length_m==0 or not math.isfinite(focal_length_m):raise ValueError("focal length must be finite and nonzero")
 return ABCD(1,0,-1/focal_length_m,1)
def spherical_mirror(radius_m):
 if radius_m==0 or not math.isfinite(radius_m):raise ValueError("radius must be finite and nonzero")
 return ABCD(1,0,-2/radius_m,1)
def planar_refraction(n1,n2):
 if n1<=0 or n2<=0:raise ValueError("indices must be positive")
 return ABCD(1,0,0,n1/n2)
def spherical_refraction(n1,n2,radius_m):
 if n1<=0 or n2<=0 or radius_m==0:raise ValueError("invalid refracting surface")
 return ABCD(1,0,(n1-n2)/(radius_m*n2),n1/n2)
def system_matrix(elements):
 M=ABCD(1,0,0,1)
 for e in elements:M=e@M
 return M
def thin_lens_image_distance(object_distance_m,focal_length_m):
 if object_distance_m<=0 or focal_length_m==0:raise ValueError("invalid imaging distances")
 denom=1/focal_length_m-1/object_distance_m
 return math.inf if abs(denom)<1e-15 else 1/denom
def lateral_magnification(object_distance_m,image_distance_m):
 if object_distance_m==0:raise ValueError("object distance cannot be zero")
 return -image_distance_m/object_distance_m
def lensmaker_thin(n_lens,n_medium,r1_m,r2_m):
 if n_lens<=0 or n_medium<=0:raise ValueError("indices must be positive")
 invr1=0 if math.isinf(r1_m) else 1/r1_m;invr2=0 if math.isinf(r2_m) else 1/r2_m
 power=(n_lens/n_medium-1)*(invr1-invr2)
 return math.inf if abs(power)<1e-30 else 1/power
def trace(ray,elements):
 states=[ray];r=ray
 for e in elements:r=e.apply(r);states.append(r)
 return tuple(states)
