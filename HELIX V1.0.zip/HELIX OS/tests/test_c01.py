import json
import tempfile
import unittest
from pathlib import Path

from core.bootstrap.config import ConfigError, load_config
from core.bootstrap.preflight import verify_directory

ROOT = Path(__file__).resolve().parents[1]

class C01Tests(unittest.TestCase):
    def test_config_loads(self):
        cfg = load_config(ROOT / "skl.config")
        self.assertEqual(cfg["core"]["patch"], "SKL-CORE-C01")
        self.assertEqual(cfg["application"]["name"], "HELIX")

    def test_required_root_paths_are_declared(self):
        cfg = load_config(ROOT / "skl.config")
        self.assertEqual(set(cfg["paths"]), {"modules", "data", "projects", "user"})

    def test_write_preflight(self):
        with tempfile.TemporaryDirectory() as td:
            result = verify_directory(Path(td) / "probe")
            self.assertTrue(result.passed)

    def test_invalid_config_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "bad.config"
            p.write_text(json.dumps({"schema_version": "1.0"}), encoding="utf-8")
            with self.assertRaises(ConfigError):
                load_config(p)

if __name__ == "__main__":
    unittest.main()
