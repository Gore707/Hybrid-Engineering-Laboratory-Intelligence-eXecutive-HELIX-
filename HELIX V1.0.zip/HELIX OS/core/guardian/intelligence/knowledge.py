from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import sqlite3,re,math
@dataclass(frozen=True)
class KnowledgeItem:
 item_id:str;kind:str;title:str;text:str;source_id:str|None=None;evidence_class:str|None=None
 provenance:str|None=None
class KnowledgeIndex:
 def __init__(self,path:Path):
  self.path=path;path.parent.mkdir(parents=True,exist_ok=True)
  self.db=sqlite3.connect(path);self.db.execute("""CREATE TABLE IF NOT EXISTS knowledge(
   item_id TEXT PRIMARY KEY,kind TEXT NOT NULL,title TEXT NOT NULL,text TEXT NOT NULL,
   source_id TEXT,evidence_class TEXT,provenance TEXT)""");self.db.commit()
 @staticmethod
 def tokens(text):return set(re.findall(r"[A-Za-z0-9_]+",text.lower()))
 def upsert(self,item:KnowledgeItem):
  self.db.execute("""INSERT INTO knowledge VALUES(?,?,?,?,?,?,?) ON CONFLICT(item_id) DO UPDATE SET
   kind=excluded.kind,title=excluded.title,text=excluded.text,source_id=excluded.source_id,
   evidence_class=excluded.evidence_class,provenance=excluded.provenance""",
   (item.item_id,item.kind,item.title,item.text,item.source_id,item.evidence_class,item.provenance));self.db.commit()
 def search(self,query,limit=8):
  q=self.tokens(query)
  if not q:return []
  rows=self.db.execute("SELECT item_id,kind,title,text,source_id,evidence_class,provenance FROM knowledge").fetchall()
  scored=[]
  for r in rows:
   item=KnowledgeItem(*r);t=self.tokens(item.title+" "+item.text)
   overlap=len(q&t)
   if overlap:
    score=overlap/math.sqrt(max(1,len(q))*max(1,len(t)))
    scored.append((score,item))
  scored.sort(key=lambda x:(-x[0],x[1].item_id))
  return scored[:limit]
 def close(self):self.db.close()
