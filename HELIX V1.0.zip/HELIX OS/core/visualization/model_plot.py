from __future__ import annotations
def sweep_model(registry,model_id,parameter,values,fixed_inputs,output):
    xs=[];ys=[]
    for value in values:
        inputs=dict(fixed_inputs);inputs[parameter]=float(value)
        result=registry.evaluate(model_id,**inputs)
        xs.append(float(value));ys.append(float(result[output]))
    return xs,ys
