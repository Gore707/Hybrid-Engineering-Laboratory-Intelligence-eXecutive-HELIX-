import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HQIC"
sp=importlib.util.spec_from_file_location("skl_hqic",M/"__init__.py",submodule_search_locations=[str(M)])
h=importlib.util.module_from_spec(sp);sys.modules["skl_hqic"]=h;sp.loader.exec_module(h)
class T(unittest.TestCase):
 def test_photon_energy(self):self.assertGreater(h.photon_energy_j(1e14),0)
 def test_wave_frequency_roundtrip(self):
  w=1550e-9;self.assertAlmostEqual(h.frequency_to_wavelength_m(h.wavelength_to_frequency_hz(w)),w)
 def test_power_efficiency(self):self.assertEqual(h.power_efficiency(10,5),.5)
 def test_loss(self):self.assertAlmostEqual(h.insertion_loss_db(.5),3.0102999566)
 def test_loss_roundtrip(self):
  e=.37;self.assertAlmostEqual(h.efficiency_from_insertion_loss_db(h.insertion_loss_db(e)),e)
 def test_cascade(self):self.assertAlmostEqual(h.cascaded_efficiency(.8,.5,.9),.36)
 def test_snr(self):self.assertEqual(h.signal_to_noise_ratio(10,2),5)
 def test_input_noise(self):self.assertEqual(h.added_noise_equivalent_input(2,4),.5)
 def test_depolarizing_zero(self):self.assertEqual(h.fidelity_after_depolarizing_noise(.9,0),.9)
 def test_depolarizing_full_qubit(self):self.assertEqual(h.fidelity_after_depolarizing_noise(.9,1,2),.5)
 def chain(self):
  return h.TransductionChain((h.TransducerStage("a",h.SignalDomain.QUANTUM_MICROWAVE,h.SignalDomain.QUANTUM_OPTICAL,.8,.01),
    h.TransducerStage("b",h.SignalDomain.QUANTUM_OPTICAL,h.SignalDomain.OPTICAL,.9,.02)))
 def test_chain_efficiency(self):self.assertAlmostEqual(self.chain().efficiency,.72)
 def test_chain_loss(self):self.assertGreater(self.chain().total_insertion_loss_db,0)
 def test_chain_noise_survival(self):self.assertAlmostEqual(self.chain().survival_against_independent_added_noise,.99*.98)
 def test_chain_fidelity(self):self.assertLess(self.chain().output_fidelity(.99),.99)
 def test_domain_mismatch(self):
  with self.assertRaises(ValueError):h.TransductionChain((h.TransducerStage("a",h.SignalDomain.MICROWAVE,h.SignalDomain.OPTICAL,.8),h.TransducerStage("b",h.SignalDomain.ELECTRICAL,h.SignalDomain.OPTICAL,.9)))
 def test_layering_preserved(self):self.assertAlmostEqual(h.attenuation_transmission(1,1),math.exp(-1))
 def test_capacity_separation_preserved(self):
  with self.assertRaises(ValueError):h.aggregate_capacity_same_domain([h.Capacity(1,h.InformationDomain.CLASSICAL,"bit"),h.Capacity(1,h.InformationDomain.QUANTUM,"qubit")])
 def test_registry(self):self.assertTrue({"HQIC-XDUCE-ETA","HQIC-XDUCE-IL","HQIC-XDUCE-PHOTON","HQIC-XDUCE-NOISE","HQIC-XDUCE-FID"}<={x.model_id for x in h.HQICRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HQIC-03")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO","SKL-QMEM"])
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
