import unittest,tempfile,importlib.util,sys,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-MAT"
spec=importlib.util.spec_from_file_location("skl_mat",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
pkg=importlib.util.module_from_spec(spec);sys.modules["skl_mat"]=pkg;spec.loader.exec_module(pkg)
class MAT06(unittest.TestCase):
 def material(self):
  return pkg.MaterialRecord("MAT-X","Test Glass","SiO2",pkg.MaterialPhase.SOLID,properties=(
   pkg.PropertyValue("density",2200,"kg/m^3",pkg.PropertyCondition(temperature_k=300),10,"DEMONSTRATED_TECH",("SRC-M",)),),source_ids=("SRC-M",))
 def test_full_lab_workflow(self):
  with tempfile.TemporaryDirectory() as td:
   lab=pkg.MaterialsLaboratory(Path(td));lab.research.add_source(pkg.MaterialSource("SRC-M","Reference"))
   comp=pkg.CompositionProfile("MAT-X",pkg.parse_formula("SiO2"));r=lab.register_material(self.material(),comp);self.assertTrue(r.passed)
   ds=pkg.PropertyDataset("DS","MAT-X","density","temperature_k","K","kg/m^3",(300.,),(2200.,),("SRC-M",),"DEMONSTRATED_TECH",(10.,))
   lab.register_dataset(ds);s=lab.summary("MAT-X");self.assertEqual(s["dataset_count"],1);self.assertTrue(s["has_composition"])
 def test_bundle_checksum(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);lab=pkg.MaterialsLaboratory(td);lab.register_material(self.material(),pkg.CompositionProfile("MAT-X",pkg.parse_formula("SiO2")))
   out=td/"bundle.json";lab.export_material_bundle("MAT-X",out);self.assertTrue(lab.verify_bundle(out))
   w=json.loads(out.read_text());w["payload"]["material"]["name"]="tampered";out.write_text(json.dumps(w));self.assertFalse(lab.verify_bundle(out))
 def test_id_mismatch_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   lab=pkg.MaterialsLaboratory(Path(td))
   with self.assertRaises(ValueError):lab.register_material(self.material(),pkg.CompositionProfile("OTHER",pkg.parse_formula("SiO2")))
 def test_invalid_dataset_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   lab=pkg.MaterialsLaboratory(Path(td));d=pkg.PropertyDataset("D","M","p","T","K","x",(2.,1.),(1.,2.),("S",),"DEMONSTRATED_TECH")
   with self.assertRaises(ValueError):lab.register_dataset(d)
 def test_audit_written(self):
  with tempfile.TemporaryDirectory() as td:
   lab=pkg.MaterialsLaboratory(Path(td));lab.register_material(self.material());self.assertIn("REGISTER_MATERIAL",lab.audit.read_text())
 def test_completion_metadata(self):
  d=json.loads((MOD/"MAT_COMPLETE.json").read_text());self.assertEqual(len(d["patches"]),6);self.assertEqual(d["next_module"],"SKL-PHO-01")
 def test_manifest(self):
  d=json.loads((MOD/"module.json").read_text());self.assertEqual(d["patch_id"],"SKL-MAT-06");self.assertIn("COMPLETE",d["status"])
 def test_core_manifest_root(self):self.assertTrue((ROOT/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
