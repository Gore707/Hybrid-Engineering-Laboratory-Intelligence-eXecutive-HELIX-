import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-BND"
sp=importlib.util.spec_from_file_location("skl_bnd",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_bnd"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_interval_timelike(self):self.assertGreater(q.minkowski_interval_m2(1,1),0)
 def test_interval_spacelike(self):self.assertTrue(q.is_spacelike(0,1))
 def test_microcausal(self):self.assertTrue(q.microcausal_commutator_vanishes_for_spacelike_separation(0,1))
 def test_corr_no_signal(self):self.assertFalse(q.spacelike_vacuum_correlation_implies_controllable_signal())
 def test_squeeze_reduces(self):self.assertLess(q.squeezed_quadrature_variance(1,1),1)
 def test_antisqueeze_increases(self):self.assertGreater(q.squeezed_quadrature_variance(1,1,"antisqueezed"),1)
 def test_squeeze_db(self):self.assertGreater(q.squeezing_db(1),0)
 def test_thermal_zero(self):self.assertEqual(q.thermal_occupation(1e9,0),0)
 def test_thermal_positive(self):self.assertGreater(q.thermal_occupation(1e9,300),0)
 def test_loss_identity(self):self.assertEqual(q.bosonic_loss_channel_mean_photons(10,1,5),10)
 def test_loss_env(self):self.assertEqual(q.bosonic_loss_channel_mean_photons(10,0,5),5)
 def test_snr(self):self.assertGreater(q.shot_noise_snr(100,10),0)
 def test_latency(self):self.assertEqual(q.causal_message_latency_s(q.C_M_S),1)
 def test_assessment(self):
  a=q.VacuumChannelAssessment(q.C_M_S,.5,10,2,1);self.assertEqual(a.minimum_causal_latency_s,1);self.assertFalse(a.ftl_information_available)
 def test_dark_photon_preserved(self):self.assertGreaterEqual(q.photon_dark_photon_probability(1e-3,10,1e-3,1),0)
 def test_axion_preserved(self):self.assertGreaterEqual(q.photon_axion_conversion_probability(1e-10,10,10),0)
 def test_registry(self):self.assertTrue({"BND-QFT-INT","BND-QFT-MICRO","BND-QFT-SQ","BND-QFT-LOSS"}<={x.model_id for x in q.default_registry().all()})
 def test_foundation_guard(self):self.assertFalse(q.established_physics_causality_bypass_available())
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-BND-04")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
