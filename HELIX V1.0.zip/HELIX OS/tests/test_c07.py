import os, unittest
from pathlib import Path
os.environ.setdefault("QT_QPA_PLATFORM","offscreen")

from core.bootstrap.identity import IDENTITY
from core.commands import *
from core.guardian.console import GuardianConsoleEngine

ROOT=Path(__file__).resolve().parents[1]

def service():
    r=ActionRegistry()
    r.register(ActionDefinition("workspace.reset","Reset","reset",lambda p,c:{"layout":"Scientific Default"}))
    r.register(ActionDefinition("session.checkpoint","Checkpoint","cp",lambda p,c:{"checkpoint":"x"}))
    r.register(ActionDefinition("test.echo","Echo","echo",lambda p,c:{"value":p["value"]},
        (ParameterSpec("value",str),)))
    return CommandService(r)

class C07Tests(unittest.TestCase):
    def setUp(self):
        self.s=service()
        self.e=GuardianConsoleEngine(
            self.s,lambda:CommandContext("GUARDIAN_CONSOLE","tester"),
            lambda:{"Core":"OK"},lambda:["A"]
        )

    def test_identity(self): self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C07")
    def test_main_menu_has_16_domains(self): self.assertEqual(len(self.e.current.children),16)
    def test_navigation(self):
        self.assertTrue(self.e.handle("12").ok)
        self.assertIn("Workspaces",self.e.breadcrumb)
        self.e.handle("BACK"); self.assertEqual(len(self.e.stack),1)
        self.e.handle("15"); self.e.handle("MAIN"); self.assertEqual(len(self.e.stack),1)
    def test_universal_commands(self):
        for cmd in ("HELP","STATUS","EXPLAIN","LIST","CANCEL"):
            self.assertTrue(self.e.handle(cmd).ok,cmd)
    def test_expert_run(self):
        r=self.e.handle('RUN test.echo value="hello world"')
        self.assertTrue(r.ok); self.assertIn("hello world",r.text)
    def test_unknown_is_real_error(self):
        r=self.e.handle("nonsense")
        self.assertFalse(r.ok); self.assertEqual(r.kind,"ERROR")
    def test_bound_menu_action_executes(self):
        self.e.handle("12")
        r=self.e.handle("C")
        self.assertTrue(r.ok); self.assertIn("COMPLETED",r.text)
    def test_no_fake_ai_claim(self):
        text=(ROOT/"core/guardian/console.py").read_text(encoding="utf-8").lower()
        self.assertIn("natural-language interpretation is intentionally not claimed",text)
    def test_ui_if_available(self):
        try:
            from PySide6.QtWidgets import QApplication
            from core.bootstrap.config import load_config
            from core.ui.main_window import HelixMainWindow
        except ImportError:
            self.skipTest("PySide6 not installed")
        app=QApplication.instance() or QApplication([])
        w=HelixMainWindow(load_config(ROOT/"skl.config"),ROOT)
        self.assertIn("helix.guardian",w.workspace.docks)
        self.assertIsNotNone(w.workspace.docks["helix.guardian"].widget())

if __name__=="__main__":unittest.main()
