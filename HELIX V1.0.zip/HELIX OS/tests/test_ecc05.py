import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ECC"
sp=importlib.util.spec_from_file_location("skl_ecc",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_ecc"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_flux_positive(self):self.assertGreater(q.sinusoidal_gw_energy_flux_w_m2(1e-21,100),0)
 def test_flux_h_squared(self):self.assertAlmostEqual(q.sinusoidal_gw_energy_flux_w_m2(2e-21,100)/q.sinusoidal_gw_energy_flux_w_m2(1e-21,100),4)
 def test_flux_f_squared(self):self.assertAlmostEqual(q.sinusoidal_gw_energy_flux_w_m2(1e-21,200)/q.sinusoidal_gw_energy_flux_w_m2(1e-21,100),4)
 def test_inverse(self):
  h=1e-22;f=100;self.assertAlmostEqual(q.strain_from_energy_flux(q.sinusoidal_gw_energy_flux_w_m2(h,f),f),h)
 def test_quad_inverse_r(self):self.assertAlmostEqual(q.far_field_strain_from_quadrupole_second_derivative(1e40,2e9)/q.far_field_strain_from_quadrupole_second_derivative(1e40,1e9),.5)
 def test_rotating(self):self.assertGreater(q.rotating_quadrupole_strain(1e20,100,1000,1e9),0)
 def test_power(self):self.assertAlmostEqual(q.isotropic_equivalent_power_w(1,2),16*math.pi)
 def test_displacement(self):self.assertAlmostEqual(q.detector_displacement_m(1e-21,4e3),4e-18)
 def test_snr_time(self):self.assertAlmostEqual(q.monochromatic_snr(1e-22,1e-23,100),100)
 def test_integration_inverse(self):self.assertAlmostEqual(q.integration_time_for_snr_s(1e-22,1e-23,10),1)
 def test_symbol_rate(self):self.assertEqual(q.ideal_symbol_rate_from_integration_time(2),.5)
 def test_latency(self):self.assertEqual(q.propagation_time_s(q.C_M_S),1)
 def test_link(self):
  a=q.GravitationalWaveLink(1e-22,100,1e16,1e-23,100,4000);self.assertGreater(a.energy_flux_w_m2,0);self.assertGreater(a.ideal_coherent_snr,0);self.assertAlmostEqual(a.detector_displacement_m,4e-19)
 def test_particle_preserved(self):self.assertLess(q.speed_from_kinetic_energy_j(1e-9,1.67e-27),q.C_M_S)
 def test_hep_preserved(self):self.assertGreater(q.photon_energy_kev_from_wavelength(1e-10),0)
 def test_neutrino_preserved(self):self.assertGreater(q.approximate_cc_cross_section_m2(1),0)
 def test_causality_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ECC-GW-FLUX","ECC-GW-STRAIN","ECC-GW-QUAD","ECC-GW-DISP","ECC-GW-SNR","ECC-GW-POWER"}<={x.model_id for x in q.ExtremeCarrierRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-ECC-05")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
