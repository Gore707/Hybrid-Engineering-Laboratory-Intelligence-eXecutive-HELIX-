from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import C,H,frequency_hz,photon_energy_j_from_wavelength,circular_aperture_gain_linear,received_power_friis_w
from .transmitter import gaussian_divergence_half_angle_rad,rayleigh_range_m
from .receiver import photon_count_rate_per_s,telescope_collection_area_m2
from .pat import gaussian_pointing_coupling,rss_pointing_error_rad
from .atmosphere import transmission_from_optical_depth,optical_depth_from_transmission,fried_parameter_m,seeing_fwhm_rad
from .digital import bits_per_ppm_symbol,packet_error_rate,goodput_bps
from .simulation import IntegratedOpticalScenario,simulate,minimum_transmit_power_for_snr
from .mission import one_way_light_time_s,data_volume_bits,inverse_square_power_scale
from .system_sim import monte_carlo

@dataclass(frozen=True)
class ValidationCheck:
    name:str
    passed:bool
    detail:str

@dataclass(frozen=True)
class ValidationReport:
    checks:tuple[ValidationCheck,...]
    @property
    def passed(self): return all(x.passed for x in self.checks)
    @property
    def passed_count(self): return sum(x.passed for x in self.checks)
    @property
    def total_count(self): return len(self.checks)

def _close(a,b,rtol=1e-9,atol=0.0):
    return math.isclose(a,b,rel_tol=rtol,abs_tol=atol)

def run_cross_engine_validation():
    c=[]
    def add(name,condition,detail): c.append(ValidationCheck(name,bool(condition),detail))
    lam=1550e-9
    f=frequency_hz(lam)
    add("frequency-wavelength",_close(f*lam,C),"fλ=c")
    add("photon-energy",_close(photon_energy_j_from_wavelength(lam),H*f),"E=hν=hc/λ")
    div=gaussian_divergence_half_angle_rad(lam,.05,1.0)
    zr=rayleigh_range_m(lam,.05,1.0)
    add("gaussian-beam",div>0 and zr>0,"positive divergence and Rayleigh range")
    add("receiver-area",_close(telescope_collection_area_m2(2,0),math.pi),"2 m unobscured area = π m²")
    add("pat-zero",_close(gaussian_pointing_coupling(0,1e-6),1),"zero offset has unit coupling")
    add("pat-rss",_close(rss_pointing_error_rad(3,4),5),"RSS invariant")
    T=.73
    add("optical-depth-inverse",_close(transmission_from_optical_depth(optical_depth_from_transmission(T)),T),"T↔τ inversion")
    r0=fried_parameter_m(lam,1e-13)
    add("seeing-positive",seeing_fwhm_rad(lam,r0)>0,"seeing is positive for positive r0")
    add("ppm-order",bits_per_ppm_symbol(16)==4,"16-PPM carries 4 uncoded bits/symbol")
    add("packet-zero",packet_error_rate(0,1024)==0,"zero BER gives zero PER")
    add("goodput-perfect",goodput_bps(1000,0)==1000,"zero PER preserves goodput")
    s=IntegratedOpticalScenario(lam,1e9,.2,1,10,bit_rate_bps=1000,required_snr=5)
    r=simulate(s)
    add("integrated-positive",r.received_power_w>0 and r.detected_signal_photon_rate_per_s>0,"end-to-end received power/photon rate positive")
    r2=simulate(IntegratedOpticalScenario(**{**s.__dict__,"distance_m":2e9}))
    add("inverse-square-link",_close(r.received_power_w/r2.received_power_w,4),"doubling range quarters ideal received power")
    rp=simulate(IntegratedOpticalScenario(**{**s.__dict__,"transmitted_optical_power_w":20}))
    add("linear-power-link",_close(rp.received_power_w/r.received_power_w,2),"received power linear in transmitted power")
    p=minimum_transmit_power_for_snr(s,5)
    rr=simulate(IntegratedOpticalScenario(**{**s.__dict__,"transmitted_optical_power_w":p}))
    add("minimum-power-solver",_close(rr.photon_counting_snr_per_bit,5,rtol=1e-8),"analytical power solver reproduces target SNR")
    add("mission-light-time",_close(one_way_light_time_s(C),1),"distance c·1s gives one second")
    add("mission-volume",data_volume_bits(1000,10,.5)==5000,"goodput×time×duty")
    add("mission-power-scale",inverse_square_power_scale(10,1,2)==40,"power trade follows R²")
    mc=monte_carlo(s,50,seed=42,power_sigma_fraction=0,atmosphere_sigma_fraction=0,distance_sigma_fraction=0,pointing_sigma_rad=0)
    add("monte-carlo-deterministic",_close(mc.std_margin_db,0,atol=1e-12),"zero uncertainty collapses margin distribution")
    gt=circular_aperture_gain_linear(.2,lam,.7);gr=circular_aperture_gain_linear(1,lam,.7)
    direct=received_power_friis_w(10,gt,gr,1e9,lam,.8)
    clean=simulate(IntegratedOpticalScenario(lam,1e9,.2,1,10,optical_train_efficiency=.8,atmospheric_transmission=1,pointing_error_rad=0,beam_half_angle_rad=10e-6,bit_rate_bps=1000))
    add("integrated-friis-consistency",_close(clean.received_power_w,direct),"integrated chain matches direct Friis construction")
    photons=photon_count_rate_per_s(clean.received_power_w,lam,clean.__dict__.get("detector_quantum_efficiency",.7) if False else .7)
    add("receiver-photon-consistency",_close(clean.detected_signal_photon_rate_per_s,photons),"integrated photon rate matches receiver engine")
    return ValidationReport(tuple(c))
