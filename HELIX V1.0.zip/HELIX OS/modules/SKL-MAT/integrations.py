from .property_systems import *
def thermal_to_core_engine(core_thermal_function,props,area_m2,length_m,t_hot_k,t_cold_k,emissivity=0,radiating_area_m2=0,t_environment_k=0):
 return core_thermal_function(props.conductivity_w_mk,area_m2,length_m,t_hot_k,t_cold_k,emissivity,radiating_area_m2,t_environment_k)
def mechanical_to_core_engine(core_mechanical_function,props,load_n,area_m2):
 return core_mechanical_function(load_n,area_m2,props.youngs_modulus_pa,props.yield_strength_pa)
