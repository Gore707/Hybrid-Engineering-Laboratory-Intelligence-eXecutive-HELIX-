import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ISN"
sp=importlib.util.spec_from_file_location("skl_isn",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_isn"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_capacity(self):self.assertEqual(q.hop_delivery_capacity_bps([100,20,50]),20)
 def test_serial(self):self.assertAlmostEqual(q.store_forward_serial_message_time_s(100,[100,50],[1,2],.5),6.5)
 def test_pipeline(self):self.assertEqual(q.pipelined_steady_state_capacity_bps([100,20]),20)
 def test_series_avail(self):self.assertAlmostEqual(q.series_route_availability([.9],[.8,.5]),.36)
 def test_parallel_avail(self):self.assertAlmostEqual(q.parallel_independent_route_availability([.9,.8]),.98)
 def test_retrans(self):self.assertEqual(q.expected_retransmissions(.5),2)
 def test_goodput(self):self.assertEqual(q.effective_goodput_bps(100,.8,.5),40)
 def test_positions(self):self.assertEqual(q.equal_spacing_relay_positions_ly(12,3),(3,6,9))
 def test_power_ratio(self):self.assertEqual(q.direct_vs_relay_power_ratio_inverse_square(10,3),1/16)
 def test_latency_route(self):
  n=q.RelayNetwork(["A","B","C"]);n.add_edge(q.RelayEdge("A","B",10,1));n.add_edge(q.RelayEdge("B","C",10,1));n.add_edge(q.RelayEdge("A","C",100,5))
  self.assertEqual(len(n.shortest_latency_route("A","C")),2)
 def test_widest_route(self):
  n=q.RelayNetwork(["A","B","C"]);n.add_edge(q.RelayEdge("A","B",80,1));n.add_edge(q.RelayEdge("B","C",60,1));n.add_edge(q.RelayEdge("A","C",20,1))
  self.assertEqual(q.hop_delivery_capacity_bps([e.rate_bps for e in n.widest_rate_route("A","C")]),60)
 def test_failed_node_reroute(self):
  n=q.RelayNetwork(["A","B","C"]);n.add_edge(q.RelayEdge("A","B",80,1));n.add_edge(q.RelayEdge("B","C",60,1));n.add_edge(q.RelayEdge("A","C",20,2))
  self.assertEqual(len(n.shortest_latency_route("A","C",["B"])),1)
 def test_assess(self):
  a=q.assess_relay_route([q.RelayEdge("A","B",100,1,.9),q.RelayEdge("B","C",50,2,.8)],.5)
  self.assertEqual(a.hop_count,2);self.assertEqual(a.bottleneck_rate_bps,50);self.assertAlmostEqual(a.route_availability,.72);self.assertAlmostEqual(a.effective_goodput_bps,18)
 def test_optical_preserved(self):self.assertAlmostEqual(q.airy_divergence_rad(1e-6,1),1.22e-6)
 def test_causality_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ISN-RELAY-CAP","ISN-RELAY-SERIAL","ISN-RELAY-AVAIL","ISN-RELAY-REDUND","ISN-RELAY-GOODPUT"}<={x.model_id for x in q.InterstellarNetworkRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-ISN-03")
 def test_dependencies(self):self.assertTrue({"SKL-OPT","SKL-QCOM"}<=set(json.loads((M/"module.json").read_text())["dependencies"]))
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
