from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import BoundaryEvidence,C_M_S

G=6.67430e-11

def schwarzschild_radius_m(mass_kg):
    if mass_kg<0:raise ValueError("mass nonnegative")
    return 2*G*mass_kg/C_M_S**2

def schwarzschild_lapse(mass_kg,radius_m):
    rs=schwarzschild_radius_m(mass_kg)
    if radius_m<=rs:raise ValueError("static Schwarzschild observer requires r > r_s")
    return math.sqrt(1-rs/radius_m)

def proper_time_static_s(coordinate_time_s,mass_kg,radius_m):
    if coordinate_time_s<0:raise ValueError("time nonnegative")
    return coordinate_time_s*schwarzschild_lapse(mass_kg,radius_m)

def gravitational_frequency_ratio_static(mass_kg,r_emit_m,r_receive_m):
    """nu_receive/nu_emit = lapse(emit)/lapse(receive)."""
    return schwarzschild_lapse(mass_kg,r_emit_m)/schwarzschild_lapse(mass_kg,r_receive_m)

def gravitational_redshift_z(mass_kg,r_emit_m,r_receive_m):
    ratio=gravitational_frequency_ratio_static(mass_kg,r_emit_m,r_receive_m)
    return 1/ratio-1

def weak_field_shapiro_delay_s(mass_kg,r1_m,r2_m,impact_parameter_m):
    """One-way leading logarithmic weak-field delay ~2GM/c^3 ln(4 r1 r2/b^2)."""
    if mass_kg<0 or r1_m<=0 or r2_m<=0 or impact_parameter_m<=0:raise ValueError("positive geometry")
    arg=4*r1_m*r2_m/(impact_parameter_m**2)
    if arg<=1:raise ValueError("weak-field log geometry requires argument > 1")
    return 2*G*mass_kg/C_M_S**3*math.log(arg)

def flat_light_time_s(distance_m):
    if distance_m<0:raise ValueError("distance nonnegative")
    return distance_m/C_M_S

def curved_link_coordinate_time_s(flat_path_length_m,extra_gravitational_delay_s):
    if extra_gravitational_delay_s<0:raise ValueError("delay nonnegative")
    return flat_light_time_s(flat_path_length_m)+extra_gravitational_delay_s

def outside_schwarzschild_horizon(mass_kg,radius_m):
    return radius_m>schwarzschild_radius_m(mass_kg)

def static_escape_signal_possible(mass_kg,radius_m):
    """For this simplified Schwarzschild exterior model, a static source must be outside r_s."""
    return outside_schwarzschild_horizon(mass_kg,radius_m)

def curved_spacetime_ftl_information_available():
    return False

@dataclass(frozen=True)
class SchwarzschildCommunicationLink:
    central_mass_kg:float
    emitter_radius_m:float
    receiver_radius_m:float
    geometric_path_length_m:float
    shapiro_impact_parameter_m:float|None=None
    evidence:BoundaryEvidence=BoundaryEvidence.ESTABLISHED_PHYSICS
    def __post_init__(self):
        if self.central_mass_kg<0 or self.geometric_path_length_m<0:raise ValueError("invalid link")
        if not outside_schwarzschild_horizon(self.central_mass_kg,self.emitter_radius_m):raise ValueError("emitter must be outside Schwarzschild radius")
        if not outside_schwarzschild_horizon(self.central_mass_kg,self.receiver_radius_m):raise ValueError("receiver must be outside Schwarzschild radius")
    @property
    def frequency_ratio(self):return gravitational_frequency_ratio_static(self.central_mass_kg,self.emitter_radius_m,self.receiver_radius_m)
    @property
    def flat_latency_s(self):return flat_light_time_s(self.geometric_path_length_m)
    @property
    def shapiro_delay_s(self):
        if self.shapiro_impact_parameter_m is None:return 0.0
        return weak_field_shapiro_delay_s(self.central_mass_kg,self.emitter_radius_m,self.receiver_radius_m,self.shapiro_impact_parameter_m)
    @property
    def coordinate_latency_s(self):return self.flat_latency_s+self.shapiro_delay_s
    @property
    def ftl_information_available(self):return False
