from dataclasses import dataclass
from .engines import ClassicalCapacity,QuantumCapacity
@dataclass(frozen=True)
class HybridInformationCapacity:
 classical:ClassicalCapacity;quantum:QuantumCapacity
 def __add__(self,other):raise TypeError("Classical byte capacity and quantum-state capacity are not additive.")
 def summary(self):
  return {"classical_usable_bytes":self.classical.usable_bytes,"quantum_physical_modes":self.quantum.physical_modes,
   "quantum_interface_efficiency":self.quantum.interface_efficiency,"quantum_fidelity":self.quantum.fidelity,
   "quantum_coherence_seconds":self.quantum.coherence_seconds}
