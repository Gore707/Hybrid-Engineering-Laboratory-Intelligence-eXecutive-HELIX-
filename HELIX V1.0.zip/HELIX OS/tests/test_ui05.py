import unittest,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];W=(R/"core/ui/scientific_widgets.py").read_text();M=(R/"core/ui/main_window.py").read_text();T=(R/"core/ui/theme.py").read_text()
class X(unittest.TestCase):
 def test_provenance_states(self):
  for x in ("HARDWARE","IMPORTED","SIMULATION","SOFTWARE","EXTRAPOLATED","SPECULATIVE","NEW PHYSICS"):self.assertIn(x,W)
 def test_measurement(self):self.assertIn("class MeasurementCard",W);self.assertIn("Uncertainty:",W);self.assertIn("Source:",W)
 def test_figure(self):self.assertIn("class ScientificFigureFrame",W);self.assertIn("Model / Equation:",W)
 def test_status_zones(self):
  for x in ("StatusExperiment","StatusSystem","StatusEnvironment"):self.assertIn(x,M)
 def test_real_status_sources(self):self.assertIn("self.current_experiment.name",M);self.assertIn("len(self.bus.registered_topics())",M);self.assertIn("IDENTITY.core_version",M)
 def test_no_fake_cpu(self):self.assertNotIn("CPU 7%",M);self.assertNotIn("GPU AMD",M)
 def test_theme(self):self.assertIn('QLabel#ProvenanceBadge[provenance="HARDWARE"]',T);self.assertIn("QFrame#ScientificFigure",T)
 def test_markers(self):
  for n in range(1,6):self.assertTrue((R/f"UI_{n:02d}_COMPLETE.json").exists())
  self.assertEqual(json.loads((R/"UI_05_COMPLETE.json").read_text())["sequence"],"5/6")
 def test_backend(self):self.assertEqual(json.loads((R/"HELIX_136_COMPLETE.json").read_text())["patches_completed"],136)
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
