import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-OPT"
sp=importlib.util.spec_from_file_location("skl_opt",M/"__init__.py",submodule_search_locations=[str(M)])
o=importlib.util.module_from_spec(sp);sys.modules["skl_opt"]=o;sp.loader.exec_module(o)
class T(unittest.TestCase):
 def test_area(self):self.assertAlmostEqual(o.telescope_collection_area_m2(2),math.pi)
 def test_obscuration(self):self.assertLess(o.telescope_collection_area_m2(2,.5),math.pi)
 def test_responsivity(self):self.assertGreater(o.photodiode_responsivity_a_per_w(1550e-9,.8),0)
 def test_photocurrent(self):self.assertEqual(o.photocurrent_a(2,3),6)
 def test_shot_zero(self):self.assertEqual(o.shot_noise_current_rms_a(0,1),0)
 def test_shot(self):self.assertGreater(o.shot_noise_current_rms_a(1e-6,1e6),0)
 def test_thermal(self):self.assertGreater(o.thermal_noise_current_rms_a(290,1e6,50),0)
 def test_count_rate(self):self.assertGreater(o.photon_count_rate_per_s(1e-12,1e-6,.5),0)
 def test_total_rate(self):self.assertEqual(o.total_count_rate_per_s(1,2,3),6)
 def test_count_snr_clean(self):self.assertEqual(o.photon_counting_snr(100,0,0,1),10)
 def test_background_hurts(self):self.assertLess(o.photon_counting_snr(100,0,100,1),10)
 def test_nep(self):self.assertEqual(o.noise_equivalent_power_w_per_sqrt_hz(2,4),.5)
 def test_apd_unity(self):self.assertEqual(o.apd_excess_noise_factor(1,.5),1)
 def test_apd_signal(self):self.assertAlmostEqual(o.apd_signal_current_a(1e-6,10),1e-5)
 def test_sensitivity_clean(self):
  p=o.minimum_power_for_photon_count_snr_w(10,1e-6,1,1);rate=o.photon_count_rate_per_s(p,1e-6,1);self.assertAlmostEqual(rate,100)
 def test_sensitivity_background(self):self.assertGreater(o.minimum_power_for_photon_count_snr_w(10,1e-6,1,1,0,100),o.minimum_power_for_photon_count_snr_w(10,1e-6,1,1))
 def test_receiver(self):
  r=o.PhotonCountingReceiver(1550e-9,.7,10,20,1,1,.2,.8);self.assertGreater(r.collection_area_m2,0);self.assertGreater(r.snr(1e-12),0)
 def test_receiver_sensitivity(self):
  r=o.PhotonCountingReceiver(1e-6,.8,1,1,1,1,0,.5);p=r.sensitivity_w(5);self.assertAlmostEqual(r.snr(p),5,places=10)
 def test_zero_optical_eff(self):self.assertTrue(math.isinf(o.PhotonCountingReceiver(1e-6,.8,0,0,1,1,0,0).sensitivity_w(5)))
 def test_invalid(self):
  with self.assertRaises(ValueError):o.photodiode_responsivity_a_per_w(1e-6,1.1)
 def test_transmitter_preserved(self):self.assertGreater(o.rayleigh_range_m(1e-6,1),0)
 def test_foundation_preserved(self):self.assertAlmostEqual(o.frequency_hz(1),o.C)
 def test_registry(self):self.assertTrue({"OPT-RX-AREA","OPT-RESP","OPT-SHOT-I","OPT-COUNT-SNR","OPT-NEP","OPT-RX-SENS"}<={x.model_id for x in o.OpticalRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-OPT-03")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-RF"])
 def test_rf_complete(self):self.assertEqual(json.loads((R/"RF_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
