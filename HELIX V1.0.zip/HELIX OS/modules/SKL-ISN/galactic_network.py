from __future__ import annotations
from dataclasses import dataclass
import math,heapq

@dataclass(frozen=True)
class GalacticEdge:
    source:str
    target:str
    distance_ly:float
    capacity_bps:float
    availability:float=1.0
    processing_delay_s:float=0.0
    enabled:bool=True
    def __post_init__(self):
        if not self.source or not self.target or self.source==self.target or self.distance_ly<0 or self.capacity_bps<=0 or not 0<self.availability<=1 or self.processing_delay_s<0:
            raise ValueError("invalid edge")

def edge_cost(edge,latency_weight=1.0,capacity_weight=0.0,reliability_weight=0.0):
    if min(latency_weight,capacity_weight,reliability_weight)<0:raise ValueError("weights nonnegative")
    # Dimensionless planning score; user-selected weights define normalization preference.
    return latency_weight*edge.distance_ly + capacity_weight/edge.capacity_bps + reliability_weight*(-math.log(edge.availability))

def path_distance_ly(edges):return sum(e.distance_ly for e in edges)
def path_capacity_bps(edges):return min((e.capacity_bps for e in edges),default=0.0)
def path_availability(edges):
    if not edges:return 0.0
    p=1.0
    for e in edges:p*=e.availability
    return p
def path_processing_delay_s(edges):return sum(e.processing_delay_s for e in edges[:-1]) if edges else 0.0
def propagation_generations(distance_ly,generation_years):
    if distance_ly<0 or generation_years<=0:raise ValueError("invalid inputs")
    return distance_ly/generation_years

def infrastructure_linear_density(nodes,total_route_length_ly):
    if nodes<0 or int(nodes)!=nodes or total_route_length_ly<=0:raise ValueError("invalid inputs")
    return int(nodes)/total_route_length_ly

def average_node_degree(node_count,edge_count):
    if node_count<=0 or int(node_count)!=node_count or edge_count<0 or int(edge_count)!=edge_count:raise ValueError("invalid graph")
    return 2*int(edge_count)/int(node_count)

class GalacticNetwork:
    def __init__(self,nodes=()):
        self.nodes=set(nodes);self.edges=[]
    def add_node(self,node):self.nodes.add(node)
    def add_edge(self,e:GalacticEdge):
        if e.source not in self.nodes or e.target not in self.nodes:raise ValueError("unknown node")
        self.edges.append(e)
    def adjacency(self,failed_nodes=(),failed_edges=()):
        failed_nodes=set(failed_nodes);failed_edges=set(failed_edges)
        a={n:[] for n in self.nodes if n not in failed_nodes}
        for idx,e in enumerate(self.edges):
            if e.enabled and idx not in failed_edges and e.source in a and e.target in a:
                a[e.source].append((e.target,e,idx));a[e.target].append((e.source,e,idx))
        return a
    def connected_component(self,start,failed_nodes=(),failed_edges=()):
        a=self.adjacency(failed_nodes,failed_edges)
        if start not in a:return set()
        seen={start};stack=[start]
        while stack:
            u=stack.pop()
            for v,_,_ in a[u]:
                if v not in seen:seen.add(v);stack.append(v)
        return seen
    def is_connected(self,failed_nodes=(),failed_edges=()):
        active=self.nodes-set(failed_nodes)
        if not active:return True
        return self.connected_component(next(iter(active)),failed_nodes,failed_edges)==active
    def route(self,start,end,latency_weight=1.0,capacity_weight=0.0,reliability_weight=0.0,failed_nodes=(),failed_edges=()):
        if start==end:return []
        a=self.adjacency(failed_nodes,failed_edges)
        if start not in a or end not in a:return []
        d={start:0.0};prev={};q=[(0.0,start)]
        while q:
            cost,u=heapq.heappop(q)
            if cost!=d.get(u):continue
            if u==end:break
            for v,e,idx in a[u]:
                nc=cost+edge_cost(e,latency_weight,capacity_weight,reliability_weight)
                if nc<d.get(v,float("inf")):
                    d[v]=nc;prev[v]=(u,e,idx);heapq.heappush(q,(nc,v))
        if end not in prev:return []
        out=[];cur=end
        while cur!=start:
            u,e,idx=prev[cur];out.append((e,idx));cur=u
        return list(reversed(out))
    def edge_disjoint_alternate(self,start,end,**weights):
        first=self.route(start,end,**weights)
        if not first:return [],[]
        blocked=[idx for _,idx in first]
        second=self.route(start,end,failed_edges=blocked,**weights)
        return [e for e,_ in first],[e for e,_ in second]

@dataclass(frozen=True)
class GalacticPathAssessment:
    hops:int
    distance_ly:float
    capacity_bps:float
    availability:float
    processing_delay_s:float
    generations_at_25y:float

def assess_galactic_path(edges):
    return GalacticPathAssessment(len(edges),path_distance_ly(edges),path_capacity_bps(edges),
      path_availability(edges),path_processing_delay_s(edges),propagation_generations(path_distance_ly(edges),25.0))
