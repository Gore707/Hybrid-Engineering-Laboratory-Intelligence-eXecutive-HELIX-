from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .foundation import Qubit,pure_state_fidelity

C_M_S=299792458.0

class BellMeasurementOutcome(str,Enum):
    PHI_PLUS="PHI_PLUS"; PHI_MINUS="PHI_MINUS"; PSI_PLUS="PSI_PLUS"; PSI_MINUS="PSI_MINUS"

def classical_bits_for_bell_outcome(outcome:BellMeasurementOutcome):
    return {
      BellMeasurementOutcome.PHI_PLUS:(0,0),
      BellMeasurementOutcome.PHI_MINUS:(0,1),
      BellMeasurementOutcome.PSI_PLUS:(1,0),
      BellMeasurementOutcome.PSI_MINUS:(1,1),
    }[outcome]

def required_pauli_correction(outcome:BellMeasurementOutcome):
    # Convention for standard teleportation circuit.
    return {
      BellMeasurementOutcome.PHI_PLUS:"I",
      BellMeasurementOutcome.PHI_MINUS:"Z",
      BellMeasurementOutcome.PSI_PLUS:"X",
      BellMeasurementOutcome.PSI_MINUS:"XZ",
    }[outcome]

def apply_pauli(q:Qubit,operation:str):
    a,b=q.alpha,q.beta
    if operation=="I":return Qubit(a,b)
    if operation=="X":return Qubit(b,a)
    if operation=="Z":return Qubit(a,-b)
    if operation=="XZ":return Qubit(-b,a)  # global phase conventions are physically irrelevant
    raise ValueError("operation must be I, X, Z, or XZ")

def teleportation_fidelity_from_bell_fidelity(entanglement_fidelity):
    if not 0<=entanglement_fidelity<=1:raise ValueError("fidelity in [0,1]")
    # Werner/isotropic-resource convention: average teleportation fidelity=(2F+1)/3.
    return (2*entanglement_fidelity+1)/3

def classical_fidelity_threshold_qubit(): return 2/3

def teleportation_success_probability(entanglement_delivery_probability,bell_measurement_success_probability,correction_success_probability=1.0):
    if not all(0<=x<=1 for x in (entanglement_delivery_probability,bell_measurement_success_probability,correction_success_probability)):
        raise ValueError("probabilities in [0,1]")
    return entanglement_delivery_probability*bell_measurement_success_probability*correction_success_probability

def teleportation_rate_per_s(attempt_rate_per_s,success_probability):
    if attempt_rate_per_s<0 or not 0<=success_probability<=1:raise ValueError("invalid rate/probability")
    return attempt_rate_per_s*success_probability

def classical_message_transmission_time_s(distance_m,propagation_speed_m_s=C_M_S,processing_delay_s=0.0):
    if distance_m<0 or not 0<propagation_speed_m_s<=C_M_S or processing_delay_s<0:raise ValueError("invalid classical channel")
    return distance_m/propagation_speed_m_s+processing_delay_s

def minimum_usable_teleportation_latency_s(distance_m,propagation_speed_m_s=C_M_S,processing_delay_s=0.0):
    # Receiver cannot know/apply the Bell-outcome-dependent correction before the two classical bits arrive.
    return classical_message_transmission_time_s(distance_m,propagation_speed_m_s,processing_delay_s)

def pre_classical_message_receiver_state_information_bits(): return 0.0

@dataclass(frozen=True)
class TeleportationLink:
    distance_m:float
    attempt_rate_per_s:float
    entanglement_delivery_probability:float
    bell_measurement_success_probability:float
    entanglement_fidelity:float
    classical_propagation_speed_m_s:float=C_M_S
    processing_delay_s:float=0.0
    correction_success_probability:float=1.0
    def __post_init__(self):
        if self.distance_m<0 or self.attempt_rate_per_s<0 or self.processing_delay_s<0:raise ValueError("nonnegative geometry/rates")
        if not 0<self.classical_propagation_speed_m_s<=C_M_S:raise ValueError("classical propagation cannot exceed c")
        if not all(0<=x<=1 for x in (self.entanglement_delivery_probability,self.bell_measurement_success_probability,self.entanglement_fidelity,self.correction_success_probability)):
            raise ValueError("probabilities/fidelity in [0,1]")
    @property
    def success_probability(self):
        return teleportation_success_probability(self.entanglement_delivery_probability,self.bell_measurement_success_probability,self.correction_success_probability)
    @property
    def successful_rate_per_s(self):return teleportation_rate_per_s(self.attempt_rate_per_s,self.success_probability)
    @property
    def average_fidelity(self):return teleportation_fidelity_from_bell_fidelity(self.entanglement_fidelity)
    @property
    def minimum_usable_latency_s(self):return minimum_usable_teleportation_latency_s(self.distance_m,self.classical_propagation_speed_m_s,self.processing_delay_s)
