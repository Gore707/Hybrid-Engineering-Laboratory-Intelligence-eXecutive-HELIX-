from __future__ import annotations
from collections import defaultdict, deque
from dataclasses import dataclass
from threading import RLock
from typing import Callable, Type

from .messages import BusMessage

class BusError(RuntimeError): pass
class TypeRegistrationError(BusError): pass
class MessageValidationError(BusError): pass

@dataclass(frozen=True)
class Subscription:
    token: int
    topic: str

class HelixBus:
    """Thread-safe typed in-memory event/data bus.

    C05 deliberately carries structured messages and references, not bulk
    scientific arrays. Large arrays remain external and are referenced by ID/URI.
    """
    def __init__(self, history_per_topic: int = 256):
        self._lock = RLock()
        self._history_limit = max(0, int(history_per_topic))
        self._types: dict[str, Type[BusMessage]] = {}
        self._subscribers: dict[str, dict[int, Callable[[BusMessage], None]]] = defaultdict(dict)
        self._history: dict[str, deque[BusMessage]] = defaultdict(
            lambda: deque(maxlen=self._history_limit or None)
        )
        self._next_token = 1

    def register_type(self, topic: str, message_type: Type[BusMessage]) -> None:
        if not issubclass(message_type, BusMessage):
            raise TypeRegistrationError("message_type must derive from BusMessage")
        with self._lock:
            existing = self._types.get(topic)
            if existing and existing is not message_type:
                raise TypeRegistrationError(
                    f"Topic '{topic}' already registered as {existing.__name__}"
                )
            self._types[topic] = message_type

    def subscribe(self, topic: str, callback: Callable[[BusMessage], None]) -> Subscription:
        if not callable(callback):
            raise TypeError("callback must be callable")
        with self._lock:
            token = self._next_token
            self._next_token += 1
            self._subscribers[topic][token] = callback
            return Subscription(token, topic)

    def unsubscribe(self, subscription: Subscription) -> None:
        with self._lock:
            self._subscribers[subscription.topic].pop(subscription.token, None)

    def publish(self, message: BusMessage) -> int:
        with self._lock:
            expected = self._types.get(message.topic)
            if expected is None:
                raise MessageValidationError(f"Unregistered topic: {message.topic}")
            if not isinstance(message, expected):
                raise MessageValidationError(
                    f"Topic '{message.topic}' requires {expected.__name__}; "
                    f"received {type(message).__name__}"
                )
            if self._history_limit:
                self._history[message.topic].append(message)
            callbacks = list(self._subscribers.get(message.topic, {}).values())

        # Execute outside the lock to prevent subscriber re-entry deadlocks.
        delivered = 0
        for callback in callbacks:
            callback(message)
            delivered += 1
        return delivered

    def history(self, topic: str) -> tuple[BusMessage, ...]:
        with self._lock:
            return tuple(self._history.get(topic, ()))

    def registered_topics(self) -> dict[str, str]:
        with self._lock:
            return {k: v.__name__ for k, v in self._types.items()}
