from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import BoundaryEvidence,C_M_S

HBAR_EV_S=6.582119569e-16
HBARC_EV_M=1.973269804e-7

def momentum_mismatch_ev(m_axion_ev,photon_energy_ev,effective_photon_mass_ev=0.0):
    """Relativistic small-mass mismatch q ~= |m_a^2-m_gamma^2|/(2E)."""
    if m_axion_ev<0 or photon_energy_ev<=0 or effective_photon_mass_ev<0:raise ValueError("invalid axion inputs")
    return abs(m_axion_ev*m_axion_ev-effective_photon_mass_ev*effective_photon_mass_ev)/(2*photon_energy_ev)

def coherence_length_m(m_axion_ev,photon_energy_ev,effective_photon_mass_ev=0.0):
    q=momentum_mismatch_ev(m_axion_ev,photon_energy_ev,effective_photon_mass_ev)
    return math.inf if q==0 else 2*math.pi*HBARC_EV_M/q

def sinc(x):
    return 1.0 if x==0 else math.sin(x)/x

def photon_axion_conversion_probability(g_agamma_gev_inv,b_field_t,length_m,m_axion_ev=0.0,photon_energy_ev=1.0,effective_photon_mass_ev=0.0):
    """Coherent mixing benchmark P ~= (g B L/2)^2 sinc^2(qL/2), using SI-to-natural-unit conversions."""
    if g_agamma_gev_inv<0 or b_field_t<0 or length_m<0:raise ValueError("nonnegative coupling/field/length")
    if photon_energy_ev<=0:raise ValueError("photon energy positive")
    # 1 T ~= 195 eV^2; 1 m ~= 1/(hbar c) eV^-1; GeV^-1 -> 1e-9 eV^-1
    g_ev_inv=g_agamma_gev_inv*1e-9
    b_ev2=b_field_t*195.0
    l_ev_inv=length_m/HBARC_EV_M
    q_ev=momentum_mismatch_ev(m_axion_ev,photon_energy_ev,effective_photon_mass_ev)
    phase=q_ev*l_ev_inv/2
    p=(g_ev_inv*b_ev2*l_ev_inv/2)**2*sinc(phase)**2
    return min(1.0,max(0.0,p))

def light_shining_through_wall_probability(production_probability,reconversion_probability):
    if not 0<=production_probability<=1 or not 0<=reconversion_probability<=1:raise ValueError("probabilities in [0,1]")
    return production_probability*reconversion_probability

def regenerated_photon_rate_s(source_photon_rate_s,p_prod,p_reconv,detector_efficiency=1.0):
    if source_photon_rate_s<0 or not 0<=detector_efficiency<=1:raise ValueError("invalid rate")
    return source_photon_rate_s*light_shining_through_wall_probability(p_prod,p_reconv)*detector_efficiency

def poisson_detection_snr(signal_rate_s,background_rate_s,integration_s):
    if signal_rate_s<0 or background_rate_s<0 or integration_s<=0:raise ValueError("invalid counting")
    s=signal_rate_s*integration_s;b=background_rate_s*integration_s
    return 0.0 if s+b==0 else s/math.sqrt(s+b)

def ideal_regenerated_bit_rate_bps(regenerated_rate_s,photons_per_bit):
    if regenerated_rate_s<0 or photons_per_bit<=0:raise ValueError("invalid event budget")
    return regenerated_rate_s/photons_per_bit

def axion_information_speed_status(speed_m_s):
    """Ordinary massive axion/ALP excitations do not constitute an FTL exception."""
    if speed_m_s<0:raise ValueError("speed nonnegative")
    return speed_m_s<=C_M_S

@dataclass(frozen=True)
class AxionConversionStage:
    g_agamma_gev_inv:float
    b_field_t:float
    length_m:float
    m_axion_ev:float
    photon_energy_ev:float
    effective_photon_mass_ev:float=0.0
    @property
    def probability(self):
        return photon_axion_conversion_probability(self.g_agamma_gev_inv,self.b_field_t,self.length_m,self.m_axion_ev,self.photon_energy_ev,self.effective_photon_mass_ev)
    @property
    def coherence_length_m(self):
        return coherence_length_m(self.m_axion_ev,self.photon_energy_ev,self.effective_photon_mass_ev)

@dataclass(frozen=True)
class AxionCommunicationLink:
    production:AxionConversionStage
    reconversion:AxionConversionStage
    source_photon_rate_s:float
    detector_efficiency:float=1.0
    photons_per_bit:float=10.0
    background_rate_s:float=0.0
    evidence:BoundaryEvidence=BoundaryEvidence.SPECULATIVE_UNRESOLVED
    def __post_init__(self):
        if self.source_photon_rate_s<0 or not 0<=self.detector_efficiency<=1 or self.photons_per_bit<=0 or self.background_rate_s<0:raise ValueError("invalid link")
    @property
    def end_to_end_probability(self):return light_shining_through_wall_probability(self.production.probability,self.reconversion.probability)
    @property
    def regenerated_rate_s(self):return regenerated_photon_rate_s(self.source_photon_rate_s,self.production.probability,self.reconversion.probability,self.detector_efficiency)
    @property
    def ideal_bit_rate_bps(self):return ideal_regenerated_bit_rate_bps(self.regenerated_rate_s,self.photons_per_bit)
