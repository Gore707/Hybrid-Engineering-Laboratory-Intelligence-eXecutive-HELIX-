import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QCOM"
sp=importlib.util.spec_from_file_location("skl_qcom",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qcom"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_light_second(self):self.assertEqual(q.one_way_light_time_s(q.C_M_S),1)
 def test_round_trip(self):self.assertEqual(q.round_trip_light_time_s(q.C_M_S),2)
 def test_moon_delay(self):self.assertGreater(q.one_way_light_time_s(q.EARTH_MOON_MEAN_M),1)
 def test_au_delay(self):self.assertGreater(q.one_way_light_time_s(q.AU_M),490)
 def test_divergence(self):self.assertAlmostEqual(q.diffraction_limited_divergence_rad(1e-6,1),1.22e-6)
 def test_spot(self):self.assertEqual(q.far_field_spot_radius_m(1e6,1e-6),1)
 def test_point_req(self):self.assertAlmostEqual(q.pointing_requirement_rad(100,1e8,.1),1e-7)
 def test_memory_survival(self):self.assertTrue(0<q.memory_survival_over_herald_time(q.EARTH_MOON_MEAN_M,10)<1)
 def test_memory_requirement(self):self.assertGreater(q.required_memory_coherence_for_survival(q.EARTH_MOON_MEAN_M,.9),20)
 def test_entanglement_rate(self):self.assertEqual(q.direct_entanglement_pair_rate_per_s(1e6,.1,.2,.5,.5,.8),4000)
 def test_link(self):
  x=q.InterplanetaryQuantumLink(800e-9,.5,q.EARTH_MOON_MEAN_M,5,1e-8,.9,.9,.7,1e9,10,.01)
  self.assertGreater(x.beam_radius_m,0);self.assertTrue(0<x.channel_efficiency<1);self.assertGreater(x.one_way_light_time_s,1);self.assertTrue(0<=x.qber<=.5);self.assertGreaterEqual(x.idealized_bb84_secret_rate_bps,0)
 def test_distance_hurts(self):
  a=q.InterplanetaryQuantumLink(800e-9,.5,1e8,5,source_rate_per_s=1e9)
  b=q.InterplanetaryQuantumLink(800e-9,.5,1e9,5,source_rate_per_s=1e9)
  self.assertLess(b.channel_efficiency,a.channel_efficiency)
 def test_free_space_preserved(self):self.assertEqual(q.link_loss_db(.1),10)
 def test_memory_preserved(self):self.assertEqual(q.multimode_throughput_limit_per_s(10,.01),1000)
 def test_no_signalling_preserved(self):self.assertEqual(q.no_signalling_remote_probability("mars"),(.5,.5))
 def test_registry(self):self.assertTrue({"QCOM-IP-LIGHT","QCOM-IP-DIV","QCOM-IP-SPOT","QCOM-IP-MEM","QCOM-IP-MEMREQ","QCOM-IP-ENT"}<={x.model_id for x in q.QuantumCommRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QCOM-09")
 def test_opt_dependency(self):self.assertIn("SKL-OPT",json.loads((M/"module.json").read_text())["dependencies"])
 def test_qmem_dependency(self):self.assertIn("SKL-QMEM",json.loads((M/"module.json").read_text())["dependencies"])
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
