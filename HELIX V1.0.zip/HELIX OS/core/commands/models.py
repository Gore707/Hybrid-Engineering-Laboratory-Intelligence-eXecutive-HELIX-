from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable
from uuid import uuid4
from datetime import datetime, timezone

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

class ConfirmationLevel(str, Enum):
    NONE = "NONE"
    CONFIRM = "CONFIRM"
    DESTRUCTIVE = "DESTRUCTIVE"
    HARDWARE = "HARDWARE"

@dataclass(frozen=True)
class ParameterSpec:
    name: str
    python_type: type
    required: bool = True
    default: Any = None
    choices: tuple[Any, ...] | None = None
    minimum: float | None = None
    maximum: float | None = None

    def validate(self, value: Any) -> Any:
        if value is None:
            if self.required and self.default is None:
                raise ValueError(f"Missing required parameter '{self.name}'")
            return self.default
        if not isinstance(value, self.python_type):
            raise TypeError(
                f"Parameter '{self.name}' must be {self.python_type.__name__}; "
                f"received {type(value).__name__}"
            )
        if self.choices is not None and value not in self.choices:
            raise ValueError(f"Parameter '{self.name}' must be one of {self.choices}")
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if self.minimum is not None and value < self.minimum:
                raise ValueError(f"Parameter '{self.name}' must be >= {self.minimum}")
            if self.maximum is not None and value > self.maximum:
                raise ValueError(f"Parameter '{self.name}' must be <= {self.maximum}")
        return value

@dataclass(frozen=True)
class CommandContext:
    source: str
    actor: str
    project_id: str | None = None
    experiment_id: str | None = None

@dataclass(frozen=True)
class CommandRequest:
    action_id: str
    parameters: dict[str, Any]
    context: CommandContext
    confirmed: bool = False
    request_id: str = field(default_factory=lambda: f"CMD-{uuid4().hex[:16].upper()}")
    timestamp_utc: str = field(default_factory=utc_now)

@dataclass(frozen=True)
class CommandResult:
    request_id: str
    action_id: str
    success: bool
    status: str
    message: str
    data: dict[str, Any] = field(default_factory=dict)
    timestamp_utc: str = field(default_factory=utc_now)

@dataclass(frozen=True)
class ActionDefinition:
    action_id: str
    title: str
    description: str
    handler: Callable[[dict[str, Any], CommandContext], dict[str, Any] | None]
    parameters: tuple[ParameterSpec, ...] = ()
    confirmation: ConfirmationLevel = ConfirmationLevel.NONE
    category: str = "General"
