from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

C=299_792_458.0
K_B=1.380649e-23

class EvidenceState(str,Enum):
    HARDWARE="HARDWARE"; IMPORTED="IMPORTED"; SIMULATION="SIMULATION"
    EXTRAPOLATED="EXTRAPOLATED"; SPECULATIVE="SPECULATIVE"

def wavelength_m(frequency_hz):
    if frequency_hz<=0: raise ValueError("frequency must be positive")
    return C/frequency_hz

def frequency_hz(wavelength_m_value):
    if wavelength_m_value<=0: raise ValueError("wavelength must be positive")
    return C/wavelength_m_value

def db_to_linear(db): return 10.0**(db/10.0)
def linear_to_db(value):
    if value<=0: raise ValueError("positive linear value required")
    return 10.0*math.log10(value)

def dbm_to_w(dbm): return 10.0**((dbm-30.0)/10.0)
def w_to_dbm(w):
    if w<=0: raise ValueError("positive power required")
    return 10.0*math.log10(w)+30.0

def free_space_path_loss_linear(distance_m,frequency_hz_value):
    if distance_m<=0 or frequency_hz_value<=0: raise ValueError("positive distance/frequency required")
    lam=wavelength_m(frequency_hz_value)
    return (4*math.pi*distance_m/lam)**2

def free_space_path_loss_db(distance_m,frequency_hz_value):
    return linear_to_db(free_space_path_loss_linear(distance_m,frequency_hz_value))

def antenna_gain_linear(aperture_efficiency,diameter_m,frequency_hz_value):
    if not 0<aperture_efficiency<=1 or diameter_m<=0 or frequency_hz_value<=0: raise ValueError("invalid antenna inputs")
    lam=wavelength_m(frequency_hz_value)
    return aperture_efficiency*(math.pi*diameter_m/lam)**2

def friis_received_power_w(transmit_power_w,tx_gain_linear,rx_gain_linear,distance_m,frequency_hz_value,system_efficiency=1.0):
    if transmit_power_w<0 or tx_gain_linear<0 or rx_gain_linear<0 or not 0<=system_efficiency<=1:
        raise ValueError("invalid link inputs")
    return transmit_power_w*tx_gain_linear*rx_gain_linear*system_efficiency/free_space_path_loss_linear(distance_m,frequency_hz_value)

def thermal_noise_power_w(temperature_k,bandwidth_hz):
    if temperature_k<0 or bandwidth_hz<0: raise ValueError("nonnegative T/B required")
    return K_B*temperature_k*bandwidth_hz

def snr_linear(signal_power_w,noise_power_w):
    if signal_power_w<0 or noise_power_w<=0: raise ValueError("invalid signal/noise")
    return signal_power_w/noise_power_w

def shannon_capacity_bps(bandwidth_hz,snr):
    if bandwidth_hz<0 or snr<0: raise ValueError("nonnegative bandwidth/SNR required")
    return bandwidth_hz*math.log2(1+snr)

@dataclass(frozen=True)
class RFLink:
    frequency_hz:float
    distance_m:float
    transmit_power_w:float
    tx_gain_linear:float
    rx_gain_linear:float
    system_efficiency:float
    system_temperature_k:float
    bandwidth_hz:float
    evidence:EvidenceState=EvidenceState.SIMULATION
    def __post_init__(self):
        if min(self.frequency_hz,self.distance_m)>0 and self.transmit_power_w>=0 and self.tx_gain_linear>=0 and self.rx_gain_linear>=0 and 0<=self.system_efficiency<=1 and self.system_temperature_k>=0 and self.bandwidth_hz>0:
            return
        raise ValueError("invalid RF link")
    @property
    def received_power_w(self): return friis_received_power_w(self.transmit_power_w,self.tx_gain_linear,self.rx_gain_linear,self.distance_m,self.frequency_hz,self.system_efficiency)
    @property
    def noise_power_w(self): return thermal_noise_power_w(self.system_temperature_k,self.bandwidth_hz)
    @property
    def snr(self): return snr_linear(self.received_power_w,self.noise_power_w)
    @property
    def capacity_bps(self): return shannon_capacity_bps(self.bandwidth_hz,self.snr)
    def report(self):
        return {"frequency_hz":self.frequency_hz,"wavelength_m":wavelength_m(self.frequency_hz),
                "distance_m":self.distance_m,"received_power_w":self.received_power_w,
                "noise_power_w":self.noise_power_w,"snr_linear":self.snr,
                "snr_db":linear_to_db(self.snr),"shannon_capacity_bps":self.capacity_bps,
                "evidence":self.evidence.value}
