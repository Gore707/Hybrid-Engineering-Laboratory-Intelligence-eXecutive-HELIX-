import unittest,tempfile,zipfile,json
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.modules import *
from core.multiphysics import *
from core.engineering.engines import power_energy
ROOT=Path(__file__).resolve().parents[1]
class C23Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C23")
 def test_registry_dependencies(self):
  with tempfile.TemporaryDirectory() as td:
   r=ModuleRegistry(Path(td)/"r.json");r.register(ModuleManifest("A","A","1","1.0"))
   r.register(ModuleManifest("B","B","1","1.0",("A",)));self.assertIn("B",r.modules)
   with self.assertRaises(ModuleError):r.unregister("A")
 def test_api_reject(self):
  with tempfile.TemporaryDirectory() as td:
   with self.assertRaises(ModuleError):ModuleRegistry(Path(td)/"r").register(ModuleManifest("X","X","1","2.0"))
 def test_package_build_verify_install(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);src=td/"src";src.mkdir();(src/"module.py").write_text("VALUE=42")
   pkg=SKPPackage.build(src,td/"x.skp",ModuleManifest("SKL-TEST","Test","1.0.0","1.0",(),("model",)))
   self.assertTrue(SKPPackage.verify(pkg));r=ModuleRegistry(td/"r.json")
   q=SKPPackage.install(pkg,td/"modules",r);self.assertEqual(q.module_id,"SKL-TEST");self.assertTrue((td/"modules/SKL-TEST/module.py").exists())
 def test_checksum_tamper_detected(self):
  with tempfile.TemporaryDirectory() as td:
   td=Path(td);src=td/"s";src.mkdir();(src/"a").write_text("a");pkg=SKPPackage.build(src,td/"x.skp",ModuleManifest("M","M","1","1.0"))
   with zipfile.ZipFile(pkg,"a") as z:z.writestr("a","tampered")
   self.assertFalse(SKPPackage.verify(pkg))
 def test_multiphysics_pipeline(self):
  p=CoupledPipeline().add("power",power_energy,{"input_w":"source_power","efficiency":"efficiency","duration_s":"duration"})
  state,trace=p.run({"source_power":100,"efficiency":.8,"duration":10})
  self.assertEqual(state["power.waste_heat_w"],20);self.assertEqual(len(trace),1)
 def test_missing_coupled_value(self):
  p=CoupledPipeline().add("power",power_energy,{"input_w":"missing","efficiency":"e","duration_s":"t"})
  with self.assertRaises(CouplingError):p.run({"e":1,"t":1})
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
