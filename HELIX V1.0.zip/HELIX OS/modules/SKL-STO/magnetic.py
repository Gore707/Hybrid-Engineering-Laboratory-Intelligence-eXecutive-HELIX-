from __future__ import annotations
from dataclasses import dataclass
import math
from .framework import CapacityEstimate,EvidenceClass
K_B=1.380649e-23
def anisotropy_energy_barrier_j(anisotropy_j_m3,volume_m3):
 if anisotropy_j_m3<0 or volume_m3<0:raise ValueError("nonnegative K,V required")
 return anisotropy_j_m3*volume_m3
def thermal_stability_factor(anisotropy_j_m3,volume_m3,temperature_k):
 if temperature_k<=0:raise ValueError("temperature positive")
 return anisotropy_energy_barrier_j(anisotropy_j_m3,volume_m3)/(K_B*temperature_k)
def neel_arrhenius_retention_s(attempt_time_s,stability_factor):
 if attempt_time_s<=0 or stability_factor<0:raise ValueError("invalid retention inputs")
 try:return attempt_time_s*math.exp(stability_factor)
 except OverflowError:return math.inf
def required_stability_factor(target_retention_s,attempt_time_s):
 if target_retention_s<=0 or attempt_time_s<=0 or target_retention_s<attempt_time_s:raise ValueError("invalid target")
 return math.log(target_retention_s/attempt_time_s)
@dataclass(frozen=True)
class MagneticBitCell:
 pitch_x_m:float;pitch_y_m:float;bits_per_cell:int=1
 def __post_init__(self):
  if min(self.pitch_x_m,self.pitch_y_m)<=0 or self.bits_per_cell<1:raise ValueError("invalid cell")
 @property
 def area_m2(self):return self.pitch_x_m*self.pitch_y_m
 @property
 def areal_bit_density_m2(self):return self.bits_per_cell/self.area_m2
@dataclass(frozen=True)
class MagneticArray:
 width_m:float;height_m:float;layers:int;cell:MagneticBitCell;reserved_fraction:float=0.0
 def __post_init__(self):
  if min(self.width_m,self.height_m)<=0 or self.layers<1 or not 0<=self.reserved_fraction<1:raise ValueError("invalid array")
 @property
 def nx(self):return int(math.floor(self.width_m/self.cell.pitch_x_m+1e-12))
 @property
 def ny(self):return int(math.floor(self.height_m/self.cell.pitch_y_m+1e-12))
 @property
 def cell_count(self):return self.nx*self.ny*self.layers
 def capacity(self,evidence_class=EvidenceClass.EXTRAPOLATED_ENGINEERING):
  raw=self.cell_count*self.cell.bits_per_cell;return CapacityEstimate(raw*(1-self.reserved_fraction),raw,self.reserved_fraction,"magnetic cell geometry × layers",evidence_class)
def tunneling_magnetoresistance_ratio(r_parallel_ohm,r_antiparallel_ohm):
 if r_parallel_ohm<=0 or r_antiparallel_ohm<=0:raise ValueError("resistances positive")
 return (r_antiparallel_ohm-r_parallel_ohm)/r_parallel_ohm
def read_margin_ohm(r_parallel_ohm,r_antiparallel_ohm):
 if r_parallel_ohm<=0 or r_antiparallel_ohm<=0:raise ValueError("resistances positive")
 return abs(r_antiparallel_ohm-r_parallel_ohm)
@dataclass(frozen=True)
class TopologicalStateModel:
 distinguishable_states:int
 def __post_init__(self):
  if self.distinguishable_states<2:raise ValueError("at least two states")
 @property
 def ideal_bits_per_site(self):return math.log2(self.distinguishable_states)
