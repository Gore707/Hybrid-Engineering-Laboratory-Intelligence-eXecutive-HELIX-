import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ECC"
sp=importlib.util.spec_from_file_location("skl_ecc",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_ecc"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_sensitivity(self):self.assertAlmostEqual(q.normalized_local_sensitivity(lambda x:x*x,2),2,places=5)
 def test_global_gate(self):self.assertTrue(q.global_gates()[0].passed)
 def test_nu_gates(self):
  n=q.NeutrinoLink(10,1e20,1e6,1e-3,1e6,.8,10);self.assertEqual(len(q.neutrino_gates(n,0,0)),2);self.assertTrue(all(x.passed for x in q.neutrino_gates(n,0,0)))
 def test_hep_gates(self):
  x=q.HighEnergyPhotonLink(10,1e15,1e6,1e-6,1,.8,.8,10);self.assertTrue(all(a.passed for a in q.high_energy_photon_gates(x,0,0)))
 def test_pb_gates(self):
  p=q.ParticleBeamLink(1.67262192369e-27,1e-8,1e15,1e9,1e-9,10,.9,.8,10);self.assertTrue(all(a.passed for a in q.particle_beam_gates(p,0,0)))
 def test_gw_gates(self):
  g=q.GravitationalWaveLink(1e-22,100,1e16,1e-23,100,4000);self.assertTrue(all(a.passed for a in q.gravitational_wave_gates(g,0)))
 def test_critical_aggregation(self):self.assertTrue(q.all_critical_gates_pass(q.global_gates()))
 def test_cross_engine(self):
  c=q.run_cross_engine_validation(R);self.assertEqual(len(c),12);self.assertTrue(all(c.values()))
 def test_lab_preserved(self):
  s=q.CarrierScenario("x",q.EvidenceClass.ESTABLISHED_PHYSICS,1,10,100);self.assertEqual(s.joules_per_bit,10)
 def test_gw_preserved(self):self.assertGreater(q.sinusoidal_gw_energy_flux_w_m2(1e-21,100),0)
 def test_particle_preserved(self):self.assertLess(q.speed_from_kinetic_energy_j(1e-9,1.67e-27),q.C_M_S)
 def test_hep_preserved(self):self.assertGreater(q.photon_energy_kev_from_wavelength(1e-10),0)
 def test_neutrino_preserved(self):self.assertGreater(q.approximate_cc_cross_section_m2(1),0)
 def test_causality_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ECC-VAL-SENS","ECC-VAL-GATES","ECC-VAL-XENG"}<={x.model_id for x in q.ExtremeCarrierRegistry().all()})
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-ECC-08");self.assertEqual(x["status"],"COMPLETE — ECC 8/8")
 def test_complete_marker(self):
  x=json.loads((R/"ECC_COMPLETE.json").read_text());self.assertEqual(x["status"],"COMPLETE");self.assertEqual(x["sequence"]["complete"],8)
 def test_prior_markers(self):
  for f in ("ISN_COMPLETE.json","PHO_COMPLETE.json","OPT_COMPLETE.json","QCOM_COMPLETE.json"):self.assertTrue((R/f).exists(),f)
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
