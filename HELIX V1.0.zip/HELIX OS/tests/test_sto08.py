import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-STO";sp=importlib.util.spec_from_file_location("skl_sto",M/"__init__.py",submodule_search_locations=[str(M)]);s=importlib.util.module_from_spec(sp);sys.modules["skl_sto"]=s;sp.loader.exec_module(s)
class T(unittest.TestCase):
 def test_expected(self):self.assertEqual(s.expected_bit_errors(1_000_000,1e-6),1)
 def test_ecc_zero_ber(self):self.assertEqual(s.block_uncorrectable_probability(64,0,1),0)
 def test_ecc_no_correction(self):self.assertAlmostEqual(s.block_uncorrectable_probability(2,.1,0),.19)
 def test_code_rate(self):self.assertEqual(s.code_rate(8,10),.8)
 def test_throughput(self):self.assertEqual(s.effective_throughput_bps(1000,.8,.1),720)
 def test_latency(self):self.assertEqual(s.transfer_latency_s(1000,500,.25),2.25)
 def test_endurance(self):
  e=s.EnduranceModel(1000,250);self.assertEqual(e.consumed_fraction,.25);self.assertEqual(e.remaining_cycles,750);self.assertFalse(e.beyond_rating)
 def test_endurance_over(self):self.assertTrue(s.EnduranceModel(10,11).beyond_rating)
 def test_defects(self):self.assertEqual(s.DefectMap(100,frozenset({1,2,3})).yield_fraction,.97)
 def test_combined_ber(self):self.assertAlmostEqual(s.combined_independent_ber(.1,.2),.28)
 def test_integrity(self):
  d=b"HELIX";h=s.sha256_bytes(d);self.assertTrue(s.verify_sha256(d,h));self.assertFalse(s.verify_sha256(b"helix",h))
 def test_registry(self):self.assertEqual(s.StorageRegistry().get("STO-ECC-BLOCK-FAIL").evidence_class,"ESTABLISHED_PHYSICS")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-STO-08")
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
