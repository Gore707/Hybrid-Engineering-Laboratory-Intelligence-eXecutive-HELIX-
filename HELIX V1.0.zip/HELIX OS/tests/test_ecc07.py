import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ECC"
sp=importlib.util.spec_from_file_location("skl_ecc",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_ecc"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def rec(self,name="N",rate=100,eid="ECC-TEST"):
  s=q.CarrierScenario(name,q.EvidenceClass.EXTRAPOLATED_ENGINEERING,10,rate,1000,100,10,1e-6,.9)
  p=q.ExperimentProvenance(q.DataSourceState.SIMULATION,q.EvidenceClass.EXTRAPOLATED_ENGINEERING,("ECC-NU-EVENT",),("paper:test",))
  return q.ExtremeCarrierExperimentRecord.create(name,s,p,{"x":1},{"rate":rate},eid,"2026-09-14T00:00:00+00:00")
 def test_provenance(self):self.assertEqual(self.rec().provenance.source_state,q.DataSourceState.SIMULATION)
 def test_checksum_stable(self):self.assertEqual(self.rec().checksum_sha256(),self.rec().checksum_sha256())
 def test_checksum_length(self):self.assertEqual(len(self.rec().checksum_sha256()),64)
 def test_json(self):self.assertEqual(json.loads(self.rec().canonical_json())["experiment_id"],"ECC-TEST")
 def test_viz(self):self.assertEqual(q.visualization_rows([self.rec()])[0]["information_rate_bps"],100)
 def test_guardian_warning(self):self.assertIsNotNone(q.guardian_summary(self.rec())["warning"])
 def test_lab_add_get(self):
  l=q.ExtremeCarrierLab();r=self.rec();l.add(r);self.assertIs(l.get("ECC-TEST"),r)
 def test_duplicate(self):
  l=q.ExtremeCarrierLab();l.add(self.rec())
  with self.assertRaises(ValueError):l.add(self.rec())
 def test_lab_compare(self):
  l=q.ExtremeCarrierLab();l.add(self.rec("a",10,"a"));l.add(self.rec("b",100,"b"));self.assertEqual(l.compare()["highest_information_rate"].name,"b")
 def test_lab_viz(self):
  l=q.ExtremeCarrierLab();l.add(self.rec());self.assertEqual(len(l.visualization_dataset()),1)
 def test_sweep(self):
  l=q.ExtremeCarrierLab()
  def b(v):return self.rec(str(v),v,str(v))
  self.assertEqual(len(l.sweep([1,2,3],b)),3);self.assertEqual(len(l.all()),3)
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/ecc_experiment.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_compare_preserved(self):self.assertEqual(q.highest_information_rate([self.rec().scenario]).name,"N")
 def test_gw_preserved(self):self.assertGreater(q.sinusoidal_gw_energy_flux_w_m2(1e-21,100),0)
 def test_particle_preserved(self):self.assertLess(q.speed_from_kinetic_energy_j(1e-9,1.67e-27),q.C_M_S)
 def test_hep_preserved(self):self.assertGreater(q.photon_energy_kev_from_wavelength(1e-10),0)
 def test_neutrino_preserved(self):self.assertGreater(q.approximate_cc_cross_section_m2(1),0)
 def test_causality_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ECC-LAB-RECORD","ECC-LAB-VIZ","ECC-LAB-GUARDIAN"}<={x.model_id for x in q.ExtremeCarrierRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-ECC-07")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
