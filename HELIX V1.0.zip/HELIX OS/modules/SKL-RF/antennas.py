from __future__ import annotations
from dataclasses import dataclass
import math, cmath
from .foundation import C,wavelength_m

def effective_aperture_m2(gain_linear,frequency_hz):
    if gain_linear<0 or frequency_hz<=0: raise ValueError("invalid gain/frequency")
    lam=wavelength_m(frequency_hz)
    return gain_linear*lam*lam/(4*math.pi)

def dish_half_power_beamwidth_rad(diameter_m,frequency_hz,k=1.02):
    if diameter_m<=0 or frequency_hz<=0 or k<=0: raise ValueError("invalid beam inputs")
    return k*wavelength_m(frequency_hz)/diameter_m

def eirp_w(transmit_power_w,gain_linear,feed_efficiency=1.0):
    if transmit_power_w<0 or gain_linear<0 or not 0<=feed_efficiency<=1: raise ValueError("invalid EIRP inputs")
    return transmit_power_w*gain_linear*feed_efficiency

def polarization_mismatch_factor(angle_rad):
    return math.cos(angle_rad)**2

def pointing_loss_gaussian_linear(pointing_error_rad,hpbw_rad):
    if pointing_error_rad<0 or hpbw_rad<=0: raise ValueError("invalid pointing inputs")
    return math.exp(-4*math.log(2)*(pointing_error_rad/hpbw_rad)**2)

def progressive_phase_shift_rad(element_spacing_m,frequency_hz,steering_angle_rad):
    if element_spacing_m<0 or frequency_hz<=0: raise ValueError("invalid array inputs")
    return -2*math.pi*element_spacing_m*math.sin(steering_angle_rad)/wavelength_m(frequency_hz)

def uniform_linear_array_factor(element_count,element_spacing_m,frequency_hz,observation_angle_rad,steering_angle_rad=0.0):
    if element_count<1 or int(element_count)!=element_count or element_spacing_m<0 or frequency_hz<=0:
        raise ValueError("invalid array inputs")
    lam=wavelength_m(frequency_hz)
    psi=2*math.pi*element_spacing_m*(math.sin(observation_angle_rad)-math.sin(steering_angle_rad))/lam
    total=sum(cmath.exp(1j*n*psi) for n in range(int(element_count)))
    return abs(total)/element_count

def has_visible_grating_lobe(element_spacing_m,frequency_hz,steering_angle_rad=0.0):
    if element_spacing_m<=0 or frequency_hz<=0: raise ValueError("invalid spacing/frequency")
    lam=wavelength_m(frequency_hz)
    s0=math.sin(steering_angle_rad)
    # Search nonzero spatial aliases sin(theta)=sin(theta0)+m*lambda/d.
    for m in (-2,-1,1,2):
        x=s0+m*lam/element_spacing_m
        if -1 <= x <= 1: return True
    return False

@dataclass(frozen=True)
class PhasedArray:
    element_count:int
    element_spacing_m:float
    frequency_hz:float
    element_gain_linear:float=1.0
    per_element_power_w:float=1.0
    efficiency:float=1.0
    def __post_init__(self):
        if self.element_count<1 or self.element_spacing_m<=0 or self.frequency_hz<=0 or self.element_gain_linear<0 or self.per_element_power_w<0 or not 0<=self.efficiency<=1:
            raise ValueError("invalid phased array")
    @property
    def wavelength_m(self): return wavelength_m(self.frequency_hz)
    @property
    def coherent_peak_gain_linear(self): return self.element_count*self.element_gain_linear*self.efficiency
    @property
    def total_rf_power_w(self): return self.element_count*self.per_element_power_w
    @property
    def peak_eirp_w(self): return eirp_w(self.total_rf_power_w,self.coherent_peak_gain_linear)
    def steering_phase_rad(self,angle_rad): return progressive_phase_shift_rad(self.element_spacing_m,self.frequency_hz,angle_rad)
    def array_factor(self,observation_angle_rad,steering_angle_rad=0): return uniform_linear_array_factor(self.element_count,self.element_spacing_m,self.frequency_hz,observation_angle_rad,steering_angle_rad)
    def grating_lobe_risk(self,steering_angle_rad=0): return has_visible_grating_lobe(self.element_spacing_m,self.frequency_hz,steering_angle_rad)
