from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import BoundaryEvidence,C_M_S

G=6.67430e-11

def alcubierre_top_hat_shape(r_s_m,bubble_radius_m,wall_steepness_per_m):
    """Smooth Alcubierre top-hat shape f(r_s), normalized to f(0)~1 and f(infinity)~0."""
    if r_s_m<0 or bubble_radius_m<=0 or wall_steepness_per_m<=0:raise ValueError("invalid bubble geometry")
    sig=wall_steepness_per_m;R=bubble_radius_m
    den=2*math.tanh(sig*R)
    return (math.tanh(sig*(r_s_m+R))-math.tanh(sig*(r_s_m-R)))/den

def alcubierre_shape_derivative_per_m(r_s_m,bubble_radius_m,wall_steepness_per_m):
    if r_s_m<0 or bubble_radius_m<=0 or wall_steepness_per_m<=0:raise ValueError("invalid bubble geometry")
    sig=wall_steepness_per_m;R=bubble_radius_m
    den=2*math.tanh(sig*R)
    def sech2(x):
        c=math.cosh(x)
        return 1/(c*c)
    return sig*(sech2(sig*(r_s_m+R))-sech2(sig*(r_s_m-R)))/den

def coordinate_shift_speed_m_s(bubble_speed_m_s,shape_value):
    if bubble_speed_m_s<0 or not 0<=shape_value<=1:raise ValueError("invalid shift")
    return bubble_speed_m_s*shape_value

def effective_endpoint_speed_m_s(distance_m,coordinate_transit_time_s):
    if distance_m<0 or coordinate_transit_time_s<=0:raise ValueError("invalid endpoint timing")
    return distance_m/coordinate_transit_time_s

def effective_transit_time_s(distance_m,bubble_coordinate_speed_m_s):
    if distance_m<0 or bubble_coordinate_speed_m_s<=0:raise ValueError("invalid transit")
    return distance_m/bubble_coordinate_speed_m_s

def local_payload_speed_required_for_metric_transport():
    """Ideal Alcubierre comoving payload is locally at rest in the bubble coordinates."""
    return 0.0

def negative_energy_density_indicator_j_m3(bubble_speed_m_s,transverse_shape_gradient_per_m):
    """Alcubierre Eulerian energy-density benchmark:
       rho_E ~ -(c^2/32*pi*G) * (v_s/c)^2 * |grad_perp f|^2.
       Negative value flags exotic stress-energy requirement; not a construction recipe."""
    if bubble_speed_m_s<0 or transverse_shape_gradient_per_m<0:raise ValueError("nonnegative inputs")
    beta=bubble_speed_m_s/C_M_S
    return -(C_M_S**2/(32*math.pi*G))*beta**2*transverse_shape_gradient_per_m**2

def superluminal_coordinate_regime(bubble_coordinate_speed_m_s):
    if bubble_coordinate_speed_m_s<0:raise ValueError("speed nonnegative")
    return bubble_coordinate_speed_m_s>C_M_S

def forward_control_horizon_risk(bubble_coordinate_speed_m_s):
    """Flags the standard causal/control concern once the coordinate bubble speed exceeds c."""
    return superluminal_coordinate_regime(bubble_coordinate_speed_m_s)

def physically_demonstrated_warp_metric_engineering_available():
    return False

def established_method_to_generate_required_warp_stress_energy_available():
    return False

@dataclass(frozen=True)
class AlcubierreCommunicationAssessment:
    distance_m:float
    bubble_radius_m:float
    wall_steepness_per_m:float
    bubble_coordinate_speed_m_s:float
    representative_transverse_gradient_per_m:float
    evidence:BoundaryEvidence=BoundaryEvidence.SPECULATIVE_UNRESOLVED
    def __post_init__(self):
        if self.distance_m<0 or self.bubble_radius_m<=0 or self.wall_steepness_per_m<=0 or self.bubble_coordinate_speed_m_s<=0 or self.representative_transverse_gradient_per_m<0:
            raise ValueError("invalid warp assessment")
    @property
    def coordinate_transit_time_s(self):return effective_transit_time_s(self.distance_m,self.bubble_coordinate_speed_m_s)
    @property
    def apparent_endpoint_speed_m_s(self):return effective_endpoint_speed_m_s(self.distance_m,self.coordinate_transit_time_s)
    @property
    def superluminal_coordinate_regime(self):return superluminal_coordinate_regime(self.bubble_coordinate_speed_m_s)
    @property
    def forward_control_horizon_risk(self):return forward_control_horizon_risk(self.bubble_coordinate_speed_m_s)
    @property
    def energy_density_indicator_j_m3(self):return negative_energy_density_indicator_j_m3(self.bubble_coordinate_speed_m_s,self.representative_transverse_gradient_per_m)
    @property
    def demonstrated_hardware(self):return False
