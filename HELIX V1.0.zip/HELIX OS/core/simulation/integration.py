from core.visualization.engine import FigureSpec
def sweep_xy(result,output_key):
 if result.mode not in ("SWEEP","TIME_DOMAIN"):raise ValueError("result is not plottable sweep/time-domain")
 xkey="parameter" if result.mode=="SWEEP" else "time"
 return [r[xkey] for r in result.records],[r["outputs"][output_key] for r in result.records]
def figure_spec_for_result(result,title,equation_ids=(),assumptions=()):
 return FigureSpec("FIG-"+result.model_id,title,"Parameter","Output",
  "Generated directly from a HELIX simulation result.",tuple(equation_ids),(),tuple(assumptions),
  {"source_type":"SIMULATION","model_id":result.model_id,"simulation_mode":result.mode})
