from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class HQICModel:
    model_id:str
    name:str
    relation:str
    inputs:tuple[str,...]
    outputs:tuple[str,...]

class HQICRegistry:
    def __init__(self):
        self._models=(
            HQICModel("HQIC-CAP-SAME","Same-domain capacity aggregation","C_total=sum_i C_i",("capacities",),("capacity",)),
            HQICModel("HQIC-LAYER-VALID","Hybrid layer architecture validation","required layers subset of installed layers",("layers",),("valid","missing_layers")),
            HQICModel("HQIC-PC-CONTROL","Windows supervisory control chain","Windows->API/driver->I/O->controller->transducer->medium",("host","controller","transducer","medium"),("control_path",)),
            HQICModel("HQIC-LAYER-VOLUME","Physical layer volume","V=twh",("thickness_m","width_m","height_m"),("volume_m3",)),
            HQICModel("HQIC-OPT-FRESNEL","Normal-incidence interface reflectance","R=((n1-n2)/(n1+n2))^2",("n_a","n_b"),("reflectance",)),
            HQICModel("HQIC-OPT-SPOT","Diffraction-limited lateral spot scale","r=0.61 lambda/NA",("wavelength_m","numerical_aperture"),("spot_radius_m",)),
            HQICModel("HQIC-LAYER-ADDR","Planar physical address count","N=floor(W/px) floor(H/py)",("width_m","height_m","pitch_x_m","pitch_y_m"),("address_count",)),
            HQICModel("HQIC-OPT-ATTEN","Beer-Lambert optical transmission","T=exp(-alpha L)",("alpha_m_inv","path_length_m"),("transmission",)),
            HQICModel("HQIC-XDUCE-ETA","Cascaded transduction efficiency","eta_total=product_i eta_i",("efficiencies",),("efficiency",)),
            HQICModel("HQIC-XDUCE-IL","Insertion loss","IL=-10 log10(eta)",("efficiency",),("loss_db",)),
            HQICModel("HQIC-XDUCE-PHOTON","Photon energy","E=h f",("frequency_hz",),("energy_j",)),
            HQICModel("HQIC-XDUCE-NOISE","Equivalent input-referred added noise","N_in=N_out/G",("output_noise","gain"),("input_referred_noise",)),
            HQICModel("HQIC-XDUCE-FID","Depolarizing-noise fidelity estimate","F_out=(1-p)F_in+p/d",("input_fidelity","depolarizing_probability","dimension"),("output_fidelity",)),
            HQICModel("HQIC-CTL-ADDR","Controller address validation","0 <= address <= configured maximum",("address","capabilities"),("valid","reason")),
            HQICModel("HQIC-CTL-STATE","Deterministic device state machine","command + state -> validated transition",("command","state","capabilities"),("accepted","next_state")),
            HQICModel("HQIC-CTL-TELEM","Typed HQIC telemetry frame","timestamp,state,T,P,load,fault,source",("device_state","sensors"),("telemetry_frame",)),
            HQICModel("HQIC-ECC-RATE","Classical code rate","R=k/n",("payload_symbols","total_symbols"),("code_rate",)),
            HQICModel("HQIC-ECC-REP","Repetition-code logical bit error","p_L=sum majority-error terms",("raw_ber","distance"),("logical_ber",)),
            HQICModel("HQIC-QEC-DIST","Ideal code-distance correction capability","t=floor((d-1)/2)",("distance",),("correctable_errors",)),
            HQICModel("HQIC-QEC-CYCLE","Independent-cycle survival estimate","S=(1-p_L)^N",("logical_error_probability","cycles"),("survival",)),
            HQICModel("HQIC-INTEGRITY-HASH","Classical SHA-256 integrity check","digest=SHA256(data)",("data",),("digest","verified")),
            HQICModel("HQIC-THERM-COND","One-dimensional steady conduction","Q=kA(Th-Tc)/L",("k","area","hot_k","cold_k","length"),("heat_w",)),
            HQICModel("HQIC-THERM-RAD","Gray-body radiative heat load","Q=epsilon sigma A(Th^4-Tc^4)",("emissivity","area","hot_k","cold_k"),("heat_w",)),
            HQICModel("HQIC-THERM-EXP","Linear thermal expansion","dL=L alpha dT",("length","alpha","delta_t"),("delta_length",)),
            HQICModel("HQIC-MFG-RSS","Root-sum-square tolerance stack","T=sqrt(sum Ti^2)",("tolerances",),("rss_tolerance",)),
            HQICModel("HQIC-ALIGN-SPOT","Alignment error normalized to optical spot","A=error/r_spot",("alignment_error","spot_radius"),("normalized_error",)),
            HQICModel("HQIC-SIM-END2END","Integrated HQIC scenario","coupled analytical budgets with explicit gates",("scenario",),("result","failures","warnings")),
            HQICModel("HQIC-SIM-QSURV","QEC cycle survival estimate","S=(1-p_L)^N",("physical_error","distance","cycles"),("survival",)),
            HQICModel("HQIC-SIM-SWEEP","HQIC parameter sweep","run scenario over explicit parameter values",("scenario","parameter","values"),("results",)),
        )
    def get(self,model_id):
        for m in self._models:
            if m.model_id==model_id:return m
        raise KeyError(model_id)
    def all(self):return self._models
