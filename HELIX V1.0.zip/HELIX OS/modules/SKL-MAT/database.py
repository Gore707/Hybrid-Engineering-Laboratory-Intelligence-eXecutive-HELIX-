from __future__ import annotations
from pathlib import Path
import sqlite3,json
from .models import *
class MaterialError(RuntimeError):pass
class MaterialsDatabase:
 def __init__(self,path:Path):
  self.path=path;path.parent.mkdir(parents=True,exist_ok=True)
  self.db=sqlite3.connect(path)
  self.db.execute("""CREATE TABLE IF NOT EXISTS materials(
   material_id TEXT PRIMARY KEY,name TEXT NOT NULL,formula TEXT NOT NULL,phase TEXT NOT NULL,
   description TEXT NOT NULL,tags_json TEXT NOT NULL,source_ids_json TEXT NOT NULL,schema_version TEXT NOT NULL)""")
  self.db.execute("""CREATE TABLE IF NOT EXISTS properties(
   material_id TEXT NOT NULL,property_id TEXT NOT NULL,value REAL NOT NULL,unit TEXT NOT NULL,
   condition_json TEXT NOT NULL,uncertainty REAL,evidence_class TEXT NOT NULL,source_ids_json TEXT NOT NULL,
   FOREIGN KEY(material_id) REFERENCES materials(material_id))""")
  self.db.execute("CREATE INDEX IF NOT EXISTS idx_material_name ON materials(name)")
  self.db.execute("CREATE INDEX IF NOT EXISTS idx_property_id ON properties(property_id)");self.db.commit()
 def upsert(self,m:MaterialRecord):
  with self.db:
   self.db.execute("""INSERT INTO materials VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(material_id) DO UPDATE SET
    name=excluded.name,formula=excluded.formula,phase=excluded.phase,description=excluded.description,
    tags_json=excluded.tags_json,source_ids_json=excluded.source_ids_json,schema_version=excluded.schema_version""",
    (m.material_id,m.name,m.formula,m.phase.value,m.description,json.dumps(m.tags),json.dumps(m.source_ids),m.schema_version))
   self.db.execute("DELETE FROM properties WHERE material_id=?",(m.material_id,))
   for p in m.properties:
    self.db.execute("INSERT INTO properties VALUES(?,?,?,?,?,?,?,?)",(m.material_id,p.property_id,p.value,p.unit,
     json.dumps(p.condition.__dict__,sort_keys=True),p.uncertainty,p.evidence_class,json.dumps(p.source_ids)))
 def get(self,material_id):
  r=self.db.execute("SELECT * FROM materials WHERE material_id=?",(material_id,)).fetchone()
  if not r:raise MaterialError("unknown material")
  props=[]
  for p in self.db.execute("SELECT property_id,value,unit,condition_json,uncertainty,evidence_class,source_ids_json FROM properties WHERE material_id=?",(material_id,)):
   c=PropertyCondition(**json.loads(p[3]));props.append(PropertyValue(p[0],p[1],p[2],c,p[4],p[5],tuple(json.loads(p[6]))))
  return MaterialRecord(r[0],r[1],r[2],MaterialPhase(r[3]),r[4],tuple(json.loads(r[5])),tuple(props),tuple(json.loads(r[6])),r[7])
 def search(self,text="",phase=None,tag=None):
  rows=self.db.execute("SELECT material_id FROM materials ORDER BY name").fetchall();out=[]
  q=text.casefold()
  for (mid,) in rows:
   m=self.get(mid)
   if q and q not in m.name.casefold() and q not in m.formula.casefold() and q not in m.description.casefold():continue
   if phase and m.phase!=phase:continue
   if tag and tag not in m.tags:continue
   out.append(m)
  return out
 def property_series(self,material_id,property_id):
  m=self.get(material_id)
  return tuple(p for p in m.properties if p.property_id==property_id)
 def close(self):self.db.close()

def _ensure_atomic_tables(self):
 self.db.execute("""CREATE TABLE IF NOT EXISTS composition_profiles(
 material_id TEXT PRIMARY KEY,profile_json TEXT NOT NULL)""");self.db.commit()
def _save_composition(self,profile):
 from dataclasses import asdict
 _ensure_atomic_tables(self)
 with self.db:self.db.execute("INSERT OR REPLACE INTO composition_profiles VALUES(?,?)",(profile.material_id,json.dumps(asdict(profile),sort_keys=True)))
def _load_composition(self,material_id):
 from .atomic import CompositionEntry,DopantRecord,DefectRecord
 from .composition import CompositionProfile
 _ensure_atomic_tables(self);r=self.db.execute("SELECT profile_json FROM composition_profiles WHERE material_id=?",(material_id,)).fetchone()
 if not r:return None
 d=json.loads(r[0])
 return CompositionProfile(d["material_id"],tuple(CompositionEntry(**x) for x in d["entries"]),
  tuple(DopantRecord(**{**x,"source_ids":tuple(x.get("source_ids",[]))}) for x in d["dopants"]),
  tuple(DefectRecord(**{**x,"source_ids":tuple(x.get("source_ids",[]))}) for x in d["defects"]))
MaterialsDatabase.ensure_atomic_tables=_ensure_atomic_tables
MaterialsDatabase.save_composition=_save_composition
MaterialsDatabase.load_composition=_load_composition
