import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HWI"
sp=importlib.util.spec_from_file_location("skl_hwi",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_hwi"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_rising(self):
  c=q.TriggerConfiguration("t",q.TriggerSource.HARDWARE,q.TriggerEdge.RISING,1,.2);self.assertTrue(q.threshold_crossed(.8,1.2,c))
 def test_falling(self):
  c=q.TriggerConfiguration("t",q.TriggerSource.HARDWARE,q.TriggerEdge.FALLING,1,.2);self.assertTrue(q.threshold_crossed(1.2,.8,c))
 def test_hysteresis_blocks_noise(self):
  c=q.TriggerConfiguration("t",q.TriggerSource.HARDWARE,q.TriggerEdge.RISING,1,.2);self.assertFalse(q.threshold_crossed(.95,1.05,c))
 def test_trigger_requires_threshold(self):
  with self.assertRaises(ValueError):q.threshold_crossed(0,1,q.TriggerConfiguration("t",q.TriggerSource.SOFTWARE))
 def test_sync_ok(self):
  g=q.SynchronizationGroup("g",("a","b"),.01);ok,skew=q.synchronization_within_tolerance({"a":1,"b":1.005},g);self.assertTrue(ok);self.assertAlmostEqual(skew,.005)
 def test_sync_fail(self):
  g=q.SynchronizationGroup("g",("a","b"),.001);self.assertFalse(q.synchronization_within_tolerance({"a":1,"b":1.01},g)[0])
 def test_sync_missing(self):
  g=q.SynchronizationGroup("g",("a","b"),.1);ok,skew=q.synchronization_within_tolerance({"a":1},g);self.assertFalse(ok);self.assertTrue(math.isinf(skew))
 def test_interlock_safe(self):self.assertTrue(q.interlocks_allow_execution((q.Interlock("i","door"),)))
 def test_interlock_trip(self):self.assertFalse(q.interlocks_allow_execution((q.Interlock("i","door",q.InterlockState.TRIPPED),)))
 def test_timeline_order(self):
  t=q.ExperimentTimeline((q.SequenceStep("b",2,"x"),q.SequenceStep("a",1,"x")));self.assertEqual([s.step_id for _,s in t.scheduled(10)],["a","b"])
 def test_duplicate_step(self):
  with self.assertRaises(ValueError):q.ExperimentTimeline((q.SequenceStep("a",0,"x"),q.SequenceStep("a",1,"x")))
 def test_preflight(self):
  p=q.coordinated_preflight((q.Interlock("i","door"),),q.SynchronizationGroup("g",("a","b"),.1),{"a":0,"b":.01});self.assertTrue(p.ready)
 def test_preflight_blocked(self):
  p=q.coordinated_preflight((q.Interlock("i","door",q.InterlockState.BLOCKED),));self.assertFalse(p.ready)
 def test_execute(self):
  e=q.CoordinatedExecutor({"go":lambda s:"ok"});t=q.ExperimentTimeline((q.SequenceStep("s",1,"go","D1"),));p=q.coordinated_preflight(())
  self.assertEqual(e.execute(t,10,p)[0][:4],(11,"s","go","D1"))
 def test_execute_blocked(self):
  e=q.CoordinatedExecutor({"go":lambda s:"ok"});t=q.ExperimentTimeline((q.SequenceStep("s",0,"go"),));p=q.coordinated_preflight((q.Interlock("i","x",q.InterlockState.TRIPPED),))
  with self.assertRaises(PermissionError):e.execute(t,0,p)
 def test_confirmation(self):
  e=q.CoordinatedExecutor({"go":lambda s:"ok"});t=q.ExperimentTimeline((q.SequenceStep("s",0,"go",requires_confirmation=True),));p=q.coordinated_preflight(())
  with self.assertRaises(PermissionError):e.execute(t,0,p)
  self.assertEqual(len(e.execute(t,0,p,("s",))),1)
 def test_acquisition_preserved(self):self.assertTrue(hasattr(q,"AcquisitionSession"))
 def test_metrology_preserved(self):self.assertTrue(hasattr(q,"UncertaintyBudget"))
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/experiment_timeline.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HWI-06")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
