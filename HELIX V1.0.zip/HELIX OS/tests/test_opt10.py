import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-OPT"
sp=importlib.util.spec_from_file_location("skl_opt",M/"__init__.py",submodule_search_locations=[str(M)])
o=importlib.util.module_from_spec(sp);sys.modules["skl_opt"]=o;sp.loader.exec_module(o)
class T(unittest.TestCase):
 def test_cross_engine(self):
  r=o.run_cross_engine_validation();self.assertTrue(r.passed);self.assertEqual(r.passed_count,r.total_count);self.assertGreaterEqual(r.total_count,20)
 def test_completion(self):
  c=json.loads((R/"OPT_COMPLETE.json").read_text());self.assertEqual(c["status"],"COMPLETE");self.assertEqual(c["sequence"],{"completed":10,"total":10})
 def test_manifest_complete(self):
  m=json.loads((M/"module.json").read_text());self.assertEqual(m["patch_id"],"SKL-OPT-10");self.assertIn("COMPLETE",m["status"])
 def test_registry_validation(self):self.assertIn("OPT-VALIDATE",{x.model_id for x in o.OpticalRegistry().all()})
 def test_foundation(self):self.assertAlmostEqual(o.frequency_hz(1),o.C)
 def test_transmitter(self):self.assertGreater(o.rayleigh_range_m(1e-6,1),0)
 def test_receiver(self):self.assertGreater(o.telescope_collection_area_m2(1),0)
 def test_pat(self):self.assertEqual(o.gaussian_pointing_coupling(0,1e-6),1)
 def test_atmosphere(self):self.assertEqual(o.transmission_from_optical_depth(0),1)
 def test_digital(self):self.assertEqual(o.bits_per_ppm_symbol(16),4)
 def test_integrated(self):
  s=o.IntegratedOpticalScenario(1550e-9,1e9,.2,1,10);self.assertGreater(o.simulate(s).received_power_w,0)
 def test_mission(self):self.assertEqual(o.data_volume_bits(100,10),1000)
 def test_system_sim(self):
  s=o.IntegratedOpticalScenario(1550e-9,1e9,.2,1,10);self.assertEqual(o.monte_carlo(s,5,seed=1).trials,5)
 def test_dependencies(self):
  m=json.loads((M/"module.json").read_text());self.assertEqual(m["dependencies"],["SKL-MAT","SKL-PHO","SKL-RF"])
 def test_rf_complete(self):self.assertEqual(json.loads((R/"RF_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_hqic_complete(self):self.assertEqual(json.loads((R/"HQIC_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_qmem_complete(self):self.assertEqual(json.loads((R/"QMEM_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_storage_complete(self):self.assertEqual(json.loads((R/"STO_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_photonics_complete(self):self.assertEqual(json.loads((R/"PHO_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
 def test_no_pyc(self):self.assertFalse(list(R.rglob("*.pyc")))
if __name__=="__main__":unittest.main()
