from dataclasses import dataclass
from enum import Enum
class HALSource(str,Enum):
 HARDWARE="HARDWARE";IMPORTED="IMPORTED";SIMULATION="SIMULATION"
class DeviceState(str,Enum):
 DISCONNECTED="DISCONNECTED";CONNECTED="CONNECTED";ARMED="ARMED";FAULT="FAULT"
@dataclass(frozen=True)
class DeviceDescriptor:
 device_id:str;name:str;device_type:str;source:HALSource;capabilities:tuple[str,...];writable:bool=False
@dataclass(frozen=True)
class Measurement:
 device_id:str;channel:str;value:float;unit:str;timestamp_unix:float;source:HALSource
 quality:str="VALID";provenance_id:str|None=None
