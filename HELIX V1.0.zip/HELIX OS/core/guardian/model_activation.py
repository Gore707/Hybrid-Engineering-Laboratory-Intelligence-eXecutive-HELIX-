from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
import json,os
from .local_llm import LocalModelConfig,save_model_config

@dataclass(frozen=True)
class ModelRecommendation:
    model_class:str
    quantization_class:str
    context_size:int
    gpu_layers_mode:str
    reason:str
    requires_benchmark:bool=True

def load_diagnostic(path:Path):
    if not path.exists():
        raise FileNotFoundError(f"Guardian on-host diagnostic not found: {path}")
    return json.loads(path.read_text(encoding="utf-8"))

def recommend_from_diagnostic(report:dict)->ModelRecommendation:
    b=report.get("guardian_budget",{})
    vram=b.get("vram_bytes") or 0
    ram=b.get("ram_total_bytes") or 0
    llama=bool(report.get("modules",{}).get("llama_cpp"))
    gib=vram/(1024**3)
    if gib>=16:
        cls,q,ctx="7B–14B instruct","Q4_K_M/Q5_K_M candidate",8192
    elif gib>=8:
        cls,q,ctx="7B–8B instruct","Q4_K_M candidate",6144
    elif gib>=6:
        cls,q,ctx="3B–7B instruct","Q4_K_M candidate",4096
    else:
        cls,q,ctx="1B–3B instruct / CPU fallback","Q4_K_M candidate",4096
    reason=f"Planning recommendation from detected VRAM ({gib:.1f} GiB). "
    reason+=("llama_cpp is installed." if llama else "llama_cpp is not yet available.")
    reason+=" Exact model and GPU offload require an on-host benchmark."
    return ModelRecommendation(cls,q,ctx,"benchmark-required",reason,True)

def activate_local_gguf(root:Path,model_path:Path,model_name:str,context_size:int=4096,
                        max_tokens:int=512,temperature:float=0.2,gpu_layers:int=0,threads:int|None=None):
    root=Path(root);model_path=Path(model_path).expanduser().resolve()
    if not model_path.exists():raise FileNotFoundError(model_path)
    if model_path.suffix.lower()!=".gguf":raise ValueError("Guardian local model must be a GGUF file.")
    cfg=LocalModelConfig(str(model_path),model_name,int(context_size),int(max_tokens),
                         float(temperature),int(gpu_layers),threads)
    save_model_config(root/"user"/"guardian"/"local_model.json",cfg)
    return cfg
