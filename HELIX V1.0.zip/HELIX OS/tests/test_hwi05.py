import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HWI"
sp=importlib.util.spec_from_file_location("skl_hwi",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_hwi"]=q;sp.loader.exec_module(q)
def ch(cid="c1",enabled=True):return q.ChannelConfiguration(cid,"D1","voltage","V",10,q.ClockSource.HOST_MONOTONIC,enabled)
class T(unittest.TestCase):
 def test_channel(self):self.assertEqual(ch().nominal_sample_rate_hz,10)
 def test_bad_rate(self):
  with self.assertRaises(ValueError):q.ChannelConfiguration("c","d","x","V",0)
 def test_buffer(self):
  b=q.SampleBuffer(2);b.append(q.Sample(0,0,1));b.append(q.Sample(1,.1,2));b.append(q.Sample(2,.2,3));self.assertEqual(b.overwritten,1);self.assertEqual(len(b),2)
 def test_missing(self):self.assertEqual(q.missing_sequences((q.Sample(0,0,1),q.Sample(2,.2,1))),(1,))
 def test_sequence_order(self):
  with self.assertRaises(ValueError):q.missing_sequences((q.Sample(1,0,1),q.Sample(1,.1,1)))
 def test_jitter(self):self.assertAlmostEqual(q.timestamp_jitter_s((q.Sample(0,0,1),q.Sample(1,.11,1)),10)[0],.01)
 def test_sync(self):self.assertEqual(q.synchronization_offsets((q.Sample(0,1,1),),(q.Sample(0,1.02,1),))[0][1],.020000000000000018)
 def test_session(self):
  s=q.AcquisitionSession("S","E",(ch(),));s.start(1);s.ingest("c1",q.Sample(0,1,2));s.stop(2);r=s.records()[0];self.assertEqual(r.sample_count,1)
 def test_ingest_before_start(self):
  s=q.AcquisitionSession("S","E",(ch(),))
  with self.assertRaises(RuntimeError):s.ingest("c1",q.Sample(0,0,1))
 def test_disabled(self):
  s=q.AcquisitionSession("S","E",(ch(enabled=False),));s.start(0)
  with self.assertRaises(RuntimeError):s.ingest("c1",q.Sample(0,0,1))
 def test_stop_before_start_time(self):
  s=q.AcquisitionSession("S","E",(ch(),));s.start(2)
  with self.assertRaises(ValueError):s.stop(1)
 def test_records_before_stop(self):
  with self.assertRaises(RuntimeError):q.AcquisitionSession("S","E",(ch(),)).records()
 def test_record_drops(self):
  s=q.AcquisitionSession("S","E",(ch(),));s.start(0);s.ingest("c1",q.Sample(0,0,1));s.ingest("c1",q.Sample(2,.2,1));s.stop(1);self.assertEqual(s.records()[0].dropped_sequences,(1,))
 def test_manifest_handoff(self):
  s=q.AcquisitionSession("S","E",(ch(),));s.start(0);s.ingest("c1",q.Sample(0,0,1));s.stop(1);x=q.scientific_data_manifest(s.records()[0],"data/E/S/c1.h5");self.assertEqual(x["storage_contract"],"SCIENTIFIC_BINARY_ARRAY");self.assertNotIn("samples",x)
 def test_metrology_preserved(self):self.assertTrue(hasattr(q,"UncertaintyBudget"))
 def test_driver_preserved(self):self.assertTrue(hasattr(q,"SCPIDriver"))
 def test_transport_preserved(self):self.assertEqual(q.TransportKind.TCP.value,"TCP")
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/acquisition_manifest.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HWI-05")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
