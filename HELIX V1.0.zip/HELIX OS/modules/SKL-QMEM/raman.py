from __future__ import annotations
from dataclasses import dataclass
import math

def two_photon_raman_detuning_rad_s(signal_detuning_rad_s,control_detuning_rad_s,ground_splitting_rad_s=0.0):
    return signal_detuning_rad_s-control_detuning_rad_s-ground_splitting_rad_s

def effective_raman_rabi_rad_s(omega_signal_rad_s,omega_control_rad_s,one_photon_detuning_rad_s):
    if one_photon_detuning_rad_s==0: raise ValueError("off-resonant Raman model requires nonzero one-photon detuning")
    return omega_signal_rad_s*omega_control_rad_s/(2*one_photon_detuning_rad_s)

def ac_stark_shift_rad_s(omega_control_rad_s,one_photon_detuning_rad_s):
    if one_photon_detuning_rad_s==0: raise ValueError("nonzero detuning required")
    return omega_control_rad_s**2/(4*one_photon_detuning_rad_s)

def spontaneous_scattering_rate_s_inv(omega_control_rad_s,one_photon_detuning_rad_s,excited_decay_rate_s_inv):
    if one_photon_detuning_rad_s==0 or excited_decay_rate_s_inv<0:
        raise ValueError("invalid scattering inputs")
    return excited_decay_rate_s_inv*omega_control_rad_s**2/(4*one_photon_detuning_rad_s**2)

def scattering_survival(interaction_time_s,scattering_rate_s_inv):
    if interaction_time_s<0 or scattering_rate_s_inv<0: raise ValueError("nonnegative inputs required")
    return math.exp(-scattering_rate_s_inv*interaction_time_s)

def idealized_raman_bandwidth_rad_s(omega_control_rad_s,one_photon_detuning_rad_s,excited_decay_rad_s):
    if one_photon_detuning_rad_s==0 or excited_decay_rad_s<=0:
        raise ValueError("valid detuning and decay required")
    return abs(omega_control_rad_s**2/(4*one_photon_detuning_rad_s**2))*excited_decay_rad_s

def time_bandwidth_product(storage_time_s,bandwidth_hz):
    if storage_time_s<0 or bandwidth_hz<0: raise ValueError("nonnegative inputs required")
    return storage_time_s*bandwidth_hz

def retrieval_efficiency(write_efficiency,read_efficiency,spin_survival,scattering_survival_factor=1.0):
    vals=(write_efficiency,read_efficiency,spin_survival,scattering_survival_factor)
    if any(v<0 or v>1 for v in vals): raise ValueError("efficiencies/survival factors must be 0..1")
    return math.prod(vals)

@dataclass(frozen=True)
class RamanControl:
    omega_control_rad_s:float
    one_photon_detuning_rad_s:float
    excited_decay_rate_s_inv:float
    interaction_time_s:float
    def __post_init__(self):
        if self.omega_control_rad_s<0 or self.one_photon_detuning_rad_s==0 or self.excited_decay_rate_s_inv<0 or self.interaction_time_s<0:
            raise ValueError("invalid Raman control parameters")
    @property
    def stark_shift_rad_s(self):
        return ac_stark_shift_rad_s(self.omega_control_rad_s,self.one_photon_detuning_rad_s)
    @property
    def scattering_rate_s_inv(self):
        return spontaneous_scattering_rate_s_inv(self.omega_control_rad_s,self.one_photon_detuning_rad_s,self.excited_decay_rate_s_inv)
    @property
    def scattering_survival(self):
        return globals()["scattering_survival"](self.interaction_time_s,self.scattering_rate_s_inv)

@dataclass(frozen=True)
class RamanMemoryEstimate:
    write_efficiency:float
    read_efficiency:float
    spin_coherence_time_s:float
    control:RamanControl
    def __post_init__(self):
        if not 0<=self.write_efficiency<=1 or not 0<=self.read_efficiency<=1 or self.spin_coherence_time_s<=0:
            raise ValueError("invalid Raman-memory parameters")
    def spin_survival(self,storage_time_s):
        if storage_time_s<0: raise ValueError("nonnegative storage time required")
        return math.exp(-storage_time_s/self.spin_coherence_time_s)
    def total_efficiency(self,storage_time_s):
        return retrieval_efficiency(self.write_efficiency,self.read_efficiency,
                                    self.spin_survival(storage_time_s),self.control.scattering_survival)
