from __future__ import annotations
from dataclasses import dataclass,field
from enum import Enum
import math

class SimulationStatus(str,Enum):
    PASS="PASS"; DEGRADED="DEGRADED"; FAIL="FAIL"

@dataclass(frozen=True)
class HQICScenario:
    scenario_id:str
    classical_raw_ber:float
    classical_code_distance:int
    quantum_physical_error:float
    quantum_code_distance:int
    quantum_cycles:int
    transduction_efficiencies:tuple[float,...]
    transducer_noise_probabilities:tuple[float,...]
    cooling_capacity_w:float
    conductive_load_w:float
    radiative_load_w:float
    active_load_w:float
    alignment_error_m:float
    optical_spot_radius_m:float
    manufacturing_tolerances_m:tuple[float,...]
    max_tolerance_stack_m:float
    min_transduction_efficiency:float=.1
    min_quantum_survival:float=.5
    max_classical_logical_ber:float=1e-6
    def __post_init__(self):
        if not self.scenario_id.strip(): raise ValueError("scenario id required")
        if not 0<=self.classical_raw_ber<=1 or not 0<=self.quantum_physical_error<=1: raise ValueError("probabilities 0..1")
        if self.classical_code_distance<1 or self.classical_code_distance%2==0 or self.quantum_code_distance<1 or self.quantum_code_distance%2==0:
            raise ValueError("odd code distances required")
        if self.quantum_cycles<0: raise ValueError("nonnegative cycles")
        if not self.transduction_efficiencies or any(not 0<=x<=1 for x in self.transduction_efficiencies): raise ValueError("invalid efficiencies")
        if len(self.transducer_noise_probabilities)!=len(self.transduction_efficiencies) or any(not 0<=x<=1 for x in self.transducer_noise_probabilities):
            raise ValueError("one valid noise probability per transducer stage required")
        if min(self.cooling_capacity_w,self.conductive_load_w,self.radiative_load_w,self.active_load_w,self.alignment_error_m,self.max_tolerance_stack_m)<0:
            raise ValueError("nonnegative engineering values required")
        if self.optical_spot_radius_m<=0 or any(x<0 for x in self.manufacturing_tolerances_m): raise ValueError("invalid geometry/tolerances")

@dataclass(frozen=True)
class HQICSimulationResult:
    scenario_id:str
    classical_logical_ber:float
    quantum_logical_error:float
    quantum_cycle_survival:float
    transduction_efficiency:float
    transduction_noise_survival:float
    thermal_load_w:float
    thermal_margin_w:float
    alignment_fraction:float
    tolerance_rss_m:float
    failures:tuple[str,...]
    warnings:tuple[str,...]
    status:SimulationStatus
    provenance:str="SIMULATION"

def _rep_error(p,d):
    t=(d+1)//2
    return sum(math.comb(d,k)*p**k*(1-p)**(d-k) for k in range(t,d+1))

def run_hqic_scenario(s:HQICScenario):
    cber=_rep_error(s.classical_raw_ber,s.classical_code_distance)
    qerr=_rep_error(s.quantum_physical_error,s.quantum_code_distance)
    qsurv=(1-qerr)**s.quantum_cycles
    eta=math.prod(s.transduction_efficiencies)
    ns=math.prod(1-x for x in s.transducer_noise_probabilities)
    load=s.conductive_load_w+s.radiative_load_w+s.active_load_w
    margin=s.cooling_capacity_w-load
    align=s.alignment_error_m/s.optical_spot_radius_m
    rss=math.sqrt(sum(x*x for x in s.manufacturing_tolerances_m))
    failures=[];warnings=[]
    if cber>s.max_classical_logical_ber: failures.append("classical_integrity")
    if qsurv<s.min_quantum_survival: failures.append("quantum_survival")
    if eta<s.min_transduction_efficiency: failures.append("transduction_efficiency")
    if margin<0: failures.append("thermal_capacity")
    if align>1: failures.append("optical_alignment")
    if rss>s.max_tolerance_stack_m: failures.append("manufacturing_tolerance")
    if not failures:
        if margin < .2*s.cooling_capacity_w: warnings.append("low_thermal_margin")
        if align > .5: warnings.append("alignment_margin")
        if eta < 2*s.min_transduction_efficiency: warnings.append("transduction_margin")
    status=SimulationStatus.FAIL if failures else (SimulationStatus.DEGRADED if warnings else SimulationStatus.PASS)
    return HQICSimulationResult(s.scenario_id,cber,qerr,qsurv,eta,ns,load,margin,align,rss,tuple(failures),tuple(warnings),status)

def sweep_parameter(base:HQICScenario,field_name,values):
    if not hasattr(base,field_name): raise ValueError("unknown scenario field")
    from dataclasses import replace
    return tuple(run_hqic_scenario(replace(base,**{field_name:v},scenario_id=f"{base.scenario_id}:{field_name}={v}")) for v in values)

def summarize_results(results):
    r=tuple(results)
    if not r: raise ValueError("results required")
    return {"count":len(r),"pass":sum(x.status==SimulationStatus.PASS for x in r),
            "degraded":sum(x.status==SimulationStatus.DEGRADED for x in r),
            "fail":sum(x.status==SimulationStatus.FAIL for x in r),
            "provenance":sorted(set(x.provenance for x in r))}
