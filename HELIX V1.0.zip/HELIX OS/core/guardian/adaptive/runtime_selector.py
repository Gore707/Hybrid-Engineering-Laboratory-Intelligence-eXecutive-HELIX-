from dataclasses import dataclass
@dataclass(frozen=True)
class RuntimeRecommendation:
 class_name:str;parameter_range_billions:tuple[int,int];reason:str;requires_installation:bool
class RuntimeSelector:
 def recommend(self,compute_summary,devices):
  gpus=[d for d in devices if d.kind=="GPU" and d.memory_bytes]
  max_vram=max((d.memory_bytes for d in gpus),default=0)
  gib=max_vram/(1024**3)
  if gib>=16:return RuntimeRecommendation("quantized-local-reasoning",(7,14),"Detected GPU memory supports evaluating 7B–14B-class quantized runtimes.",True)
  if gib>=8:return RuntimeRecommendation("quantized-local-reasoning",(7,7),"Detected GPU memory suggests starting with a quantized ~7B-class runtime.",True)
  return RuntimeRecommendation("extractive-local",(0,0),"Retain C16 local grounded runtime until measured resources support a reasoning model.",False)
