from __future__ import annotations
import re
from dataclasses import dataclass

@dataclass(frozen=True)
class Interpretation:
    matched: bool
    action_id: str | None = None
    parameters: dict | None = None
    confidence: float = 0.0
    explanation: str = ""

class RuleBasedInterpreter:
    """Bounded deterministic C08 natural-language command interpreter."""
    def interpret(self,text:str,layout_names:list[str]) -> Interpretation:
        t=" ".join(text.strip().split())
        low=t.lower()

        if re.fullmatch(r"(save|write) (the )?project",low):
            return Interpretation(True,"project.save",{},1.0,"Matched project-save intent.")

        if re.fullmatch(r"(make|create|write) (a )?(recovery )?checkpoint",low):
            return Interpretation(True,"session.checkpoint",{},1.0,"Matched checkpoint intent.")

        if re.fullmatch(r"(reset|restore) (the )?(workspace|layout)( to (the )?default)?",low):
            return Interpretation(True,"workspace.reset",{},0.98,"Matched default-workspace intent.")

        m=re.fullmatch(r"save (the )?(workspace|layout)( as)? (?P<name>.+)",t,re.I)
        if m:
            name=m.group("name").strip().strip('"')
            return Interpretation(True,"workspace.save",{"name":name},0.98,"Matched named workspace-save intent.")

        m=re.fullmatch(r"(restore|load|open) (the )?(workspace|layout) (?P<name>.+)",t,re.I)
        if m:
            requested=m.group("name").strip().strip('"')
            exact=next((n for n in layout_names if n.lower()==requested.lower()),None)
            if exact:
                return Interpretation(True,"workspace.restore",{"name":exact},0.98,"Matched saved workspace name.")
            return Interpretation(False,confidence=0.0,
                explanation=f"No saved workspace named '{requested}'.")

        return Interpretation(False,confidence=0.0,
            explanation="No deterministic C08 intent matched. Use the structured menu, LIST, or Expert RUN syntax.")
