import unittest,importlib.util,sys,json,math
import numpy as np
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM"
sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_ket_density(self):
  r=q.ket_to_density([1,0]);self.assertTrue(np.allclose(r,[[1,0],[0,0]]))
 def test_purity_pure(self):self.assertAlmostEqual(q.purity([[1,0],[0,0]]),1)
 def test_purity_mixed(self):self.assertAlmostEqual(q.purity([[.5,0],[0,.5]]),.5)
 def test_entropy(self):self.assertAlmostEqual(q.von_neumann_entropy_bits([[.5,0],[0,.5]]),1)
 def test_bloch(self):
  b=q.BlochVector(1,0,0);self.assertTrue(np.allclose(b.density_matrix(),[[.5,.5],[.5,.5]]))
 def test_bloch_roundtrip(self):
  b=q.bloch_from_density(q.BlochVector(.2,.3,.4).density_matrix());self.assertAlmostEqual(b.y,.3)
 def test_bad_bloch(self):
  with self.assertRaises(ValueError):q.BlochVector(1,1,1)
 def test_trace_distance(self):self.assertAlmostEqual(q.trace_distance([[1,0],[0,0]],[[0,0],[0,1]]),1)
 def test_fidelity(self):self.assertAlmostEqual(q.state_fidelity([[1,0],[0,0]],[[1,0],[0,0]]),1)
 def test_amplitude_damping(self):
  o=q.amplitude_damping_qubit([[0,0],[0,1]],1);self.assertTrue(np.allclose(o,[[1,0],[0,0]]))
 def test_phase_damping(self):
  o=q.phase_damping_qubit([[.5,.5],[.5,.5]],1);self.assertTrue(np.allclose(o,[[.5,0],[0,.5]]))
 def test_t1(self):self.assertAlmostEqual(q.t1_relaxation_probability(1,1),1-math.exp(-1))
 def test_t2(self):self.assertAlmostEqual(q.t2_coherence_factor(1,1),math.exp(-1))
 def test_t1t2_physical_bound(self):
  with self.assertRaises(ValueError):q.evolve_t1_t2_qubit([[1,0],[0,0]],1,1,3)
 def test_t1t2_trace(self):
  o=q.evolve_t1_t2_qubit([[.5,.5],[.5,.5]],.1,1,1);self.assertAlmostEqual(np.trace(o).real,1)
 def test_no_cloning_preserved(self):
  with self.assertRaises(ValueError):q.no_cloning_guard(2,True)
 def test_registry(self):
  ids={x.model_id for x in q.QuantumMemoryRegistry().all()}
  self.assertTrue({"QMEM-PURITY","QMEM-ENTROPY-VN","QMEM-TRACE-DIST","QMEM-T1","QMEM-T2"}<=ids)
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-QMEM-02")
 def test_dependencies(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO"])
 def test_core_manifest_location(self):
  self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists())
  for d in (R/"modules").iterdir():
   if d.is_dir():self.assertFalse((d/"CORE_1_0_MANIFEST.json").exists())
 def test_completed_modules(self):
  self.assertEqual(json.loads((R/"STO_COMPLETE.json").read_text())["status"],"COMPLETE")
  self.assertEqual(json.loads((R/"PHO_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
