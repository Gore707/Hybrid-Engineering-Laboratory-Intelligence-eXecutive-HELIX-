@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo.
    echo HELIX virtual environment is not installed in this folder.
    echo Run install_helix.ps1 once from PowerShell, then launch HELIX.bat again.
    echo.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" "HELIX.py" %*
if errorlevel 1 (
    echo.
    echo HELIX exited with an error. Check data\logs and data\crash.
    pause
)
endlocal
