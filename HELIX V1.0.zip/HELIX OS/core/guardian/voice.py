from __future__ import annotations
import platform

class VoiceUnavailable(RuntimeError): pass

def recognize_once_windows() -> str:
    if platform.system()!="Windows":
        raise VoiceUnavailable("Windows Speech API voice input is available only on Windows.")
    try:
        import win32com.client
    except ImportError as exc:
        raise VoiceUnavailable("pywin32 is required for Windows Speech API voice input.") from exc

    recognizer=win32com.client.Dispatch("SAPI.SpSharedRecognizer")
    context=recognizer.CreateRecoContext()
    grammar=context.CreateGrammar()
    grammar.DictationLoad()
    grammar.DictationSetState(1)
    event=context.WaitForNotifyEvent(8000)
    if not event:
        raise VoiceUnavailable("No speech was recognized within 8 seconds.")
    result=context.GetEvents(1)
    if not result:
        raise VoiceUnavailable("Speech event contained no recognition result.")
    phrase=result[0].RecoResult.PhraseInfo.GetText()
    if not phrase.strip():
        raise VoiceUnavailable("Speech recognition returned empty text.")
    return phrase.strip()

def speak_windows(text:str) -> None:
    """Optional local spoken response. Never executes recognized commands."""
    if platform.system()!="Windows":
        raise VoiceUnavailable("Windows Speech API speech output is available only on Windows.")
    try:import win32com.client
    except ImportError as exc:raise VoiceUnavailable("pywin32 is required for Windows Speech API speech output.") from exc
    speaker=win32com.client.Dispatch("SAPI.SpVoice")
    speaker.Speak(str(text))
