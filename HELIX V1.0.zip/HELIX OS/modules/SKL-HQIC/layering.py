from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

class PhysicalLayerRole(str,Enum):
    PROTECTIVE="PROTECTIVE"
    CLASSICAL_5D_ARCHIVE="CLASSICAL_5D_ARCHIVE"
    QUANTUM_ACTIVE="QUANTUM_ACTIVE"
    OPTICAL_COUPLING="OPTICAL_COUPLING"
    THERMAL_ISOLATION="THERMAL_ISOLATION"
    ELECTROMAGNETIC_SHIELD="ELECTROMAGNETIC_SHIELD"
    CONTROLLER_INTERFACE="CONTROLLER_INTERFACE"

@dataclass(frozen=True)
class LayerGeometry:
    layer_id:str
    role:PhysicalLayerRole
    thickness_m:float
    width_m:float
    height_m:float
    refractive_index:float|None=None
    def __post_init__(self):
        if not self.layer_id.strip() or self.thickness_m<=0 or self.width_m<=0 or self.height_m<=0:
            raise ValueError("positive physical dimensions required")
        if self.refractive_index is not None and self.refractive_index<=0:
            raise ValueError("positive refractive index required")
    @property
    def volume_m3(self): return self.thickness_m*self.width_m*self.height_m
    @property
    def area_m2(self): return self.width_m*self.height_m

@dataclass(frozen=True)
class OpticalInterface:
    layer_a:str
    layer_b:str
    n_a:float
    n_b:float
    def __post_init__(self):
        if not self.layer_a.strip() or not self.layer_b.strip() or self.layer_a==self.layer_b or self.n_a<=0 or self.n_b<=0:
            raise ValueError("invalid optical interface")
    @property
    def normal_incidence_reflectance(self):
        return ((self.n_a-self.n_b)/(self.n_a+self.n_b))**2
    @property
    def ideal_transmittance(self): return 1-self.normal_incidence_reflectance

def diffraction_limited_spot_radius_m(wavelength_m,numerical_aperture):
    if wavelength_m<=0 or numerical_aperture<=0 or numerical_aperture>1.5:
        raise ValueError("invalid wavelength or numerical aperture")
    return 0.61*wavelength_m/numerical_aperture

def axial_confocal_scale_m(wavelength_m,refractive_index,numerical_aperture):
    if wavelength_m<=0 or refractive_index<=0 or numerical_aperture<=0:
        raise ValueError("invalid optical parameters")
    return 2*refractive_index*wavelength_m/(numerical_aperture**2)

def layer_address_capacity(width_m,height_m,pitch_x_m,pitch_y_m):
    if min(width_m,height_m,pitch_x_m,pitch_y_m)<=0: raise ValueError("positive geometry required")
    return math.floor(width_m/pitch_x_m)*math.floor(height_m/pitch_y_m)

def attenuation_transmission(alpha_m_inv,path_length_m):
    if alpha_m_inv<0 or path_length_m<0: raise ValueError("nonnegative attenuation/path required")
    return math.exp(-alpha_m_inv*path_length_m)

@dataclass(frozen=True)
class IsolationRequirement:
    name:str
    maximum_cross_coupling:float
    achieved_cross_coupling:float
    def __post_init__(self):
        if not self.name.strip() or not 0<=self.maximum_cross_coupling<=1 or not 0<=self.achieved_cross_coupling<=1:
            raise ValueError("cross-coupling values must be 0..1")
    @property
    def passes(self): return self.achieved_cross_coupling<=self.maximum_cross_coupling

@dataclass
class CartridgeStack:
    cartridge_id:str
    layers:list[LayerGeometry]
    def __post_init__(self):
        if not self.cartridge_id.strip() or not self.layers: raise ValueError("cartridge id and layers required")
        ids=[x.layer_id for x in self.layers]
        if len(ids)!=len(set(ids)): raise ValueError("duplicate physical layer id")
        w,h=self.layers[0].width_m,self.layers[0].height_m
        if any(not math.isclose(x.width_m,w) or not math.isclose(x.height_m,h) for x in self.layers):
            raise ValueError("baseline stack model requires common layer footprint")
    @property
    def total_thickness_m(self): return sum(x.thickness_m for x in self.layers)
    @property
    def total_volume_m3(self): return sum(x.volume_m3 for x in self.layers)
    def role_layers(self,role): return tuple(x for x in self.layers if x.role==role)
    def validate_hybrid_stack(self):
        roles={x.role for x in self.layers}
        required={PhysicalLayerRole.CLASSICAL_5D_ARCHIVE,PhysicalLayerRole.QUANTUM_ACTIVE,
                  PhysicalLayerRole.OPTICAL_COUPLING,PhysicalLayerRole.CONTROLLER_INTERFACE}
        missing=required-roles
        return (not missing,tuple(sorted(x.value for x in missing)))
