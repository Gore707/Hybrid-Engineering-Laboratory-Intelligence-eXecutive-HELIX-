from __future__ import annotations
import json,os,time
from pathlib import Path
from .detect import cpu_device,detect_nvidia,detect_amd
from .backends import probe_backends

class ComputeBackendManager:
    def __init__(self,profile_path:Path|None=None):
        self.profile_path=profile_path
        self.devices=[]
        self.capabilities=()
        self.selected_backend=None
    def detect(self):
        self.devices=[cpu_device(),*detect_nvidia(),*detect_amd()]
        self.capabilities=probe_backends(self.devices)
        self.selected_backend=self.choose_backend()
        if self.profile_path:self.save_profile()
        return self.devices
    def choose_backend(self,preferred="auto"):
        available={c.name:c for c in self.capabilities if c.available}
        if preferred!="auto":
            if preferred in available:return preferred
            if "numpy" in available:return "numpy"
            raise RuntimeError("No compute backend is available.")
        for name in ("cuda","rocm","numpy"):
            if name in available:return name
        raise RuntimeError("No compute backend is available.")
    def capability(self,name):
        return next((c for c in self.capabilities if c.name==name),None)
    def gpu_devices(self):return [d for d in self.devices if d.kind=="GPU"]
    def save_profile(self):
        self.profile_path.parent.mkdir(parents=True,exist_ok=True)
        payload={"profile_version":"1.0.0","detected_unix":time.time(),
                 "selected_backend":self.selected_backend,
                 "devices":[d.to_dict() for d in self.devices],
                 "capabilities":[c.__dict__ for c in self.capabilities]}
        tmp=self.profile_path.with_suffix(self.profile_path.suffix+".tmp")
        tmp.write_text(json.dumps(payload,indent=2),encoding="utf-8")
        os.replace(tmp,self.profile_path)
        return self.profile_path
    def summary(self):
        return {
          "selected_backend":self.selected_backend,
          "cpu_count":sum(d.kind=="CPU" for d in self.devices),
          "gpu_count":sum(d.kind=="GPU" for d in self.devices),
          "amd_gpu_count":sum(d.vendor=="AMD" and d.kind=="GPU" for d in self.devices),
          "nvidia_gpu_count":sum(d.vendor=="NVIDIA" and d.kind=="GPU" for d in self.devices)
        }
