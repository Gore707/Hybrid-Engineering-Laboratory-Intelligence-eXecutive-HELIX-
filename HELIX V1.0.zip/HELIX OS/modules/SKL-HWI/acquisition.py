from __future__ import annotations
from dataclasses import dataclass,field
from enum import Enum
from collections import deque
import math

class ClockSource(str,Enum):
    HOST_MONOTONIC="HOST_MONOTONIC"
    HOST_UTC="HOST_UTC"
    DEVICE="DEVICE"
    EXTERNAL_REFERENCE="EXTERNAL_REFERENCE"

class AcquisitionState(str,Enum):
    CONFIGURED="CONFIGURED"
    RUNNING="RUNNING"
    STOPPED="STOPPED"
    ERROR="ERROR"

@dataclass(frozen=True)
class ChannelConfiguration:
    channel_id:str
    device_id:str
    capability_id:str
    unit:str
    nominal_sample_rate_hz:float
    clock_source:ClockSource=ClockSource.HOST_MONOTONIC
    enabled:bool=True
    def __post_init__(self):
        if not self.channel_id or not self.device_id or not self.capability_id or not self.unit:raise ValueError("channel identity required")
        if self.nominal_sample_rate_hz<=0:raise ValueError("sample rate positive")

@dataclass(frozen=True)
class Sample:
    sequence:int
    timestamp_s:float
    value:float
    source_timestamp_s:float|None=None
    def __post_init__(self):
        if self.sequence<0 or not math.isfinite(self.timestamp_s) or not math.isfinite(float(self.value)):raise ValueError("invalid sample")

class SampleBuffer:
    def __init__(self,capacity):
        if capacity<1:raise ValueError("capacity >= 1")
        self.capacity=capacity;self._q=deque(maxlen=capacity);self.overwritten=0
    def append(self,sample):
        if len(self._q)==self.capacity:self.overwritten+=1
        self._q.append(sample)
    def all(self):return tuple(self._q)
    def clear(self):self._q.clear();self.overwritten=0
    def __len__(self):return len(self._q)

def missing_sequences(samples):
    samples=tuple(samples)
    if len(samples)<2:return ()
    missing=[]
    prev=samples[0].sequence
    for s in samples[1:]:
        if s.sequence<=prev:raise ValueError("sequences must be strictly increasing")
        if s.sequence>prev+1:missing.extend(range(prev+1,s.sequence))
        prev=s.sequence
    return tuple(missing)

def timestamp_jitter_s(samples,nominal_sample_rate_hz):
    samples=tuple(samples)
    if nominal_sample_rate_hz<=0:raise ValueError("sample rate positive")
    if len(samples)<2:return ()
    dt0=1.0/nominal_sample_rate_hz
    return tuple((samples[i].timestamp_s-samples[i-1].timestamp_s)-dt0 for i in range(1,len(samples)))

def synchronization_offsets(reference_samples,target_samples):
    r={s.sequence:s.timestamp_s for s in reference_samples}
    t={s.sequence:s.timestamp_s for s in target_samples}
    common=sorted(set(r)&set(t))
    return tuple((seq,t[seq]-r[seq]) for seq in common)

@dataclass(frozen=True)
class AcquisitionRecord:
    experiment_id:str
    session_id:str
    channel:ChannelConfiguration
    samples:tuple[Sample,...]
    dropped_sequences:tuple[int,...]
    buffer_overwrites:int
    started_at_s:float
    stopped_at_s:float
    def __post_init__(self):
        if not self.experiment_id or not self.session_id:raise ValueError("experiment/session required")
        if self.stopped_at_s<self.started_at_s:raise ValueError("stop before start")
    @property
    def sample_count(self):return len(self.samples)

class AcquisitionSession:
    def __init__(self,session_id,experiment_id,channels,buffer_capacity=100000):
        if not session_id or not experiment_id:raise ValueError("session and experiment IDs required")
        self.session_id=session_id;self.experiment_id=experiment_id
        self.channels={c.channel_id:c for c in channels}
        if len(self.channels)!=len(tuple(channels)):raise ValueError("duplicate channel_id")
        self.buffers={cid:SampleBuffer(buffer_capacity) for cid in self.channels}
        self.state=AcquisitionState.CONFIGURED;self.started_at_s=None;self.stopped_at_s=None
    def start(self,timestamp_s):
        if self.state!=AcquisitionState.CONFIGURED:raise RuntimeError("session not configurable")
        self.started_at_s=float(timestamp_s);self.state=AcquisitionState.RUNNING
    def ingest(self,channel_id,sample):
        if self.state!=AcquisitionState.RUNNING:raise RuntimeError("session not running")
        if channel_id not in self.channels:raise KeyError(channel_id)
        if not self.channels[channel_id].enabled:raise RuntimeError("channel disabled")
        self.buffers[channel_id].append(sample)
    def stop(self,timestamp_s):
        if self.state!=AcquisitionState.RUNNING:raise RuntimeError("session not running")
        self.stopped_at_s=float(timestamp_s)
        if self.stopped_at_s<self.started_at_s:raise ValueError("stop before start")
        self.state=AcquisitionState.STOPPED
    def records(self):
        if self.state!=AcquisitionState.STOPPED:raise RuntimeError("stop session before record generation")
        out=[]
        for cid,ch in self.channels.items():
            samples=self.buffers[cid].all()
            out.append(AcquisitionRecord(self.experiment_id,self.session_id,ch,samples,missing_sequences(samples),
                                         self.buffers[cid].overwritten,self.started_at_s,self.stopped_at_s))
        return tuple(out)

def scientific_data_manifest(record,dataset_path):
    """Metadata handoff only. Large sample arrays belong in HDF5/scientific binary storage, not JSON."""
    if not dataset_path:raise ValueError("dataset_path required")
    return {
      "experiment_id":record.experiment_id,"session_id":record.session_id,
      "channel_id":record.channel.channel_id,"device_id":record.channel.device_id,
      "capability_id":record.channel.capability_id,"unit":record.channel.unit,
      "clock_source":record.channel.clock_source.value,
      "nominal_sample_rate_hz":record.channel.nominal_sample_rate_hz,
      "sample_count":record.sample_count,"dropped_sample_count":len(record.dropped_sequences),
      "buffer_overwrites":record.buffer_overwrites,"dataset_path":dataset_path,
      "storage_contract":"SCIENTIFIC_BINARY_ARRAY"
    }
