from __future__ import annotations
from dataclasses import dataclass
import math
from .framework import CapacityEstimate,EvidenceClass
def fringe_spacing_m(wavelength_m,n_refractive,internal_beam_angle_rad):
 if wavelength_m<=0 or n_refractive<=0 or not 0<internal_beam_angle_rad<=math.pi:raise ValueError("invalid fringe parameters")
 s=math.sin(internal_beam_angle_rad/2)
 if s<=0:raise ValueError("nonzero crossing angle required")
 return wavelength_m/(2*n_refractive*s)
def grating_vector_magnitude(fringe_spacing):
 if fringe_spacing<=0:raise ValueError("positive fringe spacing required")
 return 2*math.pi/fringe_spacing
def bragg_angle_rad(wavelength_m,n_refractive,grating_period_m,order=1):
 if wavelength_m<=0 or n_refractive<=0 or grating_period_m<=0 or order<1:raise ValueError("invalid Bragg inputs")
 x=order*wavelength_m/(2*n_refractive*grating_period_m)
 return None if abs(x)>1 else math.asin(x)
def approximate_angular_selectivity_rad(wavelength_m,n_refractive,thickness_m,cos_theta=1.0):
 if wavelength_m<=0 or n_refractive<=0 or thickness_m<=0 or cos_theta<=0:raise ValueError("invalid selectivity inputs")
 return wavelength_m/(2*n_refractive*thickness_m*cos_theta)
@dataclass(frozen=True)
class HolographicPage:
 pixels_x:int;pixels_y:int;bits_per_pixel:int=1;reserved_fraction:float=0.0
 def __post_init__(self):
  if self.pixels_x<1 or self.pixels_y<1 or self.bits_per_pixel<1 or not 0<=self.reserved_fraction<1:raise ValueError("invalid page")
 @property
 def raw_bits(self):return self.pixels_x*self.pixels_y*self.bits_per_pixel
 @property
 def payload_bits(self):return self.raw_bits*(1-self.reserved_fraction)
@dataclass(frozen=True)
class MultiplexPlan:
 angular_channels:int=1;wavelength_channels:int=1;shift_channels:int=1;peristrophic_channels:int=1
 def __post_init__(self):
  if min(self.angular_channels,self.wavelength_channels,self.shift_channels,self.peristrophic_channels)<1:raise ValueError("channel counts positive")
 @property
 def nominal_pages(self):return self.angular_channels*self.wavelength_channels*self.shift_channels*self.peristrophic_channels
@dataclass(frozen=True)
class HolographicVolume:
 page:HolographicPage;multiplex:MultiplexPlan;sites:int=1;system_overhead_fraction:float=0.0
 def __post_init__(self):
  if self.sites<1 or not 0<=self.system_overhead_fraction<1:raise ValueError("invalid volume")
 @property
 def page_count(self):return self.sites*self.multiplex.nominal_pages
 def capacity(self,evidence_class=EvidenceClass.EXTRAPOLATED_ENGINEERING):
  raw=self.page_count*self.page.raw_bits
  usable=self.page_count*self.page.payload_bits*(1-self.system_overhead_fraction)
  return CapacityEstimate(usable,raw,1-usable/raw if raw else 0,"holographic page count × page payload",evidence_class)
def diffraction_efficiency_weak_grating(delta_n,thickness_m,wavelength_m,cos_theta=1.0):
 if thickness_m<0 or wavelength_m<=0 or cos_theta<=0:raise ValueError("invalid diffraction inputs")
 kappa=math.pi*delta_n/(wavelength_m*cos_theta)
 return math.sin(kappa*thickness_m)**2
