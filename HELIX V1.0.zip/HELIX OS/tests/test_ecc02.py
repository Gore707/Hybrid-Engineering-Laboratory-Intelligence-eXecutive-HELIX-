import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ECC"
sp=importlib.util.spec_from_file_location("skl_ecc",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_ecc"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_energy(self):self.assertAlmostEqual(q.neutrino_energy_j(1),1e9*q.EV_J)
 def test_xsec_linear(self):self.assertAlmostEqual(q.approximate_cc_cross_section_m2(10)/q.approximate_cc_cross_section_m2(1),10)
 def test_antinu_smaller(self):self.assertLess(q.approximate_cc_cross_section_m2(1,True),q.approximate_cc_cross_section_m2(1))
 def test_targets(self):self.assertGreater(q.target_nucleons(1000),1e29)
 def test_thin_probability(self):self.assertGreater(q.thin_detector_interaction_probability(1e-42,1e6),0)
 def test_phase(self):self.assertGreater(q.oscillation_phase(2.5e-3,1000,1),0)
 def test_survival_bounds(self):
  p=q.two_flavor_survival_probability(.6,2.5e-3,1000,1);self.assertTrue(0<=p<=1)
 def test_beam_radius(self):self.assertEqual(q.beam_radius_m(1e6,1e-3),1000)
 def test_beam_area(self):self.assertAlmostEqual(q.beam_area_m2(1e6,1e-3),math.pi*1e6)
 def test_flux_distance(self):self.assertAlmostEqual(q.neutrino_flux_per_m2(1e20,2e6,1e-3)/q.neutrino_flux_per_m2(1e20,1e6,1e-3),.25)
 def test_event_mass(self):self.assertAlmostEqual(q.event_rate_from_detector_mass(1e10,1e-42,2000)/q.event_rate_from_detector_mass(1e10,1e-42,1000),2)
 def test_ook_fail(self):self.assertEqual(q.on_off_keying_ideal_rate_bps(1,100,5,1),0)
 def test_ook_pass(self):self.assertEqual(q.on_off_keying_ideal_rate_bps(100,1,5,1),1)
 def test_power(self):self.assertGreater(q.wall_power_w(1e15,10,.1),0)
 def test_link(self):
  n=q.NeutrinoLink(10,1e20,1e6,1e-3,1e6,.8,10);self.assertGreater(n.cross_section_m2,0);self.assertGreater(n.detected_events_s,0);self.assertGreater(n.ideal_bit_rate_bps,0)
 def test_foundation_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ECC-NU-XSEC","ECC-NU-OSC","ECC-NU-BEAM","ECC-NU-EVENT","ECC-NU-POWER"}<={x.model_id for x in q.ExtremeCarrierRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-ECC-02")
 def test_isn_complete(self):self.assertEqual(json.loads((R/"ISN_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
