from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
import json,re,math

@dataclass(frozen=True)
class KnowledgeChunk:
    chunk_id:str
    source_type:str
    source_id:str
    title:str
    text:str
    provenance:str
    locator:str
    metadata:dict

@dataclass(frozen=True)
class RetrievalHit:
    chunk:KnowledgeChunk
    score:float
    matched_terms:tuple[str,...]

def _terms(s):
    return tuple(t for t in re.findall(r"[A-Za-z0-9_α-ωΑ-Ω]+",s.lower()) if len(t)>1)

class ScientificKnowledgeIndex:
    """Local HELIX scientific retrieval index. Retrieval evidence is returned verbatim
    with source IDs/provenance; the LLM is never treated as the source."""
    def __init__(self):self.chunks=[];self._df={}

    def add(self,chunk:KnowledgeChunk):
        self.chunks.append(chunk)
        for t in set(_terms(chunk.title+" "+chunk.text)):self._df[t]=self._df.get(t,0)+1

    def add_json_resource(self,path:Path,source_type="RESOURCE",provenance="SOFTWARE"):
        try:d=json.loads(path.read_text(encoding="utf-8"))
        except (OSError,json.JSONDecodeError):return 0
        docs=d if isinstance(d,list) else [d];n=0
        for i,obj in enumerate(docs):
            if not isinstance(obj,dict):continue
            sid=str(obj.get("equation_id") or obj.get("model_id") or obj.get("id") or obj.get("material_id") or f"{path.stem}:{i}")
            title=str(obj.get("title") or obj.get("name") or sid)
            text=json.dumps(obj,ensure_ascii=False,sort_keys=True)
            self.add(KnowledgeChunk(f"{source_type}:{sid}",source_type,sid,title,text,provenance,str(path),{"file":path.name}));n+=1
        return n

    def index_helix_resources(self,root:Path):
        count=0
        for folder,stype in (("core/resources/equations","EQUATION"),("core/resources/models","MODEL"),
                             ("modules","MODULE_RESOURCE")):
            base=root/folder
            if not base.exists():continue
            files=base.rglob("*.json") if folder=="modules" else base.glob("*.json")
            for p in files:
                if p.name=="module.json" and folder=="modules":continue
                count+=self.add_json_resource(p,stype,"SOFTWARE")
        return count

    def add_research_artifact(self,artifact,text):
        self.add(KnowledgeChunk("RESEARCH:"+artifact.artifact_id,"RESEARCH",artifact.artifact_id,
            artifact.title or artifact.artifact_id,text,"IMPORTED",artifact.source_url,
            {"checksum_sha256":artifact.checksum_sha256,"retrieved_utc":artifact.retrieved_utc,"license":artifact.license}))

    def search(self,query,limit=6):
        q=set(_terms(query));N=max(len(self.chunks),1);hits=[]
        for c in self.chunks:
            doc=_terms(c.title+" "+c.text);freq={}
            for t in doc:freq[t]=freq.get(t,0)+1
            matched=q.intersection(freq)
            if not matched:continue
            score=sum((1+math.log(freq[t]))*math.log((N+1)/(1+self._df.get(t,0))+1) for t in matched)
            hits.append(RetrievalHit(c,score,tuple(sorted(matched))))
        return sorted(hits,key=lambda h:h.score,reverse=True)[:max(1,limit)]

    def context(self,query,limit=6,max_chars=12000):
        hits=self.search(query,limit);parts=[]
        for h in hits:
            block=f"[{h.chunk.source_type}:{h.chunk.source_id} | {h.chunk.provenance} | {h.chunk.locator}]\n{h.chunk.title}\n{h.chunk.text}"
            if sum(len(x) for x in parts)+len(block)>max_chars:break
            parts.append(block)
        return "\n\n".join(parts),hits
