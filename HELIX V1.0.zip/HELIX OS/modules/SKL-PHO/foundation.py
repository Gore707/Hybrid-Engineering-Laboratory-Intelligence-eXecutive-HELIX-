from __future__ import annotations
from dataclasses import dataclass
import math,cmath
C0=299792458.0
H=6.62607015e-34
HBAR=H/(2*math.pi)
@dataclass(frozen=True)
class OpticalWave:
 wavelength_m:float;power_w:float=0.0;phase_rad:float=0.0;refractive_index:float=1.0
 def __post_init__(self):
  if self.wavelength_m<=0 or self.power_w<0 or self.refractive_index<=0:raise ValueError("invalid optical wave")
  if not all(math.isfinite(x) for x in (self.wavelength_m,self.power_w,self.phase_rad,self.refractive_index)):raise ValueError("wave values must be finite")
 @property
 def vacuum_frequency_hz(self):return C0/self.wavelength_m
 @property
 def medium_frequency_hz(self):return self.vacuum_frequency_hz
 @property
 def medium_wavelength_m(self):return self.wavelength_m/self.refractive_index
 @property
 def angular_frequency_rad_s(self):return 2*math.pi*self.vacuum_frequency_hz
 @property
 def wave_number_rad_m(self):return 2*math.pi/self.medium_wavelength_m
 @property
 def photon_energy_j(self):return H*self.vacuum_frequency_hz
 @property
 def photon_flux_s(self):return 0.0 if self.power_w==0 else self.power_w/self.photon_energy_j
 def phasor(self):return cmath.rect(math.sqrt(self.power_w),self.phase_rad)
@dataclass(frozen=True)
class InterfaceResult:
 reflectance:float;transmittance:float;theta_transmitted_rad:float|None;total_internal_reflection:bool
def snell_angle(n1,n2,theta1_rad):
 if n1<=0 or n2<=0:raise ValueError("indices must be positive")
 s=n1*math.sin(theta1_rad)/n2
 if abs(s)>1:return None
 return math.asin(s)
def fresnel_normal(n1,n2):
 if n1<=0 or n2<=0:raise ValueError("indices must be positive")
 r=((n1-n2)/(n1+n2))**2
 return InterfaceResult(r,1-r,0.0,False)
def dielectric_interface(n1,n2,theta1_rad,polarization="s"):
 t=snell_angle(n1,n2,theta1_rad)
 if t is None:return InterfaceResult(1.0,0.0,None,True)
 c1=math.cos(theta1_rad);c2=math.cos(t)
 if polarization=="s":amp=(n1*c1-n2*c2)/(n1*c1+n2*c2)
 elif polarization=="p":amp=(n2*c1-n1*c2)/(n2*c1+n1*c2)
 else:raise ValueError("polarization must be s or p")
 R=amp*amp;return InterfaceResult(R,1-R,t,False)
def optical_path_length(length_m,refractive_index):
 if length_m<0 or refractive_index<=0:raise ValueError("invalid optical path")
 return length_m*refractive_index
def phase_delay_rad(length_m,wavelength_m,refractive_index=1.0):
 if wavelength_m<=0:return (_ for _ in ()).throw(ValueError("wavelength must be positive"))
 return 2*math.pi*optical_path_length(length_m,refractive_index)/wavelength_m
