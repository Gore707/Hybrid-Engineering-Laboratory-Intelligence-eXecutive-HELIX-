import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-RF"
sp=importlib.util.spec_from_file_location("skl_rf",M/"__init__.py",submodule_search_locations=[str(M)])
r=importlib.util.module_from_spec(sp);sys.modules["skl_rf"]=r;sp.loader.exec_module(r)
class T(unittest.TestCase):
 def test_nf_factor(self):self.assertAlmostEqual(r.noise_factor_from_db(3),10**.3)
 def test_nf_inverse(self):self.assertAlmostEqual(r.noise_figure_db_from_factor(r.noise_factor_from_db(2)),2)
 def test_noise_temp(self):self.assertEqual(r.equivalent_noise_temperature_k(2),290)
 def test_cascade(self):
  s=(r.RFStage("LNA",10,2),r.RFStage("IF",10,3));self.assertAlmostEqual(r.cascaded_noise_factor(s),2.2)
 def test_cascade_first_stage_dominates(self):
  a=r.cascaded_noise_factor((r.RFStage("a",100,1.2),r.RFStage("b",10,5)))
  self.assertAlmostEqual(a,1.24)
 def test_sensitivity(self):self.assertAlmostEqual(r.receiver_sensitivity_w(290,1e6,10,2),r.K_B*290*1e6*20)
 def test_sensitivity_dbm(self):self.assertAlmostEqual(r.dbm_to_w(r.receiver_sensitivity_dbm(290,1e6,10,2)),r.receiver_sensitivity_w(290,1e6,10,2))
 def test_sfdr(self):self.assertGreater(r.spurious_free_dynamic_range_db(0,-174,1e6),0)
 def test_mixer_difference(self):self.assertEqual(r.mixer_output_frequency_hz(10e9,9e9),1e9)
 def test_mixer_sum(self):self.assertEqual(r.mixer_output_frequency_hz(10e9,9e9,True),19e9)
 def test_filter_bw(self):self.assertEqual(r.ideal_filter_noise_bandwidth_hz(1e6,2e6),1e6)
 def test_adc_qsnr(self):self.assertAlmostEqual(r.adc_quantization_snr_db(8),49.92)
 def test_nyquist(self):self.assertEqual(r.adc_nyquist_rate_hz(10e6),20e6)
 def test_phase_error(self):self.assertEqual(r.oscillator_phase_error_rms_rad(4),2)
 def test_pa_power(self):self.assertEqual(r.dc_power_for_rf_output_w(100,.5),200)
 def test_receiver_chain(self):
  c=r.ReceiverChain((r.RFStage("LNA",100,1.2),r.RFStage("IF",10,3)),290,1e6,10)
  self.assertEqual(c.total_gain_linear,1000);self.assertGreater(c.sensitivity_w,0)
 def test_tx_chain(self):
  t=r.TransmitterChain(100,.5,.8);self.assertEqual(t.dc_input_w,200);self.assertEqual(t.antenna_input_w,80);self.assertEqual(t.waste_heat_w,100)
 def test_invalid_stage(self):
  with self.assertRaises(ValueError):r.RFStage("bad",0,1)
 def test_invalid_nf(self):
  with self.assertRaises(ValueError):r.noise_figure_db_from_factor(.9)
 def test_propagation_preserved(self):self.assertAlmostEqual(r.propagation_delay_s(r.C),1)
 def test_array_preserved(self):self.assertAlmostEqual(r.uniform_linear_array_factor(4,.5,r.C,.2,.2),1)
 def test_registry(self):self.assertTrue({"RF-NF-CASCADE","RF-RX-SENS","RF-SFDR","RF-MIXER","RF-ADC-QSNR","RF-PA-DC"}<={x.model_id for x in r.RFRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-RF-04")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-HQIC"])
 def test_hqic_complete(self):self.assertEqual(json.loads((R/"HQIC_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
