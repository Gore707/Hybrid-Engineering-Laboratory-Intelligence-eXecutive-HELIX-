from __future__ import annotations
def dataset_figure_spec(ds,figure_spec_class):
 return figure_spec_class(
  figure_id="MAT-"+ds.dataset_id,
  title=f"{ds.material_id} — {ds.property_id}",
  x_label=f"{ds.domain_name} [{ds.domain_unit}]",
  y_label=f"{ds.property_id} [{ds.value_unit}]",
  caption=f"Material dataset {ds.dataset_id}; evidence={ds.evidence_class}; sources={', '.join(ds.source_ids)}.",
  dataset_ids=(ds.dataset_id,),
  assumptions=(),
  provenance={"source_type":"IMPORTED","material_id":ds.material_id,"dataset_id":ds.dataset_id,
   "evidence_class":ds.evidence_class,"source_ids":list(ds.source_ids)})
def dataset_xy(ds):
 return tuple(ds.x),tuple(ds.y)
def compare_datasets(datasets):
 if not datasets:return {"compatible":False,"reason":"no datasets","series":[]}
 u={(d.domain_name,d.domain_unit,d.property_id,d.value_unit) for d in datasets}
 if len(u)!=1:return {"compatible":False,"reason":"incompatible domain/property units","series":[]}
 return {"compatible":True,"reason":"compatible","series":[{"dataset_id":d.dataset_id,"material_id":d.material_id,"x":d.x,"y":d.y,
  "source_ids":d.source_ids,"evidence_class":d.evidence_class} for d in datasets]}
