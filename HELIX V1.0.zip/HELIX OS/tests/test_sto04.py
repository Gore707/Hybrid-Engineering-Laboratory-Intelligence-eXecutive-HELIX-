import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-STO";sp=importlib.util.spec_from_file_location("skl_sto",M/"__init__.py",submodule_search_locations=[str(M)]);s=importlib.util.module_from_spec(sp);sys.modules["skl_sto"]=s;sp.loader.exec_module(s)
class T(unittest.TestCase):
 def test_coherence(self):self.assertAlmostEqual(s.coherence_time_from_homogeneous_linewidth_s(1e3),1/(math.pi*1e3))
 def test_channels(self):self.assertEqual(s.max_uniform_channels(1e9,10e6),100);self.assertEqual(s.max_uniform_channels(1e9,10e6,.25),80)
 def test_hole_center(self):self.assertEqual(s.SpectralHole(1e12,1e6,.8).lorentzian_depth(1e12),.8)
 def test_hole_fwhm(self):
  h=s.SpectralHole(1e12,2e6,1);self.assertAlmostEqual(h.lorentzian_depth(1e12+1e6),.5)
 def test_afc(self):
  a=s.AtomicFrequencyComb(1e6,1e5,10);self.assertEqual(a.finesse,10);self.assertEqual(a.nominal_echo_time_s,1e-6);self.assertAlmostEqual(a.occupied_span_hz,9.1e6)
 def test_afc_freqs(self):
  f=s.AtomicFrequencyComb(10,1,3).tooth_frequencies(100);self.assertEqual(f,(90,100,110))
 def test_plan(self):
  p=s.SpectralStoragePlan(100,10,2,.1);c=p.capacity();self.assertEqual(c.raw_bits,2000);self.assertEqual(c.usable_bits,1800)
 def test_lifetime_linewidth(self):self.assertAlmostEqual(s.lifetime_limited_linewidth_hz(1),1/(2*math.pi))
 def test_invalid_afc(self):
  with self.assertRaises(ValueError):s.AtomicFrequencyComb(1,2,10)
 def test_registry(self):self.assertEqual(s.StorageRegistry().get("STO-AFC-ECHO").evidence_class,"ESTABLISHED_PHYSICS")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-STO-04")
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
