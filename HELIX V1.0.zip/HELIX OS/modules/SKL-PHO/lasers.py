from __future__ import annotations
from dataclasses import dataclass
import math
from .foundation import C0,H
@dataclass(frozen=True)
class LaserSource:
 wavelength_m:float;output_power_w:float;linewidth_hz:float=0.0;m2:float=1.0
 def __post_init__(self):
  if self.wavelength_m<=0 or self.output_power_w<0 or self.linewidth_hz<0 or self.m2<1:raise ValueError("invalid laser source")
 @property
 def frequency_hz(self):return C0/self.wavelength_m
 @property
 def photon_energy_j(self):return H*self.frequency_hz
 @property
 def photon_flux_s(self):return self.output_power_w/self.photon_energy_j
 @property
 def coherence_time_s(self):return math.inf if self.linewidth_hz==0 else 1/(math.pi*self.linewidth_hz)
 @property
 def coherence_length_m(self):return math.inf if self.linewidth_hz==0 else C0*self.coherence_time_s
@dataclass(frozen=True)
class LinearResonator:
 length_m:float;n:float=1.0
 def __post_init__(self):
  if self.length_m<=0 or self.n<=0:raise ValueError("invalid resonator")
 @property
 def free_spectral_range_hz(self):return C0/(2*self.n*self.length_m)
 def longitudinal_mode_frequency_hz(self,q):
  if q<1 or int(q)!=q:raise ValueError("q must be positive integer")
  return int(q)*self.free_spectral_range_hz
def resonator_finesse_from_reflectivity(R):
 if not 0<R<1:raise ValueError("R must be between 0 and 1")
 return math.pi*math.sqrt(R)/(1-R)
def resonator_linewidth_hz(fsr_hz,finesse):
 if fsr_hz<=0 or finesse<=0:raise ValueError("positive FSR/finesse required")
 return fsr_hz/finesse
def threshold_gain_per_m(r1,r2,length_m,distributed_loss_per_m=0.0):
 if not 0<r1<=1 or not 0<r2<=1 or length_m<=0 or distributed_loss_per_m<0:raise ValueError("invalid threshold parameters")
 return distributed_loss_per_m+(1/(2*length_m))*math.log(1/(r1*r2))
@dataclass(frozen=True)
class PulseTrain:
 average_power_w:float;repetition_rate_hz:float;pulse_duration_s:float
 def __post_init__(self):
  if self.average_power_w<0 or self.repetition_rate_hz<=0 or self.pulse_duration_s<=0:raise ValueError("invalid pulse train")
 @property
 def pulse_energy_j(self):return self.average_power_w/self.repetition_rate_hz
 @property
 def peak_power_rectangular_w(self):return self.pulse_energy_j/self.pulse_duration_s
 @property
 def duty_cycle(self):return self.repetition_rate_hz*self.pulse_duration_s
def transform_limited_gaussian_bandwidth_hz(pulse_fwhm_s):
 if pulse_fwhm_s<=0:raise ValueError("pulse width must be positive")
 return 0.441/pulse_fwhm_s
def saturation_parameter(intensity_w_m2,saturation_intensity_w_m2):
 if intensity_w_m2<0 or saturation_intensity_w_m2<=0:raise ValueError("invalid intensities")
 return intensity_w_m2/saturation_intensity_w_m2
