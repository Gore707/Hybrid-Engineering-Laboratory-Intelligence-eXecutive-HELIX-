import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HWI"
sp=importlib.util.spec_from_file_location("skl_hwi",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_hwi"]=q;sp.loader.exec_module(q)
class Fake(q.InstrumentTransport):
 def __init__(self,fail=False):self.opened=False;self.fail=fail
 def open(self):
  if self.fail:raise RuntimeError("boom")
  self.opened=True
 def close(self):self.opened=False
 def read(self,c):return 1
 def write(self,c,v):return None
def inst(t=None):
 return q.Instrument(q.HardwareIdentity("D1","SKL","Meter"),(q.CapabilityDescriptor("voltage","Voltage","V",0,10,.001,1000),),t,q.CalibrationRecord(q.CalibrationState.VALID,0,100))
class T(unittest.TestCase):
 def test_identity(self):self.assertEqual(inst().identity.device_id,"D1")
 def test_capability(self):self.assertEqual(inst().capability("voltage").unit,"V")
 def test_bad_range(self):
  with self.assertRaises(ValueError):q.CapabilityDescriptor("x","x","V",2,1)
 def test_calibration_valid(self):self.assertTrue(inst().calibration.is_valid_at(50))
 def test_calibration_expired(self):self.assertFalse(inst().calibration.is_valid_at(101))
 def test_hardware_provenance_requires_device(self):
  with self.assertRaises(ValueError):q.make_provenance(q.SourceState.HARDWARE,"x",None)
 def test_sim_provenance(self):self.assertEqual(q.make_provenance(q.SourceState.SIMULATION,"x").source_state,q.SourceState.SIMULATION)
 def test_connect(self):
  f=Fake();i=inst(f);i.connect();self.assertEqual(i.connection_state,q.ConnectionState.CONNECTED);self.assertTrue(f.opened);i.disconnect();self.assertFalse(f.opened)
 def test_connect_failure(self):
  i=inst(Fake(True))
  with self.assertRaises(RuntimeError):i.connect()
  self.assertEqual(i.health_state,q.HealthState.ERROR)
 def test_degraded(self):
  i=inst();i.mark_degraded("noise");self.assertEqual(i.connection_state,q.ConnectionState.DEGRADED)
 def test_registry(self):
  r=q.InstrumentRegistry();i=inst();r.register(i);self.assertIs(r.get("D1"),i);self.assertEqual(r.by_capability("voltage"),(i,))
 def test_duplicate(self):
  r=q.InstrumentRegistry();r.register(inst())
  with self.assertRaises(ValueError):r.register(inst())
 def test_hal_measurement(self):
  i=inst();x=q.HALInstrumentAdapter(i).measurement("voltage",1.2,"V","E1",123)
  self.assertEqual(x.provenance.source_state,q.SourceState.HARDWARE);self.assertEqual(x.provenance.device_id,"D1");self.assertEqual(x.provenance.timestamp_unix_s,123)
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/instrument.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-HWI-01")
 def test_bnd_complete_preserved(self):self.assertEqual(json.loads((R/"BND_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
