from __future__ import annotations
from dataclasses import dataclass
import math
from .framework import CapacityEstimate,EvidenceClass
@dataclass(frozen=True)
class VoxelPitch:
 x_m:float;y_m:float;z_m:float
 def __post_init__(self):
  if min(self.x_m,self.y_m,self.z_m)<=0:raise ValueError("voxel pitches must be positive")
@dataclass(frozen=True)
class FiveDEncoding:
 orientation_states:int;retardance_states:int
 def __post_init__(self):
  if self.orientation_states<1 or self.retardance_states<1:raise ValueError("state counts positive")
 @property
 def optical_states(self):return self.orientation_states*self.retardance_states
 @property
 def bits_per_voxel_ideal(self):return math.log2(self.optical_states)
 @property
 def integer_payload_bits_per_voxel(self):return int(math.floor(self.bits_per_voxel_ideal))
@dataclass(frozen=True)
class FiveDLayout:
 width_m:float;height_m:float;depth_m:float;pitch:VoxelPitch;encoding:FiveDEncoding
 def __post_init__(self):
  if min(self.width_m,self.height_m,self.depth_m)<=0:raise ValueError("medium dimensions positive")
 @property
 def nx(self):return int(math.floor(self.width_m/self.pitch.x_m + 1e-12))
 @property
 def ny(self):return int(math.floor(self.height_m/self.pitch.y_m + 1e-12))
 @property
 def nz(self):return int(math.floor(self.depth_m/self.pitch.z_m + 1e-12))
 @property
 def voxel_count(self):return self.nx*self.ny*self.nz
 def capacity(self,overhead_fraction=0.0,evidence_class=EvidenceClass.EXTRAPOLATED_ENGINEERING):
  if not 0<=overhead_fraction<1:raise ValueError("overhead 0..1")
  raw=self.voxel_count*self.encoding.integer_payload_bits_per_voxel
  return CapacityEstimate(raw*(1-overhead_fraction),raw,overhead_fraction,"5D voxel geometry + integer optical-state payload",evidence_class)
@dataclass(frozen=True)
class VoxelAddress:
 ix:int;iy:int;iz:int;orientation_state:int;retardance_state:int
def validate_address(layout,address):
 return (0<=address.ix<layout.nx and 0<=address.iy<layout.ny and 0<=address.iz<layout.nz and 0<=address.orientation_state<layout.encoding.orientation_states and 0<=address.retardance_state<layout.encoding.retardance_states)
def voxel_position(layout,address):
 if not validate_address(layout,address):raise IndexError("5D voxel address outside layout")
 return ((address.ix+.5)*layout.pitch.x_m,(address.iy+.5)*layout.pitch.y_m,(address.iz+.5)*layout.pitch.z_m)
def retardance_from_birefringence(delta_n,thickness_m,wavelength_m):
 if thickness_m<0 or wavelength_m<=0:raise ValueError("invalid retardance inputs")
 return 2*math.pi*delta_n*thickness_m/wavelength_m
def analyzer_intensity_normalized(retardance_rad,orientation_rad,analyzer_rad=0.0):
 # simplified ideal retarder between linear preparation/analyzer axes; normalized
 a=orientation_rad-analyzer_rad
 return 1-(math.sin(2*a)**2)*(math.sin(retardance_rad/2)**2)
def write_energy_j(pulse_energy_j,pulses_per_voxel,voxel_count):
 if pulse_energy_j<0 or pulses_per_voxel<1 or int(pulses_per_voxel)!=pulses_per_voxel or voxel_count<0:return _bad()
 return pulse_energy_j*int(pulses_per_voxel)*voxel_count
def _bad():raise ValueError("invalid write-energy parameters")
