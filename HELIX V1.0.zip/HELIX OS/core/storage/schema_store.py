from __future__ import annotations
import json
from pathlib import Path

class SchemaValidationError(ValueError): pass

class SchemaStore:
    def __init__(self,schema_root:Path):
        self.root=schema_root
    def load(self,name:str):
        p=self.root/name
        if not p.exists(): raise FileNotFoundError(p)
        return json.loads(p.read_text(encoding="utf-8"))
    def names(self): return sorted(p.name for p in self.root.glob("*.schema.json"))
    def validate(self,name:str,data:dict):
        schema=self.load(name)
        try:
            import jsonschema
        except ImportError:
            self._minimal_validate(schema,data)
        else:
            jsonschema.Draft202012Validator(schema).validate(data)
        return True
    def _minimal_validate(self,schema,data):
        if not isinstance(data,dict): raise SchemaValidationError("resource must be an object")
        for k in schema.get("required",[]):
            if k not in data: raise SchemaValidationError(f"missing required property: {k}")
        if schema.get("additionalProperties") is False:
            unknown=set(data)-set(schema.get("properties",{}))
            if unknown: raise SchemaValidationError(f"unknown properties: {sorted(unknown)}")
        for k,spec in schema.get("properties",{}).items():
            if k not in data: continue
            v=data[k]; typ=spec.get("type")
            if isinstance(typ,list): continue
            py={"string":str,"object":dict,"array":list,"number":(int,float),"integer":int,"boolean":bool}.get(typ)
            if py and not isinstance(v,py): raise SchemaValidationError(f"{k}: expected {typ}")
            if "enum" in spec and v not in spec["enum"]: raise SchemaValidationError(f"{k}: invalid enum value")
