import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-BND"
sp=importlib.util.spec_from_file_location("skl_bnd",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_bnd"]=q;sp.loader.exec_module(q)
def sc(f=q.BoundaryFamily.ORDINARY_RELATIVISTIC,e=q.BoundaryEvidence.ESTABLISHED_PHYSICS,speed=q.C_M_S):
 return q.BoundaryScenario(f,10*q.C_M_S,e,q.C_M_S,speed,1,1)
class T(unittest.TestCase):
 def test_sensitivity(self):self.assertAlmostEqual(q.relative_sensitivity(lambda x:x*x,2),2,places=5)
 def test_domain_gate(self):self.assertTrue(q.domain_gate(True,"X","ok").passed)
 def test_evidence_gate_wormhole(self):self.assertTrue(q.evidence_gate(sc(q.BoundaryFamily.WORMHOLE,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED,10*q.C_M_S)).passed)
 def test_evidence_reject_demonstrated_wormhole(self):self.assertFalse(q.evidence_gate(sc(q.BoundaryFamily.WORMHOLE,q.BoundaryEvidence.DEMONSTRATED_TECHNOLOGY,10*q.C_M_S)).passed)
 def test_causality_gate(self):self.assertTrue(q.causality_gate(sc(q.BoundaryFamily.WARP_METRIC,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED,10*q.C_M_S)).passed)
 def test_wormhole_gate(self):self.assertTrue(any(g.gate_id=="BND-WH-HARDWARE" for g in q.candidate_failure_gates(sc(q.BoundaryFamily.WORMHOLE,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED,10*q.C_M_S))))
 def test_warp_gate(self):self.assertTrue(any(g.gate_id=="BND-WARP-HARDWARE" for g in q.candidate_failure_gates(sc(q.BoundaryFamily.WARP_METRIC,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED,10*q.C_M_S))))
 def test_qft_gate(self):self.assertTrue(any(g.gate_id=="BND-QFT-NOSIGNAL" and g.passed for g in q.candidate_failure_gates(sc(q.BoundaryFamily.QFT_VACUUM))))
 def test_cross_engine(self):
  ok,c=q.cross_engine_passed();self.assertTrue(ok);self.assertEqual(len(c),8)
 def test_validate(self):
  ok,r=q.validate_scenarios([sc(),sc(q.BoundaryFamily.WORMHOLE,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED,10*q.C_M_S)]);self.assertTrue(ok);self.assertGreaterEqual(len(r),4)
 def test_integrated_lab_preserved(self):self.assertEqual(len(q.compare_scenarios([sc()])),1)
 def test_causality_preserved(self):self.assertFalse(q.demonstrated_ftl_information_gate(q.BoundaryEvidence.SPECULATIVE_UNRESOLVED,False,True))
 def test_warp_preserved(self):self.assertFalse(q.physically_demonstrated_warp_metric_engineering_available())
 def test_wormhole_preserved(self):self.assertFalse(q.physically_demonstrated_traversable_wormhole_available())
 def test_qft_preserved(self):self.assertFalse(q.spacelike_vacuum_correlation_implies_controllable_signal())
 def test_dp_preserved(self):self.assertEqual(q.photon_dark_photon_probability(0,10,1e-3,1),0)
 def test_axion_preserved(self):self.assertEqual(q.photon_axion_conversion_probability(0,10,10),0)
 def test_registry(self):self.assertTrue({"BND-VAL-SENS","BND-VAL-GATES","BND-VAL-XENG"}<={x.model_id for x in q.default_registry().all()})
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-BND-10");self.assertEqual(x["status"],"COMPLETE 10 of 10")
 def test_completion_marker(self):
  x=json.loads((R/"BND_COMPLETE.json").read_text());self.assertEqual(x["status"],"COMPLETE");self.assertEqual(x["sequence"],{"completed":10,"total":10})
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_prior_completion_markers(self):
  for n in ["PHO_COMPLETE.json","STO_COMPLETE.json","QMEM_COMPLETE.json","HQIC_COMPLETE.json","RF_COMPLETE.json","OPT_COMPLETE.json","QCOM_COMPLETE.json","ISN_COMPLETE.json","ECC_COMPLETE.json"]:
   self.assertTrue((R/n).exists(),n)
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
