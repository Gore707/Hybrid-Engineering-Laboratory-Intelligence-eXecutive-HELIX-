from __future__ import annotations
from dataclasses import dataclass,asdict
@dataclass(frozen=True)
class ComputeDevice:
    device_id:str
    kind:str
    vendor:str
    name:str
    memory_bytes:int|None
    backend:str
    available:bool=True
    details:dict|None=None
    def to_dict(self): return asdict(self)

@dataclass(frozen=True)
class BackendCapability:
    name:str
    available:bool
    reason:str
    devices:tuple[str,...]=()
