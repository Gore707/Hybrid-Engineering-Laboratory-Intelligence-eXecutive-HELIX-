from __future__ import annotations
import json,os,platform,time
from pathlib import Path

class ComputerProfiler:
    def __init__(self,compute_manager,profile_path:Path):
        self.compute=compute_manager;self.path=profile_path
    def conservative_benchmark(self,max_seconds=.35):
        import math
        start=time.perf_counter();n=0;x=0.0
        while time.perf_counter()-start<max_seconds:
            for i in range(1,1001):x+=math.sqrt(i)
            n+=1000
        elapsed=max(time.perf_counter()-start,1e-9)
        return {"operation":"scalar_sqrt_accumulation","iterations":n,
                "elapsed_seconds":elapsed,"iterations_per_second":n/elapsed,"checksum":x}
    def build(self,max_seconds=.35):
        if not self.compute.devices:self.compute.detect()
        data={
          "profile_version":"1.0.0","created_unix":time.time(),
          "os":platform.platform(),"machine":platform.machine(),
          "logical_cores":os.cpu_count() or 1,
          "compute":self.compute.summary(),
          "devices":[d.to_dict() for d in self.compute.devices],
          "microbenchmark":self.conservative_benchmark(max_seconds)
        }
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_suffix(".tmp");tmp.write_text(json.dumps(data,indent=2),encoding="utf-8")
        os.replace(tmp,self.path);return data
