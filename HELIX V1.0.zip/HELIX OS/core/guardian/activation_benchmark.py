from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
import json,time,platform
from .integration import GuardianAIServices

@dataclass(frozen=True)
class BenchmarkResult:
    name:str
    status:str
    elapsed_seconds:float
    metric:float|None
    unit:str|None
    detail:str

class GuardianActivationBenchmark:
    def __init__(self,services:GuardianAIServices):
        self.services=services

    def run(self,run_inference=True):
        results=[]
        # RAG retrieval benchmark is always safe and local.
        b=self.services.benchmark_retrieval(iterations=50)
        results.append(BenchmarkResult("scientific_rag","PASS",b["elapsed_seconds"],
            b["queries_per_second"],"queries/s",f'last hits={b["last_hit_count"]}'))

        # Deterministic tool bridge validation: catalog only; never execute actions during benchmark.
        start=time.perf_counter();count=len(self.services.tools.catalog());elapsed=time.perf_counter()-start
        results.append(BenchmarkResult("deterministic_tool_catalog","PASS",elapsed,float(count),"actions",
            "Catalogued registered HELIX actions without execution."))

        # Persistent memory service availability.
        start=time.perf_counter();n=len(self.services.memory.records);elapsed=time.perf_counter()-start
        results.append(BenchmarkResult("guardian_memory","PASS",elapsed,float(n),"records",
            "Read persistent Guardian memory store."))

        if not run_inference:
            results.append(BenchmarkResult("local_llm","NOT_RUN",0,None,None,"Inference benchmark disabled."))
        elif self.services.runtime.config is None:
            results.append(BenchmarkResult("local_llm","NOT_RUN",0,None,None,"No GGUF model configured."))
        elif not self.services.runtime.available():
            results.append(BenchmarkResult("local_llm","FAIL",0,None,None,"llama-cpp-python runtime unavailable."))
        else:
            if not self.services.reasoner.ready:
                start=time.perf_counter()
                try:
                    self.services.runtime.load()
                except Exception as exc:
                    results.append(BenchmarkResult("local_llm","FAIL",time.perf_counter()-start,None,None,
                        f"{type(exc).__name__}: {exc}"))
                    return results
            prompt=("Return exactly one short sentence stating that this is a local HELIX Guardian "
                    "inference benchmark. Do not call tools.")
            r=self.services.runtime.generate(prompt,system="You are running a bounded local benchmark.")
            results.append(BenchmarkResult("local_llm","PASS" if r.ok else "FAIL",r.elapsed_seconds,
                r.tokens_per_second,"tokens/s",r.error or f"runtime={r.runtime}; model={r.model_name}"))
        return results

def write_report(path:Path,results,services):
    payload={
      "report_version":"GACT-03",
      "created_unix":time.time(),
      "host":platform.platform(),
      "guardian_status":services.status(),
      "safety_authority":"DETERMINISTIC_HELIX_ONLY",
      "guardian_safety_override":False,
      "results":[asdict(x) for x in results],
      "note":"Performance values are valid only for the host/model/runtime that generated this report."
    }
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp");tmp.write_text(json.dumps(payload,indent=2),encoding="utf-8");tmp.replace(path)
    return payload
