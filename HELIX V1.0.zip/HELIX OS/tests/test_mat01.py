import unittest,tempfile,importlib.util,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];MOD=ROOT/"modules/SKL-MAT"
spec=importlib.util.spec_from_file_location("skl_mat",MOD/"__init__.py",submodule_search_locations=[str(MOD)])
pkg=importlib.util.module_from_spec(spec);sys.modules["skl_mat"]=pkg;spec.loader.exec_module(pkg)
MaterialRecord=pkg.MaterialRecord;MaterialPhase=pkg.MaterialPhase;PropertyValue=pkg.PropertyValue;PropertyCondition=pkg.PropertyCondition;MaterialsService=pkg.MaterialsService
class MAT01Tests(unittest.TestCase):
 def sample(self):
  return MaterialRecord("MAT-SIO2","Fused Silica","SiO2",MaterialPhase.SOLID,"optical glass",("glass","optical"),
   (PropertyValue("density",2200,"kg/m^3",PropertyCondition(temperature_k=293.15),10,"DEMONSTRATED_TECH",("SRC-1",)),
    PropertyValue("refractive_index",1.45,"1",PropertyCondition(wavelength_m=1.55e-6),.001,"ESTABLISHED_PHYSICS",("SRC-2",))),("SRC-1","SRC-2"))
 def test_roundtrip(self):
  with tempfile.TemporaryDirectory() as td:
   s=MaterialsService(Path(td)/"m.sqlite");s.add_material(self.sample());m=s.material("MAT-SIO2")
   self.assertEqual(m.formula,"SiO2");self.assertEqual(len(m.properties),2)
 def test_search(self):
  with tempfile.TemporaryDirectory() as td:
   s=MaterialsService(Path(td)/"m.sqlite");s.add_material(self.sample())
   self.assertEqual(s.find("silica")[0].material_id,"MAT-SIO2");self.assertEqual(s.find(tag="optical")[0].name,"Fused Silica")
 def test_property_compare_keeps_conditions_and_sources(self):
  with tempfile.TemporaryDirectory() as td:
   s=MaterialsService(Path(td)/"m.sqlite");s.add_material(self.sample());r=s.compare_property(["MAT-SIO2"],"refractive_index")[0]
   self.assertEqual(r["source_ids"],("SRC-2",));self.assertAlmostEqual(r["condition"]["wavelength_m"],1.55e-6)
 def test_invalid_property(self):
  with self.assertRaises(ValueError):PropertyValue("x",float("nan"),"m")
 def test_phase_filter(self):
  with tempfile.TemporaryDirectory() as td:
   s=MaterialsService(Path(td)/"m.sqlite");s.add_material(self.sample());self.assertEqual(len(s.find(phase=MaterialPhase.SOLID)),1)
 def test_schema_and_manifest(self):
  import json
  self.assertEqual(json.loads((MOD/"module.json").read_text())["patch_id"],"SKL-MAT-01")
  self.assertTrue((MOD/"resources/material.schema.json").exists())
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
