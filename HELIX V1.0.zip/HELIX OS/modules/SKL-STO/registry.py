from __future__ import annotations
from dataclasses import dataclass
@dataclass(frozen=True)
class StorageModel:
 model_id:str;name:str;equation:str;inputs:tuple[str,...];outputs:tuple[str,...];evidence_class:str="ESTABLISHED_PHYSICS"
class StorageRegistry:
 def __init__(self):
  self._models={m.model_id:m for m in (
   StorageModel("STO-VOLUME","Rectangular medium volume","V=x y z",("x_m","y_m","z_m"),("volume_m3",)),
   StorageModel("STO-CAP-DENSITY","Volumetric capacity","C_raw=rho_b V",("bits_per_m3","volume_m3"),("raw_bits",)),
   StorageModel("STO-CAP-USABLE","Usable capacity","C_use=C_raw(1-f_overhead)",("raw_bits","overhead_fraction"),("usable_bits",)),
   StorageModel("STO-5D-VOXELS","5D voxel count","N=floor(W/dx) floor(H/dy) floor(D/dz)",("width","height","depth","pitch"),("voxel_count",)),
   StorageModel("STO-5D-BITS","5D ideal state information","b=log2(N_orientation N_retardance)",("orientation_states","retardance_states"),("bits_per_voxel",)),
   StorageModel("STO-5D-RETARDANCE","Nanograting retardance","delta=2 pi Delta_n t/lambda",("delta_n","thickness_m","wavelength_m"),("retardance_rad",)),
   StorageModel("STO-HOLO-FRINGE","Holographic fringe spacing","Lambda=lambda/(2 n sin(theta/2))",("wavelength_m","n","crossing_angle"),("fringe_spacing_m",)),
   StorageModel("STO-HOLO-BRAGG","Bragg angle","sin(theta_B)=m lambda/(2 n Lambda)",("wavelength_m","n","period_m","order"),("bragg_angle_rad",)),
   StorageModel("STO-HOLO-PAGE","Holographic page capacity","C=N_pages Nx Ny bpp",("pages","pixels_x","pixels_y","bits_per_pixel"),("raw_bits",)),
   StorageModel("STO-SPEC-COHERENCE","Homogeneous-linewidth coherence time","T2=1/(pi Delta_nu_h)",("linewidth_hz",),("coherence_time_s",)),
   StorageModel("STO-SPEC-CHANNELS","Uniform spectral channel packing","N=floor(B/[Delta f (1+g)])",("bandwidth_hz","spacing_hz","guard_fraction"),("channels",)),
   StorageModel("STO-AFC-ECHO","AFC nominal echo time","tau=1/Delta",("tooth_spacing_hz",),("echo_time_s",)),
   StorageModel("STO-DNA-IDEAL","Ideal DNA symbol information","b=log2(4)=2 bits/base",("alphabet_size",),("bits_per_base",)),
   StorageModel("STO-DNA-CAP","DNA usable payload","C=N_base b_code (1-f_overhead)",("bases","coding_bits_per_base","overhead"),("usable_bits",)),
   StorageModel("STO-DNA-SURVIVAL","Exponential molecular survival","S(t)=exp(-t/tau)",("time_s","mean_lifetime_s"),("survival_fraction",)),
   StorageModel("STO-MAG-BARRIER","Magnetic anisotropy barrier","DeltaE=K_u V",("anisotropy_j_m3","volume_m3"),("barrier_j",)),
   StorageModel("STO-MAG-STABILITY","Thermal stability factor","Delta=K_u V/(k_B T)",("anisotropy_j_m3","volume_m3","temperature_k"),("stability_factor",)),
   StorageModel("STO-MAG-NEEL","Neel-Arrhenius retention","tau=tau0 exp(Delta)",("attempt_time_s","stability_factor"),("retention_s",)),
   StorageModel("STO-MRAM-TMR","Tunnel magnetoresistance","TMR=(R_AP-R_P)/R_P",("r_parallel","r_antiparallel"),("tmr_ratio",)),
   StorageModel("STO-DENSITY-VOL","Volumetric classical density","rho_V=C_bit/V",("capacity_bits","volume_m3"),("bits_per_m3",)),
   StorageModel("STO-DENSITY-MASS","Gravimetric classical density","rho_m=C_bit/m",("capacity_bits","mass_kg"),("bits_per_kg",)),
   StorageModel("STO-EFFECTIVE-DENSITY","Usable storage density","rho_use=rho_raw eta_enc (1-f_ecc-f_reserved)",("raw_density","encoding_efficiency","ecc_fraction","reserved_fraction"),("usable_density",)),
   StorageModel("STO-BSC-CAPACITY","Binary symmetric channel capacity","C=1-H2(p)",("bit_error_probability",),("bits_per_symbol",)),
   StorageModel("STO-RW-EXPECTED-ERRORS","Expected bit errors","E[e]=N p_b",("bit_count","ber"),("expected_errors",)),
   StorageModel("STO-ECC-BLOCK-FAIL","Bounded-distance ECC block failure","P_fail=sum_{k=t+1}^n C(n,k)p^k(1-p)^(n-k)",("bit_count","ber","correctable_errors"),("failure_probability",)),
   StorageModel("STO-RW-THROUGHPUT","Effective coded throughput","R_eff=R_raw r_code (1-p_retry)",("raw_rate_bps","code_rate","retry_probability"),("effective_bps",)),
   StorageModel("STO-RW-LATENCY","Transfer latency","t=t_fixed+N_bit/R_eff",("payload_bits","throughput_bps","fixed_latency_s"),("latency_s",)),
   StorageModel("STO-DESIGN-READINESS","Storage Design Studio readiness","requirements + evidence + provenance",("metrics","requirements","evidence_ids","source_ids"),("readiness",)),
  )}
 def get(self,model_id):return self._models[model_id]
 def all(self):return tuple(self._models.values())
