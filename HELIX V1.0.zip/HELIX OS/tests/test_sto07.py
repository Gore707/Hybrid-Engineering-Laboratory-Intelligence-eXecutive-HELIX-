import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-STO";sp=importlib.util.spec_from_file_location("skl_sto",M/"__init__.py",submodule_search_locations=[str(M)]);s=importlib.util.module_from_spec(sp);sys.modules["skl_sto"]=s;sp.loader.exec_module(s)
class T(unittest.TestCase):
 def test_density(self):
  d=s.density_report(s.CapacityMetric(1000,s.InformationUnit.CLASSICAL_BIT),s.PhysicalEnvelope(2,4,5));self.assertEqual((d.bits_per_m2,d.bits_per_m3,d.bits_per_kg),(500,250,200))
 def test_quantum_not_classical_density(self):
  d=s.density_report(s.CapacityMetric(10,s.InformationUnit.QUBIT),s.PhysicalEnvelope(1,1,1));self.assertIsNone(d.bits_per_m3)
 def test_efficiency(self):self.assertEqual(s.encoding_efficiency(800,1000),.8)
 def test_aggregate(self):self.assertEqual(s.aggregate_classical_capacity([s.CapacityMetric(10,s.InformationUnit.CLASSICAL_BIT),s.CapacityMetric(20,s.InformationUnit.CLASSICAL_BIT)]).value,30)
 def test_reject_mixed(self):
  with self.assertRaises(TypeError):s.aggregate_classical_capacity([s.CapacityMetric(1,s.InformationUnit.CLASSICAL_BIT),s.CapacityMetric(1,s.InformationUnit.QUBIT)])
 def test_compare(self):self.assertEqual(s.compare_same_unit(s.CapacityMetric(20,s.InformationUnit.CLASSICAL_BIT),s.CapacityMetric(10,s.InformationUnit.CLASSICAL_BIT)),2)
 def test_reject_compare(self):
  with self.assertRaises(TypeError):s.compare_same_unit(s.CapacityMetric(1,s.InformationUnit.CLASSICAL_BIT),s.CapacityMetric(1,s.InformationUnit.QUBIT))
 def test_scaling(self):self.assertEqual(s.geometric_scaling_capacity(100,2,3),800)
 def test_effective(self):self.assertAlmostEqual(s.effective_density(1000,.8,.1,.1),640)
 def test_shannon(self):self.assertEqual(s.shannon_binary_channel_capacity_bits_per_symbol(0),1);self.assertEqual(s.shannon_binary_channel_capacity_bits_per_symbol(.5),0)
 def test_registry(self):self.assertEqual(s.StorageRegistry().get("STO-BSC-CAPACITY").evidence_class,"ESTABLISHED_PHYSICS")
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-STO-07")
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse((M/"CORE_1_0_MANIFEST.json").exists())
 def test_no_acceptance(self):self.assertFalse(list(R.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
