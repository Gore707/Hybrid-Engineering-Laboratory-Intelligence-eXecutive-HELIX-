from __future__ import annotations
from dataclasses import dataclass
import cmath,math
@dataclass(frozen=True)
class GaussianBeam:
 wavelength_m:float;waist_m:float;refractive_index:float=1.0;power_w:float=1.0
 def __post_init__(self):
  if self.wavelength_m<=0 or self.waist_m<=0 or self.refractive_index<=0 or self.power_w<0:raise ValueError("invalid Gaussian beam")
 @property
 def medium_wavelength_m(self):return self.wavelength_m/self.refractive_index
 @property
 def rayleigh_range_m(self):return math.pi*self.waist_m**2/self.medium_wavelength_m
 @property
 def divergence_half_angle_rad(self):return self.medium_wavelength_m/(math.pi*self.waist_m)
 def radius_m(self,z_m):return self.waist_m*math.sqrt(1+(z_m/self.rayleigh_range_m)**2)
 def curvature_radius_m(self,z_m):
  if z_m==0:return math.inf
  return z_m*(1+(self.rayleigh_range_m/z_m)**2)
 def gouy_phase_rad(self,z_m):return math.atan(z_m/self.rayleigh_range_m)
 def on_axis_intensity_w_m2(self,z_m):
  w=self.radius_m(z_m);return 2*self.power_w/(math.pi*w*w)
 def intensity_w_m2(self,r_m,z_m):
  w=self.radius_m(z_m);return self.on_axis_intensity_w_m2(z_m)*math.exp(-2*r_m*r_m/(w*w))
 def q(self,z_m=0.0):return complex(z_m,self.rayleigh_range_m)
def q_propagate(q_in,abcd):
 denom=abcd.C*q_in+abcd.D
 if abs(denom)==0:raise ValueError("singular ABCD transform")
 return (abcd.A*q_in+abcd.B)/denom
def beam_from_q(q,wavelength_m,refractive_index=1.0,power_w=1.0):
 if q.imag<=0:raise ValueError("physical Gaussian q must have positive imaginary part")
 lam=wavelength_m/refractive_index
 inv=1/q
 imag=-inv.imag
 if imag<=0:raise ValueError("invalid q parameter")
 w=math.sqrt(lam/(math.pi*imag))
 curvature=math.inf if abs(inv.real)<1e-30 else 1/inv.real
 return {"radius_m":w,"curvature_radius_m":curvature,"q":q,"power_w":power_w}
def focus_waist_collimated(input_radius_m,focal_length_m,wavelength_m,refractive_index=1.0):
 if min(input_radius_m,abs(focal_length_m),wavelength_m,refractive_index)<=0:raise ValueError("positive beam/focal/wavelength/index magnitudes required")
 return wavelength_m*abs(focal_length_m)/(math.pi*refractive_index*input_radius_m)
def m2_divergence_half_angle(wavelength_m,waist_m,m2=1.0,refractive_index=1.0):
 if wavelength_m<=0 or waist_m<=0 or m2<1 or refractive_index<=0:raise ValueError("invalid M2 beam parameters")
 return m2*wavelength_m/(math.pi*refractive_index*waist_m)
