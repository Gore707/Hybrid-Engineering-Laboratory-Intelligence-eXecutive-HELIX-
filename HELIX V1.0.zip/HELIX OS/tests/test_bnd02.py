import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-BND"
sp=importlib.util.spec_from_file_location("skl_bnd",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_bnd"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_q_zero_mass(self):self.assertEqual(q.momentum_mismatch_ev(0,1),0)
 def test_q_formula(self):self.assertAlmostEqual(q.momentum_mismatch_ev(1e-3,1),5e-7)
 def test_coherence_infinite(self):self.assertTrue(math.isinf(q.coherence_length_m(0,1)))
 def test_coherence_positive(self):self.assertGreater(q.coherence_length_m(1e-3,1),0)
 def test_sinc_zero(self):self.assertEqual(q.sinc(0),1)
 def test_probability_bounds(self):self.assertTrue(0<=q.photon_axion_conversion_probability(1e-10,10,10,1e-4,1)<=1)
 def test_probability_zero_coupling(self):self.assertEqual(q.photon_axion_conversion_probability(0,10,10),0)
 def test_lsw_product(self):self.assertAlmostEqual(q.light_shining_through_wall_probability(.1,.2),.02)
 def test_rate(self):self.assertAlmostEqual(q.regenerated_photon_rate_s(100,.1,.2,.5),1)
 def test_snr(self):self.assertGreater(q.poisson_detection_snr(10,1,10),0)
 def test_bit_rate(self):self.assertEqual(q.ideal_regenerated_bit_rate_bps(100,10),10)
 def test_no_ftl(self):self.assertFalse(q.axion_information_speed_status(q.C_M_S*1.01))
 def test_stage(self):self.assertGreaterEqual(q.AxionConversionStage(1e-10,10,10,1e-4,1).probability,0)
 def test_link_evidence(self):
  a=q.AxionConversionStage(1e-10,10,10,1e-4,1);l=q.AxionCommunicationLink(a,a,1e20);self.assertEqual(l.evidence,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED)
 def test_link_rate(self):
  a=q.AxionConversionStage(1e-8,10,10,0,1);l=q.AxionCommunicationLink(a,a,1e20);self.assertGreaterEqual(l.ideal_bit_rate_bps,0)
 def test_registry(self):self.assertTrue({"BND-AX-Q","BND-AX-LCOH","BND-AX-CONV","BND-AX-LSW"}<={x.model_id for x in q.default_registry().all()})
 def test_foundation_guard(self):self.assertFalse(q.established_physics_causality_bypass_available())
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-BND-02")
 def test_ecc_complete(self):self.assertEqual(json.loads((R/"ECC_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
