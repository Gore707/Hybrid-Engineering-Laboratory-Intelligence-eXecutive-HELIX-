from __future__ import annotations
from dataclasses import dataclass
import math

def memory_round_trip_efficiency(write_efficiency,storage_survival,read_efficiency):
    if not all(0<=x<=1 for x in (write_efficiency,storage_survival,read_efficiency)):raise ValueError("efficiencies in [0,1]")
    return write_efficiency*storage_survival*read_efficiency

def exponential_memory_survival(storage_time_s,coherence_time_s):
    if storage_time_s<0 or coherence_time_s<=0:raise ValueError("invalid times")
    return math.exp(-storage_time_s/coherence_time_s)

def memory_efficiency_after_storage(write_efficiency,read_efficiency,storage_time_s,coherence_time_s):
    return memory_round_trip_efficiency(write_efficiency,exponential_memory_survival(storage_time_s,coherence_time_s),read_efficiency)

def multimode_throughput_limit_per_s(mode_capacity,cycle_time_s):
    if mode_capacity<1 or int(mode_capacity)!=mode_capacity or cycle_time_s<=0:raise ValueError("invalid capacity/cycle")
    return int(mode_capacity)/cycle_time_s

def synchronization_success_probability(memory_survival_a,memory_survival_b,read_efficiency_a=1.0,read_efficiency_b=1.0):
    if not all(0<=x<=1 for x in (memory_survival_a,memory_survival_b,read_efficiency_a,read_efficiency_b)):raise ValueError("efficiencies in [0,1]")
    return memory_survival_a*memory_survival_b*read_efficiency_a*read_efficiency_b

def required_coherence_time_s(wait_time_s,min_survival):
    if wait_time_s<0 or not 0<min_survival<1:raise ValueError("wait>=0 and survival in (0,1)")
    if wait_time_s==0:return 0.0
    return -wait_time_s/math.log(min_survival)

def memory_assisted_swap_rate_per_s(link_ready_rate_per_s,memory_round_trip_efficiency_value,bsm_success_probability):
    if link_ready_rate_per_s<0 or not all(0<=x<=1 for x in (memory_round_trip_efficiency_value,bsm_success_probability)):raise ValueError("invalid inputs")
    return link_ready_rate_per_s*memory_round_trip_efficiency_value*bsm_success_probability

@dataclass(frozen=True)
class QuantumRepeaterMemory:
    write_efficiency:float
    read_efficiency:float
    coherence_time_s:float
    mode_capacity:int=1
    cycle_time_s:float=1e-3
    platform:str="GENERIC"
    def __post_init__(self):
        if not all(0<=x<=1 for x in (self.write_efficiency,self.read_efficiency)):raise ValueError("efficiencies in [0,1]")
        if self.coherence_time_s<=0 or self.mode_capacity<1 or int(self.mode_capacity)!=self.mode_capacity or self.cycle_time_s<=0:raise ValueError("invalid memory resources")
    def survival(self,storage_time_s):return exponential_memory_survival(storage_time_s,self.coherence_time_s)
    def round_trip_efficiency(self,storage_time_s):return memory_efficiency_after_storage(self.write_efficiency,self.read_efficiency,storage_time_s,self.coherence_time_s)
    @property
    def mode_throughput_limit_per_s(self):return multimode_throughput_limit_per_s(self.mode_capacity,self.cycle_time_s)

@dataclass(frozen=True)
class MemoryAssistedRepeaterNode:
    memory_a:QuantumRepeaterMemory
    memory_b:QuantumRepeaterMemory
    expected_wait_a_s:float
    expected_wait_b_s:float
    bell_measurement_success_probability:float
    link_pair_ready_rate_per_s:float
    def __post_init__(self):
        if self.expected_wait_a_s<0 or self.expected_wait_b_s<0 or self.link_pair_ready_rate_per_s<0 or not 0<=self.bell_measurement_success_probability<=1:
            raise ValueError("invalid node inputs")
    @property
    def eta_a(self):return self.memory_a.round_trip_efficiency(self.expected_wait_a_s)
    @property
    def eta_b(self):return self.memory_b.round_trip_efficiency(self.expected_wait_b_s)
    @property
    def synchronized_memory_efficiency(self):return self.eta_a*self.eta_b
    @property
    def output_rate_per_s(self):
        return self.link_pair_ready_rate_per_s*self.synchronized_memory_efficiency*self.bell_measurement_success_probability
    @property
    def bottleneck_mode_throughput_per_s(self):
        return min(self.memory_a.mode_throughput_limit_per_s,self.memory_b.mode_throughput_limit_per_s)
