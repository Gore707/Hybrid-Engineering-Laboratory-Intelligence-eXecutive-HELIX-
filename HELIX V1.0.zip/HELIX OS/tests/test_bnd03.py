import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-BND"
sp=importlib.util.spec_from_file_location("skl_bnd",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_bnd"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_q(self):self.assertAlmostEqual(q.dark_photon_momentum_mismatch_ev(1e-3,1),5e-7)
 def test_coh_inf(self):self.assertTrue(math.isinf(q.dark_photon_coherence_length_m(0,1)))
 def test_coh_pos(self):self.assertGreater(q.dark_photon_coherence_length_m(1e-3,1),0)
 def test_zero_mix(self):self.assertEqual(q.photon_dark_photon_probability(0,10,1e-3,1),0)
 def test_prob_bounds(self):self.assertTrue(0<=q.photon_dark_photon_probability(1e-3,10,1e-3,1)<=1)
 def test_regen(self):self.assertAlmostEqual(q.regeneration_probability(.1,.2),.02)
 def test_event_rate(self):self.assertAlmostEqual(q.regenerated_event_rate_s(100,.1,.2,.5),1)
 def test_atten(self):self.assertAlmostEqual(q.attenuation_transmission(0),1)
 def test_coupling(self):self.assertEqual(q.effective_visible_coupling(1e-6,2),2e-6)
 def test_snr(self):self.assertGreater(q.poisson_snr(10,1,10),0)
 def test_rate(self):self.assertEqual(q.ideal_bit_rate_bps(100,10),10)
 def test_no_ftl(self):self.assertFalse(q.dark_photon_information_speed_status(q.C_M_S*1.01))
 def test_stage(self):self.assertGreaterEqual(q.DarkPhotonStage(1e-3,10,1e-3,1).probability,0)
 def test_link_evidence(self):
  a=q.DarkPhotonStage(1e-3,10,1e-3,1);l=q.DarkPhotonCommunicationLink(a,a,1e20);self.assertEqual(l.evidence,q.BoundaryEvidence.SPECULATIVE_UNRESOLVED)
 def test_link_rate(self):
  a=q.DarkPhotonStage(1e-3,10,1e-3,1);self.assertGreaterEqual(q.DarkPhotonCommunicationLink(a,a,1e20).ideal_bit_rate_bps,0)
 def test_axion_preserved(self):self.assertGreaterEqual(q.photon_axion_conversion_probability(1e-10,10,10),0)
 def test_registry(self):self.assertTrue({"BND-DP-Q","BND-DP-LCOH","BND-DP-OSC","BND-DP-REG"}<={x.model_id for x in q.default_registry().all()})
 def test_foundation_guard(self):self.assertFalse(q.established_physics_causality_bypass_available())
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-BND-03")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
