import os, unittest
from pathlib import Path
os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
from core.bootstrap.identity import IDENTITY
from core.commands import *
from core.guardian.console import GuardianConsoleEngine
from core.guardian.nlu import RuleBasedInterpreter
from core.guardian.workflow import GuidedWorkflow

ROOT=Path(__file__).resolve().parents[1]

def make_service():
    r=ActionRegistry()
    r.register(ActionDefinition("project.save","Save Project","",lambda p,c:{"saved":True}))
    r.register(ActionDefinition("session.checkpoint","Checkpoint","",lambda p,c:{"checkpoint":"x"}))
    r.register(ActionDefinition("workspace.reset","Reset","",lambda p,c:{"layout":"Scientific Default"}))
    r.register(ActionDefinition("workspace.save","Save Layout","",lambda p,c:{"layout":p["name"]},(ParameterSpec("name",str),)))
    r.register(ActionDefinition("workspace.restore","Restore Layout","",lambda p,c:{"layout":p["name"]},(ParameterSpec("name",str),)))
    return CommandService(r)

class C08Tests(unittest.TestCase):
    def setUp(self):
        self.s=make_service()
        self.e=GuardianConsoleEngine(self.s,lambda:CommandContext("GUARDIAN","tester"),
            lambda:{"Project":"Test"},lambda:["Optics","Default Lab"])

    def test_identity(self): self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C08")
    def test_nlu_save_project(self):
        r=self.e.handle("save the project"); self.assertTrue(r.ok); self.assertIn("COMPLETED",r.text)
    def test_nlu_checkpoint(self):
        self.assertTrue(self.e.handle("create a recovery checkpoint").ok)
    def test_nlu_named_workspace(self):
        r=self.e.handle("save workspace as Cryo Lab"); self.assertTrue(r.ok); self.assertIn("Cryo Lab",r.text)
        r=self.e.handle("restore workspace optics"); self.assertTrue(r.ok); self.assertIn("Optics",r.text)
    def test_unknown_nlu_is_not_guessed(self):
        r=self.e.handle("invent a warp drive"); self.assertFalse(r.ok); self.assertIn("No deterministic",r.text)
    def test_workflow_engine(self):
        w=GuidedWorkflow(self.s.registry)
        self.assertEqual(w.start("workspace.save"),"Enter name:")
        self.assertIsNone(w.accept("Lab One")); self.assertTrue(w.complete())
        aid,p=w.consume(); self.assertEqual(aid,"workspace.save"); self.assertEqual(p["name"],"Lab One")
    def test_cancel_clears_workflow(self):
        self.e.workflow.start("workspace.save")
        self.e.handle("CANCEL"); self.assertIsNone(self.e.workflow.state)
    def test_interpreter_confidence_is_explicit(self):
        i=RuleBasedInterpreter().interpret("save the project",[])
        self.assertTrue(i.matched); self.assertGreaterEqual(i.confidence,.9)
    def test_no_fake_success_for_missing_layout(self):
        r=self.e.handle("restore workspace Missing"); self.assertFalse(r.ok)
    def test_ui_if_available(self):
        try:
            from PySide6.QtWidgets import QApplication
            from core.bootstrap.config import load_config
            from core.ui.main_window import HelixMainWindow
        except ImportError: self.skipTest("PySide6 not installed")
        app=QApplication.instance() or QApplication([])
        w=HelixMainWindow(load_config(ROOT/"skl.config"),ROOT)
        console=w.workspace.docks["helix.guardian"].widget()
        self.assertEqual(console.mode.text(),"C08 CONTEXTUAL")

if __name__=="__main__":unittest.main()
