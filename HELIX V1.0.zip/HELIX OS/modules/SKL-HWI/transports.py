from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import socket,time
from .foundation import InstrumentTransport

class TransportKind(str,Enum):
    USB="USB"; SERIAL="SERIAL"; TCP="TCP"; VISA="VISA"; SCPI="SCPI"

class TransportError(RuntimeError):pass
class TransportUnavailable(TransportError):pass
class TransportTimeout(TransportError):pass
class TransportProtocolError(TransportError):pass

@dataclass(frozen=True)
class TransportDescriptor:
    kind:TransportKind
    address:str
    vendor_id:int|None=None
    product_id:int|None=None
    serial_number:str=""
    description:str=""
    def __post_init__(self):
        if not self.address:raise ValueError("transport address required")

@dataclass(frozen=True)
class TimeoutPolicy:
    connect_timeout_s:float=3.0
    io_timeout_s:float=2.0
    def __post_init__(self):
        if self.connect_timeout_s<=0 or self.io_timeout_s<=0:raise ValueError("timeouts must be positive")

@dataclass(frozen=True)
class ReconnectPolicy:
    attempts:int=3
    initial_delay_s:float=.25
    backoff:float=2.0
    max_delay_s:float=5.0
    def __post_init__(self):
        if self.attempts<1 or self.initial_delay_s<0 or self.backoff<1 or self.max_delay_s<0:raise ValueError("invalid reconnect policy")
    def delay_for_attempt(self,index):
        if index<0:raise ValueError("index >= 0")
        return min(self.max_delay_s,self.initial_delay_s*(self.backoff**index))

class TCPTransport(InstrumentTransport):
    transport_name="TCP"
    def __init__(self,host,port,timeout=TimeoutPolicy()):
        if not host or not 0<port<65536:raise ValueError("invalid TCP endpoint")
        self.host=host;self.port=port;self.timeout=timeout;self.sock=None
    def open(self):
        try:self.sock=socket.create_connection((self.host,self.port),self.timeout.connect_timeout_s);self.sock.settimeout(self.timeout.io_timeout_s)
        except socket.timeout as e:raise TransportTimeout(str(e)) from e
        except OSError as e:raise TransportUnavailable(str(e)) from e
    def close(self):
        if self.sock is not None:
            try:self.sock.close()
            finally:self.sock=None
    def _require(self):
        if self.sock is None:raise TransportUnavailable("TCP transport is not open")
    def write_raw(self,data):
        self._require()
        try:self.sock.sendall(data)
        except socket.timeout as e:raise TransportTimeout(str(e)) from e
        except OSError as e:raise TransportError(str(e)) from e
    def read_raw(self,max_bytes=65536):
        self._require()
        try:return self.sock.recv(max_bytes)
        except socket.timeout as e:raise TransportTimeout(str(e)) from e
        except OSError as e:raise TransportError(str(e)) from e
    def read(self,capability_id):raise TransportProtocolError("capability mapping requires an instrument driver")
    def write(self,capability_id,value):raise TransportProtocolError("capability mapping requires an instrument driver")

class SerialTransport(InstrumentTransport):
    transport_name="SERIAL"
    def __init__(self,port,baudrate=115200,timeout=TimeoutPolicy()):
        if not port or baudrate<=0:raise ValueError("invalid serial configuration")
        self.port=port;self.baudrate=baudrate;self.timeout=timeout;self.handle=None
    def open(self):
        try:import serial
        except ImportError as e:raise TransportUnavailable("pyserial is not installed") from e
        try:self.handle=serial.Serial(self.port,self.baudrate,timeout=self.timeout.io_timeout_s,write_timeout=self.timeout.io_timeout_s)
        except Exception as e:raise TransportUnavailable(str(e)) from e
    def close(self):
        if self.handle is not None:
            try:self.handle.close()
            finally:self.handle=None
    def read(self,capability_id):raise TransportProtocolError("capability mapping requires an instrument driver")
    def write(self,capability_id,value):raise TransportProtocolError("capability mapping requires an instrument driver")

class USBTransport(InstrumentTransport):
    transport_name="USB"
    def __init__(self,vendor_id,product_id,serial_number=None,timeout=TimeoutPolicy()):
        if not 0<=vendor_id<=0xffff or not 0<=product_id<=0xffff:raise ValueError("USB VID/PID out of range")
        self.vendor_id=vendor_id;self.product_id=product_id;self.serial_number=serial_number;self.timeout=timeout;self.device=None
    def open(self):
        try:import usb.core
        except ImportError as e:raise TransportUnavailable("PyUSB is not installed") from e
        dev=usb.core.find(idVendor=self.vendor_id,idProduct=self.product_id)
        if dev is None:raise TransportUnavailable("USB device not found")
        self.device=dev
    def close(self):self.device=None
    def read(self,capability_id):raise TransportProtocolError("USB endpoint/protocol requires an instrument driver")
    def write(self,capability_id,value):raise TransportProtocolError("USB endpoint/protocol requires an instrument driver")

class SCPIClient:
    def __init__(self,write_line,read_line):
        self._write=write_line;self._read=read_line
    def command(self,text):
        if not text or "?" in text:raise ValueError("SCPI command must be non-query")
        self._write(text.rstrip()+"\n")
    def query(self,text):
        if "?" not in text:raise ValueError("SCPI query must contain ?")
        self._write(text.rstrip()+"\n")
        reply=self._read()
        if reply is None:raise TransportProtocolError("empty SCPI response")
        return str(reply).strip()
    def identify(self):return self.query("*IDN?")

class VISATransport(InstrumentTransport):
    transport_name="VISA"
    def __init__(self,resource_name,timeout=TimeoutPolicy()):
        if not resource_name:raise ValueError("VISA resource required")
        self.resource_name=resource_name;self.timeout=timeout;self.rm=None;self.resource=None
    def open(self):
        try:import pyvisa
        except ImportError as e:raise TransportUnavailable("PyVISA is not installed") from e
        try:
            self.rm=pyvisa.ResourceManager();self.resource=self.rm.open_resource(self.resource_name)
            self.resource.timeout=int(self.timeout.io_timeout_s*1000)
        except Exception as e:raise TransportUnavailable(str(e)) from e
    def close(self):
        if self.resource is not None:
            try:self.resource.close()
            finally:self.resource=None
        if self.rm is not None:
            try:self.rm.close()
            finally:self.rm=None
    def query_scpi(self,text):
        if self.resource is None:raise TransportUnavailable("VISA resource not open")
        try:return str(self.resource.query(text)).strip()
        except Exception as e:raise TransportError(str(e)) from e
    def read(self,capability_id):raise TransportProtocolError("capability mapping requires an instrument driver")
    def write(self,capability_id,value):raise TransportProtocolError("capability mapping requires an instrument driver")

def discover_serial():
    try:
        from serial.tools import list_ports
    except ImportError:return ()
    return tuple(TransportDescriptor(TransportKind.SERIAL,p.device,description=p.description or "") for p in list_ports.comports())

def discover_visa():
    try:import pyvisa
    except ImportError:return ()
    rm=None
    try:
        rm=pyvisa.ResourceManager()
        return tuple(TransportDescriptor(TransportKind.VISA,r) for r in rm.list_resources())
    except Exception:return ()
    finally:
        if rm is not None:
            try:rm.close()
            except Exception:pass

def discover_usb():
    try:import usb.core
    except ImportError:return ()
    try:
        out=[]
        for d in usb.core.find(find_all=True) or ():
            out.append(TransportDescriptor(TransportKind.USB,f"usb:{d.idVendor:04x}:{d.idProduct:04x}",d.idVendor,d.idProduct))
        return tuple(out)
    except Exception:return ()

def discover_all():
    return discover_serial()+discover_visa()+discover_usb()

def validate_scpi_identity(idn):
    parts=[p.strip() for p in str(idn).split(",")]
    return len(parts)>=2 and bool(parts[0]) and bool(parts[1])

def reconnect(operation,policy=ReconnectPolicy(),sleep=time.sleep):
    last=None
    for i in range(policy.attempts):
        try:return operation()
        except (TransportError,OSError) as e:
            last=e
            if i+1<policy.attempts:sleep(policy.delay_for_attempt(i))
    raise TransportUnavailable(f"reconnect exhausted after {policy.attempts} attempts: {last}")
