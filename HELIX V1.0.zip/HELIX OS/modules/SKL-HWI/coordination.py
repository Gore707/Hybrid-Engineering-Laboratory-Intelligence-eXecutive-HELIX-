from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

class TriggerSource(str,Enum):
    SOFTWARE="SOFTWARE"
    HARDWARE="HARDWARE"
    EXTERNAL="EXTERNAL"

class TriggerEdge(str,Enum):
    RISING="RISING"
    FALLING="FALLING"
    EITHER="EITHER"

class InterlockState(str,Enum):
    SAFE="SAFE"
    BLOCKED="BLOCKED"
    TRIPPED="TRIPPED"

@dataclass(frozen=True)
class TriggerConfiguration:
    trigger_id:str
    source:TriggerSource
    edge:TriggerEdge=TriggerEdge.RISING
    threshold:float|None=None
    hysteresis:float=0.0
    pre_trigger_s:float=0.0
    post_trigger_s:float=0.0
    def __post_init__(self):
        if not self.trigger_id:raise ValueError("trigger_id required")
        if self.hysteresis<0 or self.pre_trigger_s<0 or self.post_trigger_s<0:raise ValueError("timing/hysteresis nonnegative")

def threshold_crossed(previous,current,config):
    if config.threshold is None:raise ValueError("threshold trigger requires threshold")
    lo=config.threshold-config.hysteresis/2
    hi=config.threshold+config.hysteresis/2
    rising=previous<lo and current>=hi
    falling=previous>hi and current<=lo
    return rising if config.edge==TriggerEdge.RISING else falling if config.edge==TriggerEdge.FALLING else rising or falling

@dataclass(frozen=True)
class SynchronizationGroup:
    group_id:str
    channel_ids:tuple[str,...]
    max_skew_s:float
    def __post_init__(self):
        if not self.group_id or not self.channel_ids or self.max_skew_s<0:raise ValueError("invalid synchronization group")
        if len(set(self.channel_ids))!=len(self.channel_ids):raise ValueError("duplicate channel")

def synchronization_within_tolerance(timestamps_by_channel,group):
    missing=[c for c in group.channel_ids if c not in timestamps_by_channel]
    if missing:return False,math.inf
    vals=[float(timestamps_by_channel[c]) for c in group.channel_ids]
    skew=max(vals)-min(vals)
    return skew<=group.max_skew_s,skew

@dataclass(frozen=True)
class Interlock:
    interlock_id:str
    description:str
    state:InterlockState=InterlockState.SAFE
    required_for_execution:bool=True
    def __post_init__(self):
        if not self.interlock_id or not self.description:raise ValueError("interlock identity required")

def interlocks_allow_execution(interlocks):
    return all((not x.required_for_execution) or x.state==InterlockState.SAFE for x in interlocks)

@dataclass(frozen=True)
class SequenceStep:
    step_id:str
    offset_s:float
    action_id:str
    device_id:str|None=None
    requires_confirmation:bool=False
    def __post_init__(self):
        if not self.step_id or not self.action_id or self.offset_s<0:raise ValueError("invalid sequence step")

class ExperimentTimeline:
    def __init__(self,steps):
        self.steps=tuple(sorted(steps,key=lambda x:(x.offset_s,x.step_id)))
        ids=[x.step_id for x in self.steps]
        if len(ids)!=len(set(ids)):raise ValueError("duplicate step_id")
    def scheduled(self,t0_s):
        return tuple((t0_s+s.offset_s,s) for s in self.steps)

@dataclass(frozen=True)
class ExecutionPreflight:
    interlocks_ok:bool
    sync_ok:bool
    observed_skew_s:float
    blocked_reasons:tuple[str,...]
    @property
    def ready(self):return self.interlocks_ok and self.sync_ok and not self.blocked_reasons

def coordinated_preflight(interlocks,sync_group=None,timestamps_by_channel=None):
    reasons=[]
    iok=interlocks_allow_execution(interlocks)
    if not iok:reasons.append("required interlock not SAFE")
    if sync_group is None:
        sok=True;skew=0.0
    else:
        sok,skew=synchronization_within_tolerance(timestamps_by_channel or {},sync_group)
        if not sok:reasons.append("synchronization tolerance exceeded or channel missing")
    return ExecutionPreflight(iok,sok,skew,tuple(reasons))

class CoordinatedExecutor:
    """Deterministic dispatcher. It calls supplied action handlers; it does not bypass device/HAL safety authority."""
    def __init__(self,handlers):self.handlers=dict(handlers);self.history=[]
    def execute(self,timeline,t0_s,preflight,confirmed_step_ids=()):
        if not preflight.ready:raise PermissionError("preflight blocked")
        confirmed=set(confirmed_step_ids);out=[]
        for when,step in timeline.scheduled(t0_s):
            if step.requires_confirmation and step.step_id not in confirmed:raise PermissionError(f"confirmation required: {step.step_id}")
            if step.action_id not in self.handlers:raise KeyError(step.action_id)
            result=self.handlers[step.action_id](step)
            record=(when,step.step_id,step.action_id,step.device_id,result)
            self.history.append(record);out.append(record)
        return tuple(out)
