import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QCOM"
sp=importlib.util.spec_from_file_location("skl_qcom",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qcom"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_poisson_sum(self):self.assertAlmostEqual(sum(q.poisson_photon_probability(.5,n) for n in range(20)),1,places=12)
 def test_single(self):self.assertAlmostEqual(q.poisson_single_photon_probability(1),math.exp(-1))
 def test_multi(self):self.assertGreater(q.multiphoton_probability(.5),0)
 def test_yield_zero(self):self.assertEqual(q.channel_yield_n(0,.5,0),0)
 def test_yield_one(self):self.assertEqual(q.channel_yield_n(1,.5,0),.5)
 def test_gain(self):self.assertAlmostEqual(q.coherent_state_gain(.5,.1),1-math.exp(-.05))
 def test_qber_no_error(self):self.assertEqual(q.coherent_state_qber(.5,.1,0,0),0)
 def test_qber_background(self):self.assertGreater(q.coherent_state_qber(.5,.01,.001,.01),.01)
 def test_decoy_bound(self):
  x=q.VacuumWeakDecoyExperiment(.5,.1,.1,1e-6,.01);self.assertGreater(x.y1_lower,0);self.assertGreater(x.q1_lower,0)
 def test_decoy_error(self):
  x=q.VacuumWeakDecoyExperiment(.5,.1,.1,1e-6,.01);self.assertTrue(0<=x.e1_upper<=.5)
 def test_secret_nonnegative(self):
  x=q.VacuumWeakDecoyExperiment(.5,.1,.1,1e-6,.01);self.assertGreaterEqual(x.secret_bits_per_emitted_signal_pulse,0)
 def test_ec_leak_zero(self):self.assertEqual(q.error_correction_leak_bits(1000,0),0)
 def test_privacy(self):self.assertEqual(q.privacy_amplification_fraction_single_photon(0),1)
 def test_bad_mu(self):
  with self.assertRaises(ValueError):q.VacuumWeakDecoyExperiment(.1,.5,.1)
 def test_qkd_preserved(self):self.assertEqual(q.intercept_resend_qber(1),.25)
 def test_entanglement_preserved(self):self.assertAlmostEqual(q.pure_two_qubit_concurrence(q.bell_state_vector(q.BellState.PSI_MINUS)),1)
 def test_no_signalling_preserved(self):self.assertEqual(q.no_signalling_remote_probability("Z"),(.5,.5))
 def test_registry(self):self.assertTrue({"QCOM-POISSON","QCOM-GAIN","QCOM-DECOY-Y1","QCOM-DECOY-Q1","QCOM-DECOY-KEY"}<={x.model_id for x in q.QuantumCommRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QCOM-04")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
