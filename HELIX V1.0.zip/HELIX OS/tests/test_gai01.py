import unittest,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];A=(R/"core/guardian/ai_hardware.py").read_text();B=(R/"core/bootstrap/app.py").read_text();M=(R/"core/ui/main_window.py").read_text()
class GAI01(unittest.TestCase):
 def test_profile_builder(self):self.assertIn("def build_ai_profile",A);self.assertIn("guardian_budget",A)
 def test_runtime_inventory(self):
  for x in ("llama_cpp","torch","onnxruntime","onnxruntime_directml"):self.assertIn(x,A)
 def test_adaptive_model(self):self.assertIn('"locked_model":None',A);self.assertIn("hardware-adaptive",A)
 def test_budget(self):self.assertIn("class GuardianAIBudget",A);self.assertIn("CPU fallback",A)
 def test_no_acceleration_claim(self):self.assertIn("runtime compatibility must be validated",A)
 def test_bootstrap(self):self.assertIn("build_ai_profile(window.compute",B);self.assertIn("guardian_ai_profile.json",B)
 def test_windows_fix(self):self.assertIn('quick = QGroupBox("QUICK START")',M);self.assertNotIn('quick = QGroupBox, QDialog',M)
 def test_marker(self):
  d=json.loads((R/"GAI_01_COMPLETE.json").read_text());self.assertEqual(d["sequence"],"1/8");self.assertFalse(d["model_locked"])
 def test_ui_complete(self):self.assertTrue((R/"HELIX_UI_1_0_COMPLETE.json").exists())
 def test_backend(self):self.assertEqual(json.loads((R/"HELIX_136_COMPLETE.json").read_text())["patches_completed"],136)
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
