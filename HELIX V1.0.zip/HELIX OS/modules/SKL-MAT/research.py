from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import hashlib,json,os,time
@dataclass(frozen=True)
class MaterialSource:
 source_id:str;title:str;url:str="";doi:str="";publisher:str="";retrieved_utc:str=""
 license:str="";sha256:str="";evidence_class:str="UNCLASSIFIED"
 def __post_init__(self):
  if not self.source_id.strip() or not self.title.strip():raise ValueError("source id/title required")
@dataclass(frozen=True)
class PropertyDataset:
 dataset_id:str;material_id:str;property_id:str;domain_name:str;domain_unit:str;value_unit:str
 x:tuple[float,...];y:tuple[float,...];source_ids:tuple[str,...];evidence_class:str;uncertainty:tuple[float,...]=()
 def __post_init__(self):
  if not self.dataset_id or not self.material_id or not self.property_id:raise ValueError("dataset identity required")
  if len(self.x)!=len(self.y) or not self.x:raise ValueError("x/y lengths must match and be nonempty")
  if self.uncertainty and len(self.uncertainty)!=len(self.y):raise ValueError("uncertainty length mismatch")
  if any(not __import__("math").isfinite(v) for v in self.x+self.y+self.uncertainty):raise ValueError("dataset values must be finite")
class MaterialResearchStore:
 def __init__(self,path:Path):
  self.path=path;path.parent.mkdir(parents=True,exist_ok=True)
  if not path.exists():self._write({"sources":{},"datasets":{}})
 def _read(self):return json.loads(self.path.read_text(encoding="utf-8"))
 def _write(self,d):
  tmp=self.path.with_suffix(".tmp");tmp.write_text(json.dumps(d,indent=2,sort_keys=True),encoding="utf-8");os.replace(tmp,self.path)
 def add_source(self,s):
  d=self._read();d["sources"][s.source_id]=s.__dict__;self._write(d)
 def add_dataset(self,ds):
  d=self._read()
  missing=[x for x in ds.source_ids if x not in d["sources"]]
  if missing:raise ValueError("unknown source ids: "+", ".join(missing))
  rec=dict(ds.__dict__);rec["x"]=list(ds.x);rec["y"]=list(ds.y);rec["source_ids"]=list(ds.source_ids);rec["uncertainty"]=list(ds.uncertainty)
  d["datasets"][ds.dataset_id]=rec;self._write(d)
 def source(self,source_id):
  d=self._read();return MaterialSource(**d["sources"][source_id])
 def dataset(self,dataset_id):
  r=self._read()["datasets"][dataset_id]
  return PropertyDataset(**{**r,"x":tuple(r["x"]),"y":tuple(r["y"]),"source_ids":tuple(r["source_ids"]),"uncertainty":tuple(r["uncertainty"])})
 def datasets_for(self,material_id,property_id=None):
  d=self._read();out=[]
  for k in d["datasets"]:
   ds=self.dataset(k)
   if ds.material_id==material_id and (property_id is None or ds.property_id==property_id):out.append(ds)
  return tuple(out)
