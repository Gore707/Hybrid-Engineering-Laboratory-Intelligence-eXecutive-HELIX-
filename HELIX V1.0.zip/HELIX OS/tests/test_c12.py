import tempfile,unittest,json,time
from pathlib import Path
from core.bootstrap.identity import IDENTITY
from core.resource.governor import AdaptiveResourceGovernor,JobPriority
from core.resource.telemetry import ResourceTelemetry,sample
from core.resource.profiler import ComputerProfiler
from core.compute.manager import ComputeBackendManager
ROOT=Path(__file__).resolve().parents[1]
MODES=ROOT/"core/resources/resource_modes.json"
def tel(cpu=.2,ram=.2,gpu=.2,vram=.2,temp=50):
 return ResourceTelemetry(time.time(),cpu,ram,16_000,12_000,gpu,vram,temp)
class C12Tests(unittest.TestCase):
 def test_identity(self):self.assertEqual(IDENTITY.patch_id,"SKL-CORE-C12")
 def test_modes(self):
  g=AdaptiveResourceGovernor(MODES)
  for m in ("Quiet","Balanced","Performance"):g.set_mode(m);self.assertIn("cpu_limit",g.limits())
 def test_custom(self):
  g=AdaptiveResourceGovernor(MODES);c={"cpu_limit":.5,"memory_limit":.5,"gpu_limit":.5,"max_workers_fraction":.5}
  g.set_mode("Custom",c);self.assertEqual(g.limits(),c)
 def test_normal_allowed(self):self.assertTrue(AdaptiveResourceGovernor(MODES).decide(tel()).allowed)
 def test_cpu_pressure_throttles(self):
  d=AdaptiveResourceGovernor(MODES).decide(tel(cpu=.99));self.assertTrue(d.allowed);self.assertLess(d.batch_scale,1)
 def test_guardian_yields(self):
  d=AdaptiveResourceGovernor(MODES).decide(tel(cpu=.99),JobPriority.GUARDIAN);self.assertFalse(d.allowed)
 def test_hard_thermal_emergency(self):
  d=AdaptiveResourceGovernor(MODES,thermal_hard_c=90).decide(tel(temp=95),JobPriority.SAFETY)
  self.assertFalse(d.allowed);self.assertTrue(d.emergency)
 def test_priority_order(self):
  self.assertGreater(JobPriority.SAFETY,JobPriority.HARDWARE)
  self.assertGreater(JobPriority.HARDWARE,JobPriority.EXPERIMENT)
  self.assertGreater(JobPriority.EXPERIMENT,JobPriority.SCIENTIFIC_COMPUTE)
  self.assertGreater(JobPriority.SCIENTIFIC_COMPUTE,JobPriority.VISUALIZATION)
  self.assertGreater(JobPriority.VISUALIZATION,JobPriority.GUARDIAN)
 def test_telemetry_sample_real_object(self):
  t=sample();self.assertGreater(t.timestamp,0)
 def test_profiler_writes(self):
  with tempfile.TemporaryDirectory() as td:
   cm=ComputeBackendManager();p=Path(td)/"machine.json"
   d=ComputerProfiler(cm,p).build(.02);self.assertTrue(p.exists())
   self.assertGreater(d["microbenchmark"]["iterations"],0)
 def test_no_acceptance_files(self):self.assertFalse(list(ROOT.glob("*ACCEPTANCE.md")))
if __name__=="__main__":unittest.main()
