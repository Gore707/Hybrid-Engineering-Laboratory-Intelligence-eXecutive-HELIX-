from __future__ import annotations
import math
import numpy as np
from .foundation import no_cloning_guard
from .state_engine import purity,state_fidelity
from .rydberg import blockade_radius_m,blockade_shift_rad_s
from .atomic_vapor import beer_lambert_transmission
from .raman import time_bandwidth_product
from .rare_earth import afc_echo_time_s,afc_finesse
from .diamond import initialization_readout_success
from .bec import ideal_condensate_fraction
from .noise import combine_independent_rates_s_inv,effective_coherence_time_s
from .qec import majority_vote_logical_error_probability

def run_cross_engine_validation():
    checks={}
    rho=np.eye(2)/2
    checks["state_purity_mixed"]=math.isclose(purity(rho),.5,rel_tol=1e-12)
    checks["state_self_fidelity"]=math.isclose(state_fidelity(rho,rho),1,rel_tol=1e-9)
    c6=1e-60; gamma=1e6; rb=blockade_radius_m(c6,gamma)
    checks["rydberg_blockade_inverse"]=math.isclose(blockade_shift_rad_s(c6,rb),gamma,rel_tol=1e-9)
    checks["vapor_beer_lambert"]=math.isclose(beer_lambert_transmission(1),math.exp(-1),rel_tol=1e-12)
    checks["raman_tbp"]=math.isclose(time_bandwidth_product(.01,1e6),1e4,rel_tol=1e-12)
    checks["afc_echo"]=math.isclose(afc_echo_time_s(1e6),1e-6,rel_tol=1e-12)
    checks["afc_finesse"]=math.isclose(afc_finesse(10,2),5,rel_tol=1e-12)
    checks["diamond_io"]=math.isclose(initialization_readout_success(.9,.8),.72,rel_tol=1e-12)
    checks["bec_zero_temp"]=math.isclose(ideal_condensate_fraction(0,1),1,rel_tol=1e-12)
    checks["noise_rate_budget"]=math.isclose(combine_independent_rates_s_inv(1,2,3),6,rel_tol=1e-12)
    checks["noise_t2"]=math.isclose(effective_coherence_time_s(1,1),.5,rel_tol=1e-12)
    checks["qec_repetition"]=majority_vote_logical_error_probability(.1,3)<.1
    try:
        no_cloning_guard(2,True); checks["no_cloning_guard"]=False
    except ValueError: checks["no_cloning_guard"]=True
    return checks

def validation_passes():
    c=run_cross_engine_validation()
    return all(c.values()),c
