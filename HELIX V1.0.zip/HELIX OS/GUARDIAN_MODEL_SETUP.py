from __future__ import annotations
from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from core.guardian.model_activation import load_diagnostic,recommend_from_diagnostic,activate_local_gguf

def main():
    ap=argparse.ArgumentParser(description="HELIX Guardian local-model setup")
    ap.add_argument("--diagnostic",default=str(ROOT/"user"/"guardian_ai_diagnostic.json"))
    ap.add_argument("--model",help="Path to an existing local .gguf model")
    ap.add_argument("--name",default="Guardian Local Model")
    ap.add_argument("--context",type=int)
    ap.add_argument("--gpu-layers",type=int,default=0,
                    help="Explicit offload setting. Default 0 until benchmarked.")
    ap.add_argument("--threads",type=int)
    a=ap.parse_args()
    report=load_diagnostic(Path(a.diagnostic))
    rec=recommend_from_diagnostic(report)
    print(json.dumps(rec.__dict__,indent=2))
    if not a.model:
        print("\nRecommendation only. No model configured. Supply --model after selecting/downloading a GGUF.")
        return 0
    cfg=activate_local_gguf(ROOT,Path(a.model),a.name,a.context or rec.context_size,
                            gpu_layers=a.gpu_layers,threads=a.threads)
    print("\nGuardian model configuration written:")
    print(json.dumps(cfg.__dict__,indent=2))
    print("\nGPU layers remain explicit and must be validated by GACT-03 benchmarking.")
    return 0
if __name__=="__main__":raise SystemExit(main())
