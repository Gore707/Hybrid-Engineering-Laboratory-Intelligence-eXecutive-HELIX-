from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

VALID_PROVENANCE = {
    "HARDWARE", "IMPORTED", "SIMULATION", "SOFTWARE",
    "EXTRAPOLATED", "SPECULATIVE", "NEW_PHYSICS"
}

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

@dataclass(frozen=True)
class Provenance:
    source_type: str
    source_id: str
    confidence: float = 1.0
    evidence: str = "UNCLASSIFIED"

    def __post_init__(self):
        if self.source_type not in VALID_PROVENANCE:
            raise ValueError(f"Invalid provenance source_type: {self.source_type}")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence must be within [0, 1]")
        if not self.source_id.strip():
            raise ValueError("source_id is required")

@dataclass(frozen=True)
class BusMessage:
    topic: str
    provenance: Provenance
    timestamp_utc: str = field(default_factory=utc_now)
    message_id: str = field(default_factory=lambda: f"MSG-{uuid4().hex[:16].upper()}")

    def __post_init__(self):
        if not self.topic.strip():
            raise ValueError("topic is required")

@dataclass(frozen=True)
class TelemetrySample(BusMessage):
    quantity: str = ""
    value: float = 0.0
    unit: str = ""
    experiment_id: str | None = None

    def __post_init__(self):
        super().__post_init__()
        if not self.quantity.strip():
            raise ValueError("quantity is required")
        if not self.unit.strip():
            raise ValueError("unit is required")

@dataclass(frozen=True)
class ExperimentStateEvent(BusMessage):
    experiment_id: str = ""
    state: str = "IDLE"
    detail: str = ""

    def __post_init__(self):
        super().__post_init__()
        if not self.experiment_id.strip():
            raise ValueError("experiment_id is required")

@dataclass(frozen=True)
class DataReferenceEvent(BusMessage):
    dataset_id: str = ""
    uri: str = ""
    media_type: str = "application/octet-stream"
    description: str = ""

    def __post_init__(self):
        super().__post_init__()
        if not self.dataset_id.strip() or not self.uri.strip():
            raise ValueError("dataset_id and uri are required")

@dataclass(frozen=True)
class WarningEvent(BusMessage):
    severity: str = "WARNING"
    code: str = ""
    message: str = ""

    def __post_init__(self):
        super().__post_init__()
        if self.severity not in {"INFO","NOTICE","WARNING","ERROR","CRITICAL","EMERGENCY"}:
            raise ValueError("invalid severity")
        if not self.code.strip() or not self.message.strip():
            raise ValueError("warning code and message are required")
