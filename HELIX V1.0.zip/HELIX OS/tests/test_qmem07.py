import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM"
sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_echo(self):self.assertEqual(q.afc_echo_time_s(1e6),1e-6)
 def test_finesse(self):self.assertEqual(q.afc_finesse(10,2),5)
 def test_modes(self):self.assertEqual(q.afc_mode_capacity_estimate(10e6,1e6),10)
 def test_efficiency_range(self):
  e=q.afc_forward_efficiency_idealized(5,5);self.assertGreaterEqual(e,0);self.assertLessEqual(e,1)
 def test_efficiency_invalid(self):
  with self.assertRaises(ValueError):q.afc_forward_efficiency_idealized(-1,5)
 def test_spinwave_transfer_squared(self):self.assertAlmostEqual(q.afc_spin_wave_efficiency(.5,.8,.9),.288)
 def test_coherence_linewidth(self):self.assertAlmostEqual(q.lorentzian_coherence_time_s(1),1/math.pi)
 def test_hole_q(self):self.assertEqual(q.spectral_hole_quality_factor(100,2),50)
 def test_telecom_yes(self):self.assertTrue(q.telecom_band_relevance(1550e-9))
 def test_telecom_no(self):self.assertFalse(q.telecom_band_relevance(606e-9))
 def test_transition(self):
  t=q.RareEarthTransition("Er","host",1536e-9,1e3,1e9);self.assertTrue(t.is_in_broad_telecom_window);self.assertEqual(t.inhomogeneous_ratio,1e6)
 def test_bad_transition_widths(self):
  with self.assertRaises(ValueError):q.RareEarthTransition("Pr","host",606e-9,1e6,1e3)
 def test_afc_object(self):
  a=q.AFCMemoryEstimate(5,1e6,2e5,20e6);self.assertEqual(a.finesse,5);self.assertEqual(a.temporal_mode_estimate,20)
 def test_raman_preserved(self):self.assertEqual(q.time_bandwidth_product(.01,1e6),1e4)
 def test_vapor_preserved(self):self.assertAlmostEqual(q.beer_lambert_transmission(1),math.exp(-1))
 def test_registry(self):
  ids={x.model_id for x in q.QuantumMemoryRegistry().all()}
  self.assertTrue({"QMEM-AFC-ECHO","QMEM-AFC-FINESSE","QMEM-AFC-ETA-FWD","QMEM-RE-T2","QMEM-AFC-MODES"}<=ids)
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QMEM-07")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO"])
 def test_core_manifest(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists())
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
