from dataclasses import dataclass
@dataclass(frozen=True)
class InterstellarNetworkModel:
    model_id:str; name:str; equation:str; inputs:tuple; outputs:tuple
class InterstellarNetworkRegistry:
    def __init__(self):
        self._models=(
          InterstellarNetworkModel("ISN-LATENCY","Causal interstellar one-way latency","t=d/v, v<=c",("distance","propagation_speed"),("latency",)),
          InterstellarNetworkModel("ISN-FLUX","Isotropic free-space flux baseline","F=P/(4*pi*d^2)",("transmit_power","distance"),("flux",)),
          InterstellarNetworkModel("ISN-RELAY-COUNT","Relay count for maximum segment","Nrelay=ceil(D/Lmax)-1",("total_distance","max_segment"),("relay_count",)),
          InterstellarNetworkModel("ISN-STORE-FWD","Store-and-forward delivery time","t=sum(di)/v+(N-1)tproc",("segment_distances","speed","processing_delay"),("delivery_time",)),
          InterstellarNetworkModel("ISN-CLOCK-DRIFT","Clock drift uncertainty","dt=telapsed*y",("elapsed_time","fractional_frequency_error"),("timing_uncertainty",)),
          InterstellarNetworkModel("ISN-OPT-DIV","Diffraction-limited optical divergence","theta=1.22 lambda/D",("wavelength","transmitter_diameter"),("divergence",)),
          InterstellarNetworkModel("ISN-OPT-SPOT","Interstellar diffraction spot radius","r=d*theta",("distance","wavelength","transmitter_diameter"),("spot_radius",)),
          InterstellarNetworkModel("ISN-OPT-RX","Received optical power","Prx=Ptx*etaTx*etaCap*etaPoint*etaRx",("transmit_power","efficiencies"),("received_power",)),
          InterstellarNetworkModel("ISN-OPT-PHOTON","Detected photon rate","Ndot=Prx*etaD/(hc/lambda)",("received_power","wavelength","detector_efficiency"),("photon_rate",)),
          InterstellarNetworkModel("ISN-OPT-RATE","Ideal photon-limited bit rate","Rb=Ndot/nPhotonPerBit",("photon_rate","photons_per_bit"),("bit_rate",)),
          InterstellarNetworkModel("ISN-RELAY-CAP","Relay path steady-state capacity","Rpath=min(Ri)",("link_rates",),("capacity",)),
          InterstellarNetworkModel("ISN-RELAY-SERIAL","Serial store-forward message time","t=sum(B/Ri)+sum(tprop)+(N-1)tproc",("message_bits","rates","propagation","processing"),("delivery_time",)),
          InterstellarNetworkModel("ISN-RELAY-AVAIL","Series route availability","Aroute=product(Ai)",("availabilities",),("route_availability",)),
          InterstellarNetworkModel("ISN-RELAY-REDUND","Independent parallel-route availability","A=1-product(1-Ai)",("route_availabilities",),("network_availability",)),
          InterstellarNetworkModel("ISN-RELAY-GOODPUT","Effective relay goodput","G=Rraw*Psuccess*etaProtocol",("raw_rate","success_probability","protocol_efficiency"),("goodput",)),
          InterstellarNetworkModel("ISN-SGL-RS","Solar Schwarzschild radius","rs=2GM/c^2",("solar_mass",),("schwarzschild_radius",)),
          InterstellarNetworkModel("ISN-SGL-FMIN","Minimum SGL focal distance","z0=Rsun^2/(2rs)",("solar_radius","solar_mass"),("focal_distance",)),
          InterstellarNetworkModel("ISN-SGL-DEFLECT","Weak-field light deflection","alpha=4GM/(c^2 b)",("mass","impact_parameter"),("deflection",)),
          InterstellarNetworkModel("ISN-SGL-GAIN","Ideal on-axis SGL wave-optics gain","mu0=4*pi^2*GM/(c^2*lambda)",("mass","wavelength"),("gain",)),
          InterstellarNetworkModel("ISN-SGL-POINT","SGL transverse pointing tolerance","theta_tol=x_tol/z",("transverse_tolerance","focal_distance"),("angular_tolerance",)),
          InterstellarNetworkModel("ISN-PSR-PHASE","Pulsar pulse phase","phi=phi0+t/P",("elapsed_time","period","phase0"),("phase",)),
          InterstellarNetworkModel("ISN-PSR-RESID","Timing residual","r=t_obs-t_model",("observed_toa","predicted_toa"),("residual",)),
          InterstellarNetworkModel("ISN-PSR-RANGE","Timing residual range equivalent","dx=c*r",("timing_residual",),("range_equivalent",)),
          InterstellarNetworkModel("ISN-PSR-TOA","Combined TOA uncertainty","sigma=sqrt(sum(sigma_i^2))",("uncertainties",),("combined_uncertainty",)),
          InterstellarNetworkModel("ISN-PSR-CLOCK","Weighted clock offset","dt=sum(w_i r_i)/sum(w_i)",("residuals","uncertainties"),("clock_offset",)),
          InterstellarNetworkModel("ISN-GAL-COST","Multi-objective galactic edge cost","C=wL*d+wC/R+wA*(-ln A)",("distance","capacity","availability","weights"),("cost",)),
          InterstellarNetworkModel("ISN-GAL-AVAIL","Galactic path availability","Apath=product(Ai)",("edge_availabilities",),("path_availability",)),
          InterstellarNetworkModel("ISN-GAL-DENSITY","Linear infrastructure density","rho=N/L",("nodes","route_length"),("node_density",)),
          InterstellarNetworkModel("ISN-GAL-DEGREE","Average graph degree","kbar=2E/N",("edge_count","node_count"),("average_degree",)),
          InterstellarNetworkModel("ISN-GAL-GEN","Message propagation in human generations","Ng=d_ly/Tgeneration_yr",("distance_ly","generation_years"),("generations",)),
          InterstellarNetworkModel("ISN-SIM-ROUTE","Integrated route scenario","route(network,failures,weights)",("network","endpoints","failures","weights"),("scenario_result",)),
          InterstellarNetworkModel("ISN-SIM-MC","Monte Carlo network failure simulation","sample edge availability states",("network","trials","seed"),("resilience_summary",)),
          InterstellarNetworkModel("ISN-SIM-OPT-SWEEP","Interstellar optical distance sweep","Rb(d) from optical link model",("distances","optical_parameters"),("rate_curve",)),
          InterstellarNetworkModel("ISN-SIM-SGL-SWEEP","SGL focal-line sweep","gain(lambda), theta_tol=x_tol/z",("focal_distances","wavelength","position_tolerance"),("gain_pointing_curve",)),
          InterstellarNetworkModel("ISN-SIM-COMPARE","Architecture comparison","argmin latency; argmax capacity,availability",("scenario_results",),("comparative_winners",)),
          InterstellarNetworkModel("ISN-VAL-MC","Optical-link Monte Carlo uncertainty","sample power and pointing uncertainty",("link","trials","uncertainty"),("rate_distribution",)),
          InterstellarNetworkModel("ISN-VAL-SENS","Normalized local sensitivity","S=(dy/dx)(x/y)",("model","parameter","step"),("normalized_sensitivity",)),
          InterstellarNetworkModel("ISN-VAL-GATES","Interstellar engineering failure gates","evaluate causal,rate,pointing,route,SGL gates",("scenario","thresholds"),("findings",)),
        )
    def get(self,model_id):
        for x in self._models:
            if x.model_id==model_id:return x
        raise KeyError(model_id)
    def all(self):return self._models
