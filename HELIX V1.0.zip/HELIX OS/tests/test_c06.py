import os, tempfile, unittest
from pathlib import Path
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from core.bootstrap.config import load_config
from core.bootstrap.identity import IDENTITY
from core.commands import *
from core.commands.registry import RegistryError

ROOT = Path(__file__).resolve().parents[1]

class C06Tests(unittest.TestCase):
    def action(self, confirmation=ConfirmationLevel.NONE):
        return ActionDefinition(
            "test.scale", "Scale", "test",
            lambda p,c: {"answer": p["value"]*2},
            (ParameterSpec("value", int, minimum=0, maximum=10),),
            confirmation=confirmation, category="Test"
        )

    def test_identity(self):
        self.assertEqual(IDENTITY.patch_id, "SKL-CORE-C06")

    def test_registry_duplicate_and_unknown(self):
        r=ActionRegistry(); r.register(self.action())
        with self.assertRaises(RegistryError): r.register(self.action())
        with self.assertRaises(RegistryError): r.get("missing.action")

    def test_execute_success(self):
        r=ActionRegistry(); r.register(self.action()); s=CommandService(r)
        q=CommandRequest("test.scale",{"value":4},CommandContext("TEST","tester"))
        out=s.execute(q)
        self.assertTrue(out.success); self.assertEqual(out.data["answer"],8)

    def test_parameter_type_range_unknown_validation(self):
        r=ActionRegistry(); r.register(self.action()); s=CommandService(r)
        ctx=CommandContext("TEST","tester")
        self.assertEqual(s.execute(CommandRequest("test.scale",{"value":"4"},ctx)).status,"REJECTED")
        self.assertEqual(s.execute(CommandRequest("test.scale",{"value":11},ctx)).status,"REJECTED")
        self.assertEqual(s.execute(CommandRequest("test.scale",{"value":4,"x":1},ctx)).status,"REJECTED")

    def test_confirmation_enforced(self):
        r=ActionRegistry(); r.register(self.action(ConfirmationLevel.CONFIRM)); s=CommandService(r)
        ctx=CommandContext("TEST","tester")
        q=CommandRequest("test.scale",{"value":2},ctx)
        self.assertEqual(s.execute(q).status,"CONFIRMATION_REQUIRED")
        q2=CommandRequest("test.scale",{"value":2},ctx,confirmed=True)
        self.assertTrue(s.execute(q2).success)

    def test_handler_failure_reported_not_faked(self):
        r=ActionRegistry()
        def boom(p,c): raise RuntimeError("real failure")
        r.register(ActionDefinition("test.boom","Boom","test",boom))
        out=CommandService(r).execute(CommandRequest("test.boom",{},CommandContext("TEST","tester")))
        self.assertFalse(out.success); self.assertEqual(out.status,"FAILED")
        self.assertIn("real failure",out.message)

    def test_history(self):
        r=ActionRegistry(); r.register(self.action()); s=CommandService(r, history_limit=2)
        ctx=CommandContext("TEST","tester")
        for i in range(3): s.execute(CommandRequest("test.scale",{"value":i},ctx))
        self.assertEqual(len(s.history()),2)

    def test_no_placeholder_language_in_python_sources(self):
        forbidden = ("placeholder", "not implemented", "initialize in later")
        for p in (ROOT/"core").rglob("*.py"):
            text=p.read_text(encoding="utf-8").lower()
            for phrase in forbidden:
                self.assertNotIn(phrase,text,f"{phrase!r} found in {p}")

    def test_ui_if_pyside_available(self):
        try:
            from PySide6.QtWidgets import QApplication
            from core.ui.main_window import HelixMainWindow
        except ImportError:
            self.skipTest("PySide6 not installed")
        app=QApplication.instance() or QApplication([])
        w=HelixMainWindow(load_config(ROOT/"skl.config"),ROOT)
        self.assertGreaterEqual(len(w.action_registry.all()),5)
        result=w.execute_action("session.checkpoint",source="TEST")
        self.assertTrue(result.success)

if __name__=="__main__": unittest.main()
