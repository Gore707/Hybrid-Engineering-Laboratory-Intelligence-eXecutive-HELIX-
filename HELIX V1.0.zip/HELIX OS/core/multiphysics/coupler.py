from dataclasses import dataclass
class CouplingError(RuntimeError):pass
@dataclass(frozen=True)
class Step:
 name:str;function:object;input_map:dict
class CoupledPipeline:
 def __init__(self):self.steps=[]
 def add(self,name,function,input_map):self.steps.append(Step(name,function,dict(input_map)));return self
 def run(self,initial):
  state=dict(initial);trace=[]
  for step in self.steps:
   kwargs={}
   for arg,key in step.input_map.items():
    if key not in state:raise CouplingError(f"{step.name}: missing coupled value {key}")
    kwargs[arg]=state[key]
   result=step.function(**kwargs)
   if hasattr(result,"__dict__"):out=dict(result.__dict__)
   elif isinstance(result,dict):out=result
   else:raise CouplingError(f"{step.name}: unsupported result")
   for k,v in out.items():state[step.name+"."+k]=v
   trace.append({"step":step.name,"inputs":kwargs,"outputs":out})
  return state,tuple(trace)
