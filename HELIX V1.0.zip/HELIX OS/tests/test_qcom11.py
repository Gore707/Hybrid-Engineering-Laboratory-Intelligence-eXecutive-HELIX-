import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QCOM"
sp=importlib.util.spec_from_file_location("skl_qcom",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qcom"]=q;sp.loader.exec_module(q)
def L(a,b,r=100,f=.9,p=.8,t=.1,k=50):return q.QuantumNetworkLink(a,b,q.QuantumLinkKind.FREE_SPACE,r,f,p,t,k)
class T(unittest.TestCase):
 def test_bottleneck(self):self.assertEqual(q.path_bottleneck_rate_per_s([L("a","b",100),L("b","c",20)]),20)
 def test_key_bottleneck(self):self.assertEqual(q.path_bottleneck_key_rate_bps([L("a","b",k=50),L("b","c",k=10)]),10)
 def test_latency(self):self.assertAlmostEqual(q.path_classical_latency_s([L("a","b"),L("b","c")],.05),.25)
 def test_success(self):self.assertAlmostEqual(q.path_success_probability([L("a","b",p=.8),L("b","c",p=.5)],.5),.2)
 def test_fidelity_perfect(self):self.assertEqual(q.path_fidelity([L("a","b",f=1),L("b","c",f=1)],1),1)
 def test_fidelity_degrades(self):self.assertLess(q.path_fidelity([L("a","b",f=.9),L("b","c",f=.9)],.95),.9)
 def test_throughput(self):self.assertAlmostEqual(q.effective_entanglement_throughput_per_s([L("a","b",100,p=.5),L("b","c",50,p=.5)],.5),6.25)
 def test_network_latency_route(self):
  n=q.QuantumNetwork()
  for x in "ABC":n.add_node(q.QuantumNetworkNode(x))
  n.add_link(L("A","B",t=.1));n.add_link(L("B","C",t=.1));n.add_link(L("A","C",t=1))
  p=n.shortest_latency_path("A","C");self.assertEqual(len(p),2)
 def test_widest_route(self):
  n=q.QuantumNetwork()
  for x in "ABC":n.add_node(q.QuantumNetworkNode(x))
  n.add_link(L("A","B",100));n.add_link(L("B","C",80));n.add_link(L("A","C",20))
  p=n.widest_entanglement_path("A","C");self.assertEqual(q.path_bottleneck_rate_per_s(p),80)
 def test_assess(self):
  a=q.assess_path([L("A","B"),L("B","C")],.5,.95,.01)
  self.assertEqual(a.hop_count,2);self.assertGreater(a.effective_entanglement_throughput_per_s,0);self.assertGreater(a.end_to_end_fidelity,.25)
 def test_duplicate_node(self):
  n=q.QuantumNetwork();n.add_node(q.QuantumNetworkNode("A"))
  with self.assertRaises(ValueError):n.add_node(q.QuantumNetworkNode("A"))
 def test_bad_endpoint(self):
  n=q.QuantumNetwork();n.add_node(q.QuantumNetworkNode("A"))
  with self.assertRaises(ValueError):n.add_link(L("A","B"))
 def test_squeezing_preserved(self):self.assertFalse(q.causality_or_capacity_bypass_available())
 def test_interplanetary_preserved(self):self.assertEqual(q.one_way_light_time_s(q.C_M_S),1)
 def test_memory_preserved(self):self.assertEqual(q.multimode_throughput_limit_per_s(10,.01),1000)
 def test_no_signalling_preserved(self):self.assertEqual(q.no_signalling_remote_probability("network"),(.5,.5))
 def test_registry(self):self.assertTrue({"QCOM-NET-BOTTLENECK","QCOM-NET-SUCCESS","QCOM-NET-FID","QCOM-NET-LATENCY","QCOM-NET-THROUGHPUT"}<={x.model_id for x in q.QuantumCommRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QCOM-11")
 def test_dependencies(self):
  d=json.loads((M/"module.json").read_text())["dependencies"];self.assertTrue({"SKL-PHO","SKL-QMEM","SKL-OPT"}<=set(d))
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
