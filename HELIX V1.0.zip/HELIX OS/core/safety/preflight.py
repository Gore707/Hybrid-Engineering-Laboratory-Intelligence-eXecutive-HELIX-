from dataclasses import dataclass
from .models import *
@dataclass(frozen=True)
class RangeRule:
 parameter:str;minimum:float|None=None;maximum:float|None=None;validated_minimum:float|None=None;validated_maximum:float|None=None
class PreflightEngine:
 def run(self,parameters,rules,required=()):
  checks=[]
  for name in required:
   ok=name in parameters
   checks.append(CheckResult("required:"+name,ok,AlertLevel.ERROR if not ok else AlertLevel.INFO,
    f"{name} {'present' if ok else 'missing'}"))
  for rule in rules:
   if rule.parameter not in parameters:continue
   v=float(parameters[rule.parameter]);hard=True
   if rule.minimum is not None and v<rule.minimum:hard=False
   if rule.maximum is not None and v>rule.maximum:hard=False
   checks.append(CheckResult("range:"+rule.parameter,hard,AlertLevel.CRITICAL if not hard else AlertLevel.INFO,
    f"{rule.parameter} {'within' if hard else 'outside'} hard domain"))
   if hard and (rule.validated_minimum is not None or rule.validated_maximum is not None):
    valid=(rule.validated_minimum is None or v>=rule.validated_minimum) and (rule.validated_maximum is None or v<=rule.validated_maximum)
    checks.append(CheckResult("validated:"+rule.parameter,valid,AlertLevel.WARNING if not valid else AlertLevel.INFO,
     f"{rule.parameter} {'inside' if valid else 'outside'} validated range"))
  blocking=any((not c.passed) and c.level>=AlertLevel.ERROR for c in checks)
  highest=max((c.level for c in checks if not c.passed),default=AlertLevel.INFO)
  return PreflightResult(not blocking,tuple(checks),highest)
