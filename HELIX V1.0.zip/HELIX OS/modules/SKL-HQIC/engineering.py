from __future__ import annotations
from dataclasses import dataclass
import math

SIGMA=5.670374419e-8

def conductive_heat_w(k_w_mk,area_m2,hot_k,cold_k,length_m):
    if k_w_mk<0 or area_m2<0 or hot_k<cold_k or cold_k<0 or length_m<=0: raise ValueError("invalid conduction inputs")
    return k_w_mk*area_m2*(hot_k-cold_k)/length_m

def radiative_heat_w(emissivity,area_m2,hot_k,cold_k):
    if not 0<=emissivity<=1 or area_m2<0 or hot_k<cold_k or cold_k<0: raise ValueError("invalid radiation inputs")
    return emissivity*SIGMA*area_m2*(hot_k**4-cold_k**4)

def thermal_margin_w(cooling_capacity_w,steady_load_w):
    if cooling_capacity_w<0 or steady_load_w<0: raise ValueError("nonnegative powers required")
    return cooling_capacity_w-steady_load_w

def thermal_margin_fraction(cooling_capacity_w,steady_load_w):
    if cooling_capacity_w<=0 or steady_load_w<0: raise ValueError("invalid cooling/load")
    return (cooling_capacity_w-steady_load_w)/cooling_capacity_w

def linear_thermal_expansion_m(length_m,alpha_per_k,delta_t_k):
    if length_m<0: raise ValueError("nonnegative length required")
    return length_m*alpha_per_k*delta_t_k

def rss_tolerance(*tolerances):
    if not tolerances: raise ValueError("tolerances required")
    if any(x<0 for x in tolerances): raise ValueError("nonnegative tolerances required")
    return math.sqrt(sum(x*x for x in tolerances))

def worst_case_tolerance(*tolerances):
    if not tolerances: raise ValueError("tolerances required")
    if any(x<0 for x in tolerances): raise ValueError("nonnegative tolerances required")
    return sum(tolerances)

def alignment_fraction_of_spot(alignment_error_m,spot_radius_m):
    if alignment_error_m<0 or spot_radius_m<=0: raise ValueError("invalid alignment geometry")
    return alignment_error_m/spot_radius_m

@dataclass(frozen=True)
class CryogenicStage:
    name:str
    target_temperature_k:float
    cooling_capacity_w:float
    conductive_load_w:float=0
    radiative_load_w:float=0
    active_load_w:float=0
    def __post_init__(self):
        if not self.name.strip() or self.target_temperature_k<0 or min(self.cooling_capacity_w,self.conductive_load_w,self.radiative_load_w,self.active_load_w)<0:
            raise ValueError("invalid cryogenic stage")
    @property
    def total_load_w(self): return self.conductive_load_w+self.radiative_load_w+self.active_load_w
    @property
    def margin_w(self): return thermal_margin_w(self.cooling_capacity_w,self.total_load_w)
    @property
    def passes(self): return self.margin_w>=0

@dataclass(frozen=True)
class ManufacturingTolerance:
    name:str
    nominal_m:float
    tolerance_m:float
    required_max_tolerance_m:float
    def __post_init__(self):
        if not self.name.strip() or self.nominal_m<0 or self.tolerance_m<0 or self.required_max_tolerance_m<0:
            raise ValueError("invalid manufacturing tolerance")
    @property
    def passes(self): return self.tolerance_m<=self.required_max_tolerance_m

@dataclass(frozen=True)
class BuildReadiness:
    thermal_ok:bool
    alignment_ok:bool
    tolerances_ok:bool
    materials_characterized:bool
    process_demonstrated:bool
    hardware_validated:bool
    @property
    def ready_for_build(self):
        return all((self.thermal_ok,self.alignment_ok,self.tolerances_ok,self.materials_characterized,self.process_demonstrated))
    @property
    def validated_hardware(self): return self.ready_for_build and self.hardware_validated
