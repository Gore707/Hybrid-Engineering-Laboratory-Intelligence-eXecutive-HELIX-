from __future__ import annotations
from dataclasses import dataclass
import math
from .qkd import qber_from_signal_and_background,asymptotic_bb84_secret_fraction

C_M_S=299792458.0

def gaussian_beam_radius_m(w0_m,wavelength_m,distance_m):
    if w0_m<=0 or wavelength_m<=0 or distance_m<0:raise ValueError("invalid beam inputs")
    z_r=math.pi*w0_m*w0_m/wavelength_m
    return w0_m*math.sqrt(1+(distance_m/z_r)**2)

def circular_aperture_capture_fraction(aperture_diameter_m,beam_radius_m):
    if aperture_diameter_m<=0 or beam_radius_m<=0:raise ValueError("positive dimensions")
    radius=aperture_diameter_m/2
    return 1-math.exp(-2*radius*radius/(beam_radius_m*beam_radius_m))

def gaussian_pointing_efficiency(pointing_offset_rad,distance_m,beam_radius_m):
    if pointing_offset_rad<0 or distance_m<0 or beam_radius_m<=0:raise ValueError("invalid pointing inputs")
    offset=pointing_offset_rad*distance_m
    return math.exp(-2*offset*offset/(beam_radius_m*beam_radius_m))

def atmospheric_transmission_from_optical_depth(optical_depth,airmass=1.0):
    if optical_depth<0 or airmass<1:raise ValueError("tau>=0, airmass>=1")
    return math.exp(-optical_depth*airmass)

def free_space_channel_efficiency(tx_internal_efficiency,atmospheric_transmission,aperture_capture,pointing_efficiency,rx_internal_efficiency):
    xs=(tx_internal_efficiency,atmospheric_transmission,aperture_capture,pointing_efficiency,rx_internal_efficiency)
    if not all(0<=x<=1 for x in xs):raise ValueError("efficiencies in [0,1]")
    out=1.0
    for x in xs:out*=x
    return out

def link_loss_db(efficiency):
    if not 0<efficiency<=1:raise ValueError("efficiency in (0,1]")
    return -10*math.log10(efficiency)

def slant_range_m(earth_radius_m,altitude_m,elevation_rad):
    if earth_radius_m<=0 or altitude_m<0 or not 0<=elevation_rad<=math.pi/2:raise ValueError("invalid geometry")
    r=earth_radius_m; rs=r+altitude_m
    return -r*math.sin(elevation_rad)+math.sqrt(rs*rs-r*r*math.cos(elevation_rad)**2)

def light_time_s(distance_m):
    if distance_m<0:raise ValueError("distance nonnegative")
    return distance_m/C_M_S

@dataclass(frozen=True)
class FreeSpaceQuantumLink:
    wavelength_m:float
    tx_beam_waist_m:float
    range_m:float
    rx_aperture_diameter_m:float
    pointing_offset_rad:float=0.0
    atmospheric_transmission:float=1.0
    tx_internal_efficiency:float=1.0
    rx_internal_efficiency:float=1.0
    detector_efficiency:float=1.0
    source_rate_per_s:float=1.0
    background_rate_per_s:float=0.0
    intrinsic_error:float=0.0
    def __post_init__(self):
        if self.wavelength_m<=0 or self.tx_beam_waist_m<=0 or self.range_m<0 or self.rx_aperture_diameter_m<=0 or self.pointing_offset_rad<0 or self.source_rate_per_s<0 or self.background_rate_per_s<0:
            raise ValueError("invalid geometry/rates")
        if not all(0<=x<=1 for x in (self.atmospheric_transmission,self.tx_internal_efficiency,self.rx_internal_efficiency,self.detector_efficiency)):
            raise ValueError("efficiencies in [0,1]")
        if not 0<=self.intrinsic_error<=.5:raise ValueError("intrinsic error in [0,.5]")
    @property
    def beam_radius_m(self):return gaussian_beam_radius_m(self.tx_beam_waist_m,self.wavelength_m,self.range_m)
    @property
    def aperture_capture(self):return circular_aperture_capture_fraction(self.rx_aperture_diameter_m,self.beam_radius_m)
    @property
    def pointing_efficiency(self):return gaussian_pointing_efficiency(self.pointing_offset_rad,self.range_m,self.beam_radius_m)
    @property
    def channel_efficiency(self):return free_space_channel_efficiency(self.tx_internal_efficiency,self.atmospheric_transmission,self.aperture_capture,self.pointing_efficiency,self.rx_internal_efficiency)
    @property
    def signal_detection_rate_per_s(self):return self.source_rate_per_s*self.channel_efficiency*self.detector_efficiency
    @property
    def qber(self):return qber_from_signal_and_background(self.signal_detection_rate_per_s,self.background_rate_per_s,self.intrinsic_error)
    @property
    def idealized_bb84_secret_rate_bps(self):
        raw=self.signal_detection_rate_per_s+self.background_rate_per_s
        return .5*raw*asymptotic_bb84_secret_fraction(self.qber)
    @property
    def loss_db(self):return link_loss_db(self.channel_efficiency*self.detector_efficiency)
