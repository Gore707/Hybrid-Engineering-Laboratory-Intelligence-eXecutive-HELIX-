from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math
from .foundation import binary_entropy_bits

class BB84Basis(str,Enum):
    Z="Z"; X="X"

class BB84Bit(int,Enum):
    ZERO=0; ONE=1

def basis_match_probability(probability_z_alice=.5,probability_z_bob=.5):
    if not 0<=probability_z_alice<=1 or not 0<=probability_z_bob<=1: raise ValueError("basis probabilities in [0,1]")
    return probability_z_alice*probability_z_bob+(1-probability_z_alice)*(1-probability_z_bob)

def sifted_key_rate_bps(raw_detection_rate_bps,basis_match_fraction=.5):
    if raw_detection_rate_bps<0 or not 0<=basis_match_fraction<=1: raise ValueError("invalid rate/fraction")
    return raw_detection_rate_bps*basis_match_fraction

def qber(error_counts,total_sifted_counts):
    if error_counts<0 or total_sifted_counts<0 or error_counts>total_sifted_counts: raise ValueError("invalid counts")
    return 0.0 if total_sifted_counts==0 else error_counts/total_sifted_counts

def qber_from_signal_and_background(signal_counts,background_counts,intrinsic_signal_error=0.0):
    if min(signal_counts,background_counts)<0 or not 0<=intrinsic_signal_error<=.5: raise ValueError("invalid inputs")
    total=signal_counts+background_counts
    if total==0:return 0.0
    # Background is modeled as random and therefore contributes 50% errors.
    return (signal_counts*intrinsic_signal_error+.5*background_counts)/total

def asymptotic_bb84_secret_fraction(qber_value,error_correction_efficiency=1.0):
    if not 0<=qber_value<=.5 or error_correction_efficiency<1: raise ValueError("invalid QBER/fEC")
    # Simplified asymptotic single-photon BB84 expression:
    # r=max[0,1-fEC H2(Q)-H2(Q)].
    h=binary_entropy_bits(qber_value)
    return max(0.0,1-error_correction_efficiency*h-h)

def asymptotic_secret_key_rate_bps(raw_detection_rate_bps,qber_value,basis_match_fraction=.5,error_correction_efficiency=1.0):
    return sifted_key_rate_bps(raw_detection_rate_bps,basis_match_fraction)*asymptotic_bb84_secret_fraction(qber_value,error_correction_efficiency)

def intercept_resend_qber(intercept_fraction=1.0):
    if not 0<=intercept_fraction<=1: raise ValueError("fraction in [0,1]")
    # Random-basis intercept/resend contributes 25% QBER when every signal is intercepted.
    return .25*intercept_fraction

def expected_detected_rate_per_s(pulse_rate_hz,mean_photons_per_pulse,channel_efficiency,detector_efficiency):
    if pulse_rate_hz<0 or mean_photons_per_pulse<0 or not 0<=channel_efficiency<=1 or not 0<=detector_efficiency<=1:
        raise ValueError("invalid source/channel inputs")
    # Poisson source: probability of >=1 detected photon after thinning by eta.
    eta=channel_efficiency*detector_efficiency
    return pulse_rate_hz*(1-math.exp(-mean_photons_per_pulse*eta))

@dataclass(frozen=True)
class BB84Link:
    pulse_rate_hz:float
    mean_photons_per_pulse:float
    channel_efficiency:float
    detector_efficiency:float
    background_rate_per_s:float=0.0
    intrinsic_signal_error:float=0.0
    alice_z_probability:float=.5
    bob_z_probability:float=.5
    error_correction_efficiency:float=1.16
    def __post_init__(self):
        if self.pulse_rate_hz<0 or self.mean_photons_per_pulse<0 or self.background_rate_per_s<0:raise ValueError("rates nonnegative")
        if not all(0<=x<=1 for x in (self.channel_efficiency,self.detector_efficiency,self.alice_z_probability,self.bob_z_probability)):raise ValueError("probabilities in [0,1]")
        if not 0<=self.intrinsic_signal_error<=.5 or self.error_correction_efficiency<1:raise ValueError("invalid error model")
    @property
    def signal_detection_rate_per_s(self):
        return expected_detected_rate_per_s(self.pulse_rate_hz,self.mean_photons_per_pulse,self.channel_efficiency,self.detector_efficiency)
    @property
    def raw_detection_rate_per_s(self):return self.signal_detection_rate_per_s+self.background_rate_per_s
    @property
    def qber(self):return qber_from_signal_and_background(self.signal_detection_rate_per_s,self.background_rate_per_s,self.intrinsic_signal_error)
    @property
    def basis_match_fraction(self):return basis_match_probability(self.alice_z_probability,self.bob_z_probability)
    @property
    def sifted_rate_bps(self):return sifted_key_rate_bps(self.raw_detection_rate_per_s,self.basis_match_fraction)
    @property
    def idealized_secret_fraction(self):return asymptotic_bb84_secret_fraction(self.qber,self.error_correction_efficiency)
    @property
    def idealized_secret_rate_bps(self):return self.sifted_rate_bps*self.idealized_secret_fraction
