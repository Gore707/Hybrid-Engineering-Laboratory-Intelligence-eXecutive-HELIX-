from __future__ import annotations
from dataclasses import dataclass,replace
from enum import Enum
import math,random,statistics
from .simulation import IntegratedOpticalScenario,IntegratedOpticalResult,OpticalLinkStatus,simulate

class FailureSeverity(str,Enum):
    WARNING="WARNING"; FAIL="FAIL"; KILL="KILL"

@dataclass(frozen=True)
class FailureFinding:
    severity:FailureSeverity
    code:str
    message:str

@dataclass(frozen=True)
class SensitivityPoint:
    parameter:str
    baseline:float
    perturbed:float
    metric_baseline:float
    metric_perturbed:float
    normalized_sensitivity:float|None

@dataclass(frozen=True)
class MonteCarloSummary:
    trials:int
    pass_fraction:float
    marginal_fraction:float
    fail_fraction:float
    mean_margin_db:float
    std_margin_db:float
    p05_margin_db:float
    p50_margin_db:float
    p95_margin_db:float

def _percentile(xs,p):
    if not xs: raise ValueError("empty sample")
    ys=sorted(xs); pos=(len(ys)-1)*p; lo=int(math.floor(pos)); hi=int(math.ceil(pos))
    if lo==hi:return ys[lo]
    f=pos-lo
    return ys[lo]*(1-f)+ys[hi]*f

def sweep_parameter(s:IntegratedOpticalScenario,parameter,values):
    if parameter not in s.__dataclass_fields__: raise ValueError("unknown scenario parameter")
    out=[]
    for v in values:
        sc=replace(s,**{parameter:v})
        out.append((v,simulate(sc)))
    return out

def local_sensitivity(s:IntegratedOpticalScenario,parameter,fractional_step=.01,metric="snr_margin_db"):
    if not 0<fractional_step<1: raise ValueError("fractional step in (0,1)")
    if parameter not in s.__dataclass_fields__: raise ValueError("unknown parameter")
    x=getattr(s,parameter)
    if not isinstance(x,(int,float)) or isinstance(x,bool) or x==0: raise ValueError("parameter must be nonzero numeric")
    b=simulate(s); p=simulate(replace(s,**{parameter:x*(1+fractional_step)}))
    y0=getattr(b,metric); y1=getattr(p,metric)
    if not isinstance(y0,(int,float)) or not isinstance(y1,(int,float)): raise ValueError("metric must be numeric")
    norm=None if y0==0 or not math.isfinite(y0) or not math.isfinite(y1) else ((y1-y0)/y0)/fractional_step
    return SensitivityPoint(parameter,x,x*(1+fractional_step),y0,y1,norm)

def analyze_failures(s:IntegratedOpticalScenario,r:IntegratedOpticalResult|None=None):
    r=simulate(s) if r is None else r
    f=[]
    if r.status==OpticalLinkStatus.FAIL:f.append(FailureFinding(FailureSeverity.KILL,"LINK_MARGIN","Link margin is below the marginal band."))
    elif r.status==OpticalLinkStatus.MARGINAL:f.append(FailureFinding(FailureSeverity.WARNING,"LINK_MARGIN","Link margin is marginal."))
    if r.pointing_coupling<.5:f.append(FailureFinding(FailureSeverity.FAIL,"POINTING_LOSS","Pointing coupling is below 50%."))
    if s.atmospheric_transmission<.2:f.append(FailureFinding(FailureSeverity.FAIL,"ATMOSPHERIC_LOSS","Atmospheric transmission is below 20%."))
    if r.photons_per_information_bit<1:f.append(FailureFinding(FailureSeverity.WARNING,"PHOTON_STARVED","Detected signal is below one photon per information bit."))
    if r.packet_error is not None and r.packet_error>.1:f.append(FailureFinding(FailureSeverity.FAIL,"PACKET_ERROR","Modeled packet error exceeds 10%."))
    return tuple(f)

def compare_scenarios(named_scenarios):
    return [(name,simulate(s),analyze_failures(s)) for name,s in named_scenarios]

def monte_carlo(s:IntegratedOpticalScenario,trials=1000,seed=1,
                power_sigma_fraction=.05,distance_sigma_fraction=0.0,
                pointing_sigma_rad=0.0,atmosphere_sigma_fraction=.05):
    if trials<1 or min(power_sigma_fraction,distance_sigma_fraction,pointing_sigma_rad,atmosphere_sigma_fraction)<0:
        raise ValueError("invalid Monte Carlo settings")
    rng=random.Random(seed); margins=[]; counts={x:0 for x in OpticalLinkStatus}
    for _ in range(trials):
        power=max(0,rng.gauss(s.transmitted_optical_power_w,s.transmitted_optical_power_w*power_sigma_fraction))
        distance=max(1e-30,rng.gauss(s.distance_m,s.distance_m*distance_sigma_fraction))
        # Jitter is a zero-mean angular perturbation added to deterministic boresight error.
        pointing=s.pointing_error_rad+rng.gauss(0,pointing_sigma_rad)
        atm=min(1,max(1e-12,rng.gauss(s.atmospheric_transmission,s.atmospheric_transmission*atmosphere_sigma_fraction)))
        r=simulate(replace(s,transmitted_optical_power_w=power,distance_m=distance,pointing_error_rad=pointing,atmospheric_transmission=atm))
        margins.append(r.snr_margin_db);counts[r.status]+=1
    finite=[x for x in margins if math.isfinite(x)]
    if not finite: mean=std=p05=p50=p95=-math.inf
    else:
        mean=statistics.fmean(finite);std=statistics.pstdev(finite);p05=_percentile(finite,.05);p50=_percentile(finite,.5);p95=_percentile(finite,.95)
    return MonteCarloSummary(trials,counts[OpticalLinkStatus.PASS]/trials,counts[OpticalLinkStatus.MARGINAL]/trials,
                             counts[OpticalLinkStatus.FAIL]/trials,mean,std,p05,p50,p95)
