import unittest,importlib.util,sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-HWI"
sp=importlib.util.spec_from_file_location("skl_hwi",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_hwi"]=q;sp.loader.exec_module(q)
class Inst:
 def __init__(self):self.identity=q.HardwareIdentity("D1","SKL","Meter");self.connection_state=q.ConnectionState.CONNECTED;self.calibration_state=q.CalibrationState.VALID
class Reg:
 def __init__(self):self.i=Inst()
 def get(self,d):
  if d!="D1":raise KeyError(d)
  return self.i
def lab():
 o=q.HardwareExperimentOrchestrator("E","R",(q.InstrumentBinding("meter","D1"),),Reg())
 o.preflight(0);o.start(1);o.attach_acquisition_manifest("data/E/R/c1.h5");o.complete(2)
 return q.IntegratedHardwareLab(o)
class T(unittest.TestCase):
 def test_cross_engine(self):self.assertTrue(q.cross_engine_passed())
 def test_cross_engine_count(self):self.assertEqual(len(q.cross_engine_validation()),9)
 def test_lab_summary(self):
  l=lab();l.add_validation_gate(q.calibration_gate("D1",q.CalibrationState.VALID));s=l.summary();self.assertTrue(s.validation_passed);self.assertEqual(s.device_count,1)
 def test_lab_failure(self):
  l=lab();l.add_validation_gate(q.calibration_gate("D1",q.CalibrationState.INVALID));self.assertFalse(l.summary().validation_passed)
 def test_guardian_advisory(self):self.assertEqual(lab().guardian_summary()["authority"],"ADVISORY_VIEW_OF_DETERMINISTIC_RESULTS")
 def test_guardian_no_override(self):self.assertFalse(q.guardian_can_override_safety())
 def test_visualization_dataset(self):
  l=lab();l.add_validation_gate(q.calibration_gate("D1",q.CalibrationState.VALID));self.assertEqual(l.visualization_dataset()[0]["status"],"PASS")
 def test_hwi_complete(self):
  x=json.loads((R/"HWI_COMPLETE.json").read_text());self.assertEqual(x["patches_completed"],10);self.assertEqual(x["status"],"COMPLETE")
 def test_helix_complete(self):
  x=json.loads((R/"HELIX_136_COMPLETE.json").read_text());self.assertEqual((x["patches_completed"],x["patches_total"]),(136,136))
 def test_roadmap_math(self):
  x=json.loads((R/"HELIX_136_COMPLETE.json").read_text());self.assertEqual(x["core_patches"]+x["module_patches"],136)
 def test_manifest(self):
  x=json.loads((M/"module.json").read_text());self.assertEqual(x["patch_id"],"SKL-HWI-10");self.assertEqual(x["status"],"COMPLETE 10/10")
 def test_schema(self):self.assertEqual(json.loads((M/"schemas/hardware_lab_summary.schema.json").read_text())["$schema"],"https://json-schema.org/draft/2020-12/schema")
 def test_validation_preserved(self):self.assertTrue(hasattr(q,"ValidationReport"))
 def test_orchestration_preserved(self):self.assertTrue(hasattr(q,"HardwareExperimentOrchestrator"))
 def test_safety_preserved(self):self.assertTrue(hasattr(q,"EmergencyController"))
 def test_acquisition_preserved(self):self.assertTrue(hasattr(q,"AcquisitionSession"))
 def test_metrology_preserved(self):self.assertTrue(hasattr(q,"UncertaintyBudget"))
 def test_driver_preserved(self):self.assertTrue(hasattr(q,"SCPIDriver"))
 def test_transport_preserved(self):self.assertEqual(q.TransportKind.VISA.value,"VISA")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
