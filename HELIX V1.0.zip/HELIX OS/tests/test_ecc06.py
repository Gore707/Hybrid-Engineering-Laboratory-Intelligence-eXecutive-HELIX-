import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-ECC"
sp=importlib.util.spec_from_file_location("skl_ecc",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_ecc"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def scenarios(self):
  return [q.CarrierScenario("A",q.EvidenceClass.ESTABLISHED_PHYSICS,10,100,1000,100,10,1e-6,.9),
          q.CarrierScenario("B",q.EvidenceClass.EXTRAPOLATED_ENGINEERING,20,1000,5000,10,5,1e-7,.8),
          q.CarrierScenario("C",q.EvidenceClass.EXTRAPOLATED_ENGINEERING,30,10,10000,1000,1,None,.5)]
 def test_total_power(self):self.assertEqual(q.CarrierScenario("x",q.EvidenceClass.ESTABLISHED_PHYSICS,1,10,20,infrastructure_power_w=5).total_power_w,25)
 def test_jpb(self):self.assertEqual(q.CarrierScenario("x",q.EvidenceClass.ESTABLISHED_PHYSICS,1,10,20).joules_per_bit,2)
 def test_zero_rate_inf(self):self.assertTrue(math.isinf(q.CarrierScenario("x",q.EvidenceClass.ESTABLISHED_PHYSICS,1,0,20).joules_per_bit))
 def test_low_latency(self):self.assertEqual(q.lowest_latency(self.scenarios()).name,"A")
 def test_high_rate(self):self.assertEqual(q.highest_information_rate(self.scenarios()).name,"B")
 def test_low_energy(self):self.assertEqual(q.lowest_energy_per_bit(self.scenarios()).name,"B")
 def test_low_mass(self):self.assertEqual(q.lowest_detector_mass(self.scenarios()).name,"B")
 def test_dominates(self):
  a=q.CarrierScenario("a",q.EvidenceClass.ESTABLISHED_PHYSICS,1,100,10,1,survival_or_transmission=1)
  b=q.CarrierScenario("b",q.EvidenceClass.ESTABLISHED_PHYSICS,2,10,20,2,survival_or_transmission=.5)
  self.assertTrue(q.dominates(a,b))
 def test_pareto(self):self.assertGreaterEqual(len(q.pareto_front(self.scenarios())),1)
 def test_partition(self):self.assertEqual(len(q.evidence_partition(self.scenarios())),2)
 def test_sweep(self):self.assertEqual([x.information_rate_bps for x in q.parameter_sweep([1,2],lambda v:q.CarrierScenario(str(v),q.EvidenceClass.ESTABLISHED_PHYSICS,1,v,1))],[1,2])
 def test_mc_seed(self):self.assertEqual(q.monte_carlo_rate(100,.1,100,42),q.monte_carlo_rate(100,.1,100,42))
 def test_mc_order(self):
  x=q.monte_carlo_rate(100,.1,100,1);self.assertLessEqual(x.p05_rate_bps,x.p50_rate_bps);self.assertLessEqual(x.p50_rate_bps,x.p95_rate_bps)
 def test_compare(self):self.assertEqual(q.compare_architectures(self.scenarios())["highest_information_rate"].name,"B")
 def test_gw_preserved(self):self.assertGreater(q.sinusoidal_gw_energy_flux_w_m2(1e-21,100),0)
 def test_particle_preserved(self):self.assertLess(q.speed_from_kinetic_energy_j(1e-9,1.67e-27),q.C_M_S)
 def test_hep_preserved(self):self.assertGreater(q.photon_energy_kev_from_wavelength(1e-10),0)
 def test_neutrino_preserved(self):self.assertGreater(q.approximate_cc_cross_section_m2(1),0)
 def test_causality_preserved(self):self.assertFalse(q.causality_bypass_available())
 def test_registry(self):self.assertTrue({"ECC-CMP-EBIT","ECC-CMP-PARETO","ECC-CMP-SWEEP","ECC-CMP-MC"}<={x.model_id for x in q.ExtremeCarrierRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-ECC-06")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
