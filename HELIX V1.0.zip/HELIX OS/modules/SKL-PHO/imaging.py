from dataclasses import dataclass
import math
@dataclass(frozen=True)
class ImagingResult:
 object_distance_m:float;image_distance_m:float;focal_length_m:float;magnification:float;real_image:bool
def thin_lens_imaging(object_distance_m,focal_length_m):
 from .geometric import thin_lens_image_distance,lateral_magnification
 di=thin_lens_image_distance(object_distance_m,focal_length_m)
 return ImagingResult(object_distance_m,di,focal_length_m,lateral_magnification(object_distance_m,di),di>0)
def numerical_aperture(n,half_angle_rad):
 if n<=0:raise ValueError("index must be positive")
 return n*math.sin(half_angle_rad)
def diffraction_limited_airy_radius(wavelength_m,numerical_aperture_value):
 if wavelength_m<=0 or numerical_aperture_value<=0:raise ValueError("positive wavelength and NA required")
 return 0.61*wavelength_m/numerical_aperture_value
