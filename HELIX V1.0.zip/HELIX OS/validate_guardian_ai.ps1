param([switch]$NoInference)
$ErrorActionPreference="Stop"
$root=$PSScriptRoot
$python=Join-Path $root ".venv\Scripts\python.exe"
if (-not (Test-Path $python)) { throw "HELIX .venv not found." }
$args=@((Join-Path $root "GUARDIAN_AI_BENCHMARK.py"))
if ($NoInference) { $args += "--no-inference" }
& $python @args
if ($LASTEXITCODE -ne 0) { throw "Guardian AI validation reported a failure. Inspect user\guardian\activation_benchmark.json." }
Write-Host "Guardian AI validation completed. Report: user\guardian\activation_benchmark.json"
