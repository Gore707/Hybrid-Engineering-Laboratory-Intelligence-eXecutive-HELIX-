from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import math

class UncertaintyType(str,Enum):
    TYPE_A="TYPE_A"
    TYPE_B="TYPE_B"

class QualityFlag(str,Enum):
    VALID="VALID"
    CALIBRATION_EXPIRED="CALIBRATION_EXPIRED"
    CALIBRATION_INVALID="CALIBRATION_INVALID"
    OUT_OF_RANGE="OUT_OF_RANGE"
    DRIFT_WARNING="DRIFT_WARNING"
    UNCERTAINTY_HIGH="UNCERTAINTY_HIGH"

@dataclass(frozen=True)
class UncertaintyComponent:
    name:str
    standard_uncertainty:float
    kind:UncertaintyType
    sensitivity_coefficient:float=1.0
    degrees_of_freedom:float|None=None
    def __post_init__(self):
        if not self.name or self.standard_uncertainty<0:raise ValueError("invalid uncertainty component")
        if self.degrees_of_freedom is not None and self.degrees_of_freedom<=0:raise ValueError("degrees_of_freedom positive")

@dataclass(frozen=True)
class UncertaintyBudget:
    components:tuple[UncertaintyComponent,...]
    coverage_factor:float=2.0
    def __post_init__(self):
        if self.coverage_factor<=0:raise ValueError("coverage factor positive")
    @property
    def combined_standard_uncertainty(self):
        return math.sqrt(sum((c.sensitivity_coefficient*c.standard_uncertainty)**2 for c in self.components))
    @property
    def expanded_uncertainty(self):return self.coverage_factor*self.combined_standard_uncertainty

def type_a_standard_uncertainty(values):
    values=tuple(float(x) for x in values)
    if len(values)<2:raise ValueError("at least two observations")
    mean=sum(values)/len(values)
    sample_sd=math.sqrt(sum((x-mean)**2 for x in values)/(len(values)-1))
    return sample_sd/math.sqrt(len(values))

def rectangular_standard_uncertainty(half_width):
    if half_width<0:raise ValueError("half width nonnegative")
    return half_width/math.sqrt(3)

def propagate_uncertainty(derivatives,standard_uncertainties):
    if len(derivatives)!=len(standard_uncertainties):raise ValueError("length mismatch")
    if any(u<0 for u in standard_uncertainties):raise ValueError("uncertainties nonnegative")
    return math.sqrt(sum((d*u)**2 for d,u in zip(derivatives,standard_uncertainties)))

@dataclass(frozen=True)
class TraceabilityReference:
    reference_id:str
    authority:str
    description:str=""
    parent_reference_id:str|None=None
    def __post_init__(self):
        if not self.reference_id or not self.authority:raise ValueError("traceability identity required")

def validate_traceability_chain(references):
    refs={r.reference_id:r for r in references}
    if len(refs)!=len(tuple(references)):return False
    for r in refs.values():
        seen={r.reference_id};p=r.parent_reference_id
        while p is not None:
            if p not in refs or p in seen:return False
            seen.add(p);p=refs[p].parent_reference_id
    return True

@dataclass(frozen=True)
class CalibrationCertificate:
    certificate_id:str
    device_id:str
    calibrated_at_unix_s:float
    expires_at_unix_s:float|None
    laboratory:str
    traceability_reference_ids:tuple[str,...]=()
    stated_expanded_uncertainty:float|None=None
    coverage_factor:float|None=None
    def __post_init__(self):
        if not self.certificate_id or not self.device_id or not self.laboratory:raise ValueError("certificate identity required")
        if self.expires_at_unix_s is not None and self.expires_at_unix_s<self.calibrated_at_unix_s:raise ValueError("expiry before calibration")
        if self.stated_expanded_uncertainty is not None and self.stated_expanded_uncertainty<0:raise ValueError("uncertainty nonnegative")
    def valid_at(self,t):return t>=self.calibrated_at_unix_s and (self.expires_at_unix_s is None or t<=self.expires_at_unix_s)

class CalibrationHistory:
    def __init__(self):self._records=[]
    def add(self,certificate):
        if any(x.certificate_id==certificate.certificate_id for x in self._records):raise ValueError("duplicate certificate")
        self._records.append(certificate);self._records.sort(key=lambda x:x.calibrated_at_unix_s);return certificate
    def all(self):return tuple(self._records)
    def latest(self):return self._records[-1] if self._records else None

def linear_drift_rate_per_s(t0,v0,t1,v1):
    if t1<=t0:raise ValueError("t1 > t0 required")
    return (v1-v0)/(t1-t0)

def drift_exceeds_limit(t0,v0,t1,v1,max_abs_rate_per_s):
    if max_abs_rate_per_s<0:raise ValueError("limit nonnegative")
    return abs(linear_drift_rate_per_s(t0,v0,t1,v1))>max_abs_rate_per_s

def measurement_quality_flags(value,minimum,maximum,certificate,timestamp_unix_s,
                              drift_warning=False,relative_uncertainty=None,max_relative_uncertainty=None):
    flags=[]
    if minimum is not None and value<minimum or maximum is not None and value>maximum:flags.append(QualityFlag.OUT_OF_RANGE)
    if certificate is not None and not certificate.valid_at(timestamp_unix_s):flags.append(QualityFlag.CALIBRATION_EXPIRED)
    if drift_warning:flags.append(QualityFlag.DRIFT_WARNING)
    if relative_uncertainty is not None and max_relative_uncertainty is not None and relative_uncertainty>max_relative_uncertainty:flags.append(QualityFlag.UNCERTAINTY_HIGH)
    return tuple(flags) if flags else (QualityFlag.VALID,)

def uncertainty_decimal_places(expanded_uncertainty,significant_digits=2):
    if expanded_uncertainty<=0 or significant_digits<1:raise ValueError("positive uncertainty and significant digits")
    exponent=math.floor(math.log10(abs(expanded_uncertainty)))
    return significant_digits-1-exponent

def round_value_to_uncertainty(value,expanded_uncertainty,significant_digits=2):
    places=uncertainty_decimal_places(expanded_uncertainty,significant_digits)
    return round(value,places),round(expanded_uncertainty,places)
