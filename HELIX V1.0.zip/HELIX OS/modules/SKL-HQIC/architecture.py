from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable

class InformationDomain(str,Enum):
    CLASSICAL="CLASSICAL"
    QUANTUM="QUANTUM"

class LayerKind(str,Enum):
    CLASSICAL_ARCHIVE="CLASSICAL_ARCHIVE"
    QUANTUM_ACTIVE="QUANTUM_ACTIVE"
    TRANSDUCER="TRANSDUCER"
    CONTROL="CONTROL"
    METADATA="METADATA"
    ERROR_CONTROL="ERROR_CONTROL"

class SourceState(str,Enum):
    HARDWARE="HARDWARE"
    IMPORTED="IMPORTED"
    SIMULATION="SIMULATION"
    EXTRAPOLATED="EXTRAPOLATED"
    SPECULATIVE="SPECULATIVE"

@dataclass(frozen=True)
class Capacity:
    value:float
    domain:InformationDomain
    unit:str
    def __post_init__(self):
        if self.value<0 or not self.unit.strip(): raise ValueError("invalid capacity")
        if self.domain==InformationDomain.CLASSICAL and self.unit not in ("bit","byte"):
            raise ValueError("classical capacity unit must be bit or byte")
        if self.domain==InformationDomain.QUANTUM and self.unit not in ("qubit","qudit"):
            raise ValueError("quantum capacity unit must be qubit or qudit")

def aggregate_capacity_same_domain(capacities:Iterable[Capacity]):
    vals=tuple(capacities)
    if not vals: raise ValueError("at least one capacity required")
    d,u=vals[0].domain,vals[0].unit
    if any(x.domain!=d or x.unit!=u for x in vals):
        raise ValueError("unlike information domains/units cannot be summed")
    return Capacity(sum(x.value for x in vals),d,u)

@dataclass(frozen=True)
class StorageLayer:
    layer_id:str
    kind:LayerKind
    domain:InformationDomain|None
    source:SourceState
    description:str=""
    def __post_init__(self):
        if not self.layer_id.strip(): raise ValueError("layer_id required")
        if self.kind==LayerKind.CLASSICAL_ARCHIVE and self.domain!=InformationDomain.CLASSICAL:
            raise ValueError("classical archive must be classical")
        if self.kind==LayerKind.QUANTUM_ACTIVE and self.domain!=InformationDomain.QUANTUM:
            raise ValueError("quantum-active layer must be quantum")

@dataclass(frozen=True)
class InterfaceEdge:
    source_layer_id:str
    target_layer_id:str
    interface_type:str
    preserves_quantum_state:bool=False
    def __post_init__(self):
        if not self.source_layer_id.strip() or not self.target_layer_id.strip() or not self.interface_type.strip():
            raise ValueError("invalid interface edge")
        if self.source_layer_id==self.target_layer_id: raise ValueError("self edges are not allowed")

@dataclass
class HQICArchitecture:
    architecture_id:str
    layers:list[StorageLayer]=field(default_factory=list)
    edges:list[InterfaceEdge]=field(default_factory=list)
    def __post_init__(self):
        if not self.architecture_id.strip(): raise ValueError("architecture_id required")
    def add_layer(self,layer:StorageLayer):
        if any(x.layer_id==layer.layer_id for x in self.layers): raise ValueError("duplicate layer id")
        self.layers.append(layer); return layer
    def connect(self,edge:InterfaceEdge):
        ids={x.layer_id for x in self.layers}
        if edge.source_layer_id not in ids or edge.target_layer_id not in ids:
            raise ValueError("edge endpoints must exist")
        self.edges.append(edge); return edge
    def layers_by_kind(self,kind): return tuple(x for x in self.layers if x.kind==kind)
    def validate_minimum_hybrid_architecture(self):
        kinds={x.kind for x in self.layers}
        required={LayerKind.CLASSICAL_ARCHIVE,LayerKind.QUANTUM_ACTIVE,LayerKind.TRANSDUCER,LayerKind.CONTROL,LayerKind.METADATA}
        missing=required-kinds
        return (not missing,tuple(sorted(x.value for x in missing)))

def windows_control_path():
    return ("Windows/HELIX","driver_or_API","PCIe_USB_or_network","FPGA_or_controller",
            "laser_microwave_photonic_transducer","storage_or_quantum_medium")

def no_direct_quantum_pc_claim():
    return True
