from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
import math

class QuantumMemoryPlatform(str,Enum):
    RYDBERG="RYDBERG"
    ATOMIC_VAPOR="ATOMIC_VAPOR"
    RAMAN="RAMAN"
    RARE_EARTH="RARE_EARTH"
    DIAMOND_COLOR_CENTER="DIAMOND_COLOR_CENTER"
    BEC="BEC"

class EvidenceState(str,Enum):
    HARDWARE="HARDWARE"
    IMPORTED="IMPORTED"
    SIMULATION="SIMULATION"
    EXTRAPOLATED="EXTRAPOLATED"
    SPECULATIVE="SPECULATIVE"

@dataclass(frozen=True)
class MemoryLabRecord:
    platform:QuantumMemoryPlatform
    storage_time_s:float
    efficiency:float
    fidelity:float
    bandwidth_hz:float
    evidence:EvidenceState
    source_id:str=""
    notes:str=""
    def __post_init__(self):
        if self.storage_time_s<0 or self.bandwidth_hz<0: raise ValueError("times/bandwidth must be nonnegative")
        if not 0<=self.efficiency<=1 or not 0<=self.fidelity<=1: raise ValueError("efficiency/fidelity must be 0..1")
    @property
    def time_bandwidth_product(self): return self.storage_time_s*self.bandwidth_hz
    @property
    def end_to_end_quality(self): return self.efficiency*self.fidelity

@dataclass(frozen=True)
class MemoryRequirement:
    minimum_storage_time_s:float=0.0
    minimum_efficiency:float=0.0
    minimum_fidelity:float=0.0
    minimum_bandwidth_hz:float=0.0
    def __post_init__(self):
        if self.minimum_storage_time_s<0 or self.minimum_bandwidth_hz<0: raise ValueError("nonnegative requirements required")
        if not 0<=self.minimum_efficiency<=1 or not 0<=self.minimum_fidelity<=1: raise ValueError("fractional requirements must be 0..1")

@dataclass(frozen=True)
class RequirementAssessment:
    record:MemoryLabRecord
    requirement:MemoryRequirement
    passes:bool
    failed_constraints:tuple[str,...]

def assess_requirement(record,requirement):
    failed=[]
    if record.storage_time_s<requirement.minimum_storage_time_s: failed.append("storage_time")
    if record.efficiency<requirement.minimum_efficiency: failed.append("efficiency")
    if record.fidelity<requirement.minimum_fidelity: failed.append("fidelity")
    if record.bandwidth_hz<requirement.minimum_bandwidth_hz: failed.append("bandwidth")
    return RequirementAssessment(record,requirement,not failed,tuple(failed))

def compare_records(records,requirement=None):
    rows=[]
    for rec in records:
        assessment=assess_requirement(rec,requirement) if requirement else None
        rows.append({
            "platform":rec.platform.value,
            "storage_time_s":rec.storage_time_s,
            "efficiency":rec.efficiency,
            "fidelity":rec.fidelity,
            "bandwidth_hz":rec.bandwidth_hz,
            "time_bandwidth_product":rec.time_bandwidth_product,
            "end_to_end_quality":rec.end_to_end_quality,
            "evidence":rec.evidence.value,
            "passes":None if assessment is None else assessment.passes,
            "failed_constraints":() if assessment is None else assessment.failed_constraints,
        })
    return tuple(rows)

def pareto_front(records):
    recs=tuple(records)
    out=[]
    for i,a in enumerate(recs):
        dominated=False
        for j,b in enumerate(recs):
            if i==j: continue
            av=(a.storage_time_s,a.efficiency,a.fidelity,a.bandwidth_hz)
            bv=(b.storage_time_s,b.efficiency,b.fidelity,b.bandwidth_hz)
            if all(y>=x for x,y in zip(av,bv)) and any(y>x for x,y in zip(av,bv)):
                dominated=True;break
        if not dominated:out.append(a)
    return tuple(out)

@dataclass
class QuantumMemoryLab:
    records:list[MemoryLabRecord]=field(default_factory=list)
    def add(self,record): self.records.append(record); return record
    def by_platform(self,platform): return tuple(r for r in self.records if r.platform==platform)
    def by_evidence(self,evidence): return tuple(r for r in self.records if r.evidence==evidence)
    def assess_all(self,requirement): return tuple(assess_requirement(r,requirement) for r in self.records)
    def pareto(self): return pareto_front(self.records)
