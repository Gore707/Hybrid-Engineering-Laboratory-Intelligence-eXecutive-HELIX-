from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from .foundation import CalibrationState
from .safety import SafetyDecision,SafetySeverity

class GateSeverity(str,Enum):
    INFO="INFO"; WARNING="WARNING"; KILL="KILL"

class GateStatus(str,Enum):
    PASS="PASS"; WARN="WARN"; FAIL="FAIL"

@dataclass(frozen=True)
class ValidationGate:
    gate_id:str
    status:GateStatus
    severity:GateSeverity
    reason:str
    evidence:tuple[str,...]=()
    def __post_init__(self):
        if not self.gate_id or not self.reason:raise ValueError("gate identity required")

@dataclass(frozen=True)
class ValidationReport:
    experiment_id:str
    run_id:str
    gates:tuple[ValidationGate,...]
    @property
    def passed(self):return not any(g.status==GateStatus.FAIL and g.severity==GateSeverity.KILL for g in self.gates)
    @property
    def warnings(self):return tuple(g for g in self.gates if g.status==GateStatus.WARN)
    @property
    def failures(self):return tuple(g for g in self.gates if g.status==GateStatus.FAIL)

def calibration_gate(device_id,state):
    if state==CalibrationState.VALID or state==CalibrationState.NOT_REQUIRED:
        return ValidationGate(f"CAL:{device_id}",GateStatus.PASS,GateSeverity.KILL,"calibration acceptable",(state.value,))
    if state==CalibrationState.UNKNOWN:
        return ValidationGate(f"CAL:{device_id}",GateStatus.WARN,GateSeverity.WARNING,"calibration state unknown",(state.value,))
    return ValidationGate(f"CAL:{device_id}",GateStatus.FAIL,GateSeverity.KILL,"calibration expired or invalid",(state.value,))

def uncertainty_gate(label,expanded_uncertainty,value,max_relative_uncertainty=None):
    if expanded_uncertainty<0:raise ValueError("uncertainty nonnegative")
    if max_relative_uncertainty is None:
        return ValidationGate(f"UNC:{label}",GateStatus.PASS,GateSeverity.INFO,"uncertainty recorded", (f"U={expanded_uncertainty}",))
    if max_relative_uncertainty<0:raise ValueError("relative uncertainty limit nonnegative")
    if value==0:
        return ValidationGate(f"UNC:{label}",GateStatus.WARN,GateSeverity.WARNING,"relative uncertainty undefined at zero value",(f"U={expanded_uncertainty}",))
    rel=abs(expanded_uncertainty/value)
    if rel>max_relative_uncertainty:
        return ValidationGate(f"UNC:{label}",GateStatus.FAIL,GateSeverity.KILL,"relative expanded uncertainty exceeds declared limit",(f"relative_U={rel}",))
    return ValidationGate(f"UNC:{label}",GateStatus.PASS,GateSeverity.KILL,"relative expanded uncertainty within limit",(f"relative_U={rel}",))

def drift_gate(label,observed_abs_rate,max_abs_rate):
    if observed_abs_rate<0 or max_abs_rate<0:raise ValueError("rates nonnegative")
    if observed_abs_rate>max_abs_rate:
        return ValidationGate(f"DRIFT:{label}",GateStatus.FAIL,GateSeverity.KILL,"observed drift exceeds declared limit",(f"rate={observed_abs_rate}",f"limit={max_abs_rate}"))
    return ValidationGate(f"DRIFT:{label}",GateStatus.PASS,GateSeverity.KILL,"drift within declared limit",(f"rate={observed_abs_rate}",))

def acquisition_integrity_gate(label,dropped_sample_count,buffer_overwrites,allow_dropped=0,allow_overwrites=0):
    if min(dropped_sample_count,buffer_overwrites,allow_dropped,allow_overwrites)<0:raise ValueError("counts nonnegative")
    if dropped_sample_count>allow_dropped or buffer_overwrites>allow_overwrites:
        return ValidationGate(f"ACQ:{label}",GateStatus.FAIL,GateSeverity.KILL,"acquisition integrity limit exceeded",
                              (f"dropped={dropped_sample_count}",f"overwrites={buffer_overwrites}"))
    return ValidationGate(f"ACQ:{label}",GateStatus.PASS,GateSeverity.KILL,"acquisition integrity acceptable",
                          (f"dropped={dropped_sample_count}",f"overwrites={buffer_overwrites}"))

def synchronization_gate(group_id,observed_skew_s,max_skew_s):
    if observed_skew_s<0 or max_skew_s<0:raise ValueError("skew nonnegative")
    if observed_skew_s>max_skew_s:
        return ValidationGate(f"SYNC:{group_id}",GateStatus.FAIL,GateSeverity.KILL,"synchronization skew exceeds tolerance",
                              (f"skew={observed_skew_s}",f"limit={max_skew_s}"))
    return ValidationGate(f"SYNC:{group_id}",GateStatus.PASS,GateSeverity.KILL,"synchronization within tolerance",(f"skew={observed_skew_s}",))

def safety_event_gate(event):
    if event.decision in (SafetyDecision.ABORT,SafetyDecision.EMERGENCY_SHUTDOWN):
        return ValidationGate(f"SAFE:{event.device_id}:{event.quantity}",GateStatus.FAIL,GateSeverity.KILL,event.reason,
                              (event.severity.value,event.decision.value,event.authority.value))
    if event.decision==SafetyDecision.HOLD:
        return ValidationGate(f"SAFE:{event.device_id}:{event.quantity}",GateStatus.WARN,GateSeverity.WARNING,event.reason,
                              (event.severity.value,event.decision.value,event.authority.value))
    return ValidationGate(f"SAFE:{event.device_id}:{event.quantity}",GateStatus.PASS,GateSeverity.KILL,event.reason,
                          (event.severity.value,event.decision.value,event.authority.value))

def build_validation_report(experiment_id,run_id,gates):
    if not experiment_id or not run_id:raise ValueError("experiment/run required")
    return ValidationReport(experiment_id,run_id,tuple(gates))
