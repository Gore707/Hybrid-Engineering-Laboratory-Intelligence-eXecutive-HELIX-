import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-QMEM"
sp=importlib.util.spec_from_file_location("skl_qmem",M/"__init__.py",submodule_search_locations=[str(M)])
q=importlib.util.module_from_spec(sp);sys.modules["skl_qmem"]=q;sp.loader.exec_module(q)
class T(unittest.TestCase):
 def test_thermal_zero(self):self.assertEqual(q.thermal_boson_occupation(1e9,0),0)
 def test_thermal_positive(self):self.assertGreater(q.thermal_boson_occupation(1e9,300),0)
 def test_phase_variance(self):self.assertEqual(q.white_noise_phase_variance(2,3),6)
 def test_gaussian_coherence(self):self.assertAlmostEqual(q.gaussian_phase_coherence(2),math.exp(-1))
 def test_field_rate(self):self.assertEqual(q.field_noise_dephasing_rate_s_inv(2,3,4),144)
 def test_spectral_diffusion(self):self.assertAlmostEqual(q.spectral_diffusion_coherence(1,1,2),math.exp(-1))
 def test_combine_rates(self):self.assertEqual(q.combine_independent_rates_s_inv(1,2,3),6)
 def test_effective_t2(self):self.assertAlmostEqual(q.effective_coherence_time_s(1,1),.5)
 def test_zero_rate_infinite(self):self.assertTrue(math.isinf(q.effective_coherence_time_s(0,0)))
 def test_survival(self):self.assertAlmostEqual(q.combined_survival(1,1),math.exp(-1))
 def test_noise_source(self):self.assertEqual(q.NoiseSource("magnetic",2,"HARDWARE").provenance,"HARDWARE")
 def test_budget(self):
  b=q.DecoherenceBudget((q.NoiseSource("a",1),q.NoiseSource("b",3)));self.assertEqual(b.total_rate_s_inv,4);self.assertAlmostEqual(b.effective_t2_s,.25)
 def test_budget_fractions(self):
  f=q.DecoherenceBudget((q.NoiseSource("a",1),q.NoiseSource("b",3))).fractional_contributions();self.assertAlmostEqual(f["a"],.25)
 def test_platform(self):
  p=q.PlatformNoiseAssessment("NV",1,2,3,4,5);self.assertEqual(p.total_rate_s_inv,15);self.assertAlmostEqual(p.effective_time_s,1/15)
 def test_bec_preserved(self):self.assertEqual(q.ideal_condensate_fraction(0,1),1)
 def test_diamond_preserved(self):self.assertAlmostEqual(q.initialization_readout_success(.9,.8),.72)
 def test_registry(self):
  ids={x.model_id for x in q.QuantumMemoryRegistry().all()}
  self.assertTrue({"QMEM-NOISE-NTH","QMEM-NOISE-PHASE","QMEM-NOISE-FIELD","QMEM-NOISE-SD","QMEM-NOISE-BUDGET"}<=ids)
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-QMEM-10")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-STO"])
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
