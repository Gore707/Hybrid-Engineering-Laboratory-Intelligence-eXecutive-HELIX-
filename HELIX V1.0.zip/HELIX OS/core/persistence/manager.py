from __future__ import annotations
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .atomic import atomic_write_json, read_json
from .models import ExperimentRecord, ProjectRecord, SessionRecord, utc_now

class PersistenceError(RuntimeError):
    pass

class ProjectManager:
    PROJECT_MANIFEST = "project.helix.json"
    EXPERIMENT_MANIFEST = "experiment.helix.json"

    def __init__(self, projects_root: Path):
        self.projects_root = projects_root
        self.projects_root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _safe_dir_name(name: str) -> str:
        cleaned = "".join(c if c.isalnum() or c in " _-." else "_" for c in name).strip()
        return cleaned or "Untitled Project"

    def create_project(self, name: str, description: str = "") -> tuple[Path, ProjectRecord]:
        record = ProjectRecord.create(name, description)
        folder = self.projects_root / self._safe_dir_name(name)
        if folder.exists():
            suffix = record.project_id.split("-")[-1][:6]
            folder = self.projects_root / f"{self._safe_dir_name(name)}-{suffix}"
        (folder / "experiments").mkdir(parents=True, exist_ok=False)
        (folder / "data").mkdir()
        (folder / "exports").mkdir()
        atomic_write_json(folder / self.PROJECT_MANIFEST, {
            "schema_version": "1.0",
            "resource_type": "helix_project",
            **record.to_dict()
        })
        return folder, record

    def load_project(self, folder: Path) -> ProjectRecord:
        path = folder / self.PROJECT_MANIFEST
        if not path.exists():
            raise PersistenceError(f"HELIX project manifest not found: {path}")
        d = read_json(path)
        if d.get("resource_type") != "helix_project":
            raise PersistenceError("Not a HELIX project manifest.")
        return ProjectRecord(
            project_id=d["project_id"], name=d["name"],
            created_utc=d["created_utc"], modified_utc=d["modified_utc"],
            description=d.get("description", ""),
            experiments=d.get("experiments", []),
            metadata=d.get("metadata", {})
        )

    def save_project(self, folder: Path, project: ProjectRecord) -> None:
        project.modified_utc = utc_now()
        atomic_write_json(folder / self.PROJECT_MANIFEST, {
            "schema_version": "1.0",
            "resource_type": "helix_project",
            **project.to_dict()
        })

    def create_experiment(self, folder: Path, project: ProjectRecord,
                          name: str, mode: str = "SIMULATION") -> ExperimentRecord:
        exp = ExperimentRecord.create(name, mode)
        exp_dir = folder / "experiments" / exp.experiment_id
        exp_dir.mkdir(parents=True, exist_ok=False)
        atomic_write_json(exp_dir / self.EXPERIMENT_MANIFEST, {
            "schema_version": "1.0",
            "resource_type": "helix_experiment",
            **exp.to_dict()
        })
        project.experiments.append(exp.experiment_id)
        self.save_project(folder, project)
        return exp

class SessionManager:
    def __init__(self, user_root: Path, recovery_root: Path):
        self.user_root = user_root
        self.recovery_root = recovery_root
        self.user_root.mkdir(parents=True, exist_ok=True)
        self.recovery_root.mkdir(parents=True, exist_ok=True)
        self.session_path = self.user_root / "session.helix.json"

    def new_session(self) -> SessionRecord:
        session = SessionRecord.create()
        self.save(session)
        return session

    def save(self, session: SessionRecord) -> None:
        session.modified_utc = utc_now()
        atomic_write_json(self.session_path, {
            "schema_version": "1.0",
            "resource_type": "helix_session",
            **session.to_dict()
        })

    def load_or_create(self) -> SessionRecord:
        if not self.session_path.exists():
            return self.new_session()
        try:
            d = read_json(self.session_path)
            if d.get("resource_type") != "helix_session":
                raise ValueError("wrong resource type")
            return SessionRecord(
                session_id=d["session_id"],
                started_utc=d["started_utc"],
                modified_utc=d["modified_utc"],
                project_path=d.get("project_path"),
                active_experiment_id=d.get("active_experiment_id"),
                workspace_layout=d.get("workspace_layout"),
                dirty=bool(d.get("dirty", False))
            )
        except Exception:
            return self.new_session()

    def checkpoint(self, session: SessionRecord) -> Path:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        target = self.recovery_root / f"{session.session_id}-{stamp}.json"
        atomic_write_json(target, {
            "schema_version": "1.0",
            "resource_type": "helix_recovery_session",
            **session.to_dict()
        })
        return target
