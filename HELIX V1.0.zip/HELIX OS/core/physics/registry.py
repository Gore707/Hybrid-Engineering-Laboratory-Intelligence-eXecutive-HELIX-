from __future__ import annotations
import json
from pathlib import Path
from . import implementations as impl

class PhysicsRegistry:
    def __init__(self,constants_path:Path,equations_dir:Path,models_dir:Path):
        self.constants=json.loads(constants_path.read_text(encoding="utf-8"))["constants"]
        self.equations={}
        self.models={}
        self.functions={
          "shannon_capacity":impl.shannon_capacity,
          "free_space_path_loss":impl.free_space_path_loss,
          "photon_energy":impl.photon_energy,
          "coherence_decay":impl.coherence_decay
        }
        for p in equations_dir.glob("*.json"):
            d=json.loads(p.read_text(encoding="utf-8"));self.equations[d["resource_id"]]=d
        for p in models_dir.glob("*.json"):
            d=json.loads(p.read_text(encoding="utf-8"))
            if d["implementation"] not in self.functions: raise ValueError(f"Missing implementation: {d['implementation']}")
            for eid in d["equation_ids"]:
                if eid not in self.equations: raise ValueError(f"Missing equation: {eid}")
            self.models[d["resource_id"]]=d

    def constant(self,symbol): return self.constants[symbol]
    def equation(self,eid): return self.equations[eid]
    def model(self,mid): return self.models[mid]

    def evaluate(self,mid,**inputs):
        m=self.model(mid); expected=set(m["inputs"]); got=set(inputs)
        if expected!=got:
            raise ValueError(f"Inputs for {mid} must be exactly {sorted(expected)}; received {sorted(got)}")
        fn=self.functions[m["implementation"]]
        if m["implementation"]=="free_space_path_loss":
            return fn(inputs["d"],inputs["lambda"])
        if m["implementation"]=="photon_energy":
            return fn(inputs["lambda"],self.constants["h"]["value"],self.constants["c"]["value"])
        return fn(**inputs)

    def verify_links(self):
        for mid,m in self.models.items():
            for eid in m["equation_ids"]:
                if self.equations[eid].get("model_id")!=mid:
                    raise ValueError(f"Equation/model backlink mismatch: {eid} ↔ {mid}")
        return True
