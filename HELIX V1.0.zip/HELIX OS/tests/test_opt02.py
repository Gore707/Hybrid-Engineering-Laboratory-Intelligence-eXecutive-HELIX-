import unittest,importlib.util,sys,json,math
from pathlib import Path
R=Path(__file__).resolve().parents[1];M=R/"modules/SKL-OPT"
sp=importlib.util.spec_from_file_location("skl_opt",M/"__init__.py",submodule_search_locations=[str(M)])
o=importlib.util.module_from_spec(sp);sys.modules["skl_opt"]=o;sp.loader.exec_module(o)
class T(unittest.TestCase):
 def test_linewidth(self):self.assertEqual(o.optical_linewidth_from_q_hz(1e14,1e8),1e6)
 def test_coherence_time(self):self.assertAlmostEqual(o.coherence_time_s(1),1/math.pi)
 def test_coherence_length(self):self.assertAlmostEqual(o.coherence_length_m(1),o.C/math.pi)
 def test_rayleigh(self):self.assertAlmostEqual(o.rayleigh_range_m(1e-6,1),math.pi/1e-6)
 def test_m2_shortens_zr(self):self.assertLess(o.rayleigh_range_m(1e-6,1,2),o.rayleigh_range_m(1e-6,1,1))
 def test_radius_at_waist(self):self.assertEqual(o.gaussian_beam_radius_m(0,1e-6,1),1)
 def test_radius_grows(self):self.assertGreater(o.gaussian_beam_radius_m(1e9,1e-6,1),1)
 def test_divergence(self):self.assertAlmostEqual(o.gaussian_divergence_half_angle_rad(1e-6,1),1e-6/math.pi)
 def test_m2_divergence(self):self.assertGreater(o.gaussian_divergence_half_angle_rad(1e-6,1,2),o.gaussian_divergence_half_angle_rad(1e-6,1,1))
 def test_trunc_zero(self):self.assertEqual(o.gaussian_aperture_transmitted_fraction(0,1),0)
 def test_trunc_large(self):self.assertGreater(o.gaussian_aperture_transmitted_fraction(3,1),.999)
 def test_strehl_perfect(self):self.assertEqual(o.strehl_ratio_marechal(0,1e-6),1)
 def test_strehl_degrades(self):self.assertLess(o.strehl_ratio_marechal(1e-7,1e-6),1)
 def test_output(self):self.assertEqual(o.transmitter_optical_output_w(100,.5,.8),40)
 def test_heat(self):self.assertEqual(o.transmitter_waste_heat_w(100,.5),50)
 def test_coupling(self):self.assertEqual(o.telescope_coupled_power_w(100,.8,.5,.5),20)
 def test_transmitter(self):
  t=o.LaserTransmitter(1550e-9,100,.4,.8,.05,1.2,1e5,.1,.9,10e-9)
  self.assertGreater(t.delivered_telescope_power_w,0);self.assertGreater(t.rayleigh_range_m,0)
 def test_energy_accounting(self):
  t=o.LaserTransmitter(1e-6,100,.4,1,1);self.assertEqual(t.raw_laser_output_w+t.waste_heat_w,100)
 def test_train_loss_separate(self):
  t=o.LaserTransmitter(1e-6,100,.5,.8,1);self.assertEqual(t.optical_output_w,40);self.assertEqual(t.waste_heat_w,50)
 def test_invalid_m2(self):
  with self.assertRaises(ValueError):o.rayleigh_range_m(1e-6,1,.9)
 def test_foundation_preserved(self):self.assertAlmostEqual(o.frequency_hz(1),o.C)
 def test_registry(self):self.assertTrue({"OPT-RAYLEIGH","OPT-BEAM-RADIUS","OPT-TRUNCATION","OPT-STREHL","OPT-TX-EFF"}<={x.model_id for x in o.OpticalRegistry().all()})
 def test_manifest(self):self.assertEqual(json.loads((M/"module.json").read_text())["patch_id"],"SKL-OPT-02")
 def test_dependencies(self):self.assertEqual(json.loads((M/"module.json").read_text())["dependencies"],["SKL-MAT","SKL-PHO","SKL-RF"])
 def test_rf_complete(self):self.assertEqual(json.loads((R/"RF_COMPLETE.json").read_text())["status"],"COMPLETE")
 def test_core_manifest_root_only(self):self.assertTrue((R/"CORE_1_0_MANIFEST.json").exists());self.assertFalse(list((R/"modules").rglob("CORE_1_0_MANIFEST.json")))
 def test_no_root_skp(self):self.assertFalse(list(R.glob("*.skp")))
if __name__=="__main__":unittest.main()
